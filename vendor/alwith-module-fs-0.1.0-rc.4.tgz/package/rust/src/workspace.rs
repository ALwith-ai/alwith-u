//! Transport-neutral workspace operations. Hosts authorize roots before constructing this service.
use crate::FileSystem;
use cap_std::fs::OpenOptions;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use std::hash::{Hash, Hasher};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};

const MAX_BYTES: u64 = 16 * 1024 * 1024;
static NEXT_TEMP: AtomicU64 = AtomicU64::new(0);

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Request {
    pub root: PathBuf,
    pub operation: String,
    pub path: PathBuf,
    pub to: Option<PathBuf>,
    pub data: Option<Vec<u8>>,
    pub mode: Option<String>,
    pub expected_version: Option<String>,
    pub show_hidden: Option<bool>,
    pub show_ignored: Option<bool>,
}
#[derive(Serialize)]
struct Stat {
    kind: &'static str,
    size: u64,
    version: String,
}

fn read_bytes(fs: &FileSystem, path: &Path) -> Result<Vec<u8>, String> {
    let (root, relative) = fs.resolve(path)?;
    let file = root.directory.open(relative).map_err(|e| e.to_string())?;
    let mut bytes = Vec::new();
    file.take(MAX_BYTES + 1).read_to_end(&mut bytes).map_err(|e| e.to_string())?;
    if bytes.len() as u64 > MAX_BYTES {
        return Err("File exceeds the 16 MiB limit".into());
    }
    Ok(bytes)
}
fn stat(fs: &FileSystem, path: &Path) -> Result<Option<Stat>, String> {
    let (root, relative) = fs.resolve(path)?;
    let metadata = match root.directory.metadata(&relative) {
        Ok(value) => value,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(error.to_string()),
    };
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    metadata.len().hash(&mut hasher);
    metadata.modified().map_err(|e| e.to_string())?.hash(&mut hasher);
    Ok(Some(Stat {
        kind: if metadata.is_dir() { "directory" } else { "file" },
        size: metadata.len(),
        version: format!("{:x}", hasher.finish()),
    }))
}
fn destination(request: &Request) -> Result<PathBuf, String> {
    request.to.clone().ok_or_else(|| "Destination is required".into())
}
fn reject_symlink(fs: &FileSystem, path: &Path) -> Result<(), String> {
    let parent = path.parent().ok_or("Path has no parent")?;
    let name = path.file_name().ok_or("Path has no filename")?;
    let (root, relative) = fs.resolve(parent)?;
    match root.directory.symlink_metadata(relative.join(name)) {
        Ok(metadata) if metadata.file_type().is_symlink() => Err("Changing symbolic links is unsupported".into()),
        Ok(_) => Ok(()),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error.to_string()),
    }
}
fn require_child(fs: &FileSystem, path: &Path) -> Result<(), String> {
    reject_symlink(fs, path)?;
    let (root, relative) = fs.resolve(path)?;
    if relative == Path::new(".") || root.path == path {
        return Err("Workspace root cannot be changed".into());
    }
    Ok(())
}
fn require_absent(fs: &FileSystem, path: &Path) -> Result<(), String> {
    require_child(fs, path)?;
    if stat(fs, path)?.is_some() {
        return Err("Destination already exists; choose another name".into());
    }
    Ok(())
}
fn write_atomic(fs: &FileSystem, request: &Request) -> Result<(), String> {
    require_child(fs, &request.path)?;
    let bytes = request.data.as_ref().ok_or("File data is required")?;
    if bytes.len() as u64 > MAX_BYTES {
        return Err("File exceeds the 16 MiB limit".into());
    }
    let before = stat(fs, &request.path)?;
    let mode = request.mode.as_deref().ok_or("Write mode is required")?;
    match mode {
        "create" if before.is_some() => return Err("Destination already exists".into()),
        "replace" if before.is_none() => return Err("File was deleted".into()),
        "create" | "replace" | "upsert" => (),
        _ => return Err("Invalid write mode".into()),
    }
    if let Some(expected) = &request.expected_version {
        if before.as_ref().map(|s| &s.version) != Some(expected) {
            return Err("File changed on disk; reload before saving".into());
        }
    }
    let (root, relative) = fs.resolve(&request.path)?;
    let parent = relative.parent().ok_or("File has no parent")?;
    let temporary =
        parent.join(format!(".alwith-save-{}-{}", std::process::id(), NEXT_TEMP.fetch_add(1, Ordering::Relaxed)));
    let mut open = OpenOptions::new();
    open.write(true).create_new(true);
    let mut file = root.directory.open_with(&temporary, &open).map_err(|e| e.to_string())?;
    let result = (|| -> Result<(), String> {
        file.write_all(bytes).map_err(|e| e.to_string())?;
        if before.is_some() {
            file.set_permissions(root.directory.metadata(&relative).map_err(|e| e.to_string())?.permissions())
                .map_err(|e| e.to_string())?;
        }
        file.sync_all().map_err(|e| e.to_string())?;
        drop(file);
        // Recheck after writing the temporary file. Native hosts serialize their own requests.
        if stat(fs, &request.path)?.as_ref().map(|s| &s.version) != before.as_ref().map(|s| &s.version) {
            return Err("File changed while saving".into());
        }
        if mode == "create" {
            root.directory.hard_link(&temporary, &root.directory, &relative).map_err(|e| e.to_string())?;
            root.directory.remove_file(&temporary).map_err(|e| e.to_string())?;
        } else {
            root.directory.rename(&temporary, &root.directory, &relative).map_err(|e| e.to_string())?;
        }
        Ok(())
    })();
    if result.is_err() {
        root.directory.remove_file(&temporary).map_err(|e| format!("{result:?}; temporary cleanup failed: {e}"))?;
    }
    result
}
fn copy_tree(fs: &FileSystem, from: &Path, to: &Path) -> Result<(), String> {
    let (source, relative) = fs.resolve(from)?;
    let (destination, target) = fs.resolve(to)?;
    if source.directory.metadata(&relative).map_err(|e| e.to_string())?.is_dir() {
        destination.directory.create_dir(&target).map_err(|e| e.to_string())?;
        for entry in source.directory.read_dir(&relative).map_err(|e| e.to_string())? {
            let entry = entry.map_err(|e| e.to_string())?;
            if entry.file_type().map_err(|e| e.to_string())?.is_symlink() {
                return Err("Copying symbolic links is unsupported".into());
            }
            copy_tree(fs, &from.join(entry.file_name()), &to.join(entry.file_name()))?;
        }
    } else {
        source.directory.copy(&relative, &destination.directory, &target).map_err(|e| e.to_string())?;
    }
    Ok(())
}
/// Requests must be serialized by the host. JavaScript paths are not authorization.
pub async fn execute(fs: &FileSystem, request: Request) -> Result<Value, String> {
    match request.operation.as_str() {
        "stat" => serde_json::to_value(stat(fs, &request.path)?).map_err(|e| e.to_string()),
        "readFile" => Ok(json!(read_bytes(fs, &request.path)?)),
        "readDirectory" => {
            let entries = fs
                .read_dir_filtered(
                    request.path.clone(),
                    request.show_hidden.ok_or("showHidden is required")?,
                    request.show_ignored.ok_or("showIgnored is required")?,
                )
                .await?;
            Ok(json!(entries.into_iter().map(|entry| json!({ "path": request.path.join(&entry.name).to_string_lossy().replace('\\', "/"), "name": entry.name, "kind": if entry.is_dir { "directory" } else { "file" } })).collect::<Vec<_>>()))
        }
        "writeFile" => {
            write_atomic(fs, &request)?;
            Ok(Value::Null)
        }
        "createDirectory" => {
            require_absent(fs, &request.path)?;
            let (root, relative) = fs.resolve(&request.path)?;
            root.directory.create_dir(relative).map_err(|e| e.to_string())?;
            Ok(Value::Null)
        }
        "remove" => {
            require_child(fs, &request.path)?;
            fs.remove(request.path).await?;
            Ok(Value::Null)
        }
        "move" | "copy" => {
            let to = destination(&request)?;
            require_child(fs, &request.path)?;
            require_absent(fs, &to)?;
            let source = fs.authorize_path(&request.path)?;
            let target = fs.authorize_path(&to)?;
            if target.starts_with(&source) {
                return Err("Destination cannot be inside the source".into());
            }
            if request.operation == "move" {
                fs.rename(request.path, to).await?;
            } else {
                let parent = to.parent().ok_or("Destination has no parent")?;
                let temporary = parent.join(format!(
                    ".alwith-copy-{}-{}",
                    std::process::id(),
                    NEXT_TEMP.fetch_add(1, Ordering::Relaxed)
                ));
                require_absent(fs, &temporary)?;
                let copied = copy_tree(fs, &request.path, &temporary);
                if let Err(error) = copied {
                    if stat(fs, &temporary)?.is_some() {
                        fs.remove(temporary).await.map_err(|cleanup| format!("{error}; cleanup failed: {cleanup}"))?;
                    }
                    return Err(error);
                }
                if let Err(error) = require_absent(fs, &to) {
                    fs.remove(temporary).await.map_err(|cleanup| format!("{error}; cleanup failed: {cleanup}"))?;
                    return Err(error);
                }
                if let Err(error) = fs.rename(temporary.clone(), to).await {
                    fs.remove(temporary).await.map_err(|cleanup| format!("{error}; cleanup failed: {cleanup}"))?;
                    return Err(error);
                }
            }
            Ok(Value::Null)
        }
        _ => Err(format!("Unknown filesystem operation: {}", request.operation)),
    }
}

pub type WorkspaceWatcher = notify::RecommendedWatcher;
/// Watch only a capability-authorized root. The host owns this handle's lifetime.
pub fn watch(
    fs: FileSystem, root: PathBuf, listener: impl Fn(Result<Vec<PathBuf>, String>) + Send + 'static,
) -> Result<WorkspaceWatcher, String> {
    use notify::Watcher;
    let path = fs.authorize_watch_path(&root)?;
    let mut watcher = notify::recommended_watcher(move |event: Result<notify::Event, notify::Error>| match event {
        Ok(event) => {
            if matches!(event.kind, notify::EventKind::Access(_)) {
                return;
            }
            let paths = event.paths.into_iter().filter(|path| fs.authorize_path(path).is_ok()).collect::<Vec<_>>();
            if !paths.is_empty() {
                listener(Ok(paths));
            }
        }
        Err(error) => listener(Err(error.to_string())),
    })
    .map_err(|error| error.to_string())?;
    watcher.watch(&path, notify::RecursiveMode::Recursive).map_err(|error| error.to_string())?;
    Ok(watcher)
}

#[cfg(test)]
mod workspace_tests {
    use super::*;
    fn request(root: &Path, operation: &str, path: &Path) -> Request {
        Request {
            root: root.to_owned(),
            operation: operation.into(),
            path: path.to_owned(),
            to: None,
            data: None,
            mode: None,
            expected_version: None,
            show_hidden: Some(true),
            show_ignored: Some(true),
        }
    }
    #[tokio::test]
    async fn guards_roots_conflicts_and_binary_writes() {
        let root = tempfile::tempdir().unwrap();
        let fs = FileSystem::new([root.path().to_owned()]).unwrap();
        assert!(execute(&fs, request(root.path(), "remove", root.path())).await.is_err());
        let file = root.path().join("binary");
        let mut create = request(root.path(), "writeFile", &file);
        create.mode = Some("create".into());
        create.data = Some(vec![0, 255, 128]);
        execute(&fs, create).await.unwrap();
        assert_eq!(read_bytes(&fs, &file).unwrap(), vec![0, 255, 128]);
        let mut stale = request(root.path(), "writeFile", &file);
        stale.mode = Some("replace".into());
        stale.data = Some(vec![1]);
        stale.expected_version = Some("stale".into());
        assert!(execute(&fs, stale).await.unwrap_err().contains("changed"));
        assert_eq!(read_bytes(&fs, &file).unwrap(), vec![0, 255, 128]);
    }
    #[cfg(unix)]
    #[tokio::test]
    async fn removing_a_symlink_never_removes_its_target() {
        let root = tempfile::tempdir().unwrap();
        let real = root.path().join("real");
        std::fs::write(&real, "keep").unwrap();
        let link = root.path().join("link");
        std::os::unix::fs::symlink(&real, &link).unwrap();
        let fs = FileSystem::new([root.path().to_owned()]).unwrap();
        assert!(execute(&fs, request(root.path(), "remove", &link)).await.is_err());
        assert_eq!(std::fs::read_to_string(&real).unwrap(), "keep");
        assert!(link.symlink_metadata().unwrap().file_type().is_symlink());
    }
}

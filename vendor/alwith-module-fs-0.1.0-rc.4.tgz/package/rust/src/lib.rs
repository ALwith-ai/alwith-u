#[cfg(feature = "workspace")]
pub mod workspace;
use std::io::{Read, Write};
use std::path::{Component, Path, PathBuf};
use std::sync::Arc;
use std::time::SystemTime;

use base64::Engine;
use cap_std::ambient_authority;
use cap_std::fs::{Dir, OpenOptions};
use serde::Serialize;

#[derive(Clone)]
pub struct FileSystem {
    roots: Arc<Vec<Root>>,
}

struct Root {
    path: PathBuf,
    directory: Dir,
}

#[derive(Clone, Debug, Serialize)]
pub struct DirectoryEntry {
    pub name: String,
    pub is_dir: bool,
}

/// Entry for `fsListDirectories`: used by the web directory picker (lists only subdirectories + whether each is empty).
#[derive(Clone, Debug, Serialize)]
#[cfg_attr(feature = "specta", derive(specta::Type))]
#[serde(rename_all = "camelCase")]
pub struct FsDirectory {
    pub name: String,
    pub is_empty: bool,
}

/// Entry for `fsListEntries`: used for read-only file tree observation (files + directories, one level).
#[derive(Clone, Debug, Serialize)]
#[cfg_attr(feature = "specta", derive(specta::Type))]
#[serde(rename_all = "camelCase")]
pub struct FsEntry {
    pub name: String,
    pub is_dir: bool,
}

/// Capability roots resolution with one convention for both sides: prefers `ALWITH_HUB_FS_ROOTS` (the
/// startup environment in fab dev / alwith-web mode); when unset (standalone desktop launch) falls back to
/// the desktop default authorized roots. Default roots = the settings directory + the standard directories
/// that exist (`~/.alwith`, `~/Documents/ALwith`) -- "exists" is the definition of the authorized scope
/// (the directory picker's roots must be truly enterable), not error masking; the settings directory is
/// guaranteed by the app to always exist, so the list is never empty.
pub fn capability_roots(settings_directory: PathBuf) -> Vec<PathBuf> {
    if let Some(roots) = std::env::var_os("ALWITH_HUB_FS_ROOTS") {
        return std::env::split_paths(&roots).collect();
    }
    let mut roots = vec![settings_directory.clone()];
    let home = dirs::home_dir().expect("platform home directory");
    for candidate in [home.join(".alwith"), home.join("Documents/ALwith")] {
        if candidate.is_dir() {
            roots.push(candidate);
        }
    }
    roots.extend(registered_project_roots(&settings_directory));
    roots
}

/// Registered project roots -- **registration is authorization**.
///
/// When a user creates this project in ALwith, that authorizes ALwith to read and write it; splitting
/// "registration" and "authorization" into two lists inevitably makes them disagree: hit for real on
/// 2026-07-28 -- a project was created under `~/Projects/ALwith/` and was in the registry, but that is
/// not within the default authorized roots, so the desktop shell's cross-project overview drew not a single
/// row and reported no error at all (snapshot read fails as out of bounds -> no rows -> an empty list draws
/// not even the header, per project convention).
/// And the "cross-project overview" is a fixed Desktop boundary, not optional.
///
/// This does not loosen the boundary for **third-party extensions**: that boundary is about extensions and
/// the browser side; the authorized scope should be decided by the user's registrations, not by a few
/// hard-coded directories.
fn registered_project_roots(settings_directory: &Path) -> Vec<PathBuf> {
    let Ok(text) = std::fs::read_to_string(settings_directory.join("settings.json")) else {
        return Vec::new();
    };
    let Ok(settings) = serde_json::from_str::<serde_json::Value>(&text) else {
        return Vec::new();
    };
    settings
        .get("alwithDev.projectRoots")
        .and_then(|value| value.as_array())
        .map(|roots| {
            roots.iter().filter_map(|root| root.as_str()).map(PathBuf::from).filter(|root| root.is_dir()).collect()
        })
        .unwrap_or_default()
}

#[derive(Clone, Debug, Serialize)]
pub struct PathStat {
    pub is_dir: bool,
    pub is_file: bool,
    pub size: u64,
    pub modified_ms: u64,
}

impl FileSystem {
    pub fn new(paths: impl IntoIterator<Item = PathBuf>) -> Result<Self, String> {
        let roots = paths
            .into_iter()
            .map(|path| {
                let path = path.canonicalize().map_err(|error| format!("canonicalize {}: {error}", path.display()))?;
                let directory = Dir::open_ambient_dir(&path, ambient_authority())
                    .map_err(|error| format!("open filesystem root {}: {error}", path.display()))?;
                Ok(Root { path, directory })
            })
            .collect::<Result<Vec<_>, String>>()?;
        if roots.is_empty() {
            return Err("at least one filesystem root is required".to_string());
        }
        Ok(Self { roots: Arc::new(roots) })
    }

    pub async fn read_text(&self, path: PathBuf) -> Result<String, String> {
        let (root, relative) = self.resolve(&path)?;
        tokio::task::spawn_blocking(move || {
            let mut file = root.directory.open(&relative).map_err(|error| error.to_string())?;
            let mut content = String::new();
            file.read_to_string(&mut content).map_err(|error| error.to_string())?;
            Ok(content)
        })
        .await
        .map_err(|error| error.to_string())?
    }

    pub async fn read_base64(&self, path: PathBuf) -> Result<String, String> {
        let (root, relative) = self.resolve(&path)?;
        tokio::task::spawn_blocking(move || {
            let mut file = root.directory.open(&relative).map_err(|error| error.to_string())?;
            let mut content = Vec::new();
            file.read_to_end(&mut content).map_err(|error| error.to_string())?;
            Ok(base64::engine::general_purpose::STANDARD.encode(content))
        })
        .await
        .map_err(|error| error.to_string())?
    }

    pub async fn write_text(&self, path: PathBuf, content: String) -> Result<(), String> {
        let (root, relative) = self.resolve(&path)?;
        tokio::task::spawn_blocking(move || {
            create_parent_directories(&root.directory, &relative)?;
            let mut options = OpenOptions::new();
            options.write(true).create(true).truncate(true);
            let mut file = root.directory.open_with(&relative, &options).map_err(|error| error.to_string())?;
            file.write_all(content.as_bytes()).map_err(|error| error.to_string())
        })
        .await
        .map_err(|error| error.to_string())?
    }

    pub async fn write_base64(&self, path: PathBuf, content: String) -> Result<(), String> {
        let bytes = base64::engine::general_purpose::STANDARD.decode(content).map_err(|error| error.to_string())?;
        self.write_bytes(path, bytes).await
    }

    pub async fn append_text(&self, path: PathBuf, content: String) -> Result<(), String> {
        let (root, relative) = self.resolve(&path)?;
        tokio::task::spawn_blocking(move || {
            create_parent_directories(&root.directory, &relative)?;
            let mut options = OpenOptions::new();
            options.write(true).create(true).append(true);
            let mut file = root.directory.open_with(&relative, &options).map_err(|error| error.to_string())?;
            file.write_all(content.as_bytes()).map_err(|error| error.to_string())
        })
        .await
        .map_err(|error| error.to_string())?
    }

    pub async fn exists(&self, path: PathBuf) -> Result<bool, String> {
        let (root, relative) = self.resolve(&path)?;
        tokio::task::spawn_blocking(move || match root.directory.metadata(&relative) {
            Ok(_) => Ok(true),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(false),
            Err(error) => Err(error.to_string()),
        })
        .await
        .map_err(|error| error.to_string())?
    }

    pub async fn read_dir(&self, path: PathBuf) -> Result<Vec<DirectoryEntry>, String> {
        let (root, relative) = self.resolve(&path)?;
        tokio::task::spawn_blocking(move || {
            root.directory
                .read_dir(&relative)
                .map_err(|error| error.to_string())?
                .map(|entry| {
                    let entry = entry.map_err(|error| error.to_string())?;
                    let file_type = entry.file_type().map_err(|error| error.to_string())?;
                    Ok(DirectoryEntry {
                        name: entry.file_name().to_string_lossy().into_owned(),
                        is_dir: file_type.is_dir(),
                    })
                })
                .collect()
        })
        .await
        .map_err(|error| error.to_string())?
    }

    pub async fn read_dir_filtered(
        &self, path: PathBuf, show_hidden: bool, show_gitignored: bool,
    ) -> Result<Vec<DirectoryEntry>, String> {
        let absolute = self.authorize_watch_path(&path)?;
        tokio::task::spawn_blocking(move || {
            let walker = ignore::WalkBuilder::new(&absolute)
                .max_depth(Some(1))
                .hidden(!show_hidden)
                .git_ignore(!show_gitignored)
                .git_global(!show_gitignored)
                .git_exclude(!show_gitignored)
                .build();
            let mut entries = Vec::new();
            for result in walker {
                let entry = result.map_err(|error| error.to_string())?;
                if entry.path() == absolute || entry.file_name() == ".git" {
                    continue;
                }
                let file_type =
                    entry.file_type().ok_or_else(|| format!("missing file type: {}", entry.path().display()))?;
                entries.push(DirectoryEntry {
                    name: entry.file_name().to_string_lossy().into_owned(),
                    is_dir: file_type.is_dir(),
                });
            }
            Ok(entries)
        })
        .await
        .map_err(|error| error.to_string())?
    }

    pub async fn stat(&self, path: PathBuf) -> Result<PathStat, String> {
        let (root, relative) = self.resolve(&path)?;
        tokio::task::spawn_blocking(move || {
            let metadata =
                root.directory.metadata(&relative).map_err(|error| format!("stat {}: {error}", path.display()))?;
            let modified_ms = metadata
                .modified()
                .map_err(|error| error.to_string())?
                .duration_since(cap_std::time::SystemTime::from_std(SystemTime::UNIX_EPOCH))
                .map_err(|error| error.to_string())?
                .as_millis() as u64;
            Ok(PathStat { is_dir: metadata.is_dir(), is_file: metadata.is_file(), size: metadata.len(), modified_ms })
        })
        .await
        .map_err(|error| error.to_string())?
    }

    pub async fn create_dir(&self, path: PathBuf) -> Result<(), String> {
        let (root, relative) = self.resolve(&path)?;
        tokio::task::spawn_blocking(move || root.directory.create_dir_all(&relative).map_err(|error| error.to_string()))
            .await
            .map_err(|error| error.to_string())?
    }

    pub async fn remove(&self, path: PathBuf) -> Result<(), String> {
        let (root, relative) = self.resolve(&path)?;
        if relative.as_os_str().is_empty() {
            return Err("filesystem roots cannot be removed".to_string());
        }
        tokio::task::spawn_blocking(move || {
            let metadata = match root.directory.metadata(&relative) {
                Ok(metadata) => metadata,
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
                Err(error) => return Err(error.to_string()),
            };
            if metadata.is_dir() {
                root.directory.remove_dir_all(&relative).map_err(|error| error.to_string())
            } else {
                root.directory.remove_file(&relative).map_err(|error| error.to_string())
            }
        })
        .await
        .map_err(|error| error.to_string())?
    }

    pub async fn rename(&self, from: PathBuf, to: PathBuf) -> Result<(), String> {
        let (source_root, source_relative) = self.resolve(&from)?;
        let (destination_root, destination_relative) = self.resolve(&to)?;
        if source_relative.as_os_str().is_empty() || destination_relative.as_os_str().is_empty() {
            return Err("filesystem roots cannot be renamed".to_string());
        }
        if source_root.path != destination_root.path {
            return Err("renaming across filesystem roots is not supported".to_string());
        }
        tokio::task::spawn_blocking(move || {
            create_parent_directories(&destination_root.directory, &destination_relative)?;
            source_root
                .directory
                .rename(&source_relative, &destination_root.directory, &destination_relative)
                .map_err(|error| error.to_string())
        })
        .await
        .map_err(|error| error.to_string())?
    }

    /// Move between independently granted roots without widening either capability.
    pub async fn move_between_roots(&self, from: PathBuf, to: PathBuf) -> Result<(), String> {
        let (source_root, source_relative) = self.resolve(&from)?;
        let (destination_root, destination_relative) = self.resolve(&to)?;
        if source_relative == Path::new(".") || destination_relative == Path::new(".") {
            return Err("Filesystem roots cannot be moved".into());
        }
        if destination_root.path.join(&destination_relative).starts_with(source_root.path.join(&source_relative)) {
            return Err("Move destination cannot be inside the source".into());
        }
        tokio::task::spawn_blocking(move || {
            match destination_root.directory.symlink_metadata(&destination_relative) {
                Ok(_) => return Err("Move destination already exists".into()),
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {},
                Err(error) => return Err(error.to_string()),
            }
            source_root.directory.rename(&source_relative, &destination_root.directory, &destination_relative)
                .map_err(|error| error.to_string())
        }).await.map_err(|error| error.to_string())?
    }

    pub async fn copy(&self, from: PathBuf, to: PathBuf) -> Result<(), String> {
        let (source_root, source_relative) = self.resolve(&from)?;
        let (destination_root, destination_relative) = self.resolve(&to)?;
        if source_root.path != destination_root.path {
            return Err("copying across filesystem roots is not supported".to_string());
        }
        tokio::task::spawn_blocking(move || {
            create_parent_directories(&destination_root.directory, &destination_relative)?;
            source_root
                .directory
                .copy(&source_relative, &destination_root.directory, &destination_relative)
                .map(|_| ())
                .map_err(|error| error.to_string())
        })
        .await
        .map_err(|error| error.to_string())?
    }

    async fn write_bytes(&self, path: PathBuf, content: Vec<u8>) -> Result<(), String> {
        let (root, relative) = self.resolve(&path)?;
        tokio::task::spawn_blocking(move || {
            create_parent_directories(&root.directory, &relative)?;
            let mut options = OpenOptions::new();
            options.write(true).create(true).truncate(true);
            let mut file = root.directory.open_with(&relative, &options).map_err(|error| error.to_string())?;
            file.write_all(&content).map_err(|error| error.to_string())
        })
        .await
        .map_err(|error| error.to_string())?
    }

    /// Authorized capability roots (canonical absolute paths, in construction order).
    pub fn roots(&self) -> Vec<PathBuf> {
        self.roots.iter().map(|root| root.path.clone()).collect()
    }

    /// Lists the subdirectories under path (name + whether empty), sorted by name; used by the web directory picker.
    /// path must be within the capability roots; out-of-bounds paths return an error.
    pub async fn list_directories(&self, path: PathBuf) -> Result<Vec<FsDirectory>, String> {
        let (root, relative) = self.resolve(&path)?;
        tokio::task::spawn_blocking(move || {
            let directory = root.directory.open_dir(&relative).map_err(|error| error.to_string())?;
            let mut directories = Vec::new();
            for entry in directory.entries().map_err(|error| error.to_string())? {
                let entry = entry.map_err(|error| error.to_string())?;
                if !entry.file_type().map_err(|error| error.to_string())?.is_dir() {
                    continue;
                }
                let name = entry.file_name().to_string_lossy().into_owned();
                let is_empty = directory.read_dir(&name).map_err(|error| error.to_string())?.next().is_none();
                directories.push(FsDirectory { name, is_empty });
            }
            directories.sort_by(|left, right| left.name.cmp(&right.name));
            Ok(directories)
        })
        .await
        .map_err(|error| error.to_string())?
    }

    /// Lists the files and directories one level under path (directories first, each sorted by name); used for read-only file tree observation.
    /// path must be within the capability roots; out-of-bounds paths return an error.
    pub async fn list_entries(&self, path: PathBuf) -> Result<Vec<FsEntry>, String> {
        let (root, relative) = self.resolve(&path)?;
        tokio::task::spawn_blocking(move || {
            let directory = root.directory.open_dir(&relative).map_err(|error| error.to_string())?;
            let mut entries = directory
                .entries()
                .map_err(|error| error.to_string())?
                .map(|entry| {
                    let entry = entry.map_err(|error| error.to_string())?;
                    let file_type = entry.file_type().map_err(|error| error.to_string())?;
                    Ok(FsEntry { name: entry.file_name().to_string_lossy().into_owned(), is_dir: file_type.is_dir() })
                })
                .collect::<Result<Vec<_>, String>>()?;
            entries.sort_by(|left, right| match (left.is_dir, right.is_dir) {
                (true, false) => std::cmp::Ordering::Less,
                (false, true) => std::cmp::Ordering::Greater,
                _ => left.name.cmp(&right.name),
            });
            Ok(entries)
        })
        .await
        .map_err(|error| error.to_string())?
    }

    pub fn authorize_watch_path(&self, path: &Path) -> Result<PathBuf, String> {
        let (root, relative) = self.resolve(path)?;
        let absolute = root.path.join(relative);
        absolute.canonicalize().map_err(|error| error.to_string())
    }

    /// Deterministic project creation must also pass the same capability boundary; when the target does not exist yet, the valid trailing path is kept.
    pub fn authorize_path(&self, path: &Path) -> Result<PathBuf, String> {
        let (root, relative) = self.resolve(path)?;
        Ok(root.path.join(relative))
    }

    fn resolve(&self, path: &Path) -> Result<(Arc<Root>, PathBuf), String> {
        let normalized = canonicalize_with_missing_tail(&normalize_absolute(path)?)?;
        let root = self
            .roots
            .iter()
            .filter(|root| normalized.starts_with(&root.path))
            .max_by_key(|root| root.path.components().count())
            .ok_or_else(|| format!("filesystem access denied: {}", path.display()))?;
        let relative = normalized.strip_prefix(&root.path).expect("matching filesystem root");
        // When the path is exactly **equal to** a capability root, the relative path is empty, and cap-std
        // reports "No such file or directory" for every empty path -- project disk scanning (reading which
        // project directories are under a root) is exactly this usage, so the overview never found any
        // projects. stat / list_directories / list_entries each special-cased it separately
        // (`is_empty()` -> `dir_metadata()` / `try_clone()`), and read_dir was missed when it did not keep up.
        // Normalize to "." once so no method has to write it again.
        let relative = if relative.as_os_str().is_empty() { PathBuf::from(".") } else { relative.to_path_buf() };
        Ok((Arc::new(root.clone()), relative))
    }
}

fn canonicalize_with_missing_tail(path: &Path) -> Result<PathBuf, String> {
    let mut existing = path;
    let mut missing = Vec::new();
    while !existing.exists() {
        let name = existing
            .file_name()
            .ok_or_else(|| format!("filesystem path has no existing ancestor: {}", path.display()))?;
        missing.push(name.to_os_string());
        existing =
            existing.parent().ok_or_else(|| format!("filesystem path has no existing ancestor: {}", path.display()))?;
    }
    let mut canonical = existing.canonicalize().map_err(|error| error.to_string())?;
    for name in missing.into_iter().rev() {
        canonical.push(name);
    }
    Ok(canonical)
}

impl Clone for Root {
    fn clone(&self) -> Self {
        Self { path: self.path.clone(), directory: self.directory.try_clone().expect("clone capability directory") }
    }
}

fn normalize_absolute(path: &Path) -> Result<PathBuf, String> {
    if !path.is_absolute() {
        return Err(format!("filesystem path must be absolute: {}", path.display()));
    }
    let mut normalized = PathBuf::new();
    for component in path.components() {
        match component {
            Component::Prefix(prefix) => normalized.push(prefix.as_os_str()),
            Component::RootDir => normalized.push(Path::new(std::path::MAIN_SEPARATOR_STR)),
            Component::CurDir => {}
            Component::ParentDir => {
                if !normalized.pop() {
                    return Err(format!("invalid filesystem path: {}", path.display()));
                }
            }
            Component::Normal(name) => normalized.push(name),
        }
    }
    Ok(normalized)
}

fn create_parent_directories(root: &Dir, path: &Path) -> Result<(), String> {
    if let Some(parent) = path.parent() {
        root.create_dir_all(parent).map_err(|error| error.to_string())?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use std::fs;

    use tempfile::tempdir;

    use super::FileSystem;

    #[tokio::test]
    async fn limits_access_to_authorized_roots() {
        let root = tempdir().expect("root");
        let outside = tempdir().expect("outside");
        fs::write(root.path().join("inside.txt"), "inside").expect("write inside");
        fs::write(outside.path().join("outside.txt"), "outside").expect("write outside");
        let file_system = FileSystem::new([root.path().to_path_buf()]).expect("filesystem");

        assert!(file_system.stat(root.path().to_path_buf()).await.expect("stat root").is_dir);
        assert_eq!(file_system.read_text(root.path().join("inside.txt")).await.expect("read inside"), "inside");
        assert!(file_system.read_text(outside.path().join("outside.txt")).await.unwrap_err().contains("access denied"));
        assert!(file_system.authorize_path(&root.path().join("new/application")).is_ok());
        assert!(file_system.authorize_path(&outside.path().join("new/application")).is_err());
    }

    #[tokio::test]
    async fn moves_between_explicit_roots_without_overwriting() {
        let source = tempdir().unwrap();
        let target = tempdir().unwrap();
        fs::write(source.path().join("file.txt"), "source").unwrap();
        let filesystem = FileSystem::new([source.path().to_path_buf(), target.path().to_path_buf()]).unwrap();
        assert!(filesystem.rename(source.path().join("file.txt"), target.path().join("file.txt")).await.is_err());
        filesystem.move_between_roots(source.path().join("file.txt"), target.path().join("file.txt")).await.unwrap();
        assert!(!source.path().join("file.txt").exists());
        assert_eq!(fs::read_to_string(target.path().join("file.txt")).unwrap(), "source");
        fs::write(source.path().join("file.txt"), "second").unwrap();
        assert!(filesystem.move_between_roots(source.path().join("file.txt"), target.path().join("file.txt")).await.is_err());
        assert_eq!(fs::read_to_string(target.path().join("file.txt")).unwrap(), "source");
        assert_eq!(fs::read_to_string(source.path().join("file.txt")).unwrap(), "second");
        assert!(filesystem.move_between_roots(source.path().to_path_buf(), target.path().join("root")).await.is_err());
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn cross_root_moves_reject_symlink_escapes() {
        let source = tempdir().unwrap();
        let target = tempdir().unwrap();
        let outside = tempdir().unwrap();
        fs::write(source.path().join("file.txt"), "source").unwrap();
        std::os::unix::fs::symlink(outside.path(), target.path().join("escape")).unwrap();
        let filesystem = FileSystem::new([source.path().to_path_buf(), target.path().to_path_buf()]).unwrap();
        assert!(filesystem.move_between_roots(source.path().join("file.txt"), target.path().join("escape/file.txt")).await.is_err());
        assert!(!outside.path().join("file.txt").exists());
        assert!(source.path().join("file.txt").exists());
    }

    #[tokio::test]
    async fn preserves_binary_append_and_copy_semantics() {
        let root = tempdir().expect("root");
        let file_system = FileSystem::new([root.path().to_path_buf()]).expect("filesystem");
        let binary_path = root.path().join("nested/binary.dat");
        let copied_path = root.path().join("copied.dat");

        file_system.write_base64(binary_path.clone(), "AP+A".to_string()).await.expect("write binary");
        assert_eq!(file_system.read_base64(binary_path.clone()).await.expect("read binary"), "AP+A");
        file_system.copy(binary_path, copied_path.clone()).await.expect("copy binary");
        assert_eq!(file_system.read_base64(copied_path).await.expect("read copy"), "AP+A");

        let text_path = root.path().join("append.txt");
        file_system.write_text(text_path.clone(), "first".to_string()).await.expect("write text");
        file_system.append_text(text_path.clone(), " second".to_string()).await.expect("append text");
        assert_eq!(file_system.read_text(text_path).await.expect("read appended text"), "first second");
    }

    #[tokio::test]
    async fn lists_directories_with_emptiness_inside_roots_only() {
        let root = tempdir().expect("root");
        let outside = tempdir().expect("outside");
        fs::create_dir_all(root.path().join("filled/child")).expect("create filled directory");
        fs::create_dir(root.path().join("empty")).expect("create empty directory");
        fs::write(root.path().join("file.txt"), "file").expect("write file");
        let file_system = FileSystem::new([root.path().to_path_buf()]).expect("filesystem");

        let directories = file_system.list_directories(root.path().to_path_buf()).await.expect("list directories");
        let listed: Vec<(&str, bool)> =
            directories.iter().map(|directory| (directory.name.as_str(), directory.is_empty)).collect();
        assert_eq!(listed, vec![("empty", true), ("filled", false)]);

        let denied = file_system.list_directories(outside.path().to_path_buf()).await.unwrap_err();
        assert!(denied.contains("access denied"));
    }

    #[tokio::test]
    async fn lists_entries_directories_first_inside_roots_only() {
        let root = tempdir().expect("root");
        let outside = tempdir().expect("outside");
        fs::create_dir(root.path().join("directory")).expect("create directory");
        fs::write(root.path().join("aaa.txt"), "file").expect("write file");
        let file_system = FileSystem::new([root.path().to_path_buf()]).expect("filesystem");

        let entries = file_system.list_entries(root.path().to_path_buf()).await.expect("list entries");
        let listed: Vec<(&str, bool)> = entries.iter().map(|entry| (entry.name.as_str(), entry.is_dir)).collect();
        assert_eq!(listed, vec![("directory", true), ("aaa.txt", false)]);

        let denied = file_system.list_entries(outside.path().to_path_buf()).await.unwrap_err();
        assert!(denied.contains("access denied"));
    }

    #[tokio::test]
    async fn exposes_canonicalized_capability_roots() {
        let root = tempdir().expect("root");
        let file_system = FileSystem::new([root.path().to_path_buf()]).expect("filesystem");
        assert_eq!(file_system.roots(), vec![root.path().canonicalize().expect("canonical root")]);
    }

    /// Regression: when the path is exactly **equal to** a capability root, the relative path is empty and
    /// cap-std reports "No such file or directory" for every one.
    /// Project disk scanning (reading which project directories are under a root) is exactly this usage --
    /// so the overview never found any projects, and finished projects vanished from the UI along with their deliverables.
    #[tokio::test]
    async fn the_capability_root_itself_can_be_listed() {
        let root = tempdir().expect("root");
        fs::create_dir_all(root.path().join("alwith-coffee/.alwith/runs")).expect("建项目目录");
        fs::write(root.path().join("alwith-coffee/.alwith/runs/canvas.json"), "{}").expect("写画布");
        let file_system = FileSystem::new([root.path().to_path_buf()]).expect("filesystem");

        let entries = file_system.read_dir(root.path().to_path_buf()).await.expect("读 root 自身");
        assert!(entries.iter().any(|entry| entry.name == "alwith-coffee" && entry.is_dir), "{entries:?}");

        // The other entry points for the same path must not disagree either
        assert!(file_system.stat(root.path().to_path_buf()).await.is_ok(), "stat root 自身");
        assert!(file_system.list_directories(root.path().to_path_buf()).await.is_ok(), "列 root 自身的子目录");
        assert!(file_system.list_entries(root.path().to_path_buf()).await.is_ok(), "列 root 自身的条目");
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn symlinks_cannot_escape_the_authorized_root() {
        use std::os::unix::fs::symlink;

        let root = tempdir().expect("root");
        let outside = tempdir().expect("outside");
        fs::write(outside.path().join("secret.txt"), "secret").expect("write secret");
        symlink(outside.path(), root.path().join("escape")).expect("create symlink");
        let file_system = FileSystem::new([root.path().to_path_buf()]).expect("filesystem");

        assert!(file_system.read_text(root.path().join("escape/secret.txt")).await.is_err());
        assert!(file_system.authorize_path(&root.path().join("escape/new/application")).is_err());
    }
}

# Third-party notices — @alwith/module-collection

This package contains ALwith's collection model and no bundled third-party code.
It has no runtime dependencies. The accompanying ALwith Developer and
Redistribution License applies to this package's own material.

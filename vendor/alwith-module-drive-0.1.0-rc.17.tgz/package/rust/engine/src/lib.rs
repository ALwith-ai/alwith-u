//! YUP Drive 同步引擎(桌面端,契约见 docs/drive-sync-api-contract.md)。
//!
//! 分层:
//! - `types`:契约 DTO(roots / snapshot / changes / batch / devices)与 UI 快照类型
//! - `client`:HTTP 客户端,401 + `DEVICE_REVOKED` 单独成错
//! - `index`:SQLite 本地索引(files / roots / meta)
//! - `cleanup`:「清理未选中的本地副本」——已落盘但不在同步选择集里的项目目录挪进暂存目录
//! - `ignore`:`.yupignore` + 契约默认排除 + 200 MB 阈值
//! - `naming`:冲突副本命名、`.yupcloud` 占位、Windows 非法字符映射
//! - `scanner`:遍历 + 按 (mtime, size) 增量 sha256
//! - `watcher`:notify 去抖
//! - `engine`:状态机与上下行
//! - `sso`:授权码 + PKCE 登录(6.1)
//! - `push`:`/ws/sync` 变更推送(6.2)
//! - `archive`:会话归档,上行专用根(`~/.alwith/projects/**/*.jsonl` → `ai-session-archive`)
//! - `knowledge`:知识回流到会话的关键词提取与文本拼装(方案 4.5)

pub mod archive;
pub mod cleanup;
pub mod client;
pub mod delete_guard;
pub mod engine;
pub mod ignore;
pub mod index;
pub mod knowledge;
pub mod naming;
pub mod push;
pub mod scanner;
pub mod skills;
pub mod sso;
pub mod types;
pub mod watcher;

pub use archive::{ArchiveConfig, ArchiveOutcome};
pub use cleanup::STAGING_DIR_NAME;
pub use client::{ClientError, CloudFolder, DriveClient};
pub use engine::{
    DEFAULT_TRANSFER_CONCURRENCY, Engine, EngineConfig, EngineError, EngineEvent, LEGACY_PERSONAL_ROOT_LIMIT,
};
pub use push::{PushConfig, PushEvent, run_push};
pub use sso::SsoError;
pub use types::*;

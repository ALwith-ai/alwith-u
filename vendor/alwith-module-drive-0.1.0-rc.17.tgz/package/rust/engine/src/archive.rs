//! 会话归档:`~/.alwith/projects/**/*.jsonl` → `POST /sessions/archive`(V61)。
//!
//! **对话归它发生的那个项目**:会话 jsonl 里记着 `cwd`,cwd 落在某个 Drive 项目目录下就带上
//! 那个 `projectId`,对不上就**不带**(服务端落到调用者自己的个人知识库)—— 不猜,猜错等于
//! 把一段私人对话塞进别人的项目。落点、目录、`content_kind=SESSION` 标记与强制 cloudOnly
//! 全部由服务端决定,客户端不再自己拼云端路径。
//!
//! 为什么从「一个公司级归档库」改成按项目:对话是项目记录的一部分,半年后问「当时为什么这么
//! 定」,答案常在对话里;而集中成一个大库之后它的量比真正的资料大一到两个数量级,把云盘的
//! 最近更新和搜索全淹了(2026-09-04 实测:最近更新 12 条里 10 条是对话 jsonl)。
//! 老的 `ai-session-archive` 已停写(往它推一律 403),历史数据原样留着,不迁移。
//!
//! 过滤与命名规则沿用 yup-kb 插件 v1.8 的 sessions-sync:
//! - 只归档 `user` / `assistant` 的文本(剥掉 thinking / tool_use / tool_result),按过滤后内容 sha256 去重;
//! - 同目录存在 `<uuid>.private` 则排除;单文件 > 25 MB 跳过;
//! - 文件名 `<YYYYMMDD-HHmm>_<uuid8>_<标题>.jsonl` —— **只给人看**,身份是 `sessionId`;
//! - 每 5 分钟一轮(定时在桌面侧);首次需要用户在设置页勾选同意(桌面侧按设置决定是否调用)。
//!
//! 不下行、不删本地。

use std::path::{Path, PathBuf};
use std::time::Duration;

use serde_json::Value;

use crate::engine::{Engine, EngineError};
use crate::index::ArchiveRow;
use crate::scanner::{file_mtime_ms, sha256_bytes};
use crate::types::{ArchiveStatus, RemoteId};

/// 老的公司级归档库。**已停写**,只用于两件事:把它排除在「对话该归哪个项目」的匹配之外,
/// 以及在占位文件里说清「这个项目整个只在云端」(见 engine.rs)。
pub const ARCHIVE_PROJECT_KEY: &str = "ai-session-archive";
/// 插件同款:每 5 分钟扫一轮。
pub const ARCHIVE_INTERVAL: Duration = Duration::from_secs(5 * 60);
/// 插件同款:超过 25 MB 的会话不归档。
pub const MAX_SESSION_BYTES: u64 = 25 * 1024 * 1024;
const TITLE_MAX_CHARS: usize = 30;

const META_LAST_RUN_AT: &str = "archive.last_run_at";
const META_LAST_UPLOAD_AT: &str = "archive.last_upload_at";
const META_LAST_UPLOADED: &str = "archive.last_uploaded";
const META_LAST_ERROR: &str = "archive.last_error";

/// 设置页显示的上行方式。只剩这一条路(V61 的 `/sessions/archive`)——
/// 从前还有 batch / upload 两种回落,那是为了往停写的公司级归档库里塞东西
pub const MODE_SESSIONS: &str = "sessions";

#[derive(Debug, Clone)]
pub struct ArchiveConfig {
    /// `~/.alwith/projects`
    pub sessions_dir: PathBuf,
}

impl ArchiveConfig {
    pub fn standard(home: &Path) -> Self {
        Self { sessions_dir: home.join(".alwith").join("projects") }
    }
}

#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct ArchiveOutcome {
    pub scanned: usize,
    pub uploaded: usize,
    pub skipped_private: usize,
    pub failed: usize,
}

/// 过滤后的会话:只剩 user / assistant 文本。
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FilteredSession {
    pub jsonl: String,
    pub kept: usize,
    pub first_ts: Option<String>,
}

/// 剥掉 thinking / tool_use / tool_result,只留用户输入与助手文本回复(插件 `_filterJsonlForArchive` 同款)。
pub fn filter_jsonl_for_archive(content: &str) -> FilteredSession {
    let mut out: Vec<String> = Vec::new();
    let mut kept = 0;
    let mut first_ts: Option<String> = None;
    for raw in content.split('\n') {
        if raw.is_empty() {
            continue;
        }
        let Ok(mut event) = serde_json::from_str::<Value>(raw) else { continue };
        if let Some(timestamp) = event.get("timestamp").and_then(Value::as_str)
            && first_ts.as_deref().is_none_or(|first| timestamp < first)
        {
            first_ts = Some(timestamp.to_string());
        }
        let kind = event.get("type").and_then(Value::as_str).map(str::to_string);
        let Some(message) = event.get_mut("message").and_then(Value::as_object_mut) else { continue };
        match kind.as_deref() {
            Some("user") => match message.get("content") {
                Some(Value::String(_)) => {}
                Some(Value::Array(blocks)) => {
                    let filtered: Vec<Value> = blocks
                        .iter()
                        .filter(|block| block.get("type").and_then(Value::as_str) != Some("tool_result"))
                        .cloned()
                        .collect();
                    if filtered.is_empty() {
                        continue;
                    }
                    message.insert("content".into(), Value::Array(filtered));
                }
                _ => continue,
            },
            Some("assistant") => match message.get("content") {
                Some(Value::Array(blocks)) => {
                    let text_blocks: Vec<Value> = blocks
                        .iter()
                        .filter(|block| block.get("type").and_then(Value::as_str) == Some("text"))
                        .cloned()
                        .collect();
                    if text_blocks.is_empty() {
                        continue;
                    }
                    message.insert("content".into(), Value::Array(text_blocks));
                }
                _ => continue,
            },
            _ => continue,
        }
        out.push(event.to_string());
        kept += 1;
    }
    FilteredSession { jsonl: out.join("\n"), kept, first_ts }
}

/// 第一条用户消息 → 文件名安全的标题(插件 `_extractSessionTitle` 同款:截 30 字、去非法字符、空白换下划线)。
pub fn session_title_slug(filtered_jsonl: &str) -> String {
    for raw in filtered_jsonl.split('\n') {
        if raw.is_empty() {
            continue;
        }
        let Ok(event) = serde_json::from_str::<Value>(raw) else { continue };
        if event.get("type").and_then(Value::as_str) != Some("user") {
            continue;
        }
        let text = match event.get("message").and_then(|message| message.get("content")) {
            // **落盘的常态是这一支**:cli 把所有 prompt 块拼成一整个字符串发出去
            //(promptConversion 的 text-only 路径),注入在前、用户原话在后 —— 按行剥掉开头
            // 那几行注入。2026-09-11 实查用户 jsonl 才发现下面那条只修了数组分支,
            // 而真实数据从来不走数组:老板 9-07 截图的那个毛病其实一直还在。
            Some(Value::String(text)) => strip_injected_prefix(text).to_string(),
            // 用户**真正说的那句**是这条消息里**最后一个** text 块:桌面端每轮把上下文
            // (「用户当前在项目内的 … 目录下工作」这类注入)排在前面、用户原话排在最后
            // (prompt-blocks.ts:「context 块在前,提问在后」)。从前取第一个,于是所有人的
            // 归档文件名开头都是同一句系统话,几十条排一起完全分不出(2026-09-07 老板截图)。
            // 再按前缀挡一道:某条消息只有注入、没有原话(纯发图)时,最后一个 text 块仍是注入。
            Some(Value::Array(blocks)) => blocks
                .iter()
                .filter(|block| block.get("type").and_then(Value::as_str) == Some("text"))
                .filter_map(|block| block.get("text").and_then(Value::as_str))
                .filter(|text| !is_injected_context(text))
                .next_back()
                .unwrap_or_default()
                .to_string(),
            _ => String::new(),
        };
        let text = text.trim();
        if text.is_empty() {
            continue;
        }
        let truncated: String = text.chars().take(TITLE_MAX_CHARS).collect();
        let cleaned: String = truncated
            .chars()
            .filter(|c| !matches!(c, '\\' | '/' | ':' | '*' | '?' | '"' | '<' | '>' | '|' | '\r' | '\n'))
            .collect();
        let mut slug = String::new();
        let mut in_space = false;
        for c in cleaned.chars() {
            if c.is_whitespace() {
                if !in_space {
                    slug.push('_');
                    in_space = true;
                }
            } else {
                slug.push(c);
                in_space = false;
            }
        }
        return slug.trim_end_matches('_').to_string();
    }
    String::new()
}

/// `"2026-05-26T08:28:32.641Z"` → `"20260526-0828"`(UTC 原样截取,不做时区换算,与插件一致)。
pub fn ts_prefix(iso: &str) -> Option<String> {
    let bytes = iso.as_bytes();
    if bytes.len() < 16 || bytes[4] != b'-' || bytes[7] != b'-' || bytes[10] != b'T' || bytes[13] != b':' {
        return None;
    }
    let digits = [&iso[0..4], &iso[5..7], &iso[8..10], &iso[11..13], &iso[14..16]];
    if !digits.iter().all(|part| part.bytes().all(|b| b.is_ascii_digit())) {
        return None;
    }
    Some(format!("{}{}{}-{}{}", digits[0], digits[1], digits[2], digits[3], digits[4]))
}

/// `<YYYYMMDD-HHmm>_<uuid8>_<标题>.jsonl`
pub fn upload_name(uuid: &str, ts_prefix: Option<&str>, slug: &str) -> String {
    let short: String = uuid.chars().take(8).collect();
    let mut name = String::new();
    if let Some(prefix) = ts_prefix {
        name.push_str(prefix);
        name.push('_');
    }
    name.push_str(&short);
    if !slug.is_empty() {
        name.push('_');
        name.push_str(slug);
    }
    name.push_str(".jsonl");
    name
}

/// 这段对话是在哪个目录里发生的 —— 会话 jsonl 的事件带 `cwd`。取**第一条**给了 cwd 的:
/// 一段对话的工作目录不会中途换。整份都没有(只有信封类事件的老文件)就回 None,
/// 那时归档落个人空间,不猜。
pub fn session_cwd(raw: &str) -> Option<String> {
    for line in raw.split('\n') {
        if line.is_empty() {
            continue;
        }
        let Ok(event) = serde_json::from_str::<Value>(line) else { continue };
        if let Some(cwd) = event.get("cwd").and_then(Value::as_str)
            && !cwd.is_empty()
        {
            return Some(cwd.to_string());
        }
    }
    None
}

/// 契约 §6.12 的 `folderPath` 上限:超过就是非法,一律不传。
const FOLDER_PATH_MAX_DEPTH: usize = 16;
const FOLDER_PATH_MAX_SEGMENT_CHARS: usize = 128;

/// 这段对话**开始时**用户在会话 cwd 下的哪个子目录 —— 桌面端算好写进 jsonl 的 ALwith 信封
///(`selected-directory-context.ts` 的 `sessionWorkingDirectory`,相对**会话 cwd**)。
///
/// 取**第一条**带 `folderPath` 的信封:落点按「对话开始时那个目录」算,不是结束时
///(跨目录的对话按开始算,2026-09-07 老板定的取舍;服务端那边也是第一次归档时定死落点、
/// 续写不搬家,两边对齐)。桌面端每轮重写的都是同一个值,取第一条与取最后一条等价 ——
/// 取第一条只是把「按开始算」写死在读端,将来写端真漂了也不会跟着漂。
///
/// 没有信封(老会话 / 一轮都还没聊完)就回 None,归档落项目根,与从前一致。
pub fn session_folder_path(raw: &str) -> Option<String> {
    for line in raw.split('\n') {
        if line.is_empty() {
            continue;
        }
        let Ok(event) = serde_json::from_str::<Value>(line) else { continue };
        if event.get("type").and_then(Value::as_str) != Some("ALwith") {
            continue;
        }
        if let Some(folder) = event.get("folderPath").and_then(Value::as_str)
            && !folder.is_empty()
        {
            return Some(folder.to_string());
        }
    }
    None
}

/// 把一段相对路径洗成契约认的 `folderPath`;**任何一条不合规就整个不要**(回 None → 不传该
/// 字段 → 落项目根)。
///
/// 为什么是「不传」而不是「传上去让服务端拒」:服务端对四种非法情况一律 400
/// `BAD_SESSION_FOLDER_PATH`,那会让**整段对话归档失败**,而它本来只是少一个可选字段的事。
/// 落项目根是从前的行为,用户看得懂;整段对话传不上去不是。
///
/// 逐条对齐 §6.12 的表:含 `..` 段 / 绝对路径 / 超过 16 层 / 任一段超过 128 字符。
/// `.` 与空段属于没意义的噪音,直接丢掉(`a//b` → `a/b`)。
pub fn sanitize_session_folder_path(raw: &str) -> Option<String> {
    let normalized = raw.replace('\\', "/");
    // 绝对路径:`/x`、`\\x`(上面已归一)、`C:/x`
    if normalized.starts_with('/') || normalized.chars().nth(1) == Some(':') {
        return None;
    }
    let mut segments: Vec<&str> = Vec::new();
    for part in normalized.split('/') {
        if part.is_empty() || part == "." {
            continue;
        }
        if part == ".." || part.chars().count() > FOLDER_PATH_MAX_SEGMENT_CHARS {
            return None;
        }
        segments.push(part);
    }
    if segments.is_empty() || segments.len() > FOLDER_PATH_MAX_DEPTH {
        return None;
    }
    Some(segments.join("/"))
}

/// 这段 text 是不是桌面端注入给 AI 的上下文,而不是用户说的话。
///
/// 判据是**包在小写 XML 标签里** —— 这是 alwith-cli 给「系统注入的上下文」定的约定
///(`utils/displayTags.ts`:会话标题会剥掉所有这样的块),桌面端注入的每一句都照它包。
/// 按标签认而不是按措辞认,措辞怎么改这边都不用跟着动。
///
/// 前缀表只留给**存量**:2026-09-11 之前落盘的会话里那句没有标签,历史归档还得认得出来。
const INJECTED_CONTEXT_PREFIXES: &[&str] = &["用户当前在项目内的", "Resource link:", "Embedded resource:"];

/// 一条 user 消息拼成一整个字符串时,剥掉开头那几行注入,剩下的才是他说的话。
/// 与 `alwith-session` 的 `title.rs::strip_injected_prefix` 是同一条口径(两个 crate 不互相依赖)。
fn strip_injected_prefix(text: &str) -> &str {
    let mut rest = text.trim_start();
    loop {
        let Some(line) = rest.lines().next() else { return rest };
        if !is_injected_context(line) {
            return rest;
        }
        // 跨行的注入块(今天没有产生它的地方,但别在这儿装作不可能):跳到闭合标签之后
        let consumed = unclosed_tag_end(rest, line).unwrap_or(line.len());
        rest = rest[consumed..].trim_start();
    }
}

/// 这一行开了个小写标签却没在本行闭合 → 返回「闭合标签末尾」在 `rest` 里的下标。
fn unclosed_tag_end(rest: &str, line: &str) -> Option<usize> {
    let name: String =
        line.strip_prefix('<')?.chars().take_while(|c| c.is_ascii_alphanumeric() || *c == '-' || *c == '_').collect();
    let close = format!("</{name}>");
    if name.is_empty() || line.contains(&close) {
        return None;
    }
    rest.find(&close).map(|at| at + close.len())
}

fn is_injected_context(text: &str) -> bool {
    let text = text.trim_start();
    starts_with_lowercase_tag(text) || INJECTED_CONTEXT_PREFIXES.iter().any(|prefix| text.starts_with(prefix))
}

/// `<workspace-directory>…` 这种。只认小写开头 —— 用户自己写的 `<Button>` / `<!DOCTYPE`
/// 不该被当成注入(与 alwith-cli 的 XML_TAG_BLOCK_PATTERN 同一条口径)。
fn starts_with_lowercase_tag(text: &str) -> bool {
    let Some(rest) = text.strip_prefix('<') else { return false };
    if !rest.starts_with(|c: char| c.is_ascii_lowercase()) {
        return false;
    }
    let name_len = rest.find(|c: char| !(c.is_ascii_alphanumeric() || c == '-' || c == '_')).unwrap_or(0);
    matches!(rest.as_bytes().get(name_len), Some(b'>') | Some(b' '))
}

/// 同目录存在 `<uuid>.private` 即排除。
pub fn is_private(session: &Path) -> bool {
    session.with_extension("private").is_file()
}

/// 递归找 `*.jsonl`(不读内容;读不到的目录跳过)。
pub fn walk_sessions(dir: &Path) -> Vec<PathBuf> {
    if !dir.is_dir() {
        return Vec::new();
    }
    walkdir::WalkDir::new(dir)
        .follow_links(false)
        .sort_by_file_name()
        .into_iter()
        .filter_map(Result::ok)
        .filter(|entry| entry.file_type().is_file() && entry.path().extension().is_some_and(|ext| ext == "jsonl"))
        .map(|entry| entry.into_path())
        .collect()
}

fn now_iso() -> String {
    chrono::Local::now().to_rfc3339_opts(chrono::SecondsFormat::Secs, true)
}

impl Engine {
    /// 设置页看的状态(`enabled` / `syncing` 由桌面侧填)。
    pub fn archive_status(&self) -> ArchiveStatus {
        let meta = |key: &str| self.index.meta_get(key).ok().flatten();
        ArchiveStatus {
            enabled: false,
            syncing: false,
            last_run_at: meta(META_LAST_RUN_AT),
            last_upload_at: meta(META_LAST_UPLOAD_AT),
            synced: self.index.archive_count().unwrap_or(0),
            last_uploaded: meta(META_LAST_UPLOADED).and_then(|value| value.parse().ok()).unwrap_or(0),
            last_error: meta(META_LAST_ERROR),
            mode: Some(MODE_SESSIONS.to_string()),
        }
    }

    /// 扫一轮并上传变了的会话。任何一条上传失败只记错误不中断;吊销即返回 `Revoked`。
    pub async fn archive_sessions(&self, config: &ArchiveConfig) -> Result<ArchiveOutcome, EngineError> {
        let _guard = self.archive_lock.lock().await;
        if self.is_revoked() {
            return Err(EngineError::Revoked);
        }
        let result = self.archive_sessions_inner(config).await;
        self.index.meta_set(META_LAST_RUN_AT, &now_iso()).map_err(EngineError::Index)?;
        match &result {
            Ok(outcome) => {
                self.index.meta_set(META_LAST_UPLOADED, &outcome.uploaded.to_string()).map_err(EngineError::Index)?;
                if outcome.uploaded > 0 {
                    self.index.meta_set(META_LAST_UPLOAD_AT, &now_iso()).map_err(EngineError::Index)?;
                }
                if outcome.failed == 0 {
                    self.index.meta_set(META_LAST_ERROR, "").map_err(EngineError::Index)?;
                }
            }
            Err(error) => {
                self.index.meta_set(META_LAST_ERROR, &error.to_string()).map_err(EngineError::Index)?;
            }
        }
        result
    }

    async fn archive_sessions_inner(&self, config: &ArchiveConfig) -> Result<ArchiveOutcome, EngineError> {
        let mut outcome = ArchiveOutcome::default();
        let sessions = walk_sessions(&config.sessions_dir);
        if sessions.is_empty() {
            return Ok(outcome);
        }
        // 落点要靠根清单认(cwd → 哪个项目)。归档循环与同步循环各跑各的,冷启动时这一轮
        // 可能排在第一次 `sync_once` 前面 —— 那时索引里一个根都没有,所有对话都会落个人空间,
        // 而服务端按 sessionId 认身份,**落错了之后再也搬不回来**。所以空的时候先拉一次。
        if self.index.list_roots().map_err(EngineError::Index)?.is_empty() {
            self.refresh_roots().await?;
        }
        for session in sessions {
            outcome.scanned += 1;
            if is_private(&session) {
                outcome.skipped_private += 1;
                continue;
            }
            let Some(uuid) = session.file_stem().map(|stem| stem.to_string_lossy().to_string()) else { continue };
            let Ok(metadata) = std::fs::metadata(&session) else { continue };
            if metadata.len() > MAX_SESSION_BYTES {
                continue;
            }
            let mtime_ms = file_mtime_ms(&metadata);
            let size = metadata.len();
            let existing = self.index.archive_get(&uuid).map_err(EngineError::Index)?;
            if let Some(row) = &existing
                && row.mtime_ms == mtime_ms
                && row.size == size
            {
                continue;
            }
            let Ok(raw) = std::fs::read_to_string(&session) else { continue };
            let filtered = filter_jsonl_for_archive(&raw);
            if filtered.kept == 0 {
                continue;
            }
            let sha256 = sha256_bytes(filtered.jsonl.as_bytes());
            if let Some(row) = &existing
                && row.sha256 == sha256
            {
                // 内容没变(只是 tool 调用之类的噪音变了):记下新的 (mtime, size) 走快路径
                self.index.archive_upsert(&ArchiveRow { mtime_ms, size, ..row.clone() }).map_err(EngineError::Index)?;
                continue;
            }
            let prefix = filtered.first_ts.as_deref().and_then(ts_prefix).or_else(|| {
                metadata.modified().ok().map(|modified| {
                    let time: chrono::DateTime<chrono::Utc> = modified.into();
                    time.format("%Y%m%d-%H%M").to_string()
                })
            });
            let name = upload_name(&uuid, prefix.as_deref(), &session_title_slug(&filtered.jsonl));
            // 对话归它发生的那个项目;对不上就不带 projectId,由服务端落到个人知识库
            let matched = session_cwd(&raw).map(PathBuf::from).and_then(|cwd| {
                self.archive_project_for_cwd(&cwd)
                    .map(|(project_id, dir)| (project_id, folder_path_in_project(&dir, &cwd, &raw)))
            });
            let (project_id, folder_path) = match matched {
                Some((project_id, folder_path)) => (Some(project_id), folder_path),
                // 落个人知识库时不带 folderPath:那个 folderPath 是相对**项目根**算的,
                // 个人空间根本不是那个根,拼过去只会在个人空间里建出一串莫名其妙的目录
                None => (None, None),
            };
            match self
                .guard_revoked(
                    self.client
                        .archive_session(
                            &uuid,
                            &sha256,
                            project_id.as_ref(),
                            folder_path.as_deref(),
                            &name,
                            filtered.jsonl.into_bytes(),
                        )
                        .await,
                )
                .await
            {
                Ok(archived) => {
                    log::debug!(
                        "[drive-sync] 会话 {uuid} 归档到 {}{}",
                        archived.path,
                        if archived.personal { "(个人空间)" } else { "" }
                    );
                    self.index
                        .archive_upsert(&ArchiveRow {
                            uuid,
                            sha256,
                            remote_file_id: Some(archived.file_id),
                            remote_version_id: archived.version_id,
                            mtime_ms,
                            size,
                            cloud_path: archived.path,
                        })
                        .map_err(EngineError::Index)?;
                    outcome.uploaded += 1;
                }
                Err(EngineError::Revoked) => return Err(EngineError::Revoked),
                Err(error) => {
                    outcome.failed += 1;
                    self.index.meta_set(META_LAST_ERROR, &format!("{uuid}: {error}")).map_err(EngineError::Index)?;
                    log::warn!("[drive-sync] 会话 {uuid} 归档失败: {error}");
                }
            }
        }
        Ok(outcome)
    }

    /// 对话发生的目录 → 它属于哪个 Drive 项目。
    ///
    /// **匹配不上就回 None**,由服务端落到调用者的个人知识库 —— 不猜一个项目:猜错等于把一段
    /// 私人对话塞进别人的项目里,而那是同项目成员都读得到的。取**最长前缀**:Drive 项目目录
    /// 可能互相嵌套(`部门/运营部/【运营】策略` 在 `部门/运营部` 下面),该归最里面那一个。
    ///
    /// 只认写得进去的项目:没有写权限的项目服务端会回 403,那还不如落个人空间。
    /// 老的归档库整个排除 —— 往它推一律 403 `SESSION_ARCHIVE_READ_ONLY`。
    fn archive_project_for_cwd(&self, cwd: &Path) -> Option<(RemoteId, PathBuf)> {
        let mut best: Option<(usize, RemoteId, PathBuf)> = None;
        for root in self.index.list_roots().ok()? {
            if root.project_key == ARCHIVE_PROJECT_KEY || !root.can_write || root.cloud_only || !root.sync_enabled {
                continue;
            }
            let dir = self.root_local_dir(&root);
            if !cwd.starts_with(&dir) {
                continue;
            }
            let depth = dir.components().count();
            if best.as_ref().is_none_or(|(deepest, _, _)| depth > *deepest) {
                best = Some((depth, root.project_id, dir));
            }
        }
        best.map(|(_, project_id, dir)| (project_id, dir))
    }
}

/// 这段对话该落项目里的哪个子目录 —— 契约要的 `folderPath` 是**相对项目根**的,而桌面端
/// 写进信封的那一截是**相对会话 cwd** 的。两截拼起来才是答案:
///
/// ```text
/// 项目根  ~/YUP Drive/部门/运营部/【运营】策略
/// 会话cwd ~/YUP Drive/部门/运营部/【运营】策略/子项目     → 前一截「子项目」
/// 信封    深处                                           → 后一截
/// folderPath = 子项目/深处
/// ```
///
/// 少拼前一截的话,用户「把子目录当项目打开」时对话就整整落浅一层 —— 而那正是 2026-09-07
/// 那条 bug 的同款错法(两个口径混着用)。
///
/// 任何一步不合规就回 None:不传该字段、落项目根。宁可落根也不要猜(传一个非法值上去,
/// 服务端 400,整段对话归档失败)。
fn folder_path_in_project(project_dir: &Path, cwd: &Path, raw_jsonl: &str) -> Option<String> {
    let mut parts: Vec<String> = Vec::new();
    // 会话 cwd 相对项目根那一截。cwd == 项目根时为空,正常
    if let Ok(relative) = cwd.strip_prefix(project_dir) {
        parts.extend(relative.components().map(|part| part.as_os_str().to_string_lossy().to_string()));
    }
    if let Some(folder) = session_folder_path(raw_jsonl) {
        parts.push(folder);
    }
    if parts.is_empty() {
        return None;
    }
    sanitize_session_folder_path(&parts.join("/"))
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = concat!(
        r#"{"type":"summary","summary":"x"}"#,
        "\n",
        r#"{"type":"user","timestamp":"2026-05-26T08:28:32.641Z","message":{"role":"user","content":"帮我 看看: 交易限额/提前还款 文案"}}"#,
        "\n",
        r#"{"type":"assistant","timestamp":"2026-05-26T08:28:40.000Z","message":{"role":"assistant","content":[{"type":"thinking","thinking":"secret"},{"type":"text","text":"好的"},{"type":"tool_use","name":"Bash"}]}}"#,
        "\n",
        r#"{"type":"user","timestamp":"2026-05-26T08:28:41.000Z","message":{"role":"user","content":[{"type":"tool_result","content":"out"}]}}"#,
        "\n",
        r#"{"type":"assistant","timestamp":"2026-05-26T08:28:42.000Z","message":{"role":"assistant","content":[{"type":"tool_use","name":"Read"}]}}"#,
        "\n",
        "not json\n"
    );

    #[test]
    fn 过滤只留用户输入与助手文本() {
        let filtered = filter_jsonl_for_archive(SAMPLE);
        assert_eq!(filtered.kept, 2);
        assert_eq!(filtered.first_ts.as_deref(), Some("2026-05-26T08:28:32.641Z"));
        assert!(!filtered.jsonl.contains("thinking"));
        assert!(!filtered.jsonl.contains("tool_use"));
        assert!(!filtered.jsonl.contains("tool_result"));
        assert!(filtered.jsonl.contains("\"text\":\"好的\""));
        assert_eq!(filtered.jsonl.lines().count(), 2);
        // 同样的输入两次过滤内容一致 → sha 稳定
        assert_eq!(
            sha256_bytes(filtered.jsonl.as_bytes()),
            sha256_bytes(filter_jsonl_for_archive(SAMPLE).jsonl.as_bytes())
        );
    }

    #[test]
    fn 标题_时间前缀_文件名() {
        let filtered = filter_jsonl_for_archive(SAMPLE);
        assert_eq!(session_title_slug(&filtered.jsonl), "帮我_看看_交易限额提前还款_文案");
        assert_eq!(ts_prefix("2026-05-26T08:28:32.641Z").as_deref(), Some("20260526-0828"));
        assert_eq!(ts_prefix("garbage"), None);
        assert_eq!(
            upload_name("0123456789abcdef", Some("20260526-0828"), "帮我_看看"),
            "20260526-0828_01234567_帮我_看看.jsonl"
        );
        assert_eq!(upload_name("abc", None, ""), "abc.jsonl");
    }

    /// 老板截图里的归档文件叫 `20260907-0751_2877b578_用户当前在项目内的_`test`_目录下工作;新建文件默认…`。
    /// 「用户当前在项目内的 `test` 目录下工作」是桌面端**每轮注入给 AI 的上下文**
    /// (selected-directory-context.ts 的 selectedDirectoryHint),不是用户说的话。
    /// 取名抓的是第一条 user 消息里的**第一个** text 块,而注入的上下文按设计排在用户原话
    /// **前面**(prompt-blocks.ts:「context 块在前,提问在后」)—— 于是抓到了系统的那句。
    /// 不修的话以后所有人的归档文件名开头都是同一句话,几十条排一起完全分不出。
    #[test]
    fn 取名跳过系统注入的上下文_只取用户真正说的第一句() {
        let jsonl = concat!(
            r#"{"type":"user","timestamp":"2026-09-07T07:51:00.000Z","message":{"role":"user","content":["#,
            r#"{"type":"text","text":"用户当前在项目内的 `test` 目录下工作;新建文件默认放在这里,除非用户另有指定。"},"#,
            r#"{"type":"text","text":"建一个 test md"}"#,
            r#"]}}"#
        );
        assert_eq!(session_title_slug(&filter_jsonl_for_archive(jsonl).jsonl), "建一个_test_md");
    }

    /// 落盘的常态:一条 user 消息是**一整个字符串**。2026-09-11 实查用户 jsonl 才发现
    /// 之前只修了数组分支,而真实数据从来不走数组 —— 老板 9-07 截图的毛病其实一直还在。
    #[test]
    fn 取名跳过拼成一串的注入前缀() {
        let jsonl = concat!(
            r#"{"type":"user","timestamp":"2026-09-11T07:51:00.000Z","message":{"role":"user","content":"#,
            r#""Resource link: name=YAP Paylater.md, uri=file:///a.md\n"#,
            r#"<workspace-directory>用户当前在项目内的 `AI舆情分析` 目录下工作。</workspace-directory>\n"#,
            r#"这篇讲了什么"}}"#
        );
        assert_eq!(session_title_slug(&filter_jsonl_for_archive(jsonl).jsonl), "这篇讲了什么");
    }

    /// 2026-09-11 起注入的那句包在 `<workspace-directory>` 里(会话标题那边也靠标签剥),
    /// 按标签认就不用跟着措辞走;上面那条存量用例照样得过。
    #[test]
    fn 取名跳过包在小写标签里的注入() {
        let jsonl = concat!(
            r#"{"type":"user","timestamp":"2026-09-11T07:51:00.000Z","message":{"role":"user","content":["#,
            r#"{"type":"text","text":"<workspace-directory>用户当前在项目内的 `AI舆情分析` 目录下工作;新建文件默认放在这里。</workspace-directory>"},"#,
            r#"{"type":"text","text":"这篇讲了什么"}"#,
            r#"]}}"#
        );
        assert_eq!(session_title_slug(&filter_jsonl_for_archive(jsonl).jsonl), "这篇讲了什么");
    }

    /// 用户自己写的大写标签 / `<!DOCTYPE` 不是注入,不许被吞掉。
    #[test]
    fn 用户写的大写标签不算注入() {
        let jsonl = concat!(
            r#"{"type":"user","timestamp":"2026-09-11T07:51:00.000Z","message":{"role":"user","content":["#,
            r#"{"type":"text","text":"<Button> 这个组件怎么改"}"#,
            r#"]}}"#
        );
        assert_eq!(session_title_slug(&filter_jsonl_for_archive(jsonl).jsonl), "Button_这个组件怎么改");
    }

    /// 只有注入、没有用户原话(纯发图片之类)的那一条不该被当成标题,往下找真正说了话的那条。
    #[test]
    fn 只有系统注入没有用户原话的消息不当标题() {
        let jsonl = concat!(
            r#"{"type":"user","timestamp":"2026-09-07T07:51:00.000Z","message":{"role":"user","content":["#,
            r#"{"type":"text","text":"用户当前在项目内的 `test` 目录下工作;新建文件默认放在这里,除非用户另有指定。"}"#,
            r#"]}}"#,
            "\n",
            r#"{"type":"user","timestamp":"2026-09-07T07:52:00.000Z","message":{"role":"user","content":"帮我看看这张图"}}"#
        );
        assert_eq!(session_title_slug(&filter_jsonl_for_archive(jsonl).jsonl), "帮我看看这张图");
    }

    #[test]
    fn 私有标记与遍历() {
        let dir = tempfile::tempdir().unwrap();
        let project = dir.path().join("-Users-me-proj");
        std::fs::create_dir_all(&project).unwrap();
        std::fs::write(project.join("a.jsonl"), b"{}").unwrap();
        std::fs::write(project.join("b.jsonl"), b"{}").unwrap();
        std::fs::write(project.join("b.private"), b"").unwrap();
        std::fs::write(project.join("notes.txt"), b"").unwrap();
        let sessions = walk_sessions(dir.path());
        assert_eq!(sessions.len(), 2);
        assert!(!is_private(&project.join("a.jsonl")));
        assert!(is_private(&project.join("b.jsonl")));
        assert!(walk_sessions(&dir.path().join("missing")).is_empty());
    }
}

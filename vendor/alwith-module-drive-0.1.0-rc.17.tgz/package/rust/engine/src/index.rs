//! SQLite 本地索引:`files`(path 是云端原名)/ `roots` / `meta`。
//!
//! 单连接 + Mutex;每次写只动真正变的行。

use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::sync::Mutex;

use rusqlite::{Connection, OptionalExtension, params};

use crate::types::{FileState, ProjectKind, ProjectScope, RemoteId, SyncDirection};

/// v2:files 加 `collab_active`(6.7 协同中停止上行);v3:加 `archive_sessions`(会话归档,上行专用根);
/// v4:roots 加 `owner_id` / `is_mine`(「我的空间」按归属分组,不按 scope);
/// v5:roots 加 `department_id`(部门按 id 比对,不按显示名)、files 加 `read_only`(需走修改申请的文件不上行);
/// v6:加 `file_errors`(上行失败的原因 / 次数 / 退避 —— 失败以前只有一个 `state=error`,
/// 说不出为什么、试了几次,UI 也就无从提起);
/// v7:`file_errors` 加 `direction`(下行失败也要进这张表 —— 从前它只落在内存 ring 里,
/// 重启就没,于是「下载卡死」在界面上一片安静);
/// v8:加 `folders`(**目录本身也是内容**)—— 从前 MKDIR 是从文件操作反推的,空文件夹
/// 推不出任何 op、永远不上行;
/// v9:roots 加 `node` / `container` / `node_path`(服务端 7662157 的新目录结构,
/// 面板按 `node_path` 分组)。
const SCHEMA_VERSION: i64 = 9;

/// 「已经做过那一次全量对账了」。见 `open` 里的说明 —— 一次性的数据修补不该动 schema 版本,
/// 那会把所有还没升级的客户端挡在门外(它们共用同一份索引文件)。
const META_RECONCILE_ONCE: &str = "reconcile_once.2026_09_15";

#[derive(Debug, Clone, PartialEq)]
pub struct FileRow {
    pub project_id: RemoteId,
    /// 云端相对路径(原名)
    pub path: String,
    pub remote_file_id: Option<RemoteId>,
    pub remote_version_id: Option<RemoteId>,
    pub sha256: Option<String>,
    pub size: u64,
    pub mtime_ms: i64,
    pub state: FileState,
    /// 服务端 collabActive:Yjs 文档是真相,本地改动不上行
    pub collab_active: bool,
    /// 服务端 readOnly:内容正常落到本地,但本地改动不上行(要改走网页上的修改申请)
    pub read_only: bool,
}

#[derive(Debug, Clone, PartialEq)]
pub struct RootRow {
    pub project_id: RemoteId,
    pub project_key: String,
    pub name: String,
    pub kind: ProjectKind,
    pub scope: ProjectScope,
    pub dept_name: Option<String>,
    /// **空串 = 不进目录树**(SKILL 项目:服务端 7662157 起 `drivePath` 为 null,
    /// 它走 `skills_path` 装进 `~/.alwith/skills/`,人不需要浏览)
    pub drive_path: String,
    /// 树上的哪一节 / 哪个容器 / 分组用的节点路径。**分组按 `node_path`,不切 `drive_path`
    /// 的字符串** —— 部门名自己带斜杠时切字符串会炸
    pub node: Option<String>,
    pub container: Option<String>,
    pub node_path: Option<String>,
    pub skills_path: Option<String>,
    pub sync_enabled: bool,
    pub can_write: bool,
    pub cloud_only: bool,
    pub cursor: Option<String>,
    pub pinned: bool,
    /// 服务端 `departmentId`;None = 老服务端没这个字段,回落按 `dept_name` 比
    pub department_id: Option<RemoteId>,
    /// 服务端 `ownerId`(DEPT / COMPANY 为 null;老服务端不返回)
    pub owner_id: Option<RemoteId>,
    /// 服务端 `isMine`;None = 老服务端没这个字段
    pub is_mine: Option<bool>,
}

/// 一次上行失败留下的记录。`files.state` 只能说「失败了」,而用户要问的是「为什么」;
/// 引擎要问的是「该不该再试一次」—— 两个问题的答案都在这张表里。
///
/// 单独一张表而不是给 `files` 加列:失败是少数派(正常情况下一行都没有),而 `FileRow`
/// 是每次扫描都要成千上万次构造的热结构,不该为几行异常背上四个字段。
#[derive(Debug, Clone, PartialEq)]
pub struct FileErrorRow {
    pub project_id: RemoteId,
    /// 云端相对路径
    pub path: String,
    /// `FileState::Error` 或 `FileState::Forbidden`
    pub state: FileState,
    /// 服务端原话,一个字都不改
    pub message: String,
    /// 已经试过几次(第一次失败就是 1)
    pub attempts: u32,
    /// `upload` 还是 `download` —— UI 那句话不一样:「没传上去」与「没下下来」是两件事,
    /// 用户要做的动作也不同(前者等重试 / 看权限,后者可以点一下手动拉)
    pub direction: SyncDirection,
    pub first_at_ms: i64,
    pub last_at_ms: i64,
    /// 早于这个时刻不再重试(退避,见 `engine::upload_backoff`)
    pub next_at_ms: i64,
}

/// 会话归档一行:`~/.alwith/projects/**/<uuid>.jsonl` → 服务端 `ai-session-archive` 里的文件。
#[derive(Debug, Clone, PartialEq)]
pub struct ArchiveRow {
    pub uuid: String,
    /// 过滤后(只留 user / assistant 文本)内容的 sha256
    pub sha256: String,
    pub remote_file_id: Option<RemoteId>,
    pub remote_version_id: Option<RemoteId>,
    /// 原始 jsonl 的 (mtime, size):没变就不读文件
    pub mtime_ms: i64,
    pub size: u64,
    /// 云端相对路径 `<email 前缀>/<YYYY-MM>/<name>.jsonl`
    pub cloud_path: String,
}

pub struct Index {
    connection: Mutex<Connection>,
}

enum IndexOpenFailure {
    Sqlite { action: &'static str, error: rusqlite::Error },
    Integrity(String),
    Initialize(String),
}

impl IndexOpenFailure {
    fn describe(&self, path: &Path) -> String {
        match self {
            Self::Sqlite { action, error } => format!("{action}索引 {} 失败: {error}", path.display()),
            Self::Integrity(detail) => format!("索引 {} 完整性检查失败: {detail}", path.display()),
            Self::Initialize(error) => error.clone(),
        }
    }
}

fn kind_str(kind: ProjectKind) -> &'static str {
    match kind {
        ProjectKind::Material => "MATERIAL",
        ProjectKind::Knowledge => "KNOWLEDGE",
        ProjectKind::Skill => "SKILL",
    }
}

fn parse_kind(value: &str) -> ProjectKind {
    match value {
        "MATERIAL" => ProjectKind::Material,
        "KNOWLEDGE" => ProjectKind::Knowledge,
        "SKILL" => ProjectKind::Skill,
        other => panic!("索引里的 kind 非法: {other}"),
    }
}

fn scope_str(scope: ProjectScope) -> &'static str {
    match scope {
        ProjectScope::Personal => "PERSONAL",
        ProjectScope::Dept => "DEPT",
        ProjectScope::Team => "TEAM",
        ProjectScope::Company => "COMPANY",
    }
}

fn parse_scope(value: &str) -> ProjectScope {
    match value {
        "PERSONAL" => ProjectScope::Personal,
        "DEPT" => ProjectScope::Dept,
        "TEAM" => ProjectScope::Team,
        "COMPANY" => ProjectScope::Company,
        other => panic!("索引里的 scope 非法: {other}"),
    }
}

impl Index {
    pub fn open(path: &Path) -> Result<Self, String> {
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|error| format!("创建索引目录 {} 失败: {error}", parent.display()))?;
        }
        Self::validate_existing(path).and_then(|()| Self::open_at(path).map_err(|error| error.describe(path))).map_err(
            |error| format!("{error};同步未启动。请保留原索引及 WAL/SHM/journal 文件进行诊断，不要删除索引或重建空库"),
        )
    }

    pub fn open_in_memory() -> Result<Self, String> {
        let connection = Connection::open_in_memory().map_err(|error| format!("打开内存索引失败: {error}"))?;
        Self::from_connection(connection)
    }

    fn open_at(path: &Path) -> Result<Self, IndexOpenFailure> {
        let connection =
            Connection::open(path).map_err(|error| IndexOpenFailure::Sqlite { action: "打开", error })?;
        Self::check_integrity(&connection)?;
        Self::from_connection(connection).map_err(IndexOpenFailure::Initialize)
    }

    fn check_integrity(connection: &Connection) -> Result<(), IndexOpenFailure> {
        let integrity = connection
            .query_row("PRAGMA quick_check", [], |row| row.get::<_, String>(0))
            .map_err(|error| IndexOpenFailure::Sqlite { action: "检查", error })?;
        if integrity != "ok" {
            return Err(IndexOpenFailure::Integrity(integrity));
        }
        Ok(())
    }

    /// SQLite 即使只做完整性检查也可能恢复 WAL 或清理 sidecar。
    /// 先检查私有副本；任何复制/检查失败都停止启动，原文件不交给 SQLite。
    fn validate_existing(path: &Path) -> Result<(), String> {
        let exists = path.try_exists().map_err(|error| format!("检查索引 {} 失败: {error}", path.display()))?;
        if !exists {
            for suffix in ["-wal", "-shm", "-journal"] {
                let sidecar = sidecar_path(path, suffix);
                if sidecar.try_exists().map_err(|error| format!("检查 {} 失败: {error}", sidecar.display()))? {
                    return Err(format!("索引主库 {} 缺失，但 {} 仍存在", path.display(), sidecar.display()));
                }
            }
            return Ok(());
        }
        let metadata =
            std::fs::metadata(path).map_err(|error| format!("读取索引 {} 元信息失败: {error}", path.display()))?;
        if metadata.len() == 0 {
            return Err(format!("既有索引 {} 是空文件", path.display()));
        }
        let directory = tempfile::Builder::new()
            .prefix("alwith-index-check-")
            .tempdir()
            .map_err(|error| format!("创建索引检查副本目录失败: {error}"))?;
        let probe = directory.path().join("index.sqlite3");
        std::fs::copy(path, &probe).map_err(|error| format!("复制索引 {} 供检查失败: {error}", path.display()))?;
        for suffix in ["-wal", "-shm", "-journal"] {
            let sidecar = sidecar_path(path, suffix);
            if sidecar.try_exists().map_err(|error| format!("检查 {} 失败: {error}", sidecar.display()))? {
                std::fs::copy(&sidecar, sidecar_path(&probe, suffix))
                    .map_err(|error| format!("复制 {} 供检查失败: {error}", sidecar.display()))?;
            }
        }
        let connection =
            Connection::open(&probe).map_err(|error| format!("打开索引 {} 的检查副本失败: {error}", path.display()))?;
        Self::check_integrity(&connection).map_err(|error| error.describe(path))
    }

    fn from_connection(connection: Connection) -> Result<Self, String> {
        connection
            .execute_batch(
                "PRAGMA journal_mode = WAL;
                 CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                 CREATE TABLE IF NOT EXISTS files (
                    project_id TEXT NOT NULL,
                    path TEXT NOT NULL,
                    remote_file_id TEXT,
                    remote_version_id TEXT,
                    sha256 TEXT,
                    size INTEGER NOT NULL DEFAULT 0,
                    mtime INTEGER NOT NULL DEFAULT 0,
                    state TEXT NOT NULL,
                    collab_active INTEGER NOT NULL DEFAULT 0,
                    read_only INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (project_id, path)
                 );
                 CREATE INDEX IF NOT EXISTS files_sha ON files (project_id, sha256);
                 CREATE TABLE IF NOT EXISTS roots (
                    project_id TEXT PRIMARY KEY,
                    project_key TEXT NOT NULL,
                    name TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    scope TEXT NOT NULL,
                    dept_name TEXT,
                    drive_path TEXT NOT NULL,
                    node TEXT,
                    container TEXT,
                    node_path TEXT,
                    skills_path TEXT,
                    sync_enabled INTEGER NOT NULL DEFAULT 1,
                    can_write INTEGER NOT NULL DEFAULT 1,
                    cloud_only INTEGER NOT NULL DEFAULT 0,
                    cursor TEXT,
                    pinned INTEGER NOT NULL DEFAULT 0,
                    department_id TEXT,
                    owner_id TEXT,
                    is_mine INTEGER
                 );
                 CREATE TABLE IF NOT EXISTS file_errors (
                    project_id TEXT NOT NULL,
                    path TEXT NOT NULL,
                    state TEXT NOT NULL,
                    message TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    direction TEXT NOT NULL DEFAULT 'upload',
                    first_at INTEGER NOT NULL DEFAULT 0,
                    last_at INTEGER NOT NULL DEFAULT 0,
                    next_at INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (project_id, path)
                 );
                 CREATE TABLE IF NOT EXISTS folders (
                    project_id TEXT NOT NULL,
                    path TEXT NOT NULL,
                    PRIMARY KEY (project_id, path)
                 );
                 CREATE TABLE IF NOT EXISTS archive_sessions (
                    uuid TEXT PRIMARY KEY,
                    sha256 TEXT NOT NULL,
                    remote_file_id TEXT,
                    remote_version_id TEXT,
                    mtime INTEGER NOT NULL DEFAULT 0,
                    size INTEGER NOT NULL DEFAULT 0,
                    cloud_path TEXT NOT NULL
                 );",
            )
            .map_err(|error| format!("初始化索引表失败: {error}"))?;
        let index = Self { connection: Mutex::new(connection) };
        match index.meta_get("schema_version")? {
            Some(version) if version == SCHEMA_VERSION.to_string() => {}
            Some(version) if matches!(version.as_str(), "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8") => {
                // 每一步都用 add_column_if_missing:同一个升级路径可能被跑到一半(进程被杀),
                // 重复 ALTER 会直接报错,而用户手上的库没有第二次机会
                index.add_column_if_missing("files", "collab_active", "INTEGER NOT NULL DEFAULT 0")?;
                // v2 → v3 只是多一张表,建表语句已在上面的 IF NOT EXISTS 里
                index.add_column_if_missing("roots", "owner_id", "TEXT")?;
                index.add_column_if_missing("roots", "is_mine", "INTEGER")?;
                index.add_column_if_missing("roots", "department_id", "TEXT")?;
                index.add_column_if_missing("files", "read_only", "INTEGER NOT NULL DEFAULT 0")?;
                // v6 → v7:老库里的失败记录都是上行留下的,默认 'upload' 正是它们的真身
                index.add_column_if_missing("file_errors", "direction", "TEXT NOT NULL DEFAULT 'upload'")?;
                // v8 → v9:根清单每轮都从服务端重拉,这三列空着也只空到下一次 refresh_roots
                index.add_column_if_missing("roots", "node", "TEXT")?;
                index.add_column_if_missing("roots", "container", "TEXT")?;
                index.add_column_if_missing("roots", "node_path", "TEXT")?;
                // v7 → v8 只是多一张 folders,建表语句已在上面的 IF NOT EXISTS 里。
                // 升上来时它是空的 —— 于是老库第一轮会把本地所有目录都发一遍 MKDIR,
                // 服务端对已存在的目录回「已存在」,我们当成功并登记下来,一轮之后就安静了
                // v5 → v6 只是多一张 file_errors,建表语句已在上面的 IF NOT EXISTS 里。
                // 升上来的库里已经躺着的 error 行没有对应记录:`retry_due` 把「没记录」当成
                // 「可以试」,所以老用户升上来的第一轮就会把卡住的文件重新推一遍 —— 这正是要的
                index.meta_set("schema_version", &SCHEMA_VERSION.to_string())?;
            }
            Some(version) => return Err(format!("索引 schema 版本 {version} 与程序 {SCHEMA_VERSION} 不一致")),
            None => index.meta_set("schema_version", &SCHEMA_VERSION.to_string())?,
        }
        // 「升上来之后跑一次全量对账」用一个**独立标记**,不碰 schema 版本。
        //
        // 2026-09-15 教训:为这件事把 SCHEMA_VERSION 从 9 提到 10,结果 dev 版一启动就把
        // 索引升到 10,而**正式版和 dev 共用同一份索引文件** —— 正式版(程序还是 9)再打开
        // 就是「索引 schema 版本 10 与程序 9 不一致」,YUP Drive 整个起不来。那次迁移其实
        // 一个 ALTER 都没有,纯粹是清一次 cursor,完全不值得挡住所有没升级的客户端。
        //
        // 版本号只在**表结构真的变了**的时候动。这种一次性的数据修补,用自己的标记。
        if index.meta_get(META_RECONCILE_ONCE)?.is_none() {
            index
                .lock()
                .execute("UPDATE roots SET cursor = NULL", [])
                .map(|_| ())
                .map_err(|error| format!("清 cursor 失败: {error}"))?;
            index.meta_set(META_RECONCILE_ONCE, "done")?;
            log::info!("[drive-sync] 首次升到这一版:清 cursor,下一轮走全量对账把历史漂移拉回来");
        }
        Ok(index)
    }

    fn lock(&self) -> std::sync::MutexGuard<'_, Connection> {
        self.connection.lock().expect("index connection mutex poisoned")
    }

    /// 迁移用:列已经在(库是新建的、或迁移跑过一半)就跳过,ALTER 不能重复执行。
    fn add_column_if_missing(&self, table: &str, column: &str, declaration: &str) -> Result<(), String> {
        let connection = self.lock();
        let mut statement =
            connection.prepare(&format!("PRAGMA table_info({table})")).map_err(|error| error.to_string())?;
        let existing: Vec<String> = statement
            .query_map([], |row| row.get::<_, String>(1))
            .map_err(|error| error.to_string())?
            .collect::<Result<_, _>>()
            .map_err(|error| error.to_string())?;
        if existing.iter().any(|name| name == column) {
            return Ok(());
        }
        drop(statement);
        connection
            .execute_batch(&format!("ALTER TABLE {table} ADD COLUMN {column} {declaration};"))
            .map_err(|error| format!("给 {table} 加列 {column} 失败: {error}"))
    }

    // ─── meta ─────────────────────────────────────────────────────────────

    pub fn meta_get(&self, key: &str) -> Result<Option<String>, String> {
        self.lock()
            .query_row("SELECT value FROM meta WHERE key = ?1", params![key], |row| row.get::<_, String>(0))
            .optional()
            .map_err(|error| format!("读 meta {key} 失败: {error}"))
    }

    pub fn meta_set(&self, key: &str, value: &str) -> Result<(), String> {
        self.lock()
            .execute(
                "INSERT INTO meta (key, value) VALUES (?1, ?2) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                params![key, value],
            )
            .map(|_| ())
            .map_err(|error| format!("写 meta {key} 失败: {error}"))
    }

    // ─── files ────────────────────────────────────────────────────────────

    pub fn upsert_file(&self, row: &FileRow) -> Result<(), String> {
        self.lock()
            .execute(
                "INSERT INTO files (project_id, path, remote_file_id, remote_version_id, sha256, size, mtime, state, collab_active, read_only)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)
                 ON CONFLICT(project_id, path) DO UPDATE SET
                    remote_file_id = excluded.remote_file_id,
                    remote_version_id = excluded.remote_version_id,
                    sha256 = excluded.sha256,
                    size = excluded.size,
                    mtime = excluded.mtime,
                    state = excluded.state,
                    collab_active = excluded.collab_active,
                    read_only = excluded.read_only",
                params![
                    row.project_id.as_key(),
                    row.path,
                    row.remote_file_id.as_ref().map(RemoteId::as_key),
                    row.remote_version_id.as_ref().map(RemoteId::as_key),
                    row.sha256,
                    row.size as i64,
                    row.mtime_ms,
                    row.state.as_str(),
                    row.collab_active as i64,
                    row.read_only as i64
                ],
            )
            .map(|_| ())
            .map_err(|error| format!("写索引 {} 失败: {error}", row.path))
    }

    pub fn get_file(&self, project_id: &RemoteId, path: &str) -> Result<Option<FileRow>, String> {
        self.lock()
            .query_row(
                "SELECT project_id, path, remote_file_id, remote_version_id, sha256, size, mtime, state, collab_active, read_only
                 FROM files WHERE project_id = ?1 AND path = ?2",
                params![project_id.as_key(), path],
                map_file_row,
            )
            .optional()
            .map_err(|error| format!("读索引 {path} 失败: {error}"))
    }

    pub fn delete_file(&self, project_id: &RemoteId, path: &str) -> Result<(), String> {
        let connection = self.lock();
        connection
            .execute("DELETE FROM files WHERE project_id = ?1 AND path = ?2", params![project_id.as_key(), path])
            .map_err(|error| format!("删索引 {path} 失败: {error}"))?;
        // 行都没了,失败记录跟着走:留着它,UI 上就会挂着一个已经不存在的文件说「没传上去」
        connection
            .execute("DELETE FROM file_errors WHERE project_id = ?1 AND path = ?2", params![project_id.as_key(), path])
            .map(|_| ())
            .map_err(|error| format!("删失败记录 {path} 失败: {error}"))
    }

    /// 重命名 / 移动:改 path(含目录前缀批量)。
    ///
    /// **先给目标位置清场。**远端完全可能把东西移到一个本地索引里已经有行的路径上
    /// (同名覆盖、或者同一条移动事件被重放过),而 files 的主键是 (project_id, path) ——
    /// 直接 UPDATE 会撞 `UNIQUE constraint failed: files.project_id, files.path`,
    /// 这条根从此再也同步不动(2026-09-15 实撞:一个人 52 条错误全是这一个)。
    /// 移动的语义本来就是覆盖,被压在下面的那行销掉是对的。
    pub fn move_path(&self, project_id: &RemoteId, old_path: &str, new_path: &str) -> Result<(), String> {
        if old_path == new_path {
            return Ok(());
        }
        let connection = self.lock();
        let new_prefix = format!("{new_path}/");
        // 往自己的子树里移是非法移动(服务端会拒)。这里只防一件事:别在清场时把自己清掉。
        if !new_path.starts_with(&format!("{old_path}/")) {
            connection
                .execute(
                    "DELETE FROM files WHERE project_id = ?1 AND (path = ?2 OR substr(path, 1, length(?3)) = ?3)",
                    params![project_id.as_key(), new_path, new_prefix],
                )
                .map_err(|error| format!("清目标位置 {new_path} 失败: {error}"))?;
            connection
                .execute(
                    "DELETE FROM file_errors WHERE project_id = ?1 AND (path = ?2 OR substr(path, 1, length(?3)) = ?3)",
                    params![project_id.as_key(), new_path, new_prefix],
                )
                .map_err(|error| format!("清目标失败记录 {new_path} 失败: {error}"))?;
        }
        connection
            .execute(
                "UPDATE files SET path = ?3 WHERE project_id = ?1 AND path = ?2",
                params![project_id.as_key(), old_path, new_path],
            )
            .map_err(|error| format!("移动索引 {old_path} 失败: {error}"))?;
        let prefix = format!("{old_path}/");
        connection
            .execute(
                "UPDATE files SET path = ?3 || substr(path, length(?2) + 1)
                 WHERE project_id = ?1 AND substr(path, 1, length(?2)) = ?2",
                params![project_id.as_key(), prefix, format!("{new_path}/")],
            )
            .map_err(|error| format!("移动索引目录 {old_path} 失败: {error}"))?;
        // 失败记录按 path 认身份,不跟着走就会变成一条指向空气的「没传上去」——
        // 直接销案而不是改写 path:文件已经在新位置了,它现在成不成功要在新位置重新问一遍,
        // 把旧那次失败的次数与退避带过去只会让新位置一上来就被退避挡住。
        // **目录移动同理**:上面那句前缀批量改的是整棵子树,它们的失败记录也一并销掉,
        // 否则 UI 上会挂着一串旧路径的「没传上去」,点「显示」还找不到文件。
        connection
            .execute(
                "DELETE FROM file_errors WHERE project_id = ?1 AND (path = ?2 OR substr(path, 1, length(?3)) = ?3)",
                params![project_id.as_key(), old_path, prefix],
            )
            .map(|_| ())
            .map_err(|error| format!("移动失败记录 {old_path} 失败: {error}"))
    }

    pub fn set_state(&self, project_id: &RemoteId, path: &str, state: FileState) -> Result<(), String> {
        self.lock()
            .execute(
                "UPDATE files SET state = ?3 WHERE project_id = ?1 AND path = ?2",
                params![project_id.as_key(), path, state.as_str()],
            )
            .map(|_| ())
            .map_err(|error| format!("更新索引状态 {path} 失败: {error}"))
    }

    pub fn set_collab_active(&self, project_id: &RemoteId, path: &str, collab_active: bool) -> Result<(), String> {
        self.lock()
            .execute(
                "UPDATE files SET collab_active = ?3 WHERE project_id = ?1 AND path = ?2",
                params![project_id.as_key(), path, collab_active as i64],
            )
            .map(|_| ())
            .map_err(|error| format!("更新协同标记 {path} 失败: {error}"))
    }

    pub fn list_files(&self, project_id: &RemoteId) -> Result<Vec<FileRow>, String> {
        let connection = self.lock();
        let mut statement = connection
            .prepare(
                "SELECT project_id, path, remote_file_id, remote_version_id, sha256, size, mtime, state, collab_active, read_only
                 FROM files WHERE project_id = ?1 ORDER BY path",
            )
            .map_err(|error| error.to_string())?;
        let rows = statement
            .query_map(params![project_id.as_key()], map_file_row)
            .map_err(|error| error.to_string())?
            .collect::<Result<Vec<_>, _>>()
            .map_err(|error| format!("读索引清单失败: {error}"))?;
        Ok(rows)
    }

    pub fn list_all_files(&self) -> Result<Vec<FileRow>, String> {
        let connection = self.lock();
        let mut statement = connection
            .prepare(
                "SELECT project_id, path, remote_file_id, remote_version_id, sha256, size, mtime, state, collab_active, read_only
                 FROM files ORDER BY project_id, path",
            )
            .map_err(|error| error.to_string())?;
        let rows = statement
            .query_map([], map_file_row)
            .map_err(|error| error.to_string())?
            .collect::<Result<Vec<_>, _>>()
            .map_err(|error| format!("读索引全量失败: {error}"))?;
        Ok(rows)
    }

    /// path → row 的快照(扫描增量用)。
    pub fn file_map(&self, project_id: &RemoteId) -> Result<HashMap<String, FileRow>, String> {
        Ok(self.list_files(project_id)?.into_iter().map(|row| (row.path.clone(), row)).collect())
    }

    // ─── file_errors ──────────────────────────────────────────────────────

    pub fn put_file_error(&self, row: &FileErrorRow) -> Result<(), String> {
        self.lock()
            .execute(
                "INSERT INTO file_errors (project_id, path, state, message, attempts, direction, first_at, last_at, next_at)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)
                 ON CONFLICT(project_id, path) DO UPDATE SET
                    state = excluded.state,
                    message = excluded.message,
                    attempts = excluded.attempts,
                    direction = excluded.direction,
                    last_at = excluded.last_at,
                    next_at = excluded.next_at",
                params![
                    row.project_id.as_key(),
                    row.path,
                    row.state.as_str(),
                    row.message,
                    row.attempts as i64,
                    row.direction.as_str(),
                    row.first_at_ms,
                    row.last_at_ms,
                    row.next_at_ms
                ],
            )
            .map(|_| ())
            .map_err(|error| format!("写失败记录 {} 失败: {error}", row.path))
    }

    pub fn file_error(&self, project_id: &RemoteId, path: &str) -> Result<Option<FileErrorRow>, String> {
        self.lock()
            .query_row(
                "SELECT project_id, path, state, message, attempts, direction, first_at, last_at, next_at
                 FROM file_errors WHERE project_id = ?1 AND path = ?2",
                params![project_id.as_key(), path],
                map_file_error_row,
            )
            .optional()
            .map_err(|error| format!("读失败记录 {path} 失败: {error}"))
    }

    /// 一个项目的失败记录(上行规划器每轮开头取一次,不做 per-file 查询)。
    pub fn file_error_map(&self, project_id: &RemoteId) -> Result<HashMap<String, FileErrorRow>, String> {
        let connection = self.lock();
        let mut statement = connection
            .prepare(
                "SELECT project_id, path, state, message, attempts, direction, first_at, last_at, next_at
                 FROM file_errors WHERE project_id = ?1",
            )
            .map_err(|error| error.to_string())?;
        let rows = statement
            .query_map(params![project_id.as_key()], map_file_error_row)
            .map_err(|error| error.to_string())?
            .collect::<Result<Vec<_>, _>>()
            .map_err(|error| format!("读失败记录失败: {error}"))?;
        Ok(rows.into_iter().map(|row| (row.path.clone(), row)).collect())
    }

    /// 全部失败记录,最近失败的排前面 —— UI 那张「没传上去的文件」清单。
    pub fn list_file_errors(&self) -> Result<Vec<FileErrorRow>, String> {
        let connection = self.lock();
        let mut statement = connection
            .prepare(
                "SELECT project_id, path, state, message, attempts, direction, first_at, last_at, next_at
                 FROM file_errors ORDER BY last_at DESC, path",
            )
            .map_err(|error| error.to_string())?;
        let rows = statement
            .query_map([], map_file_error_row)
            .map_err(|error| error.to_string())?
            .collect::<Result<Vec<_>, _>>()
            .map_err(|error| format!("读失败清单失败: {error}"))?;
        Ok(rows)
    }

    pub fn count_file_errors(&self) -> Result<u32, String> {
        self.lock()
            .query_row("SELECT COUNT(*) FROM file_errors", [], |row| row.get::<_, i64>(0))
            .map(|count| count as u32)
            .map_err(|error| format!("统计失败记录失败: {error}"))
    }

    pub fn clear_file_error(&self, project_id: &RemoteId, path: &str) -> Result<(), String> {
        self.lock()
            .execute("DELETE FROM file_errors WHERE project_id = ?1 AND path = ?2", params![project_id.as_key(), path])
            .map(|_| ())
            .map_err(|error| format!("清失败记录 {path} 失败: {error}"))
    }

    /// 把退避表清零(「立刻重试」):记录本身留着 —— 用户点了重试,不等于失败没发生过。
    /// 只把**一条**失败行的退避清零(面板上逐条的「重试」)。全局那颗按钮是把整张表清零,
    /// 用户想单独再试一个文件时不该顺带把其余几十条也拉起来重试。
    pub fn clear_file_error_backoff_of(&self, project_id: &RemoteId, path: &str) -> Result<u32, String> {
        self.lock()
            .execute(
                "UPDATE file_errors SET next_at = 0 WHERE project_id = ?1 AND path = ?2",
                params![project_id.as_key(), path],
            )
            .map(|count| count as u32)
            .map_err(|error| format!("重置 {path} 的失败退避失败: {error}"))
    }

    pub fn clear_file_error_backoff(&self) -> Result<u32, String> {
        self.lock()
            .execute("UPDATE file_errors SET next_at = 0", [])
            .map(|count| count as u32)
            .map_err(|error| format!("重置失败退避失败: {error}"))
    }

    // ─── folders ──────────────────────────────────────────────────────────
    //
    // 「服务端上已经有这个目录了」的登记簿。目录不是文件的副产品:一个空文件夹也是用户
    // 建出来的东西,得有地方记它(2026-09-07)。写入点只有一处 —— MKDIR 拿到成功回执时。

    pub fn put_folder(&self, project_id: &RemoteId, path: &str) -> Result<(), String> {
        self.lock()
            .execute(
                "INSERT OR IGNORE INTO folders (project_id, path) VALUES (?1, ?2)",
                params![project_id.as_key(), path],
            )
            .map(|_| ())
            .map_err(|error| format!("记目录 {path} 失败: {error}"))
    }

    /// 销掉一条目录登记(RMDIR 成功后)。空文件夹在本地被删、云端也 RMDIR 了,登记簿要跟着清,
    /// 否则 `prepend_mkdirs` 会把它当「服务端已有」而漏建 / `folders_to_rmdir` 会反复挑它。
    pub fn delete_folder(&self, project_id: &RemoteId, path: &str) -> Result<(), String> {
        self.lock()
            .execute("DELETE FROM folders WHERE project_id = ?1 AND path = ?2", params![project_id.as_key(), path])
            .map(|_| ())
            .map_err(|error| format!("销目录登记 {path} 失败: {error}"))
    }

    pub fn list_folders(&self, project_id: &RemoteId) -> Result<HashSet<String>, String> {
        let connection = self.lock();
        let mut statement =
            connection.prepare("SELECT path FROM folders WHERE project_id = ?1").map_err(|error| error.to_string())?;
        let rows = statement
            .query_map(params![project_id.as_key()], |row| row.get::<_, String>(0))
            .map_err(|error| error.to_string())?
            .collect::<Result<HashSet<_>, _>>()
            .map_err(|error| format!("读目录清单失败: {error}"))?;
        Ok(rows)
    }

    /// 按云端 fileId 找这份文件在哪个项目、哪条路径上。**跨项目找** —— 沉淀产出的草稿落在
    /// 知识库项目里,而用户是在资料项目里点的沉淀,两个项目不是同一个。
    pub fn find_by_remote_file_id(&self, file_id: &RemoteId) -> Result<Option<(RemoteId, String)>, String> {
        self.lock()
            .query_row(
                "SELECT project_id, path FROM files WHERE remote_file_id = ?1 LIMIT 1",
                params![file_id.as_key()],
                |row| Ok((RemoteId::from_key(&row.get::<_, String>(0)?), row.get::<_, String>(1)?)),
            )
            .optional()
            .map_err(|error| format!("按 fileId 找文件失败: {error}"))
    }

    pub fn count_state(&self, state: FileState) -> Result<u32, String> {
        self.lock()
            .query_row("SELECT COUNT(*) FROM files WHERE state = ?1", params![state.as_str()], |row| {
                row.get::<_, i64>(0)
            })
            .map(|count| count as u32)
            .map_err(|error| format!("统计索引失败: {error}"))
    }

    /// 按项目汇总占用:(projectId, 字节数, 文件数),从多到少。
    pub fn usage_by_project(&self, limit: u32) -> Result<Vec<(RemoteId, u64, u32)>, String> {
        let guard = self.lock();
        let mut statement = guard
            .prepare(
                "SELECT project_id, SUM(size), COUNT(*) FROM files GROUP BY project_id ORDER BY SUM(size) DESC LIMIT ?1",
            )
            .map_err(|error| format!("统计项目占用失败: {error}"))?;
        let rows = statement
            .query_map(params![limit as i64], |row| {
                Ok((
                    RemoteId::from_key(&row.get::<_, String>(0)?),
                    row.get::<_, i64>(1)? as u64,
                    row.get::<_, i64>(2)? as u32,
                ))
            })
            .map_err(|error| format!("统计项目占用失败: {error}"))?;
        rows.collect::<Result<Vec<_>, _>>().map_err(|error| format!("统计项目占用失败: {error}"))
    }

    /// 最大的几个文件:(projectId, 云端路径, 字节数),从大到小。
    pub fn largest_files(&self, limit: u32) -> Result<Vec<(RemoteId, String, u64)>, String> {
        let guard = self.lock();
        let mut statement = guard
            .prepare("SELECT project_id, path, size FROM files ORDER BY size DESC LIMIT ?1")
            .map_err(|error| format!("统计文件占用失败: {error}"))?;
        let rows = statement
            .query_map(params![limit as i64], |row| {
                Ok((
                    RemoteId::from_key(&row.get::<_, String>(0)?),
                    row.get::<_, String>(1)?,
                    row.get::<_, i64>(2)? as u64,
                ))
            })
            .map_err(|error| format!("统计文件占用失败: {error}"))?;
        rows.collect::<Result<Vec<_>, _>>().map_err(|error| format!("统计文件占用失败: {error}"))
    }

    /// 全部文件的字节数与条数。
    pub fn usage_total(&self) -> Result<(u64, u32), String> {
        self.lock()
            .query_row("SELECT COALESCE(SUM(size),0), COUNT(*) FROM files", [], |row| {
                Ok((row.get::<_, i64>(0)? as u64, row.get::<_, i64>(1)? as u32))
            })
            .map_err(|error| format!("统计占用失败: {error}"))
    }

    // ─── roots ────────────────────────────────────────────────────────────

    /// 写入服务端根;本地字段(pinned / cursor)保留已有值。
    pub fn upsert_root(&self, row: &RootRow) -> Result<(), String> {
        self.lock()
            .execute(
                "INSERT INTO roots (project_id, project_key, name, kind, scope, dept_name, drive_path, node, container,
                                    node_path, skills_path,
                                    sync_enabled, can_write, cloud_only, cursor, pinned, department_id, owner_id, is_mine)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15, ?16, ?17, ?18, ?19)
                 ON CONFLICT(project_id) DO UPDATE SET
                    project_key = excluded.project_key,
                    name = excluded.name,
                    kind = excluded.kind,
                    scope = excluded.scope,
                    dept_name = excluded.dept_name,
                    drive_path = excluded.drive_path,
                    node = excluded.node,
                    container = excluded.container,
                    node_path = excluded.node_path,
                    skills_path = excluded.skills_path,
                    sync_enabled = excluded.sync_enabled,
                    can_write = excluded.can_write,
                    cloud_only = excluded.cloud_only,
                    department_id = excluded.department_id,
                    owner_id = excluded.owner_id,
                    is_mine = excluded.is_mine",
                params![
                    row.project_id.as_key(),
                    row.project_key,
                    row.name,
                    kind_str(row.kind),
                    scope_str(row.scope),
                    row.dept_name,
                    row.drive_path,
                    row.node,
                    row.container,
                    row.node_path,
                    row.skills_path,
                    row.sync_enabled as i64,
                    row.can_write as i64,
                    row.cloud_only as i64,
                    row.cursor,
                    row.pinned as i64,
                    row.department_id.as_ref().map(RemoteId::as_key),
                    row.owner_id.as_ref().map(RemoteId::as_key),
                    row.is_mine.map(|value| value as i64)
                ],
            )
            .map(|_| ())
            .map_err(|error| format!("写根 {} 失败: {error}", row.project_key))
    }

    pub fn get_root(&self, project_id: &RemoteId) -> Result<Option<RootRow>, String> {
        self.lock()
            .query_row(
                "SELECT project_id, project_key, name, kind, scope, dept_name, drive_path, node, container, node_path,
                        skills_path, sync_enabled, can_write, cloud_only, cursor, pinned, department_id, owner_id, is_mine
                 FROM roots WHERE project_id = ?1",
                params![project_id.as_key()],
                map_root_row,
            )
            .optional()
            .map_err(|error| format!("读根 {project_id} 失败: {error}"))
    }

    pub fn list_roots(&self) -> Result<Vec<RootRow>, String> {
        let connection = self.lock();
        let mut statement = connection
            .prepare(
                "SELECT project_id, project_key, name, kind, scope, dept_name, drive_path, node, container, node_path,
                        skills_path, sync_enabled, can_write, cloud_only, cursor, pinned, department_id, owner_id, is_mine
                 FROM roots ORDER BY drive_path",
            )
            .map_err(|error| error.to_string())?;
        let rows = statement
            .query_map([], map_root_row)
            .map_err(|error| error.to_string())?
            .collect::<Result<Vec<_>, _>>()
            .map_err(|error| format!("读根清单失败: {error}"))?;
        Ok(rows)
    }

    pub fn set_pinned(&self, project_id: &RemoteId, pinned: bool) -> Result<(), String> {
        let changed = self
            .lock()
            .execute("UPDATE roots SET pinned = ?2 WHERE project_id = ?1", params![project_id.as_key(), pinned as i64])
            .map_err(|error| format!("固定根 {project_id} 失败: {error}"))?;
        if changed == 0 {
            return Err(format!("根 {project_id} 不在索引里"));
        }
        Ok(())
    }

    pub fn set_cursor(&self, project_id: &RemoteId, cursor: &str) -> Result<(), String> {
        self.lock()
            .execute("UPDATE roots SET cursor = ?2 WHERE project_id = ?1", params![project_id.as_key(), cursor])
            .map(|_| ())
            .map_err(|error| format!("写 cursor {project_id} 失败: {error}"))
    }

    /// 清 cursor:下一轮改走 snapshot 全量对账。用在「这一轮有事件没落地」之后 ——
    /// 变更流是一次性的,丢了的那条不会再来,只有对账能把索引拉回与远端一致。
    pub fn clear_cursor(&self, project_id: &RemoteId) -> Result<(), String> {
        self.lock()
            .execute("UPDATE roots SET cursor = NULL WHERE project_id = ?1", params![project_id.as_key()])
            .map(|_| ())
            .map_err(|error| format!("清 cursor {project_id} 失败: {error}"))
    }

    /// 本地副本被移走(cleanup)后忘掉这个项目的文件行并清空 cursor:它以后要是被固定,
    /// 走 snapshot 从头拉一遍,而不是拿着「已同步」的旧索引对着空目录。根本身留着。
    pub fn forget_project_files(&self, project_id: &RemoteId) -> Result<(), String> {
        let connection = self.lock();
        connection
            .execute("DELETE FROM files WHERE project_id = ?1", params![project_id.as_key()])
            .map_err(|error| format!("清 {project_id} 的文件行失败: {error}"))?;
        connection
            .execute("DELETE FROM file_errors WHERE project_id = ?1", params![project_id.as_key()])
            .map_err(|error| format!("清 {project_id} 的失败记录失败: {error}"))?;
        // 目录登记簿一起清:它记的是「服务端上已经有了」,本地副本都撤了就不该再替服务端打包票
        connection
            .execute("DELETE FROM folders WHERE project_id = ?1", params![project_id.as_key()])
            .map_err(|error| format!("清 {project_id} 的目录登记失败: {error}"))?;
        connection
            .execute("UPDATE roots SET cursor = NULL WHERE project_id = ?1", params![project_id.as_key()])
            .map(|_| ())
            .map_err(|error| format!("清 {project_id} 的 cursor 失败: {error}"))
    }

    pub fn delete_root(&self, project_id: &RemoteId) -> Result<(), String> {
        let connection = self.lock();
        connection
            .execute("DELETE FROM files WHERE project_id = ?1", params![project_id.as_key()])
            .map_err(|error| format!("删根文件 {project_id} 失败: {error}"))?;
        connection
            .execute("DELETE FROM file_errors WHERE project_id = ?1", params![project_id.as_key()])
            .map_err(|error| format!("删根失败记录 {project_id} 失败: {error}"))?;
        connection
            .execute("DELETE FROM folders WHERE project_id = ?1", params![project_id.as_key()])
            .map_err(|error| format!("删根目录登记 {project_id} 失败: {error}"))?;
        connection
            .execute("DELETE FROM roots WHERE project_id = ?1", params![project_id.as_key()])
            .map(|_| ())
            .map_err(|error| format!("删根 {project_id} 失败: {error}"))
    }

    /// 吊销后清空:六张表全清。
    pub fn clear_all(&self) -> Result<(), String> {
        self.lock()
            .execute_batch(
                "DELETE FROM files; DELETE FROM roots; DELETE FROM archive_sessions; DELETE FROM file_errors;
                 DELETE FROM folders; DELETE FROM meta WHERE key != 'schema_version';",
            )
            .map_err(|error| format!("清空索引失败: {error}"))
    }

    // ─── archive_sessions ─────────────────────────────────────────────────

    pub fn archive_upsert(&self, row: &ArchiveRow) -> Result<(), String> {
        self.lock()
            .execute(
                "INSERT INTO archive_sessions (uuid, sha256, remote_file_id, remote_version_id, mtime, size, cloud_path)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)
                 ON CONFLICT(uuid) DO UPDATE SET
                    sha256 = excluded.sha256,
                    remote_file_id = excluded.remote_file_id,
                    remote_version_id = excluded.remote_version_id,
                    mtime = excluded.mtime,
                    size = excluded.size,
                    cloud_path = excluded.cloud_path",
                params![
                    row.uuid,
                    row.sha256,
                    row.remote_file_id.as_ref().map(RemoteId::as_key),
                    row.remote_version_id.as_ref().map(RemoteId::as_key),
                    row.mtime_ms,
                    row.size as i64,
                    row.cloud_path
                ],
            )
            .map(|_| ())
            .map_err(|error| format!("写归档索引 {} 失败: {error}", row.uuid))
    }

    pub fn archive_get(&self, uuid: &str) -> Result<Option<ArchiveRow>, String> {
        self.lock()
            .query_row(
                "SELECT uuid, sha256, remote_file_id, remote_version_id, mtime, size, cloud_path FROM archive_sessions WHERE uuid = ?1",
                params![uuid],
                map_archive_row,
            )
            .optional()
            .map_err(|error| format!("读归档索引 {uuid} 失败: {error}"))
    }

    pub fn archive_count(&self) -> Result<u32, String> {
        self.lock()
            .query_row("SELECT COUNT(*) FROM archive_sessions", [], |row| row.get::<_, i64>(0))
            .map(|count| count as u32)
            .map_err(|error| format!("统计归档索引失败: {error}"))
    }
}

fn sidecar_path(path: &Path, suffix: &str) -> PathBuf {
    let mut value = path.as_os_str().to_os_string();
    value.push(suffix);
    PathBuf::from(value)
}

fn map_archive_row(row: &rusqlite::Row<'_>) -> rusqlite::Result<ArchiveRow> {
    Ok(ArchiveRow {
        uuid: row.get(0)?,
        sha256: row.get(1)?,
        remote_file_id: row.get::<_, Option<String>>(2)?.map(|value| RemoteId::from_key(&value)),
        remote_version_id: row.get::<_, Option<String>>(3)?.map(|value| RemoteId::from_key(&value)),
        mtime_ms: row.get(4)?,
        size: row.get::<_, i64>(5)? as u64,
        cloud_path: row.get(6)?,
    })
}

fn map_file_error_row(row: &rusqlite::Row<'_>) -> rusqlite::Result<FileErrorRow> {
    let state: String = row.get(2)?;
    Ok(FileErrorRow {
        project_id: RemoteId::from_key(&row.get::<_, String>(0)?),
        path: row.get(1)?,
        state: FileState::parse(&state).unwrap_or(FileState::Error),
        message: row.get(3)?,
        attempts: row.get::<_, i64>(4)? as u32,
        direction: SyncDirection::parse(&row.get::<_, String>(5)?),
        first_at_ms: row.get(6)?,
        last_at_ms: row.get(7)?,
        next_at_ms: row.get(8)?,
    })
}

fn map_file_row(row: &rusqlite::Row<'_>) -> rusqlite::Result<FileRow> {
    let state: String = row.get(7)?;
    Ok(FileRow {
        project_id: RemoteId::from_key(&row.get::<_, String>(0)?),
        path: row.get(1)?,
        remote_file_id: row.get::<_, Option<String>>(2)?.map(|value| RemoteId::from_key(&value)),
        remote_version_id: row.get::<_, Option<String>>(3)?.map(|value| RemoteId::from_key(&value)),
        sha256: row.get(4)?,
        size: row.get::<_, i64>(5)? as u64,
        mtime_ms: row.get(6)?,
        state: FileState::parse(&state).unwrap_or_else(|| panic!("索引里的 state 非法: {state}")),
        collab_active: row.get::<_, i64>(8)? != 0,
        read_only: row.get::<_, i64>(9)? != 0,
    })
}

fn map_root_row(row: &rusqlite::Row<'_>) -> rusqlite::Result<RootRow> {
    Ok(RootRow {
        project_id: RemoteId::from_key(&row.get::<_, String>(0)?),
        project_key: row.get(1)?,
        name: row.get(2)?,
        kind: parse_kind(&row.get::<_, String>(3)?),
        scope: parse_scope(&row.get::<_, String>(4)?),
        dept_name: row.get(5)?,
        drive_path: row.get(6)?,
        node: row.get(7)?,
        container: row.get(8)?,
        node_path: row.get(9)?,
        skills_path: row.get(10)?,
        sync_enabled: row.get::<_, i64>(11)? != 0,
        can_write: row.get::<_, i64>(12)? != 0,
        cloud_only: row.get::<_, i64>(13)? != 0,
        cursor: row.get(14)?,
        pinned: row.get::<_, i64>(15)? != 0,
        department_id: row.get::<_, Option<String>>(16)?.map(|value| RemoteId::from_key(&value)),
        owner_id: row.get::<_, Option<String>>(17)?.map(|value| RemoteId::from_key(&value)),
        is_mine: row.get::<_, Option<i64>>(18)?.map(|value| value != 0),
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn 损坏索引报错且主库与_sidecar_原样保留() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("index.sqlite3");
        for (suffix, bytes) in [
            ("", b"not a sqlite database".as_slice()),
            ("-wal", b"old wal"),
            ("-shm", b"old shm"),
            ("-journal", b"old journal"),
        ] {
            std::fs::write(sidecar_path(&path, suffix), bytes).unwrap();
        }
        for _ in 0..2 {
            let error = match Index::open(&path) {
                Ok(_) => panic!("corrupt index must block synchronization"),
                Err(error) => error,
            };
            assert!(error.contains("同步未启动"), "{error}");
            for (suffix, bytes) in [
                ("", b"not a sqlite database".as_slice()),
                ("-wal", b"old wal"),
                ("-shm", b"old shm"),
                ("-journal", b"old journal"),
            ] {
                assert_eq!(std::fs::read(sidecar_path(&path, suffix)).unwrap(), bytes);
            }
            assert_eq!(std::fs::read_dir(directory.path()).unwrap().count(), 4);
        }
    }

    #[test]
    fn 既有空库不能当作首次安装重新初始化() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("index.sqlite3");
        std::fs::write(&path, []).unwrap();
        assert!(Index::open(&path).is_err());
        assert_eq!(std::fs::metadata(&path).unwrap().len(), 0);
        assert_eq!(std::fs::read_dir(directory.path()).unwrap().count(), 1);
    }

    #[test]
    fn 主库缺失但_sidecar_存在时不创建空库() {
        for suffix in ["-wal", "-shm", "-journal"] {
            let directory = tempfile::tempdir().unwrap();
            let path = directory.path().join("index.sqlite3");
            let sidecar = sidecar_path(&path, suffix);
            std::fs::write(&sidecar, b"unrecovered state").unwrap();
            assert!(Index::open(&path).is_err());
            assert!(!path.exists());
            assert_eq!(std::fs::read(sidecar).unwrap(), b"unrecovered state");
        }
    }

    #[test]
    fn 健康索引重开保留_wal_中尚未_checkpoint_的数据() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("index.sqlite3");
        let first = Index::open(&path).unwrap();
        first.lock().execute_batch("PRAGMA wal_checkpoint(TRUNCATE); PRAGMA wal_autocheckpoint = 0").unwrap();
        let row = file("offline-deleted.txt", "old-content");
        first.upsert_file(&row).unwrap();
        let wal = sidecar_path(&path, "-wal");
        assert!(std::fs::metadata(&wal).unwrap().len() > 0);
        let second = Index::open(&path).unwrap();
        assert_eq!(second.get_file(&row.project_id, &row.path).unwrap(), Some(row));
    }

    #[test]
    fn 有效_wal_与损坏数据页同时存在时原文件字节不变() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("index.sqlite3");
        let index = Index::open(&path).unwrap();
        let page_size: i64 = index.lock().query_row("PRAGMA page_size", [], |row| row.get(0)).unwrap();
        let root_page: i64 = index
            .lock()
            .query_row("SELECT rootpage FROM sqlite_master WHERE name = 'files'", [], |row| row.get(0))
            .unwrap();
        index.lock().execute_batch("PRAGMA wal_checkpoint(TRUNCATE); PRAGMA wal_autocheckpoint = 0").unwrap();
        index.meta_set("wal_marker", "committed but not checkpointed").unwrap();
        let mut database = std::fs::read(&path).unwrap();
        // 保留有效 SQLite header，破坏 files B-tree 页；WAL 只含 meta 页，不能掩盖此损坏。
        let page_offset = usize::try_from((root_page - 1) * page_size).expect("valid files B-tree page offset");
        database[page_offset] = 0;
        std::fs::write(&path, &database).unwrap();
        let wal = std::fs::read(sidecar_path(&path, "-wal")).unwrap();
        let shm = std::fs::read(sidecar_path(&path, "-shm")).unwrap();
        assert!(!wal.is_empty());

        assert!(Index::open(&path).is_err());
        assert_eq!(std::fs::read(&path).unwrap(), database);
        assert_eq!(std::fs::read(sidecar_path(&path, "-wal")).unwrap(), wal);
        assert_eq!(std::fs::read(sidecar_path(&path, "-shm")).unwrap(), shm);
    }

    #[test]
    fn 锁定索引直接报错且不改名() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("index.sqlite3");
        drop(Index::open(&path).unwrap());
        let connection = Connection::open(&path).unwrap();
        connection.execute_batch("PRAGMA journal_mode = DELETE; BEGIN EXCLUSIVE;").unwrap();

        let error = match Index::open(&path) {
            Ok(_) => panic!("locked database must not rebuild"),
            Err(error) => error,
        };
        assert!(error.contains("locked"), "{error}");
        assert!(path.exists());
        assert!(
            std::fs::read_dir(directory.path()).unwrap().all(|entry| !entry
                .unwrap()
                .file_name()
                .to_string_lossy()
                .contains(".corrupt-"))
        );
    }

    fn file(path: &str, sha: &str) -> FileRow {
        FileRow {
            project_id: RemoteId::Number(1),
            path: path.to_string(),
            remote_file_id: Some(RemoteId::Number(10)),
            remote_version_id: Some(RemoteId::Text("v1".into())),
            sha256: Some(sha.to_string()),
            size: 3,
            mtime_ms: 1000,
            state: FileState::Synced,
            collab_active: false,
            read_only: false,
        }
    }

    #[test]
    fn files_读写与移动() {
        let index = Index::open_in_memory().unwrap();
        index.upsert_file(&file("a/b.txt", "s1")).unwrap();
        index.upsert_file(&file("a/c/d.txt", "s2")).unwrap();
        assert_eq!(index.get_file(&RemoteId::Number(1), "a/b.txt").unwrap().unwrap().sha256.as_deref(), Some("s1"));
        index.move_path(&RemoteId::Number(1), "a", "z").unwrap();
        let paths: Vec<_> = index.list_files(&RemoteId::Number(1)).unwrap().into_iter().map(|row| row.path).collect();
        assert_eq!(paths, vec!["z/b.txt", "z/c/d.txt"]);
        index.set_state(&RemoteId::Number(1), "z/b.txt", FileState::Conflict).unwrap();
        assert_eq!(index.count_state(FileState::Conflict).unwrap(), 1);
        index.delete_file(&RemoteId::Number(1), "z/b.txt").unwrap();
        assert!(index.get_file(&RemoteId::Number(1), "z/b.txt").unwrap().is_none());
    }

    /// 远端把文件移到一个本地已经有行的路径上 —— 从前直接 UPDATE 会撞
    /// `UNIQUE constraint failed: files.project_id, files.path`，整条根就此卡死。
    #[test]
    fn 移到已存在的路径上要覆盖而不是报错() {
        let index = Index::open_in_memory().unwrap();
        let project = RemoteId::Number(1);
        index.upsert_file(&file("旧.csv", "aaa")).unwrap();
        index.upsert_file(&file("新.csv", "bbb")).unwrap();

        index.move_path(&project, "旧.csv", "新.csv").unwrap();

        let paths: Vec<_> = index.list_files(&project).unwrap().into_iter().map(|row| row.path).collect();
        assert_eq!(paths, vec!["新.csv"], "被压在下面的那行销掉，不是两行并存");
        assert_eq!(
            index.get_file(&project, "新.csv").unwrap().unwrap().sha256.as_deref(),
            Some("aaa"),
            "留下的是移过来的那份"
        );
    }

    /// 目录移到已存在的目录上：整棵子树都要让位，否则前缀批量改名照样撞主键。
    #[test]
    fn 目录移到已存在的目录上要覆盖整棵子树() {
        let index = Index::open_in_memory().unwrap();
        let project = RemoteId::Number(1);
        index.upsert_file(&file("旧/a.txt", "aaa")).unwrap();
        index.upsert_file(&file("新/a.txt", "bbb")).unwrap();
        index.upsert_file(&file("新/b.txt", "ccc")).unwrap();

        index.move_path(&project, "旧", "新").unwrap();

        let paths: Vec<_> = index.list_files(&project).unwrap().into_iter().map(|row| row.path).collect();
        assert_eq!(paths, vec!["新/a.txt"]);
        assert_eq!(index.get_file(&project, "新/a.txt").unwrap().unwrap().sha256.as_deref(), Some("aaa"));
    }

    /// 原地不动不能把自己清掉。
    #[test]
    fn 移到原地是空操作() {
        let index = Index::open_in_memory().unwrap();
        let project = RemoteId::Number(1);
        index.upsert_file(&file("a.txt", "aaa")).unwrap();
        index.move_path(&project, "a.txt", "a.txt").unwrap();
        assert_eq!(index.get_file(&project, "a.txt").unwrap().unwrap().sha256.as_deref(), Some("aaa"));
    }

    #[test]
    fn roots_保留本地字段() {
        let index = Index::open_in_memory().unwrap();
        let root = RootRow {
            project_id: RemoteId::Number(5),
            project_key: "p5".into(),
            name: "专题".into(),
            kind: ProjectKind::Material,
            scope: ProjectScope::Dept,
            dept_name: Some("风控".into()),
            drive_path: "部门/风控部/资料库/专题".into(),
            node: Some("DEPT".into()),
            container: Some("MATERIAL".into()),
            node_path: Some("部门/风控部".into()),
            skills_path: None,
            sync_enabled: true,
            can_write: true,
            cloud_only: false,
            cursor: None,
            pinned: false,
            department_id: Some(RemoteId::Number(9)),
            owner_id: Some(RemoteId::Number(77)),
            is_mine: Some(false),
        };
        index.upsert_root(&root).unwrap();
        index.set_pinned(&RemoteId::Number(5), true).unwrap();
        index.set_cursor(&RemoteId::Number(5), "42").unwrap();
        index.upsert_root(&RootRow { name: "专题2".into(), ..root.clone() }).unwrap();
        let stored = index.get_root(&RemoteId::Number(5)).unwrap().unwrap();
        assert_eq!(stored.name, "专题2");
        assert!(stored.pinned);
        assert_eq!(stored.cursor.as_deref(), Some("42"));
        assert_eq!(stored.owner_id, Some(RemoteId::Number(77)));
        assert_eq!(stored.is_mine, Some(false));
        // 老服务端不给 isMine:存 NULL,读回来还是 None(不能变成 false)
        index.upsert_root(&RootRow { owner_id: None, is_mine: None, ..root.clone() }).unwrap();
        let stored = index.get_root(&RemoteId::Number(5)).unwrap().unwrap();
        assert_eq!(stored.owner_id, None);
        assert_eq!(stored.is_mine, None);
        assert!(index.set_pinned(&RemoteId::Number(6), true).is_err());
    }

    #[test]
    fn archive_sessions_读写() {
        let index = Index::open_in_memory().unwrap();
        assert_eq!(index.archive_count().unwrap(), 0);
        let row = ArchiveRow {
            uuid: "u1".into(),
            sha256: "s1".into(),
            remote_file_id: Some(RemoteId::Number(7)),
            remote_version_id: None,
            mtime_ms: 5,
            size: 9,
            cloud_path: "zhang/2026-09/x.jsonl".into(),
        };
        index.archive_upsert(&row).unwrap();
        index.archive_upsert(&ArchiveRow { sha256: "s2".into(), ..row.clone() }).unwrap();
        assert_eq!(index.archive_count().unwrap(), 1);
        assert_eq!(index.archive_get("u1").unwrap().unwrap().sha256, "s2");
        assert!(index.archive_get("nope").unwrap().is_none());
        index.clear_all().unwrap();
        assert_eq!(index.archive_count().unwrap(), 0);
    }

    #[test]
    fn v1_索引自动迁到最新版() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("index.sqlite3");
        let connection = Connection::open(&path).unwrap();
        connection
            .execute_batch(
                "CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                 INSERT INTO meta VALUES ('schema_version', '1');
                 CREATE TABLE files (project_id TEXT NOT NULL, path TEXT NOT NULL, remote_file_id TEXT, remote_version_id TEXT,
                    sha256 TEXT, size INTEGER NOT NULL DEFAULT 0, mtime INTEGER NOT NULL DEFAULT 0, state TEXT NOT NULL,
                    PRIMARY KEY (project_id, path));
                 INSERT INTO files VALUES ('1', 'a.md', '10', 'v1', 's', 3, 1000, 'synced');
                 CREATE TABLE roots (project_id TEXT PRIMARY KEY, project_key TEXT NOT NULL, name TEXT NOT NULL, kind TEXT NOT NULL,
                    scope TEXT NOT NULL, dept_name TEXT, drive_path TEXT NOT NULL, skills_path TEXT, sync_enabled INTEGER NOT NULL DEFAULT 1,
                    can_write INTEGER NOT NULL DEFAULT 1, cloud_only INTEGER NOT NULL DEFAULT 0, cursor TEXT, pinned INTEGER NOT NULL DEFAULT 0);",
            )
            .unwrap();
        drop(connection);
        let index = Index::open(&path).unwrap();
        assert_eq!(index.meta_get("schema_version").unwrap().as_deref(), Some(SCHEMA_VERSION.to_string().as_str()));
        assert!(index.list_roots().unwrap().is_empty());
        let row = index.get_file(&RemoteId::Number(1), "a.md").unwrap().unwrap();
        assert!(!row.collab_active);
        assert!(!row.read_only, "v1 的老行迁上来默认可写");
        index.set_collab_active(&RemoteId::Number(1), "a.md", true).unwrap();
        assert!(index.get_file(&RemoteId::Number(1), "a.md").unwrap().unwrap().collab_active);
        assert_eq!(index.archive_count().unwrap(), 0);
    }

    #[test]
    fn v2_索引自动迁到最新版() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("index.sqlite3");
        {
            let index = Index::open(&path).unwrap();
            index.meta_set("schema_version", "2").unwrap();
            index.lock().execute_batch("DROP TABLE archive_sessions;").unwrap();
        }
        let index = Index::open(&path).unwrap();
        assert_eq!(index.meta_get("schema_version").unwrap().as_deref(), Some(SCHEMA_VERSION.to_string().as_str()));
        assert_eq!(index.archive_count().unwrap(), 0);
    }

    #[test]
    fn v3_索引补上_owner_id_与_is_mine() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("index.sqlite3");
        {
            let index = Index::open(&path).unwrap();
            index.meta_set("schema_version", "3").unwrap();
            index
                .lock()
                .execute_batch("ALTER TABLE roots DROP COLUMN owner_id; ALTER TABLE roots DROP COLUMN is_mine;")
                .unwrap();
        }
        let index = Index::open(&path).unwrap();
        assert_eq!(index.meta_get("schema_version").unwrap().as_deref(), Some(SCHEMA_VERSION.to_string().as_str()));
        assert!(index.list_roots().unwrap().is_empty());
    }

    /// v4 → v5:roots 补 department_id、files 补 read_only。用户手上的库只有一次迁移机会,
    /// 迁失败就是「索引 schema 版本不一致」+ 整个云盘不工作。
    #[test]
    fn v4_索引补上_department_id_与_read_only() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("index.sqlite3");
        {
            let index = Index::open(&path).unwrap();
            index.meta_set("schema_version", "4").unwrap();
            index
                .lock()
                .execute_batch("ALTER TABLE roots DROP COLUMN department_id; ALTER TABLE files DROP COLUMN read_only;")
                .unwrap();
            index
                .lock()
                .execute(
                    "INSERT INTO files (project_id, path, sha256, size, mtime, state, collab_active)
                     VALUES ('1', 'a.md', 's', 3, 1000, 'synced', 0)",
                    [],
                )
                .unwrap();
        }
        let index = Index::open(&path).unwrap();
        assert_eq!(index.meta_get("schema_version").unwrap().as_deref(), Some(SCHEMA_VERSION.to_string().as_str()));
        let row = index.get_file(&RemoteId::Number(1), "a.md").unwrap().unwrap();
        assert!(!row.read_only, "老行迁上来默认可写,行为与加这个字段之前一致");
    }

    /// v5 → v6:多一张 `file_errors`。老库里那些已经卡在 error 的行没有对应记录 ——
    /// 而「没有记录」在 `engine::retry_due` 里就是「可以再试」,所以用户升上来的第一轮
    /// 就会把卡住的文件重新推一遍(2026-09-07 那台机器正是靠这一下解卡的)。
    #[test]
    fn v5_索引补上_file_errors() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("index.sqlite3");
        {
            let index = Index::open(&path).unwrap();
            index.meta_set("schema_version", "5").unwrap();
            index.lock().execute_batch("DROP TABLE file_errors;").unwrap();
            index.upsert_file(&FileRow { state: FileState::Error, ..file("卡住的.md", "s") }).unwrap();
        }
        let index = Index::open(&path).unwrap();
        assert_eq!(index.meta_get("schema_version").unwrap().as_deref(), Some(SCHEMA_VERSION.to_string().as_str()));
        assert_eq!(index.count_file_errors().unwrap(), 0);
        assert!(
            index.file_error(&RemoteId::Number(1), "卡住的.md").unwrap().is_none(),
            "老的 error 行没有记录 = 可以立刻再试"
        );
    }

    /// 失败记录的一生:落一条 → 次数往上叠(首次失败的时间不动)→ 传成功就销案。
    #[test]
    fn 失败记录累计次数并在成功后销案() {
        let index = Index::open_in_memory().unwrap();
        let project = RemoteId::Number(1);
        let row = FileErrorRow {
            project_id: project.clone(),
            path: "a/b.md".into(),
            state: FileState::Error,
            direction: SyncDirection::Upload,
            message: "PARENT_FOLDER_NOT_FOUND: 上级目录不存在: a（请先 MKDIR）".into(),
            attempts: 1,
            first_at_ms: 1000,
            last_at_ms: 1000,
            next_at_ms: 61000,
        };
        index.put_file_error(&row).unwrap();
        index
            .put_file_error(&FileErrorRow { attempts: 2, last_at_ms: 70000, next_at_ms: 190000, ..row.clone() })
            .unwrap();
        let stored = index.file_error(&project, "a/b.md").unwrap().unwrap();
        assert_eq!(
            (stored.attempts, stored.first_at_ms, stored.next_at_ms),
            (2, 1000, 190000),
            "首次失败的时间不该被后来的覆盖"
        );
        assert!(stored.message.contains("PARENT_FOLDER_NOT_FOUND"), "服务端原话要原样留住");
        assert_eq!(index.count_file_errors().unwrap(), 1);

        index.clear_file_error_backoff().unwrap();
        assert_eq!(
            index.file_error(&project, "a/b.md").unwrap().unwrap().next_at_ms,
            0,
            "「立刻重试」只清退避,不抹记录"
        );

        index.clear_file_error(&project, "a/b.md").unwrap();
        assert_eq!(index.count_file_errors().unwrap(), 0);
    }

    /// 文件行没了 / 改了名,失败记录不能留在原地 —— 留着就是一条指向空气的「没传上去」。
    #[test]
    fn 删除与改名带走失败记录() {
        let index = Index::open_in_memory().unwrap();
        let project = RemoteId::Number(1);
        let error = |path: &str| FileErrorRow {
            project_id: project.clone(),
            path: path.into(),
            state: FileState::Error,
            direction: SyncDirection::Upload,
            message: "boom".into(),
            attempts: 1,
            first_at_ms: 0,
            last_at_ms: 0,
            next_at_ms: 0,
        };
        index.upsert_file(&file("a.md", "s")).unwrap();
        index.put_file_error(&error("a.md")).unwrap();
        index.delete_file(&project, "a.md").unwrap();
        assert_eq!(index.count_file_errors().unwrap(), 0);

        index.upsert_file(&file("b.md", "s")).unwrap();
        index.put_file_error(&error("b.md")).unwrap();
        index.move_path(&project, "b.md", "c.md").unwrap();
        assert_eq!(index.count_file_errors().unwrap(), 0);
    }

    #[test]
    fn 磁盘索引可重开() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("drive").join("index.sqlite3");
        Index::open(&path).unwrap().upsert_file(&file("x.txt", "s")).unwrap();
        let reopened = Index::open(&path).unwrap();
        assert_eq!(reopened.list_all_files().unwrap().len(), 1);
        reopened.clear_all().unwrap();
        assert!(reopened.list_all_files().unwrap().is_empty());
    }
}

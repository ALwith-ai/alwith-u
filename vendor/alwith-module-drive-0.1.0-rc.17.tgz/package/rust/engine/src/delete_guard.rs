//! 批量删除安全阀(Dropbox 式「你删了很多文件,确认吗」)。
//!
//! 本地清空/误删一个项目文件夹时,所有**已下载**的文件会被逐个当成本地删除、一条 DELETE
//! 上行 —— 云端整个进回收站。占位 / 只读 / 未下载的行另有保护(见 `push_root_once` 里那圈
//! `continue`),这里只管「已下载、确实被删」这批净删除的**闸门**:
//!
//! - 净删除数达到阈值 = 疑似误删 → 本轮**不上行删除**,挂起并发事件让用户确认;
//! - 阈值以下的日常删除照旧即时上行(别把删几个也拦了);
//! - 用户确认 → 下一轮放行,真的删;
//! - 用户取消 → 把这批 path 交回引擎,从云端把它们拉回本地(误删 = 恢复)。
//!
//! 判定与状态机是纯逻辑,单独成模块便于单测(引擎侧只做「攒 path → 问闸门 → 按裁决办」)。

use std::collections::{HashMap, HashSet};

use crate::types::RemoteId;

/// 绝对阈值:一轮里净删除达到这个数,无论占比多少都拦。
pub const MASS_DELETE_ABS_THRESHOLD: usize = 10;
/// 占比判定的地板:再高的占比,只删了三两个也不算「批量」——否则 3 个文件的项目删掉 2 个
/// (日常操作)也会被拦。低于这个件数只看绝对阈值。
pub const MASS_DELETE_RATIO_MIN: usize = 4;

/// 这批净删除算不算「异常批量」。两条判据谁先满足都算,对安全阀取更保守(更早拦)的一侧:
/// - 绝对数 ≥ [`MASS_DELETE_ABS_THRESHOLD`];或
/// - 件数已达 [`MASS_DELETE_RATIO_MIN`] 且占已跟踪文件的一半以上。
pub fn is_mass_delete(deletes: usize, tracked: usize) -> bool {
    if deletes >= MASS_DELETE_ABS_THRESHOLD {
        return true;
    }
    deletes >= MASS_DELETE_RATIO_MIN && tracked > 0 && deletes * 2 >= tracked
}

#[derive(Debug, Clone)]
struct GuardEntry {
    /// 挂起时刻这批被拦下的删除 path(云端相对路径)。取消时按它从云端恢复。
    paths: Vec<String>,
    /// 用户已确认放行:下一轮 gate 不再拦,真的删。
    confirmed: bool,
}

/// 各项目的删除悬挂状态。**只在内存**:进程重启后清空,那批删除会在下一轮被重新检测、
/// 重新评估(重新提示)—— 比留一个「永远拦着」的持久态安全。
#[derive(Debug, Default)]
pub struct DeleteGuards {
    by_project: HashMap<RemoteId, GuardEntry>,
}

/// 闸门对一轮净删除的裁决。
#[derive(Debug, PartialEq, Eq)]
pub enum DeleteDecision {
    /// 照常删除这些 path(阈值以下的正常删除,或已确认放行的那批)。
    Proceed(Vec<String>),
    /// 本轮挂起、不上行删除。`first` = 是否**本轮首次**挂起(仅首次发提示事件,不每轮刷屏)。
    Hold { count: usize, first: bool },
}

impl DeleteGuards {
    /// 问闸门:这一轮某个 root 的净删除该不该上行。
    ///
    /// `deletes` 是本轮检测到的净删除 path 集合(已排除占位/只读/未下载/重命名移动)。
    /// `tracked` 是该 root 已跟踪的文件数(占比判据的分母)。
    pub fn gate(&mut self, project_id: &RemoteId, deletes: Vec<String>, tracked: usize) -> DeleteDecision {
        // 没有删除了:文件可能被恢复 / 用户撤销了删除,清掉悬挂,回到常态。
        if deletes.is_empty() {
            self.by_project.remove(project_id);
            return DeleteDecision::Proceed(deletes);
        }
        match self.by_project.get(project_id) {
            // 已确认:只放行**当初拦下的**那批仍然缺失的 path(其间被手动恢复的不删)。
            Some(entry) if entry.confirmed => {
                let allowed: HashSet<&String> = entry.paths.iter().collect();
                let proceed = deletes.into_iter().filter(|path| allowed.contains(path)).collect();
                self.by_project.remove(project_id);
                DeleteDecision::Proceed(proceed)
            }
            // 挂起中、还没确认:继续拦,不再发事件。
            Some(_) => DeleteDecision::Hold { count: deletes.len(), first: false },
            // 没有悬挂:够批量就挂起并请求确认,否则照常删。
            None => {
                if is_mass_delete(deletes.len(), tracked) {
                    let count = deletes.len();
                    self.by_project.insert(project_id.clone(), GuardEntry { paths: deletes, confirmed: false });
                    DeleteDecision::Hold { count, first: true }
                } else {
                    DeleteDecision::Proceed(deletes)
                }
            }
        }
    }

    /// 用户确认放行。返回是否真有一条悬挂被标记(没有则调用方无须触发同步)。
    pub fn confirm(&mut self, project_id: &RemoteId) -> bool {
        match self.by_project.get_mut(project_id) {
            Some(entry) => {
                entry.confirmed = true;
                true
            }
            None => false,
        }
    }

    /// 用户取消:丢弃悬挂,返回被保护的 path(调用方据此从云端恢复到本地)。
    pub fn cancel(&mut self, project_id: &RemoteId) -> Vec<String> {
        self.by_project.remove(project_id).map(|entry| entry.paths).unwrap_or_default()
    }

    /// 当前**还没确认**的悬挂:(项目, 件数)。供前端查询与状态展示。
    pub fn pending(&self) -> Vec<(RemoteId, usize)> {
        self.by_project
            .iter()
            .filter(|(_, entry)| !entry.confirmed)
            .map(|(id, entry)| (id.clone(), entry.paths.len()))
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn id(n: i64) -> RemoteId {
        RemoteId::Number(n)
    }

    fn paths(n: usize) -> Vec<String> {
        (0..n).map(|i| format!("dir/file{i}.md")).collect()
    }

    // ── 阈值触发 ──────────────────────────────────────────────────────────
    #[test]
    fn absolute_threshold_trips_regardless_of_ratio() {
        // 100 个里删 10 个 = 10% 占比,但绝对数到 10 就拦
        assert!(is_mass_delete(10, 100));
        assert!(!is_mass_delete(9, 100));
    }

    #[test]
    fn ratio_threshold_trips_on_smaller_roots() {
        // 8 个里删 5 个(>50%)且达到件数地板 → 拦
        assert!(is_mass_delete(5, 8));
        // 20 个删 10 个 = 恰好一半 → 拦
        assert!(is_mass_delete(10, 20));
    }

    #[test]
    fn everyday_small_deletes_do_not_trip() {
        // 3 个文件的项目删掉 2 个:占比虽高但没到件数地板,不拦
        assert!(!is_mass_delete(2, 3));
        // 100 个里删 3 个:日常操作,不拦
        assert!(!is_mass_delete(3, 100));
        // 一件删除永远不拦
        assert!(!is_mass_delete(1, 1));
    }

    // ── 挂起 ──────────────────────────────────────────────────────────────
    #[test]
    fn mass_delete_is_held_and_prompts_once() {
        let mut guards = DeleteGuards::default();
        let first = guards.gate(&id(1), paths(12), 20);
        assert_eq!(first, DeleteDecision::Hold { count: 12, first: true });
        // 下一轮仍检测到同样的删除:继续挂,但不再是「首次」(不重复发事件)
        let again = guards.gate(&id(1), paths(12), 20);
        assert_eq!(again, DeleteDecision::Hold { count: 12, first: false });
    }

    #[test]
    fn below_threshold_proceeds_immediately() {
        let mut guards = DeleteGuards::default();
        assert_eq!(guards.gate(&id(1), paths(2), 100), DeleteDecision::Proceed(paths(2)));
        assert!(guards.pending().is_empty());
    }

    // ── 确认放行 ────────────────────────────────────────────────────────────
    #[test]
    fn confirm_then_next_round_proceeds() {
        let mut guards = DeleteGuards::default();
        guards.gate(&id(1), paths(12), 20); // 挂起
        assert!(guards.confirm(&id(1)));
        // 确认后这一轮放行,且悬挂被清掉
        assert_eq!(guards.gate(&id(1), paths(12), 20), DeleteDecision::Proceed(paths(12)));
        assert!(guards.pending().is_empty());
    }

    #[test]
    fn confirm_only_releases_the_originally_held_paths() {
        let mut guards = DeleteGuards::default();
        guards.gate(&id(1), paths(12), 20);
        guards.confirm(&id(1));
        // 确认后,其中若干个已被用户手动恢复(不在本轮删除集里),放行集只含仍缺失的
        let mut still_missing = paths(12);
        still_missing.truncate(8);
        assert_eq!(guards.gate(&id(1), still_missing.clone(), 20), DeleteDecision::Proceed(still_missing));
    }

    #[test]
    fn confirm_without_pending_reports_false() {
        let mut guards = DeleteGuards::default();
        assert!(!guards.confirm(&id(99)));
    }

    // ── 取消回滚 ────────────────────────────────────────────────────────────
    #[test]
    fn cancel_returns_held_paths_for_restore_and_clears() {
        let mut guards = DeleteGuards::default();
        guards.gate(&id(1), paths(12), 20);
        let restore = guards.cancel(&id(1));
        assert_eq!(restore, paths(12)); // 交回这批 path,引擎据此从云端恢复
        assert!(guards.pending().is_empty());
        // 取消后再来一轮:悬挂已清,同一批删除会被重新评估(重新挂起提示),不会静默删掉
        assert_eq!(guards.gate(&id(1), paths(12), 20), DeleteDecision::Hold { count: 12, first: true });
    }

    #[test]
    fn empty_deletes_clear_a_stale_hold() {
        let mut guards = DeleteGuards::default();
        guards.gate(&id(1), paths(12), 20);
        // 用户把误删的文件都拖回来了 → 本轮没有净删除 → 悬挂自动清除
        assert_eq!(guards.gate(&id(1), Vec::new(), 20), DeleteDecision::Proceed(Vec::new()));
        assert!(guards.pending().is_empty());
    }

    #[test]
    fn pending_lists_only_unconfirmed() {
        let mut guards = DeleteGuards::default();
        guards.gate(&id(1), paths(12), 20);
        guards.gate(&id(2), paths(11), 20);
        guards.confirm(&id(2));
        let pending = guards.pending();
        assert_eq!(pending.len(), 1);
        assert_eq!(pending[0], (id(1), 12));
    }
}

//! 「清理未选中的本地副本」:把已落盘、但当前不在同步选择集里的项目目录挪走。
//!
//! 为什么需要:归属兜底防线(见 `engine::LEGACY_PERSONAL_ROOT_LIMIT`)只能拦住「以后别再拉」,
//! 拦不住已经落在磁盘上的。2026-09-04 生产联调里管理员账号的 `~/YUP Drive/我的空间/` 下真的落了
//! 279 个同事的个人知识库 —— 防线上线后它们不再被同步,但目录还堆在那儿,得给用户一个入口收拾。
//!
//! 三条硬规矩:
//! - **移动不是删除**:一律挪到 `<本地根>/../YUP Drive 暂存/`,保持原有的相对层级,想恢复直接挪回去;
//! - **已固定的不动**:用户自己固定过的项目,哪怕当前不在同步范围内(如服务端把 `syncEnabled` 关了)也跳过;
//! - **有未上传改动的不动**:目录里但凡有一处还没上行的本地改动(新文件 / 改过的文件 / 本地删除 /
//!   索引里 pending、uploading、冲突、出错的行),就跳过,并在结果里说明跳过了几个、为什么。
//!
//! 判「有没有未上传改动」不算 sha256:引擎自己的增量口径就是 (mtime, size),这里同一口径 ——
//! 几百个目录的扫描不该把用户的磁盘读一遍。

use std::path::{Path, PathBuf};

use walkdir::WalkDir;

use crate::engine::{Engine, EngineError};
use crate::ignore::{IgnoreRules, Verdict};
use crate::index::FileRow;
use crate::naming::{is_cloud_only_placeholder, local_to_cloud_relative};
use crate::scanner::file_mtime_ms;
use crate::types::{CleanupEntry, CleanupReport, CleanupSkipReason, CleanupSkipped, FileState, RemoteId};

/// 暂存目录:与本地根同级,`<本地根>/../YUP Drive 暂存`。
pub const STAGING_DIR_NAME: &str = "YUP Drive 暂存";

/// 这一行在磁盘上应该有一个对应的普通文件(占位、忽略、超阈值、服务端拒收的都不算)。
fn tracked_on_disk(row: &FileRow) -> bool {
    matches!(row.state, FileState::Synced | FileState::Collab)
}

/// 索引里就明写着还没上行完的状态。
fn unpushed_state(state: FileState) -> bool {
    matches!(state, FileState::Pending | FileState::Uploading | FileState::Conflict | FileState::Error)
}

/// 目标目录已被占用就加 ` (2)` / ` (3)`…… —— 清理跑第二遍时不能覆盖上一遍挪过去的。
fn free_destination(base: &Path) -> PathBuf {
    if !base.exists() {
        return base.to_path_buf();
    }
    let parent = base.parent().map(Path::to_path_buf).unwrap_or_default();
    let name = base.file_name().map(|name| name.to_string_lossy().to_string()).unwrap_or_else(|| "project".into());
    for index in 2..1000 {
        let candidate = parent.join(format!("{name} ({index})"));
        if !candidate.exists() {
            return candidate;
        }
    }
    parent.join(format!("{name} ({})", chrono::Local::now().format("%Y%m%d-%H%M%S")))
}

fn count_files(dir: &Path) -> u32 {
    WalkDir::new(dir)
        .follow_links(false)
        .into_iter()
        .filter_map(Result::ok)
        .filter(|entry| entry.file_type().is_file())
        .count() as u32
}

impl Engine {
    /// `<本地根>/../YUP Drive 暂存`。本地根没有父目录(理论上不会)就退回到根内部,总之不越界。
    pub fn cleanup_staging_dir(&self) -> PathBuf {
        match self.config().local_root.parent() {
            Some(parent) => parent.join(STAGING_DIR_NAME),
            None => self.config().local_root.join(STAGING_DIR_NAME),
        }
    }

    /// 扫描:列出可以挪走的目录与必须跳过的目录。只读,不动磁盘。
    pub fn cleanup_scan(&self) -> Result<CleanupReport, EngineError> {
        self.cleanup(false)
    }

    /// 执行:把扫描出来的目录挪到暂存目录。跳过规则与 `cleanup_scan` 完全一致(执行前重算一遍,
    /// 用户在确认对话框上犹豫的这段时间里改了文件也拦得住)。
    pub fn cleanup_unselected(&self) -> Result<CleanupReport, EngineError> {
        self.cleanup(true)
    }

    fn cleanup(&self, apply: bool) -> Result<CleanupReport, EngineError> {
        let staging = self.cleanup_staging_dir();
        let mut report =
            CleanupReport { staging_dir: staging.to_string_lossy().to_string(), ..CleanupReport::default() };
        for root in self.roots()? {
            if root.selected {
                continue;
            }
            let dir = PathBuf::from(&root.local_path);
            if !dir.is_dir() {
                continue;
            }
            let skip = |reason: CleanupSkipReason| CleanupSkipped {
                name: root.name.clone(),
                drive_path: root.drive_path.clone(),
                local_path: root.local_path.clone(),
                reason,
            };
            if root.pinned {
                report.skipped.push(skip(CleanupSkipReason::Pinned));
                continue;
            }
            if self.has_unpushed_changes(&root.project_id, &dir)? {
                report.skipped.push(skip(CleanupSkipReason::PendingChanges));
                continue;
            }
            let entry = CleanupEntry {
                project_id: root.project_id.clone(),
                name: root.name.clone(),
                drive_path: root.drive_path.clone(),
                local_path: root.local_path.clone(),
                files: count_files(&dir),
            };
            report.candidates.push(entry.clone());
            if !apply {
                continue;
            }
            match self.move_to_staging(&dir, &staging) {
                Ok(()) => {
                    // 目录不在了,索引里那份「已同步」的记忆也不能留:以后被固定要从 snapshot 重来
                    self.index.forget_project_files(&entry.project_id).map_err(EngineError::Index)?;
                    report.moved.push(entry);
                }
                Err(error) => report.failed.push(format!("{}: {error}", entry.drive_path)),
            }
        }
        Ok(report)
    }

    pub(crate) fn move_to_staging(&self, dir: &Path, staging: &Path) -> Result<(), String> {
        let relative = dir.strip_prefix(&self.config().local_root).unwrap_or_else(|_| Path::new(""));
        let target = if relative.as_os_str().is_empty() {
            staging.join(dir.file_name().unwrap_or_default())
        } else {
            staging.join(relative)
        };
        let target = free_destination(&target);
        if let Some(parent) = target.parent() {
            std::fs::create_dir_all(parent).map_err(|error| format!("创建 {} 失败: {error}", parent.display()))?;
        }
        std::fs::rename(dir, &target).map_err(|error| format!("移到 {} 失败: {error}", target.display()))
    }

    /// 目录里有没有还没上行的本地改动。判据与引擎上行一致:(mtime, size) 对不上就是改过了。
    fn has_unpushed_changes(&self, project_id: &RemoteId, dir: &Path) -> Result<bool, EngineError> {
        let rows = self.index.file_map(project_id).map_err(EngineError::Index)?;
        if rows.values().any(|row| unpushed_state(row.state)) {
            return Ok(true);
        }
        let rules = IgnoreRules::load(dir).map_err(EngineError::Io)?;
        let windows_names = self.config().windows_names;
        let mut matched = 0usize;
        let mut walker = WalkDir::new(dir).follow_links(false).into_iter();
        while let Some(entry) = walker.next() {
            let entry = entry.map_err(|error| EngineError::Io(format!("遍历 {} 失败: {error}", dir.display())))?;
            if entry.depth() == 0 {
                continue;
            }
            let relative = entry.path().strip_prefix(dir).expect("walkdir entry is under dir");
            if entry.file_type().is_dir() {
                if rules.is_ignored(relative, true) {
                    walker.skip_current_dir();
                }
                continue;
            }
            if !entry.file_type().is_file() || is_cloud_only_placeholder(relative) {
                continue;
            }
            let metadata = entry
                .metadata()
                .map_err(|error| EngineError::Io(format!("stat {} 失败: {error}", entry.path().display())))?;
            if rules.classify(relative, metadata.len()) != Verdict::Sync {
                continue;
            }
            let cloud_path = local_to_cloud_relative(relative, windows_names);
            match rows.get(&cloud_path) {
                // 从来没上过云的文件(新建的、冲突副本……)
                None => return Ok(true),
                Some(row) if !tracked_on_disk(row) => continue,
                Some(row) if row.mtime_ms != file_mtime_ms(&metadata) || row.size != metadata.len() => return Ok(true),
                Some(_) => matched += 1,
            }
        }
        // 索引里有、磁盘上没有 → 本地删了还没上行
        Ok(matched < rows.values().filter(|row| tracked_on_disk(row)).count())
    }
}

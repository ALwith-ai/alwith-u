//! 6.1 SSO:授权码 + PKCE。
//!
//! 流程:`GET /auth/sso/config` → 生成 code_verifier / challenge / state → 在 127.0.0.1 随机端口起
//! 一次性回调监听 → 系统浏览器打开 authorizationEndpoint → 浏览器 302 到 `/callback?code&state` →
//! 用 code + verifier 换 id_token → `POST /auth/sso/exchange` 换设备 token。
//!
//! 浏览器怎么打开由调用方注入(`open`),这里不依赖 Tauri。

use std::time::Duration;

use base64::Engine as _;
use base64::engine::general_purpose::URL_SAFE_NO_PAD;
use rand::Rng as _;
use serde::Deserialize;
use sha2::{Digest, Sha256};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpListener;

use crate::client::{ClientError, DriveClient};
use crate::types::{SsoConfig, SsoExchangeRequest, SsoExchangeResponse};

pub const CALLBACK_PATH: &str = "/callback";
/// 浏览器里完成登录的最长等待。
pub const LOGIN_TIMEOUT: Duration = Duration::from_secs(5 * 60);

#[derive(Debug, Clone, thiserror::Error)]
pub enum SsoError {
    #[error("服务端未启用 SSO")]
    Disabled,
    #[error("SSO 配置缺 {0}")]
    MissingConfig(&'static str),
    #[error("回调地址 http://127.0.0.1:*{CALLBACK_PATH} 不在服务端 redirectUris 里: {0:?}")]
    RedirectNotAllowed(Vec<String>),
    #[error("回调 {0}")]
    Callback(String),
    #[error("等待浏览器登录超时")]
    Timeout,
    #[error("打开浏览器失败: {0}")]
    Open(String),
    #[error("换取 token 失败: {0}")]
    TokenExchange(String),
    #[error(transparent)]
    Client(#[from] ClientError),
    #[error("{0}")]
    Io(String),
}

// ─── PKCE ─────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Pkce {
    pub verifier: String,
    pub challenge: String,
}

/// RFC 7636:verifier 是 32 字节随机数的 base64url(43 字符),challenge = base64url(sha256(verifier))。
pub fn generate_pkce() -> Pkce {
    let mut bytes = [0u8; 32];
    rand::rng().fill_bytes(&mut bytes);
    let verifier = URL_SAFE_NO_PAD.encode(bytes);
    Pkce { challenge: challenge_for(&verifier), verifier }
}

pub fn challenge_for(verifier: &str) -> String {
    URL_SAFE_NO_PAD.encode(Sha256::digest(verifier.as_bytes()))
}

pub fn random_state() -> String {
    let mut bytes = [0u8; 16];
    rand::rng().fill_bytes(&mut bytes);
    URL_SAFE_NO_PAD.encode(bytes)
}

// ─── 授权地址 ─────────────────────────────────────────────────────────────

/// 服务端 redirectUris 必须含 `http://127.0.0.1:*/callback` 通配(或本次端口的精确地址)。
pub fn redirect_allowed(config: &SsoConfig, redirect_uri: &str) -> bool {
    config.redirect_uris.iter().any(|allowed| {
        allowed == redirect_uri
            || allowed
                .split_once('*')
                .is_some_and(|(prefix, suffix)| redirect_uri.starts_with(prefix) && redirect_uri.ends_with(suffix))
    })
}

pub fn authorization_url(
    config: &SsoConfig, redirect_uri: &str, state: &str, challenge: &str,
) -> Result<String, SsoError> {
    if !config.enabled {
        return Err(SsoError::Disabled);
    }
    let endpoint = config.authorization_endpoint.as_deref().ok_or(SsoError::MissingConfig("authorizationEndpoint"))?;
    let client_id = config.client_id.as_deref().ok_or(SsoError::MissingConfig("clientId"))?;
    if !redirect_allowed(config, redirect_uri) {
        return Err(SsoError::RedirectNotAllowed(config.redirect_uris.clone()));
    }
    let scope = if config.scopes.is_empty() { "openid profile email".to_string() } else { config.scopes.join(" ") };
    let query = form_urlencoded::Serializer::new(String::new())
        .append_pair("response_type", "code")
        .append_pair("client_id", client_id)
        .append_pair("redirect_uri", redirect_uri)
        .append_pair("scope", &scope)
        .append_pair("state", state)
        .append_pair("code_challenge", challenge)
        .append_pair("code_challenge_method", "S256")
        .finish();
    let separator = if endpoint.contains('?') { '&' } else { '?' };
    Ok(format!("{endpoint}{separator}{query}"))
}

// ─── 回调解析 ─────────────────────────────────────────────────────────────

/// 从 HTTP 请求头(至少第一行)解析授权码;state 不符 / 带 error / 缺 code 都报错。
pub fn parse_callback_request(request_head: &str, expected_state: &str) -> Result<String, SsoError> {
    let request_line = request_head.lines().next().ok_or_else(|| SsoError::Callback("空请求".to_string()))?;
    let target = request_line
        .split_whitespace()
        .nth(1)
        .ok_or_else(|| SsoError::Callback(format!("请求行不合法: {request_line}")))?;
    let (path, query) = target.split_once('?').unwrap_or((target, ""));
    if path != CALLBACK_PATH {
        return Err(SsoError::Callback(format!("路径 {path} 不是 {CALLBACK_PATH}")));
    }
    let params: Vec<(String, String)> = form_urlencoded::parse(query.as_bytes()).into_owned().collect();
    let get = |key: &str| params.iter().find(|(name, _)| name == key).map(|(_, value)| value.as_str());
    if let Some(error) = get("error") {
        let description = get("error_description").unwrap_or("");
        return Err(SsoError::Callback(format!("{error} {description}").trim().to_string()));
    }
    if get("state") != Some(expected_state) {
        return Err(SsoError::Callback("state 不匹配".to_string()));
    }
    match get("code") {
        Some(code) if !code.is_empty() => Ok(code.to_string()),
        _ => Err(SsoError::Callback("缺 code".to_string())),
    }
}

const SUCCESS_HTML: &str = "<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\"><title>登录成功</title></head>\
<body style=\"font-family:system-ui;padding:40px\"><p>登录成功,可以关闭此页面回到 ALwith。</p></body></html>";
const ERROR_HTML: &str = "<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\"><title>登录失败</title></head>\
<body style=\"font-family:system-ui;padding:40px\"><p>登录失败,请回到 ALwith 重试。</p></body></html>";

/// 127.0.0.1 随机端口上的一次性回调监听。
pub struct LoopbackListener {
    listener: TcpListener,
    port: u16,
}

impl LoopbackListener {
    pub async fn bind() -> Result<Self, SsoError> {
        let listener = TcpListener::bind("127.0.0.1:0")
            .await
            .map_err(|error| SsoError::Io(format!("绑定回调端口失败: {error}")))?;
        let port = listener.local_addr().map_err(|error| SsoError::Io(error.to_string()))?.port();
        Ok(Self { listener, port })
    }

    pub fn port(&self) -> u16 {
        self.port
    }

    pub fn redirect_uri(&self) -> String {
        format!("http://127.0.0.1:{}{CALLBACK_PATH}", self.port)
    }

    /// 接一个连接、解析、回一页 HTML。浏览器可能先来一个 favicon 之类的无关请求,
    /// 非回调路径回 404 后继续等,直到拿到 code、拿到明确错误或超时。
    pub async fn wait_for_code(self, expected_state: &str, timeout: Duration) -> Result<String, SsoError> {
        let deadline = tokio::time::Instant::now() + timeout;
        loop {
            let accept =
                tokio::time::timeout_at(deadline, self.listener.accept()).await.map_err(|_| SsoError::Timeout)?;
            let (mut stream, _) = accept.map_err(|error| SsoError::Io(format!("接受回调连接失败: {error}")))?;
            let mut buffer = vec![0u8; 16 * 1024];
            let read =
                stream.read(&mut buffer).await.map_err(|error| SsoError::Io(format!("读回调请求失败: {error}")))?;
            let head = String::from_utf8_lossy(&buffer[..read]).to_string();
            let parsed = parse_callback_request(&head, expected_state);
            let not_callback =
                matches!(&parsed, Err(SsoError::Callback(message)) if message.contains("不是 /callback"));
            let (status, body) = match &parsed {
                Ok(_) => ("200 OK", SUCCESS_HTML),
                Err(_) if not_callback => ("404 Not Found", ""),
                Err(_) => ("400 Bad Request", ERROR_HTML),
            };
            let response = format!(
                "HTTP/1.1 {status}\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",
                body.len()
            );
            let _ = stream.write_all(response.as_bytes()).await;
            let _ = stream.shutdown().await;
            if not_callback {
                continue;
            }
            return parsed;
        }
    }
}

// ─── token 交换 ───────────────────────────────────────────────────────────

#[derive(Debug, Clone, Deserialize)]
pub struct OidcTokens {
    pub id_token: String,
    #[serde(default)]
    pub access_token: Option<String>,
}

#[derive(Debug, Deserialize)]
struct OidcTokenError {
    error: String,
    #[serde(default)]
    error_description: Option<String>,
}

/// 授权码换 id_token(公开客户端,靠 PKCE,不带 client_secret)。
pub async fn exchange_code(
    http: &reqwest::Client, token_endpoint: &str, client_id: &str, code: &str, verifier: &str, redirect_uri: &str,
) -> Result<OidcTokens, SsoError> {
    let body = form_urlencoded::Serializer::new(String::new())
        .append_pair("grant_type", "authorization_code")
        .append_pair("client_id", client_id)
        .append_pair("code", code)
        .append_pair("redirect_uri", redirect_uri)
        .append_pair("code_verifier", verifier)
        .finish();
    let response = http
        .post(token_endpoint)
        .header("content-type", "application/x-www-form-urlencoded")
        .header("accept", "application/json")
        .body(body)
        .send()
        .await
        .map_err(|error| SsoError::TokenExchange(error.to_string()))?;
    let status = response.status();
    let text = response.text().await.map_err(|error| SsoError::TokenExchange(error.to_string()))?;
    if !status.is_success() {
        let message = match serde_json::from_str::<OidcTokenError>(&text) {
            Ok(error) => format!("{} {}", error.error, error.error_description.unwrap_or_default()).trim().to_string(),
            Err(_) => text,
        };
        return Err(SsoError::TokenExchange(format!("HTTP {status}: {message}")));
    }
    serde_json::from_str(&text).map_err(|error| SsoError::TokenExchange(format!("响应格式错误: {error}; body={text}")))
}

/// 本设备在 exchange 里的自描述;带 device_name 服务端就顺手注册设备并返回设备 token。
#[derive(Debug, Clone)]
pub struct DeviceDescriptor {
    pub device_name: String,
    pub platform: String,
    pub client_version: String,
}

/// 完整一次 SSO 登录。`open` 负责用系统浏览器打开地址。
pub async fn login(
    client: &DriveClient, device: DeviceDescriptor, open: impl FnOnce(&str) -> Result<(), String>, timeout: Duration,
) -> Result<SsoExchangeResponse, SsoError> {
    let config = client.sso_config().await?;
    if !config.enabled {
        return Err(SsoError::Disabled);
    }
    let token_endpoint = config.token_endpoint.clone().ok_or(SsoError::MissingConfig("tokenEndpoint"))?;
    let client_id = config.client_id.clone().ok_or(SsoError::MissingConfig("clientId"))?;
    let pkce = generate_pkce();
    let state = random_state();
    let listener = LoopbackListener::bind().await?;
    let redirect_uri = listener.redirect_uri();
    let url = authorization_url(&config, &redirect_uri, &state, &pkce.challenge)?;
    open(&url).map_err(SsoError::Open)?;
    let code = listener.wait_for_code(&state, timeout).await?;
    let http = reqwest::Client::builder().build().expect("reqwest client builds");
    let tokens = exchange_code(&http, &token_endpoint, &client_id, &code, &pkce.verifier, &redirect_uri).await?;
    let response = client
        .sso_exchange(&SsoExchangeRequest {
            id_token: tokens.id_token,
            access_token: tokens.access_token,
            device_name: Some(device.device_name),
            platform: Some(device.platform),
            client_version: Some(device.client_version),
        })
        .await?;
    Ok(response)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn config() -> SsoConfig {
        SsoConfig {
            enabled: true,
            issuer: Some("https://sso.example.com/realms/yup".into()),
            client_id: Some("alwith".into()),
            authorization_endpoint: Some("https://sso.example.com/realms/yup/protocol/openid-connect/auth".into()),
            token_endpoint: Some("https://sso.example.com/realms/yup/protocol/openid-connect/token".into()),
            redirect_uris: vec!["http://127.0.0.1:*/callback".into(), "https://kb.example.com/sso/callback".into()],
            scopes: vec!["openid".into(), "profile".into(), "email".into()],
        }
    }

    #[test]
    fn pkce_是_43_字符_base64url_且_challenge_是_sha256() {
        let pkce = generate_pkce();
        assert_eq!(pkce.verifier.len(), 43);
        assert!(pkce.verifier.chars().all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_'));
        assert_eq!(pkce.challenge, challenge_for(&pkce.verifier));
        assert_ne!(generate_pkce().verifier, pkce.verifier);
        // RFC 7636 附录 B 的样例
        assert_eq!(
            challenge_for("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk"),
            "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM"
        );
    }

    #[test]
    fn 授权地址带全部_pkce_参数() {
        let url = authorization_url(&config(), "http://127.0.0.1:4321/callback", "st", "ch").unwrap();
        assert!(url.starts_with(
            "https://sso.example.com/realms/yup/protocol/openid-connect/auth?response_type=code&client_id=alwith&"
        ));
        assert!(url.contains("redirect_uri=http%3A%2F%2F127.0.0.1%3A4321%2Fcallback"));
        assert!(url.contains("scope=openid+profile+email"));
        assert!(url.contains("state=st&code_challenge=ch&code_challenge_method=S256"));
    }

    #[test]
    fn 回调通配不匹配时拒绝() {
        let mut config = config();
        config.redirect_uris = vec!["https://kb.example.com/sso/callback".into()];
        assert!(matches!(
            authorization_url(&config, "http://127.0.0.1:4321/callback", "st", "ch"),
            Err(SsoError::RedirectNotAllowed(_))
        ));
        assert!(matches!(
            authorization_url(&SsoConfig { enabled: false, ..self::tests::config() }, "x", "s", "c"),
            Err(SsoError::Disabled)
        ));
    }

    #[test]
    fn 回调解析() {
        assert_eq!(
            parse_callback_request("GET /callback?code=abc&state=st HTTP/1.1\r\nHost: x\r\n\r\n", "st").unwrap(),
            "abc"
        );
        assert_eq!(parse_callback_request("GET /callback?state=st&code=a%2Fb HTTP/1.1", "st").unwrap(), "a/b");
        assert!(
            matches!(parse_callback_request("GET /callback?code=abc&state=other HTTP/1.1", "st"), Err(SsoError::Callback(m)) if m.contains("state"))
        );
        assert!(
            matches!(parse_callback_request("GET /callback?state=st HTTP/1.1", "st"), Err(SsoError::Callback(m)) if m.contains("code"))
        );
        assert!(matches!(
            parse_callback_request("GET /callback?error=access_denied&error_description=nope&state=st HTTP/1.1", "st"),
            Err(SsoError::Callback(m)) if m == "access_denied nope"
        ));
        assert!(
            matches!(parse_callback_request("GET /favicon.ico HTTP/1.1", "st"), Err(SsoError::Callback(m)) if m.contains("不是 /callback"))
        );
    }

    #[test]
    fn scopes_接受字符串或数组() {
        let text: SsoConfig = serde_json::from_str(r#"{"enabled":true,"scopes":"openid email"}"#).unwrap();
        assert_eq!(text.scopes, vec!["openid", "email"]);
        let list: SsoConfig = serde_json::from_str(r#"{"enabled":true,"scopes":["openid"]}"#).unwrap();
        assert_eq!(list.scopes, vec!["openid"]);
        let none: SsoConfig = serde_json::from_str(r#"{"enabled":false}"#).unwrap();
        assert!(none.scopes.is_empty());
    }
}

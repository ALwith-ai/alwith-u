//! 把云盘镜像下来的 SKILL 项目**摊平**成 alwith-cli 能扫到、能叫得出名字的一层。
//!
//! CLI 的 `loadSkillsFromSkillsDir` 只认 `~/.alwith/skills/<目录名>/SKILL.md`,**不递归**;
//! 而云盘把 SKILL 项目镜像成 `<skills_dir>/.yup-drive/<projectKey>/<子目录>/…/SKILL.md`,
//! 深了至少一层。于是各部门按规范写好 skill、传进自己的 Skill 库、云盘也确实同步下来了,
//! **一个都不会生效,而且没有任何报错** —— 这是最坏的一种失败:看起来全都成功了。
//!
//! 几个定死的判断,理由写在这里,别在别处再猜一遍:
//!
//! **目录名 = skill 自报的 `name:`,不加项目前缀。** 2026-09-08 更正:这里原先拼的是
//! `<项目名>-<skill 名>`,理由是「顺便说清这条规范是哪个部门的」。那个理由建立在一个错误前提上 ——
//! 以为目录名只是给人看的。翻 CLI 源码(`src/skills/loadSkillsDir.ts`)才发现
//! `const skillName = entry.name`,**目录名就是 skill 的名字、就是斜杠命令**。
//! 装成 `公司-Skill-库-kb-condense`,用户敲 `/kb-condense` 敲不到它,基座 frontmatter 里
//! 那句「触发:/kb-condense」和别的 skill 里那句「用 kb-condense」全都指向一个不存在的东西。
//! 名字必须听 skill 自己的:`SKILL.md` frontmatter 里的 `name:`,拿不到才退回目录/文件名
//! (真机上那三份的层级是 `YUP专题分析规范/YUP专题分析插件_不要改动/skill/`,
//! 拿目录名拼出来又长又没信息,而 frontmatter 里写的是干净的 `yup-topic-analysis-standards`)。
//!
//! 丢掉前缀就丢掉了它挡过的那次事故:镜像里那份自报 `name: yup-kb`,而
//! `~/.alwith/skills/yup-kb/` 已经有一份用户手工装的同名 skill。**那种情况现在按下面这条走 ——
//! 跳过并报出来,绝不覆盖。** 少装一份、让人去处理,比装上一个叫错名字的强。
//!
//! **重名一律拒绝后到的,绝不覆盖。** 两份 skill 自报同一个名字时,按 (项目, 形态, 路径) 排序
//! 取第一个,第二个记一条冲突交给设置页去说。「后到的覆盖先到的」等于一个部门的 skill 悄悄
//! 替换掉另一个部门的,那比装不上更危险。同名时**目录形态优先于单文件形态** —— 目录里可能
//! 还带着 references/ 之类的附件,丢了是静默丢文件;单文件丢掉只是丢一份正文的重复。
//!
//! **部门补充(overlay)不单独上架,拼进基座。** 公司 Skill 库放基座 `X`,每个部门的 Skill 库
//! 放一份同名 `X-overlay`(《如何写部门补充》:一个部门只留一份)。装的时候 overlay 不占一个
//! 目录 —— AI 那份「货架清单」有总长度预算、全公司共享,多一条就挤掉别人一条,而 overlay
//! 本身也不是能被调用的东西。它的正文追加到基座末尾,前面加一条分隔线和
//! `# 部门补充：<部门名>`。**只有 overlay 没有基座时跳过并报出来** —— 一个孤零零的
//! 「补充」装上去,AI 会拿着半套规则当全套用。
//!
//! **只碰自己装的。** 每个摊平出来的目录里放一个 `.yup-drive-source` 标记,记着来源与内容指纹。
//! 没有标记的目录一律不删不改不覆盖 —— 用户手工放在 `~/.alwith/skills/` 下的东西是他自己的。
//! 目标目录已经被一个**没有标记**的目录占着时,也记一条冲突,绝不动它。
//!
//! **删除与权限收回自动跟随。** 每轮同步后重算一遍「应该有哪些」,带标记但不在这一份清单里的
//! 目录直接删掉。项目里删掉一份 skill、整个项目被取消同步、权限被收回导致镜像清空,
//! 三种情况都会让它从清单里消失,于是本地那份跟着消失 —— 不会留着继续生效。
//!
//! **一份装不上不许带走整批。** 每一步失败都只影响当前这一份:记一条冲突、接着装下一个。
//!
//! 为什么是**复制**不是软链:Windows 建软链要额外权限,而 CLI 那边会不会跟随软链不由我们决定。
//! skill 都很小,复制换来的是「在哪台机器上都一样」。内容指纹没变就整个跳过,不做无谓的写盘。

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

/// 摊平目录里的来源标记。CLI 只找 `SKILL.md`,多一个点开头的文件不影响它。
pub const MARKER_FILE: &str = ".yup-drive-source";
/// CLI 认的入口文件名。
pub const SKILL_ENTRY: &str = "SKILL.md";
/// 部门补充的名字后缀(《如何写部门补充》定的:`kb-condense-overlay`)。
pub const OVERLAY_SUFFIX: &str = "-overlay";

/// 拆出最前面那个 frontmatter 块:返回 (块内文本, 块之后的正文)。
///
/// 按行判断闭合的 `---`,不用 `find("\n---")` —— 正文里一条 `----` 分隔线会把块吃穿。
fn split_front(text: &str) -> Option<(&str, &str)> {
    let rest = text.strip_prefix("---\n").or_else(|| text.strip_prefix("---\r\n"))?;
    let mut offset = 0usize;
    for line in rest.split_inclusive('\n') {
        if line.trim_end() == "---" {
            return Some((&rest[..offset], &rest[offset + line.len()..]));
        }
        offset += line.len();
    }
    None
}

fn name_in_front(block: &str) -> Option<String> {
    for line in block.lines() {
        let Some(value) = line.trim().strip_prefix("name:") else { continue };
        let value = value.trim().trim_matches(['"', '\'']).trim();
        if !value.is_empty() {
            return Some(value.to_string());
        }
    }
    None
}

/// `SKILL.md` frontmatter 里的 `name:`。只认最前面那段 `---` 围起来的部分,
/// 拿不到就回 None(调用方退回目录名)—— 猜一个名字比没有名字更糟。
pub fn declared_name(skill_md: &str) -> Option<String> {
    let (front, _) = split_front(skill_md)?;
    name_in_front(front)
}

/// 服务端把 Skill 库里的**单文件** skill 同步下来时,会在正文前面再套一层元数据 frontmatter
/// (`name` / `description` / `ai-loadable`),于是文件里叠着两个 `---` 块 —— 真机上
/// `.yup-drive/skill-company/kb-condense.md` 就是这样。CLI 只解析最前面那一个,拿到的是被
/// 截短的 description,而且 `allowed-tools`、`argument-hint` 这些全丢了。
///
/// **两块都自报同一个 `name:` 时**才剥掉外层。条件卡这么死是故意的:正文以 `---` 开头的
/// 正常 skill 不能被误伤,剥错一层等于把 skill 的真身份删掉。
pub fn strip_envelope(text: &str) -> &str {
    let Some((outer, rest)) = split_front(text) else { return text };
    let inner_start = rest.trim_start_matches(['\n', '\r']);
    let Some((inner, _)) = split_front(inner_start) else { return text };
    match (name_in_front(outer), name_in_front(inner)) {
        (Some(outer_name), Some(inner_name)) if outer_name == inner_name => inner_start,
        _ => text,
    }
}

/// frontmatter 之后的正文。overlay 只要正文 —— 它的 frontmatter 是给知识库网页用的,
/// 拼进基座里只会变成一段乱码似的文字。
fn body_of(text: &str) -> &str {
    match split_front(text) {
        Some((_, body)) => body,
        None => text,
    }
}

/// 削掉 overlay 开头那段写给维护人的 `<!-- … -->`。
///
/// 两份真在用的 overlay(`overlays/风控.overlay.md`、`overlays/运营.overlay.md`)开头都是
/// 「本文件由谁维护、运行时会被自动追加、所以别重复写标题」—— 那是说给写补充的人听的,
/// 不是说给 AI 听的,拼进基座只是几百字的噪声。当初手工拼进老板本机那份 `kb-new` 时
/// 也正是把它删掉的。**只削最开头那一段**,正文中间的注释是作者自己的东西,不碰。
fn strip_leading_comment(body: &str) -> &str {
    let trimmed = body.trim_start();
    let Some(rest) = trimmed.strip_prefix("<!--") else { return body };
    match rest.find("-->") {
        Some(end) => &rest[end + 3..],
        None => body,
    }
}

/// 从 Skill 库的项目名推部门名:「风控部 Skill 库」→「风控部」、「公司 Skill 库」→「公司」。
///
/// 推不出来(整串都被削光)就用项目名原样。标题长一点没关系,**标错是谁的补充**才要命 ——
/// 拿着运营的规则当风控的用,产出是错的而且看不出来。
pub fn department_of(project: &str) -> String {
    const TAIL: [&str; 7] = ["Skills", "skills", "SKILL", "Skill", "skill", "库", "的"];
    let mut name = project.trim();
    'strip: loop {
        let trimmed = name.trim_end_matches([' ', '\t', '-', '_', '·', '　']);
        if trimmed.len() != name.len() {
            name = trimmed;
            continue;
        }
        for token in TAIL {
            if let Some(head) = name.strip_suffix(token) {
                name = head;
                continue 'strip;
            }
        }
        break;
    }
    if name.is_empty() { project.trim().to_string() } else { name.to_string() }
}

/// 一份等待摊平的 skill:正文在哪、它属于哪个项目、是目录形态还是单文件形态。
///
/// 字段顺序即排序键。`single_file` 排在 `entry` 之前,好让同名时目录形态排在前面(见模块注释)。
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub struct SkillSource {
    /// 项目名(人读的那个,未清洗)
    pub project: String,
    /// skill 自报的名字;没自报才退回目录名 / 文件名
    pub skill: String,
    /// `<lib>/<name>.md` 这种单文件形态。false 表示 `<dir>/SKILL.md`,整个 `dir` 要带过去
    pub single_file: bool,
    /// 正文文件本身
    pub entry: PathBuf,
}

impl SkillSource {
    /// 目录形态要整份拷过去的那个目录;单文件形态没有。
    pub fn bundle_dir(&self) -> Option<&Path> {
        if self.single_file { None } else { self.entry.parent() }
    }
}

/// 没能装上的一条,以及为什么。设置页要把这个说给用户听——装不上却不吭声是这件事的原罪。
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SkillConflict {
    pub dir_name: String,
    /// 被拒的这一份来自哪里
    pub rejected: String,
    pub reason: SkillConflictReason,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SkillConflictReason {
    /// 同名的另一份先占了
    Duplicate,
    /// 那个目录是用户手工装的,不动
    Occupied,
    /// 是一份部门补充,但同名基座不在本机(只有补充没有基座)
    MissingBase,
    /// 文件读不出来 / 写不进去。只影响这一份
    Unreadable,
}

#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct SkillInstall {
    /// 这一轮之后存在的、由我们装的目录名
    pub installed: Vec<String>,
    /// 这一轮真的写了盘的(内容变了 / 新装)
    pub written: Vec<String>,
    /// 来源没了,删掉的
    pub removed: Vec<String>,
    /// 拼进基座的部门补充,`<基座名> ← <部门名>`。只用于日志
    pub overlaid: Vec<String>,
    pub conflicts: Vec<SkillConflict>,
}

/// 目录名清洗:只留字母数字、中日韩、`.`、`_`、`-`,其余一律折成 `-`,连续的 `-` 合并。
///
/// 空格和斜杠是必须处理的(名字里常有),点开头会被当成隐藏目录、CLI 未必扫,所以也削掉。
pub fn sanitize_segment(raw: &str) -> String {
    let mut out = String::with_capacity(raw.len());
    let mut dash = false;
    for ch in raw.chars() {
        let keep = ch.is_alphanumeric() || matches!(ch, '.' | '_' | '-');
        if keep && !(out.is_empty() && ch == '.') {
            out.push(ch);
            dash = false;
        } else if !out.is_empty() && !dash {
            out.push('-');
            dash = true;
        }
    }
    while out.ends_with(['-', '.']) {
        out.pop();
    }
    out
}

/// 装出来的目录名 = 清洗过的 skill 名。清洗后为空(名字全是符号)才退回兜底串。
pub fn install_dir_name(skill: &str, fallback: &str) -> String {
    let name = sanitize_segment(skill);
    if name.is_empty() { sanitize_segment(fallback) } else { name }
}

/// 在一个 SKILL 项目的镜像目录里找出所有 skill。
///
/// 两种形态:
/// - `<dir>/SKILL.md` —— 目录形态,取**最浅**的那一层。一个 skill 自己的子目录里可能还有别的
///   `SKILL.md`(引用、示例),那是它的内容,不是另一份 skill。找到一个就不再往下走。
///   真机上 `YUP知识库_Dz/yup-skill-package/skill/SKILL.md` 嵌了三层,照样认。
/// - `<项目根>/<name>.md` —— 单文件形态,**只认项目根这一层**。再往下的 `.md` 是别人的
///   README、附录、references,把它们当 skill 装上去就是往那份有长度预算的货架清单里灌垃圾。
///   而且必须带 frontmatter:没有 frontmatter 的 markdown 对 CLI 来说根本不是 skill。
pub fn find_skills(mirror_dir: &Path, project: &str) -> Vec<SkillSource> {
    let mut found = Vec::new();
    let root_is_bundle = mirror_dir.join(SKILL_ENTRY).is_file();
    collect_bundles(mirror_dir, mirror_dir, project, &mut found);
    if !root_is_bundle {
        collect_single_files(mirror_dir, project, &mut found);
    }
    found.sort();
    found
}

fn collect_bundles(dir: &Path, root: &Path, project: &str, out: &mut Vec<SkillSource>) {
    let entry = dir.join(SKILL_ENTRY);
    if entry.is_file() {
        // 名字优先听 skill 自己的;它不说才退回目录名
        let declared = std::fs::read_to_string(&entry).ok().and_then(|text| declared_name(strip_envelope(&text)));
        let skill = declared.unwrap_or_else(|| match dir.strip_prefix(root) {
            // SKILL.md 就在项目根下:这个项目本身就是一份 skill
            Ok(relative) if relative.as_os_str().is_empty() => project.to_string(),
            Ok(relative) => relative.to_string_lossy().to_string(),
            Err(_) => project.to_string(),
        });
        out.push(SkillSource { project: project.to_string(), skill, single_file: false, entry });
        return;
    }
    let Ok(entries) = std::fs::read_dir(dir) else { return };
    for entry in entries.filter_map(Result::ok) {
        if entry.file_type().is_ok_and(|kind| kind.is_dir()) {
            collect_bundles(&entry.path(), root, project, out);
        }
    }
}

fn collect_single_files(root: &Path, project: &str, out: &mut Vec<SkillSource>) {
    let Ok(entries) = std::fs::read_dir(root) else { return };
    for entry in entries.filter_map(Result::ok) {
        let path = entry.path();
        if !entry.file_type().is_ok_and(|kind| kind.is_file()) {
            continue;
        }
        let file_name = entry.file_name().to_string_lossy().to_string();
        if file_name.starts_with('.') || !file_name.to_ascii_lowercase().ends_with(".md") {
            continue;
        }
        // 读不出来就当它不存在:一份文件读失败不该影响同项目里别的 skill
        let Ok(text) = std::fs::read_to_string(&path) else { continue };
        let text = strip_envelope(&text);
        // 没有 frontmatter 的 markdown 不是 skill,是别人的文档
        if split_front(text).is_none() {
            continue;
        }
        let stem = file_name[..file_name.len() - 3].to_string();
        let skill = declared_name(text).unwrap_or(stem);
        out.push(SkillSource { project: project.to_string(), skill, single_file: true, entry: path });
    }
}

/// 来源的内容指纹:目录形态是整棵树(相对路径 + 字节数 + mtime),单文件形态是那一个文件。
fn source_signature(source: &SkillSource) -> String {
    let mut parts: Vec<String> = Vec::new();
    let base = source.bundle_dir().unwrap_or(&source.entry);
    let walk: Vec<PathBuf> = match source.bundle_dir() {
        Some(dir) => walkdir::WalkDir::new(dir)
            .sort_by_file_name()
            .into_iter()
            .filter_map(Result::ok)
            .filter(|entry| entry.file_type().is_file())
            .map(|entry| entry.path().to_path_buf())
            .collect(),
        None => vec![source.entry.clone()],
    };
    for path in walk {
        let relative = path.strip_prefix(base).unwrap_or(&path).to_string_lossy().to_string();
        let (len, mtime) =
            std::fs::metadata(&path).map(|meta| (meta.len(), crate::scanner::file_mtime_ms(&meta))).unwrap_or((0, 0));
        parts.push(format!("{relative}\u{0}{len}\u{0}{mtime}"));
    }
    crate::scanner::sha256_bytes(parts.join("\n").as_bytes())
}

/// 这个目录是不是我们装的;是的话它记的指纹是什么。
fn marker_of(dir: &Path) -> Option<String> {
    let raw = std::fs::read_to_string(dir.join(MARKER_FILE)).ok()?;
    let value: serde_json::Value = serde_json::from_str(&raw).ok()?;
    Some(value.get("signature").and_then(|v| v.as_str()).unwrap_or_default().to_string())
}

fn copy_tree(from: &Path, to: &Path) -> std::io::Result<()> {
    std::fs::create_dir_all(to)?;
    for entry in walkdir::WalkDir::new(from).into_iter().filter_map(Result::ok) {
        let relative = match entry.path().strip_prefix(from) {
            Ok(relative) if !relative.as_os_str().is_empty() => relative,
            _ => continue,
        };
        let target = to.join(relative);
        if entry.file_type().is_dir() {
            std::fs::create_dir_all(&target)?;
        } else if entry.file_type().is_file() {
            if let Some(parent) = target.parent() {
                std::fs::create_dir_all(parent)?;
            }
            std::fs::copy(entry.path(), &target)?;
        }
    }
    Ok(())
}

/// 基座正文 + 各部门补充,拼成最终写进 `SKILL.md` 的那份。
///
/// 分隔用一条 `---` 加 `# 部门补充：<部门名>`,和当初手工拼的那份逐字节一致 ——
/// 老板本机那份带风控补充的 `kb-new` 就长这样,换个格式等于让他重新认一遍。
fn compose(base: &str, overlays: &[(String, String)]) -> String {
    let mut out = base.trim_end().to_string();
    for (department, body) in overlays {
        let body = body.trim();
        if body.is_empty() {
            continue;
        }
        out.push_str("\n\n---\n\n# 部门补充：");
        out.push_str(department);
        out.push_str("\n\n");
        out.push_str(body);
    }
    out.push('\n');
    out
}

/// 一个装好的目标:基座 + 拼在它后面的部门补充。
struct Target {
    base: SkillSource,
    /// (部门名, overlay 来源),按部门名排序 —— 装出来的正文不能取决于同步顺序
    overlays: Vec<(String, SkillSource)>,
}

/// 把 `sources` 摊平进 `skills_dir`,并收走来源已经消失的那些。
///
/// `fallback` 用于 skill 名清洗后为空的极端情况(一般传 projectKey)。
pub fn install(skills_dir: &Path, sources: &[SkillSource], fallback: &str) -> SkillInstall {
    let mut report = SkillInstall::default();
    // 先定名、先分基座与补充,再落盘:名字只取决于 (项目, 形态, 路径),与谁先同步完无关
    let mut sorted = sources.to_vec();
    sorted.sort();

    let mut targets: BTreeMap<String, Target> = BTreeMap::new();
    let mut overlays: BTreeMap<String, Vec<SkillSource>> = BTreeMap::new();
    for source in sorted {
        let name = install_dir_name(&source.skill, fallback);
        if name.is_empty() {
            continue;
        }
        // `-overlay` 结尾的不单独上架,记到一边等着拼进同名基座
        let base_name = name.strip_suffix(OVERLAY_SUFFIX).filter(|base| !base.is_empty()).map(str::to_string);
        if let Some(base_name) = base_name {
            let waiting = overlays.entry(base_name).or_default();
            // 《如何写部门补充》:一个部门只留一份。同一个项目里出现第二份就报出来
            if waiting.iter().any(|kept| kept.project == source.project) {
                report.conflicts.push(SkillConflict {
                    dir_name: name,
                    rejected: source.entry.to_string_lossy().to_string(),
                    reason: SkillConflictReason::Duplicate,
                });
                continue;
            }
            waiting.push(source);
            continue;
        }
        if targets.contains_key(&name) {
            // 绝不覆盖:先到的留着,后到的记一条冲突交给设置页去说
            report.conflicts.push(SkillConflict {
                dir_name: name,
                rejected: source.entry.to_string_lossy().to_string(),
                reason: SkillConflictReason::Duplicate,
            });
            continue;
        }
        targets.insert(name, Target { base: source, overlays: Vec::new() });
    }

    for (base_name, waiting) in overlays {
        let Some(target) = targets.get_mut(&base_name) else {
            // 只有补充没有基座:装上去 AI 会拿着半套规则当全套用。跳过并说清楚
            for source in waiting {
                report.conflicts.push(SkillConflict {
                    dir_name: format!("{base_name}{OVERLAY_SUFFIX}"),
                    rejected: source.entry.to_string_lossy().to_string(),
                    reason: SkillConflictReason::MissingBase,
                });
            }
            continue;
        };
        for source in waiting {
            target.overlays.push((department_of(&source.project), source));
        }
        target.overlays.sort_by(|left, right| left.0.cmp(&right.0));
    }

    for (name, target) in &targets {
        install_one(skills_dir, name, target, &mut report);
    }

    // 收走来源已经没了的:项目里删了这份 skill / 整个项目不再同步 / 权限被收回镜像清空。
    // **只看带标记的目录** —— 没标记的是用户自己的东西
    let Ok(entries) = std::fs::read_dir(skills_dir) else { return report };
    for entry in entries.filter_map(Result::ok) {
        let path = entry.path();
        if !entry.file_type().is_ok_and(|kind| kind.is_dir()) {
            continue;
        }
        let name = entry.file_name().to_string_lossy().to_string();
        if targets.contains_key(&name) || marker_of(&path).is_none() {
            continue;
        }
        match std::fs::remove_dir_all(&path) {
            Ok(()) => report.removed.push(name),
            Err(error) => log::warn!("[drive-sync] 收走已失效的 skill {name} 失败: {error}"),
        }
    }
    report
}

/// 手工装的那份能不能直接认领:正文逐字节就是我们要写的,**而且**目录里除了正文没有别的。
///
/// 后半条是安全阀:认领等于把这个目录交给以后的同步管,内容一变就是 `remove_dir_all` 重写。
/// 用户要是在里面放了自己的附件,那份东西会跟着没 —— 宁可继续报冲突,也不吞掉别人的文件。
fn adoptable(dir: &Path, content: &str) -> bool {
    if std::fs::read_to_string(dir.join(SKILL_ENTRY)).ok().as_deref() != Some(content) {
        return false;
    }
    let Ok(entries) = std::fs::read_dir(dir) else { return false };
    entries.filter_map(Result::ok).all(|entry| entry.file_name() == SKILL_ENTRY)
}

/// 装一份。**任何一步失败都只影响这一份**:记一条、返回、外面接着装下一个。
fn install_one(skills_dir: &Path, name: &str, target: &Target, report: &mut SkillInstall) {
    fn unreadable(name: &str, source: &SkillSource, report: &mut SkillInstall) {
        report.conflicts.push(SkillConflict {
            dir_name: name.to_string(),
            rejected: source.entry.to_string_lossy().to_string(),
            reason: SkillConflictReason::Unreadable,
        });
    }

    let dir = skills_dir.join(name);
    let existing = marker_of(&dir);
    // 用户手工装的占着这个名字。**先别急着报冲突** —— 先把这一轮该写的内容算出来比一比:
    // 早于云盘上线就手工装过同一份的人不在少数(Alex 本机的 yup-kb 就是,2026-09-11),
    // 内容一模一样却天天在面板上顶一条红字,那是我们在喊狼来了。判定见 adoptable()。
    let occupied = dir.exists() && existing.is_none();

    let Ok(base_text) = std::fs::read_to_string(&target.base.entry) else {
        unreadable(name, &target.base, report);
        return;
    };
    let mut parts: Vec<(String, String)> = Vec::new();
    let mut fingerprint_parts = vec![source_signature(&target.base)];
    for (department, source) in &target.overlays {
        // 一份补充读不出来只跳过这一份,基座和别的部门的补充照装
        let Ok(text) = std::fs::read_to_string(&source.entry) else {
            unreadable(name, source, report);
            continue;
        };
        fingerprint_parts.push(format!("{department}\u{0}{}", source_signature(source)));
        parts.push((department.clone(), strip_leading_comment(body_of(strip_envelope(&text))).to_string()));
    }
    let content = compose(strip_envelope(&base_text), &parts);
    fingerprint_parts.push(crate::scanner::sha256_bytes(content.as_bytes()));
    let fingerprint = crate::scanner::sha256_bytes(fingerprint_parts.join("\n").as_bytes());

    if occupied {
        if adoptable(&dir, &content) {
            // 逐字节相同、且目录里除了正文没有别的东西 —— 这就是我们要装的那一份,
            // 只补一个 marker 认领它,正文一个字节都不重写。
            if let Err(error) =
                std::fs::write(dir.join(MARKER_FILE), format!("{:#}\n", marker_json(target, &fingerprint)))
            {
                log::warn!("[drive-sync] 认领手工安装的 skill {name} 失败: {error}");
                report.conflicts.push(SkillConflict {
                    dir_name: name.to_string(),
                    rejected: target.base.entry.to_string_lossy().to_string(),
                    reason: SkillConflictReason::Occupied,
                });
                return;
            }
            log::info!("[drive-sync] 认领手工安装的 skill {name}(内容与云端一致)");
            report.installed.push(name.to_string());
            record_overlays(name, &parts, report);
            return;
        }
        // 内容不一样:那是用户自己改过 / 另一份同名的东西,不动它一个字节,照报。
        report.conflicts.push(SkillConflict {
            dir_name: name.to_string(),
            rejected: target.base.entry.to_string_lossy().to_string(),
            reason: SkillConflictReason::Occupied,
        });
        return;
    }

    if existing.as_deref() == Some(fingerprint.as_str()) {
        // 内容一个字节都没变:整个跳过,连 mtime 都不碰 —— 否则每轮同步都像有改动
        report.installed.push(name.to_string());
        record_overlays(name, &parts, report);
        return;
    }
    if dir.exists()
        && let Err(error) = std::fs::remove_dir_all(&dir)
    {
        log::warn!("[drive-sync] 重装 skill {name} 前清目录失败: {error}");
        unreadable(name, &target.base, report);
        return;
    }
    let copied = match target.base.bundle_dir() {
        Some(from) => copy_tree(from, &dir),
        None => std::fs::create_dir_all(&dir),
    };
    if let Err(error) = copied {
        log::warn!("[drive-sync] 摊平 skill {name} 失败: {error}");
        let _ = std::fs::remove_dir_all(&dir);
        unreadable(name, &target.base, report);
        return;
    }
    let marker = marker_json(target, &fingerprint);
    let written = std::fs::write(dir.join(SKILL_ENTRY), content.as_bytes())
        .and_then(|()| std::fs::write(dir.join(MARKER_FILE), format!("{marker:#}\n")));
    if let Err(error) = written {
        log::warn!("[drive-sync] 写 skill {name} 失败: {error}");
        let _ = std::fs::remove_dir_all(&dir);
        unreadable(name, &target.base, report);
        return;
    }
    report.installed.push(name.to_string());
    report.written.push(name.to_string());
    record_overlays(name, &parts, report);
}

/// marker 文件的内容。认领手工安装的那份与正常安装共用,免得两处各拼一份、字段漂移。
fn marker_json(target: &Target, fingerprint: &str) -> serde_json::Value {
    serde_json::json!({
        "source": target.base.entry.to_string_lossy(),
        "project": target.base.project,
        "skill": target.base.skill,
        "overlays": target.overlays.iter().map(|(department, source)| {
            serde_json::json!({ "department": department, "source": source.entry.to_string_lossy() })
        }).collect::<Vec<_>>(),
        "signature": fingerprint,
    })
}

/// 只记**真的拼进去了**的那几份:读不出来的那份已经记成一条冲突,不能同时出现在「拼上了」里。
fn record_overlays(name: &str, parts: &[(String, String)], report: &mut SkillInstall) {
    for (department, _) in parts {
        report.overlaid.push(format!("{name} ← {department}"));
    }
}

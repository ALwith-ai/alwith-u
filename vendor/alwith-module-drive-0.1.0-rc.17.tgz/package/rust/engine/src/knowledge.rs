//! 知识回流到会话(方案 4.5):打开的主 root 在 `~/YUP Drive` 内时,按项目 README 的标题 / `专题` / `部门`
//! 关键词查 `GET /ai/search?kind=KNOWLEDGE`,把命中拼成一段「公司知识库相关沉淀」文本追加进会话 system prompt。
//! 这里只放纯函数(关键词提取、文本拼装);缓存、调用与设置开关在桌面侧。

use crate::types::AiSearchHit;

/// README 里标记专题 / 部门的键(中英文都认;`专题:` / `专题：` / `- 专题：` / `| 专题 | … |` / frontmatter `topics:`)。
const TOPIC_KEYS: &[&str] = &["专题", "topic", "topics", "主题"];
const DEPT_KEYS: &[&str] = &["部门", "department", "dept", "团队", "team"];
const MAX_KEYWORDS: usize = 6;
const MAX_SNIPPET_CHARS: usize = 160;

/// README 关键词:frontmatter / 一级标题 / `专题` / `部门` 字段;什么都没找到用目录名。去重、最多 6 个。
pub fn extract_keywords(readme: Option<&str>, fallback_name: &str) -> Vec<String> {
    let mut keywords: Vec<String> = Vec::new();
    fn push_into(keywords: &mut Vec<String>, value: &str) {
        for part in split_values(value) {
            if !part.is_empty() && !keywords.iter().any(|existing| existing == &part) && keywords.len() < MAX_KEYWORDS {
                keywords.push(part);
            }
        }
    }
    let mut push = |value: &str| push_into(&mut keywords, value);
    if let Some(text) = readme {
        let (frontmatter, body) = split_frontmatter(text);
        for line in frontmatter.lines() {
            if let Some((key, value)) = line.split_once(':') {
                let key = key.trim().trim_start_matches('-').trim().to_lowercase();
                if key == "title" || TOPIC_KEYS.contains(&key.as_str()) || DEPT_KEYS.contains(&key.as_str()) {
                    push(value);
                }
            }
        }
        if let Some(title) = body.lines().map(str::trim).find(|line| line.starts_with("# ")) {
            push(title.trim_start_matches('#'));
        }
        for line in body.lines() {
            if let Some(value) = field_value(line, TOPIC_KEYS).or_else(|| field_value(line, DEPT_KEYS)) {
                push(&value);
            }
        }
    }
    if keywords.is_empty() {
        push_into(&mut keywords, fallback_name);
    }
    keywords
}

/// 一行里形如 `专题: xxx` / `- 专题：xxx` / `**专题**：xxx` / `| 专题 | xxx |` 的值。
fn field_value(line: &str, keys: &[&str]) -> Option<String> {
    let trimmed = line.trim().trim_start_matches(['-', '*', '|', ' ']).trim();
    let cleaned = trimmed.replace("**", "");
    for key in keys {
        let lower = cleaned.to_lowercase();
        if !lower.starts_with(&key.to_lowercase()) {
            continue;
        }
        let rest = &cleaned[key.len()..];
        let rest = rest.trim_start();
        let value = if let Some(value) = rest.strip_prefix([':', '：']) {
            value
        } else if let Some(value) = rest.strip_prefix('|') {
            value
        } else {
            continue;
        };
        let value = value.trim().trim_end_matches('|').trim();
        if !value.is_empty() {
            return Some(value.to_string());
        }
    }
    None
}

/// `a、b / c,d` → 多个值;去掉方括号 / 引号。
fn split_values(value: &str) -> Vec<String> {
    value
        .trim()
        .trim_matches(['[', ']', '"', '\''])
        .split(['、', ',', '，', '/', ';', '；'])
        .map(|part| part.trim().trim_matches(['"', '\'', '`']).to_string())
        .filter(|part| !part.is_empty())
        .collect()
}

fn split_frontmatter(text: &str) -> (&str, &str) {
    let Some(rest) = text.strip_prefix("---") else { return ("", text) };
    let rest = rest.trim_start_matches('\r');
    let Some(rest) = rest.strip_prefix('\n') else { return ("", text) };
    let Some(end) = rest.find("\n---") else { return ("", text) };
    let frontmatter = &rest[..end];
    let body = &rest[end + 4..];
    (frontmatter, body)
}

/// 命中的 web 链接:服务端 `humanUrl`(`public-base-url` 没配时会是 example.com,那就退回 `<baseUrl>/file/{id}`)。
pub fn hit_url(hit: &AiSearchHit, base_url: &str) -> String {
    match &hit.human_url {
        Some(url) if !url.contains("example.com") && !url.is_empty() => url.clone(),
        _ => format!("{}/file/{}", base_url.trim_end_matches('/'), hit.file_id),
    }
}

/// 追加进 system prompt 的那段文字;没有命中返回 None。
pub fn build_prompt(keywords: &[String], hits: &[AiSearchHit], base_url: &str) -> Option<String> {
    if hits.is_empty() {
        return None;
    }
    let mut text = String::new();
    text.push_str("## 公司知识库相关沉淀\n");
    text.push_str(&format!(
        "当前项目关键词:{}。以下是公司知识库里与之相关的已发布知识(标题 · 摘要 · 链接),回答时可参考并在需要时给出链接;不确定就先读原文。\n",
        keywords.join("、")
    ));
    for hit in hits {
        let snippet = hit
            .snippet
            .as_deref()
            .map(|snippet| snippet.split_whitespace().collect::<Vec<_>>().join(" "))
            .map(|snippet| truncate_chars(&snippet, MAX_SNIPPET_CHARS))
            .filter(|snippet| !snippet.is_empty());
        let mut line = format!("- {}", hit.name);
        if let Some(project) = &hit.project_name {
            line.push_str(&format!("({project})"));
        }
        if let Some(snippet) = snippet {
            line.push_str(&format!(":{snippet}"));
        }
        line.push_str(&format!(" — {}", hit_url(hit, base_url)));
        text.push_str(&line);
        text.push('\n');
    }
    Some(text.trim_end().to_string())
}

fn truncate_chars(text: &str, max: usize) -> String {
    if text.chars().count() <= max {
        return text.to_string();
    }
    let mut truncated: String = text.chars().take(max).collect();
    truncated.push('…');
    truncated
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::RemoteId;

    fn hit(id: i64, name: &str, snippet: Option<&str>, url: Option<&str>) -> AiSearchHit {
        AiSearchHit {
            file_id: RemoteId::Number(id),
            name: name.into(),
            kind: Some("KNOWLEDGE".into()),
            project_name: Some("公司知识库".into()),
            folder_path: None,
            category: None,
            snippet: snippet.map(str::to_string),
            human_url: url.map(str::to_string),
            updated_at: None,
            score: None,
        }
    }

    #[test]
    fn readme_关键词_标题_专题_部门() {
        let readme = "---\ntitle: 交易限额文案优化\ntopics: [提前还款, 交易限额]\n---\n# 交易限额提前还款文案优化\n\n- 专题：提前还款 / 额度\n- **部门**：风控\n| 负责人 | 张三 |\n";
        let keywords = extract_keywords(Some(readme), "dir");
        assert_eq!(
            keywords,
            vec!["交易限额文案优化", "提前还款", "交易限额", "交易限额提前还款文案优化", "额度", "风控"]
        );
    }

    #[test]
    fn readme_表格字段与目录名兜底() {
        let readme = "# 项目\n\n| 专题 | 商户券 |\n| 部门 | 增长 |\n";
        assert_eq!(extract_keywords(Some(readme), "dir"), vec!["项目", "商户券", "增长"]);
        assert_eq!(extract_keywords(None, "260827_交易限额"), vec!["260827_交易限额"]);
        assert_eq!(extract_keywords(Some("nothing here"), "dir"), vec!["dir"]);
    }

    #[test]
    fn 拼装文本与链接回退() {
        let hits = vec![
            hit(1, "提前还款规则", Some("  多行\n摘要  "), Some("https://kb.example.com/file/1")),
            hit(2, "限额说明", None, Some("https://web.corp/file/2")),
        ];
        let text = build_prompt(&["提前还款".to_string()], &hits, "https://kb.corp/").unwrap();
        assert!(text.starts_with("## 公司知识库相关沉淀\n当前项目关键词:提前还款。"));
        assert!(text.contains("- 提前还款规则(公司知识库):多行 摘要 — https://kb.corp/file/1"));
        assert!(text.contains("- 限额说明(公司知识库) — https://web.corp/file/2"));
        assert!(build_prompt(&[], &[], "x").is_none());
    }
}

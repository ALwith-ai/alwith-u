//! 遍历根目录 + 增量 sha256:(mtime, size) 与上次一致就复用索引里的 hash,不再读文件。

use std::collections::HashMap;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::time::UNIX_EPOCH;

use sha2::{Digest, Sha256};
use walkdir::WalkDir;

use crate::ignore::{IgnoreRules, Verdict};
use crate::naming::{is_cloud_only_placeholder, local_to_cloud_relative};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ScannedFile {
    /// 云端相对路径
    pub path: String,
    pub local_path: PathBuf,
    pub size: u64,
    pub mtime_ms: i64,
    pub sha256: String,
}

/// 增量比对的输入:上次记录的 (mtime, size, sha256)。
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Previous {
    pub mtime_ms: i64,
    pub size: u64,
    pub sha256: String,
}

#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct ScanResult {
    pub files: Vec<ScannedFile>,
    /// 被忽略规则排除的(云端相对路径)
    pub ignored: Vec<String>,
    /// 超阈值的
    pub too_large: Vec<String>,
    /// `.yupcloud` 占位(本地相对路径)
    pub placeholders: Vec<String>,
    /// 本地存在、且没被忽略规则排除的**目录**(云端相对路径,不含根自己)。
    ///
    /// 为什么要单独收:上行的 MKDIR 从前是**从文件操作反推**的,于是一个空文件夹推不出任何 op、
    /// 永远不上行 —— 用户在项目里新建一个空文件夹,云端一辈子不会有它,得先往里放东西才出现
    /// (2026-09-07 老板实机)。这不符合任何人的直觉:Dropbox / Google Drive 建个空文件夹都是
    /// 立刻同步的。**目录本身也是内容**,得有一份自己的清单。
    pub directories: Vec<String>,
    /// 本轮真正读了文件算 hash 的条数(增量验证用)
    pub hashed: usize,
}

pub fn file_mtime_ms(metadata: &std::fs::Metadata) -> i64 {
    metadata
        .modified()
        .ok()
        .and_then(|time| time.duration_since(UNIX_EPOCH).ok())
        .map(|duration| duration.as_millis() as i64)
        .expect("文件系统必须提供 mtime")
}

pub fn sha256_file(path: &Path) -> Result<String, String> {
    let mut file = std::fs::File::open(path).map_err(|error| format!("打开 {} 失败: {error}", path.display()))?;
    let mut hasher = Sha256::new();
    let mut buffer = vec![0u8; 1 << 16];
    loop {
        let read = file.read(&mut buffer).map_err(|error| format!("读 {} 失败: {error}", path.display()))?;
        if read == 0 {
            break;
        }
        hasher.update(&buffer[..read]);
    }
    Ok(hex::encode(hasher.finalize()))
}

pub fn sha256_bytes(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}

/// 遍历 `root`。`previous` 以云端相对路径为键。
pub fn scan_root(
    root: &Path, rules: &IgnoreRules, previous: &HashMap<String, Previous>, windows_names: bool,
) -> Result<ScanResult, String> {
    let mut result = ScanResult::default();
    let mut walker = WalkDir::new(root).follow_links(false).sort_by_file_name().into_iter();
    while let Some(entry) = walker.next() {
        let entry = entry.map_err(|error| format!("遍历 {} 失败: {error}", root.display()))?;
        if entry.depth() == 0 {
            continue;
        }
        let relative = entry.path().strip_prefix(root).expect("walkdir entry is under root");
        let file_type = entry.file_type();
        if file_type.is_dir() {
            if rules.is_ignored(relative, true) {
                result.ignored.push(local_to_cloud_relative(relative, windows_names));
                walker.skip_current_dir();
                continue;
            }
            result.directories.push(local_to_cloud_relative(relative, windows_names));
            continue;
        }
        if !file_type.is_file() {
            continue;
        }
        if is_cloud_only_placeholder(relative) {
            result.placeholders.push(relative.to_string_lossy().replace('\\', "/"));
            continue;
        }
        let metadata = entry.metadata().map_err(|error| format!("stat {} 失败: {error}", entry.path().display()))?;
        let cloud_path = local_to_cloud_relative(relative, windows_names);
        match rules.classify(relative, metadata.len()) {
            Verdict::Ignored => {
                result.ignored.push(cloud_path);
                continue;
            }
            Verdict::TooLarge => {
                result.too_large.push(cloud_path);
                continue;
            }
            Verdict::Sync => {}
        }
        let mtime_ms = file_mtime_ms(&metadata);
        let size = metadata.len();
        let sha256 = match previous.get(&cloud_path) {
            Some(known) if known.mtime_ms == mtime_ms && known.size == size => known.sha256.clone(),
            _ => {
                result.hashed += 1;
                sha256_file(entry.path())?
            }
        };
        result.files.push(ScannedFile {
            path: cloud_path,
            local_path: entry.path().to_path_buf(),
            size,
            mtime_ms,
            sha256,
        });
    }
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn 扫描按_mtime_size_增量复用_hash() {
        let root = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(root.path().join("src")).unwrap();
        std::fs::write(root.path().join("src/a.txt"), b"hello").unwrap();
        std::fs::write(root.path().join("b.txt"), b"world").unwrap();
        std::fs::create_dir_all(root.path().join("node_modules/x")).unwrap();
        std::fs::write(root.path().join("node_modules/x/i.js"), b"1").unwrap();
        std::fs::write(root.path().join("doc.pdf.yupcloud"), b"{}").unwrap();
        let rules = IgnoreRules::load(root.path()).unwrap();

        let first = scan_root(root.path(), &rules, &HashMap::new(), false).unwrap();
        assert_eq!(first.hashed, 2);
        assert_eq!(first.files.iter().map(|file| file.path.as_str()).collect::<Vec<_>>(), vec!["b.txt", "src/a.txt"]);
        assert_eq!(first.files[1].sha256, sha256_bytes(b"hello"));
        assert_eq!(first.ignored, vec!["node_modules"]);
        assert_eq!(first.placeholders, vec!["doc.pdf.yupcloud"]);

        // 第二次:把上次的 (mtime,size,sha) 喂回去,且故意给一个假 hash —— 没变的文件必须原样复用
        let mut previous: HashMap<String, Previous> = first
            .files
            .iter()
            .map(|file| {
                (file.path.clone(), Previous { mtime_ms: file.mtime_ms, size: file.size, sha256: file.sha256.clone() })
            })
            .collect();
        previous.get_mut("b.txt").unwrap().sha256 = "reused-marker".into();
        std::fs::write(root.path().join("src/a.txt"), b"hello!").unwrap();
        let second = scan_root(root.path(), &rules, &previous, false).unwrap();
        assert_eq!(second.hashed, 1);
        let by_path: HashMap<_, _> = second.files.iter().map(|file| (file.path.as_str(), file)).collect();
        assert_eq!(by_path["b.txt"].sha256, "reused-marker");
        assert_eq!(by_path["src/a.txt"].sha256, sha256_bytes(b"hello!"));
    }

    #[test]
    fn 超阈值单独列出() {
        let root = tempfile::tempdir().unwrap();
        std::fs::write(root.path().join("small.bin"), b"x").unwrap();
        let big = root.path().join("big.bin");
        let file = std::fs::File::create(&big).unwrap();
        file.set_len(crate::ignore::DEFAULT_MAX_FILE_SIZE + 1).unwrap();
        let rules = IgnoreRules::load(root.path()).unwrap();
        let result = scan_root(root.path(), &rules, &HashMap::new(), false).unwrap();
        assert_eq!(result.too_large, vec!["big.bin"]);
        assert_eq!(result.files.len(), 1);
    }
}

//! notify 监听 + 去抖:安静 `debounce` 后把这段时间内变化的路径合成一批送出。
//!
//! 重命名 / 移动的识别不在这里(notify 各平台事件语义不一),交给 engine 按
//! 「同 sha256 且旧路径消失」在扫描结果上判定。

use std::path::{Path, PathBuf};
use std::time::Duration;

use notify::{Config, RecommendedWatcher, RecursiveMode, Watcher as _};
use tokio::sync::mpsc;

pub const DEFAULT_DEBOUNCE: Duration = Duration::from_secs(3);

pub struct Watcher {
    inner: RecommendedWatcher,
    watched: Vec<PathBuf>,
}

impl Watcher {
    /// 监听 `paths`(递归),变化去抖后从返回的 receiver 收批。
    pub fn start(
        paths: &[PathBuf], debounce: Duration,
    ) -> Result<(Self, mpsc::UnboundedReceiver<Vec<PathBuf>>), String> {
        let (raw_sender, raw_receiver) = mpsc::unbounded_channel::<PathBuf>();
        let (batch_sender, batch_receiver) = mpsc::unbounded_channel::<Vec<PathBuf>>();
        let mut inner = RecommendedWatcher::new(
            move |result: notify::Result<notify::Event>| match result {
                Ok(event) => {
                    for path in event.paths {
                        let _ = raw_sender.send(path);
                    }
                }
                Err(error) => log::warn!("[drive-sync] watcher 错误: {error}"),
            },
            Config::default(),
        )
        .map_err(|error| format!("创建文件监听失败: {error}"))?;
        for path in paths {
            inner
                .watch(path, RecursiveMode::Recursive)
                .map_err(|error| format!("监听 {} 失败: {error}", path.display()))?;
        }
        tokio::spawn(debounce_loop(raw_receiver, batch_sender, debounce));
        Ok((Self { inner, watched: paths.to_vec() }, batch_receiver))
    }

    pub fn add(&mut self, path: &Path) -> Result<(), String> {
        if self.watched.iter().any(|watched| watched == path) {
            return Ok(());
        }
        self.inner
            .watch(path, RecursiveMode::Recursive)
            .map_err(|error| format!("监听 {} 失败: {error}", path.display()))?;
        self.watched.push(path.to_path_buf());
        Ok(())
    }

    pub fn watched(&self) -> &[PathBuf] {
        &self.watched
    }
}

async fn debounce_loop(
    mut raw: mpsc::UnboundedReceiver<PathBuf>, batches: mpsc::UnboundedSender<Vec<PathBuf>>, debounce: Duration,
) {
    while let Some(first) = raw.recv().await {
        let mut pending = vec![first];
        loop {
            tokio::select! {
                next = raw.recv() => match next {
                    Some(path) => {
                        if !pending.contains(&path) {
                            pending.push(path);
                        }
                    }
                    None => {
                        let _ = batches.send(pending);
                        return;
                    }
                },
                _ = tokio::time::sleep(debounce) => break,
            }
        }
        if batches.send(pending).is_err() {
            return;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn 连续写入合成一批() {
        let root = tempfile::tempdir().unwrap();
        let (_watcher, mut batches) = Watcher::start(&[root.path().to_path_buf()], Duration::from_millis(300)).unwrap();
        // 等监听真正装上:notify 在 macOS 上是异步注册,先写一个探针文件直到收到它
        let probe = root.path().join("probe.txt");
        let first_batch = loop {
            std::fs::write(&probe, b"p").unwrap();
            match tokio::time::timeout(Duration::from_millis(800), batches.recv()).await {
                Ok(Some(batch)) => break batch,
                Ok(None) => panic!("watcher channel closed"),
                Err(_) => continue,
            }
        };
        assert!(first_batch.iter().any(|path| path.ends_with("probe.txt")));

        for index in 0..5 {
            std::fs::write(root.path().join(format!("f{index}.txt")), b"x").unwrap();
            tokio::time::sleep(Duration::from_millis(30)).await;
        }
        let batch =
            tokio::time::timeout(Duration::from_secs(5), batches.recv()).await.expect("应在去抖后收到一批").unwrap();
        let names: Vec<String> =
            batch.iter().filter_map(|path| path.file_name().map(|name| name.to_string_lossy().to_string())).collect();
        for index in 0..5 {
            assert!(names.contains(&format!("f{index}.txt")), "缺 f{index}.txt: {names:?}");
        }
        // 去抖窗口内不应再有第二批
        assert!(tokio::time::timeout(Duration::from_millis(200), batches.recv()).await.is_err());
    }
}

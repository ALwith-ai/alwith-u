//! 6.2 变更推送:`/ws/sync?token=` 原生 WebSocket。
//!
//! 连上就发 `{"type":"subscribe","projectIds":[...]}`;服务端在 file_events 落库后推
//! `{"type":"file_events","projectId","seq"}`,客户端据此立即拉 `/sync/changes`(通过 wake 通道
//! 触发引擎);双向 `ping` / `pong` 每 30 秒。断线指数退避重连(1s → 60s 封顶),期间由引擎的
//! 60 秒轮询兜底;订阅集变化(固定 / 取消根)立即重发 subscribe。
//!
//! 同一条连接还驮着**评论**:编辑器打开一份 Drive 文件、抽屉挂上去,就把当前打开的 fileId 集
//! 整份发成 `{"type":"subscribe_files","fileIds":[...]}`;服务端剔掉没有 READ 权的那些回
//! `files_subscribed`,之后该文件的评论一变就推 `comment_event`。**不为评论另开一条连接** ——
//! token 只在 Rust 侧、重连退避与心跳只有一份、服务端也只需认一个会话。

use std::time::Duration;

use futures_util::{SinkExt as _, StreamExt as _};
use tokio::sync::{mpsc, watch};
use tokio_tungstenite::tungstenite::Message;

use crate::types::{PushMessage, RemoteId};

pub const PING_INTERVAL: Duration = Duration::from_secs(30);
/// 连续 3 个心跳周期没有任何帧就视作死连接。
pub const IDLE_TIMEOUT: Duration = Duration::from_secs(90);
pub const INITIAL_BACKOFF: Duration = Duration::from_secs(1);
pub const MAX_BACKOFF: Duration = Duration::from_secs(60);

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PushEvent {
    Connected,
    Disconnected {
        reason: String,
    },
    /// 服务端有新事件落库,拉 changes
    FileEvents {
        project_id: RemoteId,
        seq: i64,
    },
    /// 评论订阅生效。回来的集合是服务端**剔掉没有 READ 权之后**的,可能比发出去的小
    FilesSubscribed {
        file_ids: Vec<RemoteId>,
    },
    /// 某文件的评论变了(created / updated / deleted / applied)。只是信号,拿到就重拉列表
    Comment {
        file_id: RemoteId,
        comment_id: RemoteId,
        action: String,
        actor_id: Option<RemoteId>,
        at: Option<String>,
    },
}

#[derive(Debug, Clone)]
pub struct PushConfig {
    /// `wss://host/ws/sync?token=...`(见 `DriveClient::push_url`)
    pub url: String,
    pub ping_interval: Duration,
    pub idle_timeout: Duration,
    pub initial_backoff: Duration,
    pub max_backoff: Duration,
}

impl PushConfig {
    pub fn standard(url: String) -> Self {
        Self {
            url,
            ping_interval: PING_INTERVAL,
            idle_timeout: IDLE_TIMEOUT,
            initial_backoff: INITIAL_BACKOFF,
            max_backoff: MAX_BACKOFF,
        }
    }
}

/// 一个连接的结局:正常关闭 / 出错都返回原因;`subscriptions` 的发送端被丢弃时返回 None(整体退出)。
enum SessionEnd {
    Reconnect(String),
    Quit,
}

/// 主循环:直到 `subscriptions` 的发送端丢弃(引擎停了)或 `events` 的接收端丢弃才退出。
///
/// `file_subscriptions` 是评论那一路:当前打开着评论抽屉的 fileId 集,整份替换。
pub async fn run_push(
    config: PushConfig, mut subscriptions: watch::Receiver<Vec<RemoteId>>,
    mut file_subscriptions: watch::Receiver<Vec<RemoteId>>, events: mpsc::UnboundedSender<PushEvent>,
) {
    let mut backoff = config.initial_backoff;
    loop {
        if events.is_closed() {
            return;
        }
        match tokio_tungstenite::connect_async(&config.url).await {
            Ok((stream, _)) => {
                backoff = config.initial_backoff;
                let _ = events.send(PushEvent::Connected);
                let end = session(stream, &config, &mut subscriptions, &mut file_subscriptions, &events).await;
                match end {
                    SessionEnd::Quit => return,
                    SessionEnd::Reconnect(reason) => {
                        log::warn!("[drive-sync] 推送连接断开: {reason}");
                        let _ = events.send(PushEvent::Disconnected { reason });
                    }
                }
            }
            Err(error) => {
                log::warn!("[drive-sync] 推送连接失败: {error}");
                let _ = events.send(PushEvent::Disconnected { reason: error.to_string() });
            }
        }
        // 退避期间订阅端关闭也要能退出
        tokio::select! {
            changed = subscriptions.changed() => if changed.is_err() { return; },
            changed = file_subscriptions.changed() => if changed.is_err() { return; },
            _ = tokio::time::sleep(backoff) => {}
        }
        backoff = (backoff * 2).min(config.max_backoff);
    }
}

async fn session<S>(
    stream: S, config: &PushConfig, subscriptions: &mut watch::Receiver<Vec<RemoteId>>,
    file_subscriptions: &mut watch::Receiver<Vec<RemoteId>>, events: &mpsc::UnboundedSender<PushEvent>,
) -> SessionEnd
where
    S: futures_util::Stream<Item = Result<Message, tokio_tungstenite::tungstenite::Error>>
        + futures_util::Sink<Message, Error = tokio_tungstenite::tungstenite::Error>
        + Unpin,
{
    let (mut sink, mut source) = stream.split();
    let subscribe = |ids: Vec<RemoteId>| {
        Message::Text(serde_json::to_string(&PushMessage::Subscribe { project_ids: ids }).expect("serialize").into())
    };
    let subscribe_files = |ids: Vec<RemoteId>| {
        Message::Text(serde_json::to_string(&PushMessage::SubscribeFiles { file_ids: ids }).expect("serialize").into())
    };
    let initial = subscriptions.borrow_and_update().clone();
    if let Err(error) = sink.send(subscribe(initial)).await {
        return SessionEnd::Reconnect(format!("发送 subscribe 失败: {error}"));
    }
    // 重连后要把评论订阅补回去:抽屉还开着,新连接却什么都没订阅,评论就再也不实时了。
    // 集合为空时不发 —— 没人在看评论,不必占一帧
    let initial_files = file_subscriptions.borrow_and_update().clone();
    if !initial_files.is_empty()
        && let Err(error) = sink.send(subscribe_files(initial_files)).await
    {
        return SessionEnd::Reconnect(format!("发送 subscribe_files 失败: {error}"));
    }
    let mut ping = tokio::time::interval(config.ping_interval);
    ping.tick().await; // 第一次立即触发的 tick 跳过
    let mut last_frame = tokio::time::Instant::now();
    loop {
        tokio::select! {
            frame = source.next() => {
                let Some(frame) = frame else { return SessionEnd::Reconnect("服务端关闭连接".to_string()) };
                let frame = match frame {
                    Ok(frame) => frame,
                    Err(error) => return SessionEnd::Reconnect(error.to_string()),
                };
                last_frame = tokio::time::Instant::now();
                match frame {
                    Message::Text(text) => match serde_json::from_str::<PushMessage>(&text) {
                        Ok(PushMessage::FileEvents { project_id, seq }) => {
                            if events.send(PushEvent::FileEvents { project_id, seq }).is_err() {
                                return SessionEnd::Quit;
                            }
                        }
                        Ok(PushMessage::Ping) => {
                            if let Err(error) = sink.send(Message::Text(serde_json::to_string(&PushMessage::Pong).expect("serialize").into())).await {
                                return SessionEnd::Reconnect(format!("回 pong 失败: {error}"));
                            }
                        }
                        Ok(PushMessage::Subscribed { project_ids }) => {
                            log::debug!("[drive-sync] 订阅已生效: {} 个项目", project_ids.len());
                        }
                        Ok(PushMessage::FilesSubscribed { file_ids }) => {
                            if events.send(PushEvent::FilesSubscribed { file_ids }).is_err() {
                                return SessionEnd::Quit;
                            }
                        }
                        Ok(PushMessage::CommentEvent { file_id, comment_id, action, actor_id, at }) => {
                            if events.send(PushEvent::Comment { file_id, comment_id, action, actor_id, at }).is_err() {
                                return SessionEnd::Quit;
                            }
                        }
                        Ok(PushMessage::Pong) | Ok(PushMessage::Subscribe { .. }) | Ok(PushMessage::SubscribeFiles { .. }) => {}
                        // 未知帧类型是向前兼容的正常情况(服务端先上新帧、客户端还没跟上),不刷 WARN
                        Err(error) => log::debug!("[drive-sync] 忽略不认识的推送帧(向前兼容): {error}; text={text}"),
                    },
                    Message::Ping(payload) => {
                        if let Err(error) = sink.send(Message::Pong(payload)).await {
                            return SessionEnd::Reconnect(format!("回 pong 失败: {error}"));
                        }
                    }
                    Message::Close(frame) => return SessionEnd::Reconnect(format!("服务端 close: {frame:?}")),
                    Message::Binary(_) | Message::Pong(_) | Message::Frame(_) => {}
                }
            }
            changed = subscriptions.changed() => {
                if changed.is_err() {
                    let _ = sink.send(Message::Close(None)).await;
                    return SessionEnd::Quit;
                }
                let current = subscriptions.borrow_and_update().clone();
                if let Err(error) = sink.send(subscribe(current)).await {
                    return SessionEnd::Reconnect(format!("重发 subscribe 失败: {error}"));
                }
            }
            changed = file_subscriptions.changed() => {
                if changed.is_err() {
                    let _ = sink.send(Message::Close(None)).await;
                    return SessionEnd::Quit;
                }
                // 关掉最后一个抽屉时发的是空集 —— 那正是「退订全部」,照发
                let current = file_subscriptions.borrow_and_update().clone();
                if let Err(error) = sink.send(subscribe_files(current)).await {
                    return SessionEnd::Reconnect(format!("重发 subscribe_files 失败: {error}"));
                }
            }
            _ = ping.tick() => {
                if last_frame.elapsed() >= config.idle_timeout {
                    return SessionEnd::Reconnect(format!("{} 秒无心跳", config.idle_timeout.as_secs()));
                }
                if let Err(error) = sink.send(Message::Text(serde_json::to_string(&PushMessage::Ping).expect("serialize").into())).await {
                    return SessionEnd::Reconnect(format!("发 ping 失败: {error}"));
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn 帧格式对齐契约() {
        assert_eq!(
            serde_json::to_string(&PushMessage::Subscribe {
                project_ids: vec![RemoteId::Number(1), RemoteId::Number(2)]
            })
            .unwrap(),
            r#"{"type":"subscribe","projectIds":[1,2]}"#
        );
        assert_eq!(serde_json::to_string(&PushMessage::Ping).unwrap(), r#"{"type":"ping"}"#);
        assert_eq!(
            serde_json::from_str::<PushMessage>(r#"{"type":"file_events","projectId":1,"seq":123}"#).unwrap(),
            PushMessage::FileEvents { project_id: RemoteId::Number(1), seq: 123 }
        );
        assert_eq!(serde_json::from_str::<PushMessage>(r#"{"type":"pong"}"#).unwrap(), PushMessage::Pong);
    }

    #[test]
    fn 评论帧格式对齐契约() {
        assert_eq!(
            serde_json::to_string(&PushMessage::SubscribeFiles { file_ids: vec![RemoteId::Number(123)] }).unwrap(),
            r#"{"type":"subscribe_files","fileIds":[123]}"#
        );
        assert_eq!(
            serde_json::from_str::<PushMessage>(r#"{"type":"files_subscribed","fileIds":[123]}"#).unwrap(),
            PushMessage::FilesSubscribed { file_ids: vec![RemoteId::Number(123)] }
        );
        assert_eq!(
            serde_json::from_str::<PushMessage>(
                r#"{"type":"comment_event","fileId":123,"commentId":456,"action":"applied","actorId":7,"at":"2026-09-04T10:30:15"}"#
            )
            .unwrap(),
            PushMessage::CommentEvent {
                file_id: RemoteId::Number(123),
                comment_id: RemoteId::Number(456),
                action: "applied".to_string(),
                actor_id: Some(RemoteId::Number(7)),
                at: Some("2026-09-04T10:30:15".to_string()),
            }
        );
    }

    #[test]
    fn 订阅确认帧被识别() {
        assert_eq!(
            serde_json::from_str::<PushMessage>(r#"{"type":"subscribed","projectIds":[]}"#).unwrap(),
            PushMessage::Subscribed { project_ids: Vec::new() }
        );
        assert_eq!(
            serde_json::from_str::<PushMessage>(r#"{"type":"subscribed","projectIds":[1,"k2"]}"#).unwrap(),
            PushMessage::Subscribed { project_ids: vec![RemoteId::Number(1), RemoteId::Text("k2".into())] }
        );
        // projectIds 缺省也认
        assert_eq!(
            serde_json::from_str::<PushMessage>(r#"{"type":"subscribed"}"#).unwrap(),
            PushMessage::Subscribed { project_ids: Vec::new() }
        );
    }
}

//! `/api/v1/sync/*` 客户端。响应信封 `{success, message, data}`;
//! 401 + `code: DEVICE_REVOKED` 单独成 `ClientError::Revoked`,引擎据此清空本地镜像。

use std::path::Path;
use std::time::Duration;

use tokio::io::AsyncSeekExt;

use reqwest::StatusCode;
use serde::de::DeserializeOwned;

use crate::types::{
    AiSearchHit, BatchRequest, BatchResponse, BlobInfo, ChangesPage, ClientConfig, CreateCommentRequest,
    CreateProjectFromTemplateRequest, CreatedProject, Department, DeviceInfo, DeviceRegistration, Envelope, FileAccess,
    FileComment, FolderInfo, GrantList, GrantResourceKind, GrantTarget, GrantWriteOutcome, InheritedFrom, Job,
    ProjectSummary, ProjectTemplate, RegisterDeviceRequest, RemoteId, SavedContent, SessionArchive, SetGrantRequest,
    SharedItem, Snapshot, SsoConfig, SsoExchangeRequest, SsoExchangeResponse, SyncMe, SyncRoot, UploadedFile,
    UserBrief, UserInfo,
};

pub const DEVICE_REVOKED_CODE: &str = "DEVICE_REVOKED";
pub const DEVICE_MISMATCH_CODE: &str = "DEVICE_MISMATCH";
/// 409:要删的那条授权是继承来的,只能去源头改(契约 §6.18)
pub const INHERITED_GRANT_CODE: &str = "INHERITED_GRANT";
/// 409:该主体有直接 DENY 行,档位接口不碰(POST / DELETE 都拒),去网页管理后台改(服务端 fe8485d)
pub const CUSTOM_GRANT_CODE: &str = "CUSTOM_GRANT";

/// 一次下载里最多接几次。每一次续传都**必然有进展**(只有读到新字节才会再试),所以这个数字
/// 管的是「一个文件被掐断多少次仍然下得完」,不是退避次数。生产上一个 228 MB 的文件在 116 MB
/// 处被上游掐断(2026-09-05),从头重下三次的结果是永远下不来。
pub const RESUME_ATTEMPTS: u32 = 8;

/// 建连上限。**故意不设总时长上限**:大文件本来就要下很久,给总时长封顶等于给文件大小封顶。
const CONNECT_TIMEOUT: Duration = Duration::from_secs(15);
/// 两个数据块之间的最长静默。一个不发数据也不断开的对端否则能把下载槽位永远占住;
/// 这个超时只管「有没有动静」,不管一共下多久
const READ_TIMEOUT: Duration = Duration::from_secs(60);

#[derive(Debug, Clone, thiserror::Error)]
pub enum ClientError {
    #[error("设备已被吊销")]
    Revoked,
    /// 403 + `DEVICE_MISMATCH`:请求里的 deviceId 与设备 token 不一致,要重新注册设备
    #[error("设备与令牌不匹配,请重新注册设备")]
    DeviceMismatch,
    #[error("未授权: {0}")]
    Unauthorized(String),
    #[error("HTTP {status}: {message}")]
    Http { status: u16, message: String },
    #[error("网络错误: {0}")]
    Transport(String),
    /// 读响应体时失败(reqwest 的 `error decoding response body`)。单说一句「解码失败」定位不了
    /// 问题,所以把判断成因所需的一切都带上:状态码、响应头声明的 `Content-Length` 与
    /// `Content-Encoding`、断掉之前实际读到的字节数。`read < content_length` 是服务端给错长度
    /// 或连接中途断,`content_encoding` 非 identity 则是被中间层压过而长度没跟着改。
    #[error(
        "{url} 响应体读取失败(HTTP {status}, Content-Length={content_length:?}, Content-Encoding={content_encoding:?}, 实际读到 {read} 字节): {message}"
    )]
    Body {
        url: String,
        status: u16,
        content_length: Option<u64>,
        content_encoding: Option<String>,
        read: u64,
        message: String,
    },
    #[error("响应格式错误: {0}")]
    Protocol(String),
}

impl ClientError {
    /// 读响应体读到一半失败 —— 换一条下载路径(按文件而不是按内容寻址)可能就好了。
    /// `Transport` 里也认一次:非下载路径的请求仍走 `bytes()`,reqwest 把它归到传输错。
    pub fn is_body_decode(&self) -> bool {
        match self {
            ClientError::Body { .. } => true,
            ClientError::Transport(message) => message.contains("error decoding response body"),
            _ => false,
        }
    }

    /// 鉴权类错误重试没有意义,要立刻往上抛(吊销还要触发清空)。
    pub fn is_fatal(&self) -> bool {
        matches!(self, ClientError::Revoked | ClientError::DeviceMismatch | ClientError::Unauthorized(_))
    }

    /// 同一条路径再请求一次有没有意义。4xx(408 / 429 除外)是确定性的拒绝 —— 再问一遍
    /// 还是同一个答案,退避纯属浪费时间;传输错、读体失败、5xx 则可能是一次性的。
    pub fn is_retryable(&self) -> bool {
        match self {
            ClientError::Revoked | ClientError::DeviceMismatch | ClientError::Unauthorized(_) => false,
            ClientError::Http { status, .. } => !(400..500).contains(status) || *status == 408 || *status == 429,
            ClientError::Protocol(_) => false,
            ClientError::Transport(_) | ClientError::Body { .. } => true,
        }
    }
}

/// 断点续传的进度回执。
#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BlobUploadProgress {
    pub uploaded: u64,
    pub complete: bool,
}

/// 从当前位置读 `len` 个字节的流(给分段上传用)。
fn counted_take_stream(
    file: tokio::fs::File, len: u64,
) -> impl futures_util::Stream<Item = Result<Vec<u8>, std::io::Error>> + Send {
    use tokio::io::AsyncReadExt;
    futures_util::stream::unfold((file, len), |(mut file, left)| async move {
        if left == 0 {
            return None;
        }
        let mut buffer = vec![0u8; (left.min(64 * 1024)) as usize];
        match file.read(&mut buffer).await {
            Ok(0) => Some((Err(std::io::Error::new(std::io::ErrorKind::UnexpectedEof, "文件比声明的短")), (file, 0))),
            Ok(read) => {
                buffer.truncate(read);
                Some((Ok(buffer), (file, left - read as u64)))
            }
            Err(error) => Some((Err(error), (file, 0))),
        }
    })
}

/// 服务端 `folder-tree` 的一个节点(只取我们要的字段)。
#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct CloudFolderNode {
    id: RemoteId,
    name: String,
    #[serde(default)]
    children: Vec<CloudFolderNode>,
}

/// 拍平之后的一条云端目录:项目内相对路径 + 服务端 id。
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize, PartialEq)]
#[cfg_attr(feature = "specta", derive(specta::Type))]
#[serde(rename_all = "camelCase")]
pub struct CloudFolder {
    /// 项目内相对路径,例如 `01_用户增长/02_增长策略_Wee`
    pub path: String,
    pub folder_id: RemoteId,
}

fn flatten_folders(nodes: &[CloudFolderNode], prefix: &str, out: &mut Vec<CloudFolder>) {
    for node in nodes {
        let path = if prefix.is_empty() { node.name.clone() } else { format!("{prefix}/{}", node.name) };
        out.push(CloudFolder { path: path.clone(), folder_id: node.id.clone() });
        flatten_folders(&node.children, &path, out);
    }
}

#[derive(Clone)]
pub struct DriveClient {
    base_url: String,
    token: String,
    http: reqwest::Client,
}

impl DriveClient {
    /// `base_url` 是服务器地址(如 `https://kb.example.com`),不含 `/api/v1`。
    pub fn new(base_url: &str, token: &str) -> Self {
        Self {
            base_url: base_url.trim_end_matches('/').to_string(),
            token: token.to_string(),
            http: reqwest::Client::builder()
                .connect_timeout(CONNECT_TIMEOUT)
                .read_timeout(READ_TIMEOUT)
                .build()
                .expect("reqwest client builds"),
        }
    }

    pub fn base_url(&self) -> &str {
        &self.base_url
    }

    pub fn token(&self) -> &str {
        &self.token
    }

    /// `/ws/sync?token=` 的完整地址:`http(s)://` 换成 `ws(s)://`。
    pub fn push_url(&self) -> String {
        let (scheme, rest) = match self.base_url.split_once("://") {
            Some(("https", rest)) => ("wss", rest),
            Some(("http", rest)) => ("ws", rest),
            other => panic!("服务器地址必须是 http(s)://,拿到 {other:?}"),
        };
        format!(
            "{scheme}://{rest}/ws/sync?token={}",
            form_urlencoded::byte_serialize(self.token.as_bytes()).collect::<String>()
        )
    }

    fn url(&self, path: &str) -> String {
        format!("{}/api/v1{path}", self.base_url)
    }

    /// 不带 Authorization 的请求(SSO 公开端点)。
    async fn send_json_public<T: DeserializeOwned>(&self, request: reqwest::RequestBuilder) -> Result<T, ClientError> {
        let response = request.send().await.map_err(|error| ClientError::Transport(error.to_string()))?;
        let status = response.status();
        let body = response.text().await.map_err(|error| ClientError::Transport(error.to_string()))?;
        if !status.is_success() {
            return Err(ClientError::Http { status: status.as_u16(), message: server_message(&body) });
        }
        let envelope: Envelope<T> =
            serde_json::from_str(&body).map_err(|error| ClientError::Protocol(format!("{error}; body={body}")))?;
        if !envelope.success {
            return Err(ClientError::Http { status: status.as_u16(), message: server_message(&body) });
        }
        envelope.data.ok_or_else(|| ClientError::Protocol("响应缺少 data".to_string()))
    }

    fn authorized(&self, request: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
        request.bearer_auth(&self.token)
    }

    async fn send(&self, request: reqwest::RequestBuilder) -> Result<reqwest::Response, ClientError> {
        self.send_prepared(self.authorized(request)).await
    }

    /// 同 `send`,但**不加 Authorization**:调用方自己决定要不要带(直链可能是外域,
    /// 把令牌送出去是泄露)。401 / 403 的信封识别两条路共用。
    async fn send_prepared(&self, request: reqwest::RequestBuilder) -> Result<reqwest::Response, ClientError> {
        let response = request.send().await.map_err(|error| ClientError::Transport(error.to_string()))?;
        let status = response.status();
        if status == StatusCode::UNAUTHORIZED {
            let body = response.text().await.unwrap_or_default();
            if let Ok(envelope) = serde_json::from_str::<Envelope<serde_json::Value>>(&body)
                && envelope.code.as_deref() == Some(DEVICE_REVOKED_CODE)
            {
                return Err(ClientError::Revoked);
            }
            return Err(ClientError::Unauthorized(body));
        }
        if status == StatusCode::FORBIDDEN {
            let body = response.text().await.unwrap_or_default();
            if let Ok(envelope) = serde_json::from_str::<Envelope<serde_json::Value>>(&body)
                && envelope.code.as_deref() == Some(DEVICE_MISMATCH_CODE)
            {
                return Err(ClientError::DeviceMismatch);
            }
            return Err(ClientError::Http { status: 403, message: body });
        }
        Ok(response)
    }

    async fn send_json<T: DeserializeOwned>(&self, request: reqwest::RequestBuilder) -> Result<T, ClientError> {
        let response = self.send(request).await?;
        let status = response.status();
        let body = response.text().await.map_err(|error| ClientError::Transport(error.to_string()))?;
        if !status.is_success() {
            return Err(ClientError::Http { status: status.as_u16(), message: server_message(&body) });
        }
        let envelope: Envelope<T> =
            serde_json::from_str(&body).map_err(|error| ClientError::Protocol(format!("{error}; body={body}")))?;
        if !envelope.success {
            return Err(ClientError::Http { status: status.as_u16(), message: server_message(&body) });
        }
        envelope.data.ok_or_else(|| ClientError::Protocol("响应缺少 data".to_string()))
    }

    /// 只回 `{success, code, message}`、没有 `data` 的写接口(PUT / DELETE 评论)。
    /// 失败时把服务端那句 message 原样带上 —— 「你改不了别人的评论」这种话只有服务端说得出。
    async fn send_void(&self, request: reqwest::RequestBuilder) -> Result<(), ClientError> {
        let response = self.send(request).await?;
        let status = response.status();
        let body = response.text().await.map_err(|error| ClientError::Transport(error.to_string()))?;
        let envelope = serde_json::from_str::<Envelope<serde_json::Value>>(&body).ok();
        if !status.is_success() {
            let message = envelope.and_then(|envelope| envelope.message).unwrap_or(body);
            return Err(ClientError::Http { status: status.as_u16(), message });
        }
        match envelope {
            Some(envelope) if !envelope.success => {
                Err(ClientError::Http { status: status.as_u16(), message: envelope.message.unwrap_or_default() })
            }
            Some(_) => Ok(()),
            None => Err(ClientError::Protocol(format!("响应不是信封格式; body={body}"))),
        }
    }

    // ─── roots / snapshot / changes ───────────────────────────────────────

    pub async fn roots(&self) -> Result<Vec<SyncRoot>, ClientError> {
        self.send_json(self.http.get(self.url("/sync/roots"))).await
    }

    pub async fn snapshot(&self, project_id: &RemoteId) -> Result<Snapshot, ClientError> {
        self.send_json(self.http.get(self.url("/sync/snapshot")).query(&[("projectId", project_id.as_key())])).await
    }

    pub async fn changes(&self, project_id: &RemoteId, cursor: &str, limit: u32) -> Result<ChangesPage, ClientError> {
        self.send_json(self.http.get(self.url("/sync/changes")).query(&[
            ("projectId", project_id.as_key()),
            ("cursor", cursor.to_string()),
            ("limit", limit.to_string()),
        ]))
        .await
    }

    // ─── blobs ────────────────────────────────────────────────────────────

    /// `HEAD /sync/blobs/{sha256}`:200 已存在 / 404 不存在。
    pub async fn blob_exists(&self, sha256: &str) -> Result<bool, ClientError> {
        let response = self.send(self.http.head(self.url(&format!("/sync/blobs/{sha256}")))).await?;
        match response.status() {
            StatusCode::OK => Ok(true),
            StatusCode::NOT_FOUND => Ok(false),
            status => {
                Err(ClientError::Http { status: status.as_u16(), message: "HEAD blob 非预期状态".to_string() })
            }
        }
    }

    /// `POST /sync/blobs` multipart:`file` + 表单 `sha256`。
    pub async fn upload_blob(&self, sha256: &str, file_name: &str, bytes: Vec<u8>) -> Result<BlobInfo, ClientError> {
        let boundary = format!("----yupdrive{}{}", &sha256[..16], bytes.len());
        let (content_type, body) = multipart_body(&boundary, sha256, file_name, bytes);
        self.send_json(self.http.post(self.url("/sync/blobs")).header("content-type", content_type).body(body)).await
    }

    /// `POST /sync/blobs`:**边读边传**,不把整个文件读进内存。
    ///
    /// 从前是 `std::fs::read` 读成一个 `Vec<u8>` 再交给 reqwest。传输并发是 8,于是内存峰值 =
    /// 8 × 单文件大小;单文件上限 500 MB,最坏情况几个 G(2026-09-14 查出)。文档类文件看不出
    /// 差别,一批数据集 / 视频同时上行就能把内存顶上去。
    ///
    /// **按 `size` 精确发**:Content-Length 提前算得出(前缀 + size + 后缀),不走 chunked ——
    /// 网关对 chunked 的 multipart 支持参差。代价是文件在「扫描算哈希」和「上传」之间被改过
    /// 时长度对不上:读不满就当场报错,让这一轮失败、下一轮重新算哈希,而不是发一个半截的包。
    pub async fn upload_blob_from_file(
        &self, sha256: &str, file_name: &str, path: &std::path::Path, size: u64,
    ) -> Result<BlobInfo, ClientError> {
        let boundary = format!("----yupdrive{}{}", &sha256[..16.min(sha256.len())], size);
        let (content_type, prefix, suffix) = multipart_frame(&boundary, &[("sha256", sha256)], file_name);
        let total = prefix.len() as u64 + size + suffix.len() as u64;
        let file = tokio::fs::File::open(path)
            .await
            .map_err(|error| ClientError::Protocol(format!("打开 {} 失败: {error}", path.display())))?;
        let body = reqwest::Body::wrap_stream(counted_file_stream(file, prefix, suffix, size));
        self.send_json(
            self.http
                .post(self.url("/sync/blobs"))
                .header(reqwest::header::CONTENT_TYPE, content_type)
                .header(reqwest::header::CONTENT_LENGTH, total)
                .body(body),
        )
        .await
    }

    /// `GET /sync/blobs/{sha256}` 拉内容(契约缺这一条,下行必需;见报告)。
    pub async fn download_blob(&self, sha256: &str) -> Result<Vec<u8>, ClientError> {
        let url = self.url(&format!("/sync/blobs/{sha256}"));
        self.download_resumable(&url, || self.authorized(identity_encoding(self.http.get(&url)))).await
    }

    /// 按文件下载:服务端老版本行 sha256 为 NULL 时没法走内容寻址的 `/sync/blobs/{sha}`。
    /// 先要 `GET /files/{id}/download-url` 的直链(data 可能是裸串,也可能是 `{url|downloadUrl|...}`),
    /// 拿不到就回落 `GET /files/{id}/download`(302,reqwest 自动跟随)。
    pub async fn download_file(&self, file_id: &RemoteId) -> Result<Vec<u8>, ClientError> {
        match self.file_download_url(file_id).await {
            Ok(url) => self.fetch_download(&url).await,
            // 吊销 / 设备不匹配是要往上抛的,不能被回落吞掉
            Err(error @ (ClientError::Revoked | ClientError::DeviceMismatch | ClientError::Unauthorized(_))) => {
                Err(error)
            }
            Err(error) => {
                log::debug!("[drive-sync] /files/{file_id}/download-url 不可用({error}),回落 /files/{{id}}/download");
                let url = self.url(&format!("/files/{file_id}/download"));
                self.download_resumable(&url, || self.authorized(identity_encoding(self.http.get(&url)))).await
            }
        }
    }

    /// `GET /files/{id}/download-url` → 直链。字段名各版本不一,常见的几种都认。
    async fn file_download_url(&self, file_id: &RemoteId) -> Result<String, ClientError> {
        let data: serde_json::Value =
            self.send_json(self.http.get(self.url(&format!("/files/{file_id}/download-url")))).await?;
        let url = match &data {
            serde_json::Value::String(url) => Some(url.clone()),
            serde_json::Value::Object(fields) => ["url", "downloadUrl", "download_url", "href", "signedUrl"]
                .iter()
                .find_map(|key| fields.get(*key).and_then(serde_json::Value::as_str).map(str::to_string)),
            _ => None,
        };
        url.filter(|url| !url.is_empty())
            .ok_or_else(|| ClientError::Protocol(format!("download-url 响应里没有直链: {data}")))
    }

    /// 抓直链内容。相对路径 / 同源直链带上 Authorization;对象存储的预签名直链不带
    /// (S3 同时收到 Authorization 头和预签名参数会直接拒)。
    async fn fetch_download(&self, url: &str) -> Result<Vec<u8>, ClientError> {
        let (absolute, same_origin) = resolve_download_url(&self.base_url, url);
        self.download_resumable(&absolute, || {
            let request = identity_encoding(self.http.get(&absolute));
            // 外域直链不带 Authorization:把令牌送到别人家去是泄露
            if same_origin { self.authorized(request) } else { request }
        })
        .await
    }

    /// 把一个 URL 读完,**读到一半断了就接着读**,而不是从 0 重来。
    ///
    /// 生产实测:一个 228 MB 的文件读到 116 MB 被上游掐断,于是三次尝试各从 0 开始、各死在
    /// 半路,这个文件永远下不来(2026-09-05)。断点续传把「重来」换成「接上」,每一次失败
    /// 之后手上都还留着已经读到的那一截。
    ///
    /// **服务端还没上线 Range 时必须识破**:带着 `Range` 问却回 200(而不是 206)说明对端把
    /// **整份**内容发回来了 —— 那时候把它接在手上那一截后面,拼出来的是一个损坏的文件。
    /// 一旦发现这件事就记住它,之后老老实实每趟从头下。
    ///
    /// `build` 每趟现造一个请求(RequestBuilder 用一次就没了),要不要带 Authorization 由它决定。
    async fn download_resumable<F>(&self, url: &str, build: F) -> Result<Vec<u8>, ClientError>
    where
        F: Fn() -> reqwest::RequestBuilder,
    {
        let mut bytes: Vec<u8> = Vec::new();
        // 期望的**总**长度(不是这一段的长度):200 时来自 Content-Length,206 时来自 Content-Range
        let mut expected_total: Option<u64> = None;
        let mut range_supported = true;
        let mut last: Option<ClientError> = None;
        for attempt in 0..RESUME_ATTEMPTS {
            // 对端不认 Range:每一趟都只能从头,手上那截留着没有意义
            if !range_supported {
                bytes.clear();
                expected_total = None;
            }
            let resuming = !bytes.is_empty();
            let request = build();
            let request = if resuming {
                request.header(reqwest::header::RANGE, format!("bytes={}-", bytes.len()))
            } else {
                request
            };
            let response = self.send_prepared(request).await?;
            let status = response.status();
            if status == StatusCode::PARTIAL_CONTENT {
                // 服务端给的这一段必须正好接在手上那一截后面。对不上就别乱拼 —— 宁可整个失败,
                // 也不要往本地写一个字节序错乱的文件
                match content_range(&response) {
                    Some((start, total)) if start == bytes.len() as u64 => expected_total = expected_total.or(total),
                    other => {
                        return Err(ClientError::Protocol(format!(
                            "{url} 续传响应的 Content-Range 接不上(手上 {} 字节,服务端说 {other:?})",
                            bytes.len()
                        )));
                    }
                }
            } else if status.is_success() {
                if resuming {
                    log::info!("[drive-sync] {url} 服务端未实现 Range(续传请求回 {status}),放弃续传、整份重下");
                    range_supported = false;
                    bytes.clear();
                }
                expected_total = header_u64(&response, "content-length");
            } else {
                // 416:要的偏移越界(服务端换了内容 / 我们数错了)→ 丢掉手上的重来一趟
                if resuming && status == StatusCode::RANGE_NOT_SATISFIABLE {
                    log::warn!("[drive-sync] {url} 续传偏移 {} 越界,从头重下", bytes.len());
                    bytes.clear();
                    expected_total = None;
                    continue;
                }
                return Err(ClientError::Http { status: status.as_u16(), message: format!("下载 {url} 失败") });
            }

            let before = bytes.len();
            match read_chunks(response, url, &mut bytes).await {
                Ok(()) => {
                    // 声明了总长就必须对得上:少了是被截断,多了是服务端给错长度 —— 两种都不能落盘
                    if let Some(total) = expected_total
                        && total != bytes.len() as u64
                    {
                        return Err(ClientError::Body {
                            url: url.to_string(),
                            status: status.as_u16(),
                            content_length: Some(total),
                            content_encoding: None,
                            read: bytes.len() as u64,
                            message: "响应体字节数与声明的总长不符".to_string(),
                        });
                    }
                    if attempt > 0 {
                        log::info!("[drive-sync] {url} 第 {} 趟接上,共 {} 字节", attempt + 1, bytes.len());
                    }
                    return Ok(bytes);
                }
                Err(error) => {
                    // 这一趟一个新字节都没读到:卡在开头,再带 Range 问也是同一个结果。
                    // 往上抛,交给上层换一条下载路径 / 退避
                    if bytes.len() == before {
                        return Err(error);
                    }
                    // **对端不认 Range:接不上,重来也只是同一趟**(2026-09-07 实报)。
                    // 线上还没部署 Range 支持,而网关在几十兆处掐断:每一趟都从 0 下同样的
                    // 几十兆、死在同样的地方,八趟全废,下一轮再来一遍 —— 十分钟里同一个 blob
                    // 被试了 12 次,把整个引擎的时间占满,上行因此排不上。
                    // 续传不可能时,这个循环唯一能做的就是**别空转**:立刻交给上层退避。
                    if !range_supported {
                        log::warn!(
                            "[drive-sync] {url} 读到 {} 字节被掐断,而对端不支持 Range —— 重下只会是同一趟,交给上层退避",
                            bytes.len()
                        );
                        return Err(error);
                    }
                    log::warn!(
                        "[drive-sync] {url} 读到 {} 字节被掐断,带 Range 接着读(第 {}/{RESUME_ATTEMPTS} 趟): {error}",
                        bytes.len(),
                        attempt + 1
                    );
                    last = Some(error);
                }
            }
        }
        Err(last.expect("循环至少失败一次"))
    }

    // ─── 会话归档 ─────────────────────────────────────────────────────────

    /// `POST /sessions/archive`(V61)multipart:`file` + `sessionId` + `sha256`,
    /// `projectId` / `folderPath` 可空。
    ///
    /// 落点交给服务端:带 `projectId` 就落该项目,不带就落调用者的个人知识库 ——
    /// **客户端对不上项目时不要猜一个**,猜错等于把一段私人对话塞进别人的项目。
    /// 身份是 `sessionId`:内容没变就幂等返回原来那份,内容变了(对话续写)出同一个文件的新版本。
    ///
    /// `folder_path`(契约 §6.12,2026-09-07 老板拍板)= 对话发生在项目内的哪个子目录,
    /// **相对项目根、不含项目自己那一层**;落点 `<folderPath>/session/<文件名>`,省略即项目根
    /// (从前的行为)。缺的目录由归档接口自己建,**不需要先发 MKDIR**。落点在第一次归档时
    /// 定死,续写只在原目录出新版本、忽略这次带的值。
    ///
    /// 老的「往 `ai-session-archive` 推」已经停写(403 `SESSION_ARCHIVE_READ_ONLY`),
    /// 历史数据原样留着,不迁移。
    pub async fn archive_session(
        &self, session_id: &str, sha256: &str, project_id: Option<&RemoteId>, folder_path: Option<&str>,
        file_name: &str, bytes: Vec<u8>,
    ) -> Result<SessionArchive, ClientError> {
        let boundary = format!("----yupsession{}{}", &sha256[..16.min(sha256.len())], bytes.len());
        let project = project_id.map(RemoteId::as_key);
        let mut fields: Vec<(&str, &str)> = vec![("sessionId", session_id), ("sha256", sha256)];
        if let Some(project) = project.as_deref() {
            fields.push(("projectId", project));
        }
        if let Some(folder_path) = folder_path {
            fields.push(("folderPath", folder_path));
        }
        let (content_type, body) = multipart_file_body(&boundary, &fields, file_name, bytes);
        self.send_json(self.http.post(self.url("/sessions/archive")).header("content-type", content_type).body(body))
            .await
    }

    /// `GET /users/search?q=&limit=` —— @ 人的搜人接口。
    ///
    /// 空关键词直接回空表,不打服务端:输入框里刚敲下 `@` 还没打字时问一遍毫无意义。
    pub async fn search_users(&self, query: &str, limit: u32) -> Result<Vec<UserBrief>, ClientError> {
        let query = query.trim();
        if query.is_empty() {
            return Ok(Vec::new());
        }
        self.send_json(self.http.get(self.url("/users/search")).query(&[("q", query), ("limit", &limit.to_string())]))
            .await
    }

    /// `GET /client/config`(契约 §6.16)。已登录即可。
    pub async fn client_config(&self) -> Result<ClientConfig, ClientError> {
        self.send_json(self.http.get(self.url("/client/config"))).await
    }

    // ─── 沉淀(condense)──────────────────────────────────────────────────

    /// `POST /projects/{id}/condense` —— 建一条 condense job(契约 §2「便捷入口」)。
    ///
    /// **不带 `targetKnowledgeProjectId`**:落哪个知识库由服务端按项目的部门决定,客户端猜一个
    /// 就可能把一份部门知识塞进别人的库。服务端说不清时会回明确的错误码(部门还没有知识库 /
    /// 有多个要选一个),那句话原样给用户看 —— 他据此才知道该做什么。
    ///
    /// `scope_path`(服务端 140de57):只沉淀项目内这一个目录或这一份文件,相对项目根;
    /// 不传 = 整个项目。多选不做 —— 一次沉淀对应一件事。
    pub async fn create_condense_job(
        &self, project_id: &RemoteId, scope_path: Option<&str>,
    ) -> Result<Job, ClientError> {
        let mut body = serde_json::Map::new();
        if let Some(scope) = scope_path {
            body.insert("scopePath".into(), serde_json::Value::String(scope.to_string()));
        }
        self.send_json(self.http.post(self.url(&format!("/projects/{project_id}/condense"))).json(&body)).await
    }

    /// 这个项目上待批准的沉淀建议(`GET /jobs?projectId&status=PROPOSED`)。
    ///
    /// **不带 `mine=true`**:夜间扫描生成的 PROPOSED **没有发起人**(契约 §6.8),
    /// 带上 mine 就正好把要找的那些全滤掉了。
    ///
    /// **按项目问,不问全公司**:提示只在用户此刻待着的那个项目上出现 —— 「宁可漏,不可烦」
    /// 是第一硬约束,判错了两周后所有人学会无视它,比不提更糟。
    pub async fn proposed_jobs(&self, project_id: &RemoteId) -> Result<Vec<Job>, ClientError> {
        let page: JobListResponse = self
            .send_json(self.http.get(self.url("/jobs")).query(&[
                ("projectId", project_id.as_key().as_str()),
                ("status", "PROPOSED"),
                ("size", "20"),
            ]))
            .await?;
        Ok(page.into_jobs())
    }

    /// `POST /jobs/{id}/approve` —— PROPOSED → PENDING(契约 §6.8)。这就是「一键接受」。
    pub async fn approve_job(&self, job_id: &RemoteId) -> Result<(), ClientError> {
        self.send_void(self.http.post(self.url(&format!("/jobs/{job_id}/approve")))).await
    }

    /// `POST /jobs/{id}/cancel` —— 两处都用它:用户说「别再问」时把那条建议丢掉
    /// (不丢的话夜间扫描会一直挂着它,换台机器又被问一次),以及取消一条正在跑的沉淀。
    pub async fn cancel_job(&self, job_id: &RemoteId) -> Result<(), ClientError> {
        self.send_void(self.http.post(self.url(&format!("/jobs/{job_id}/cancel")))).await
    }

    /// `GET /jobs/{id}` —— 轮询一条任务。沉淀要拉整个项目的快照再跑模型,几十秒到几分钟都正常,
    /// 期间界面上必须看得见在干活。
    pub async fn job(&self, job_id: &RemoteId) -> Result<Job, ClientError> {
        self.send_json(self.http.get(self.url(&format!("/jobs/{job_id}")))).await
    }

    // ─── batch ────────────────────────────────────────────────────────────

    pub async fn batch(&self, request: &BatchRequest) -> Result<BatchResponse, ClientError> {
        self.send_json(self.http.post(self.url("/sync/batch")).json(request)).await
    }

    // ─── 6.1 SSO(公开端点,不带 token)─────────────────────────────────────

    pub async fn sso_config(&self) -> Result<SsoConfig, ClientError> {
        self.send_json_public(self.http.get(self.url("/auth/sso/config"))).await
    }

    pub async fn sso_exchange(&self, request: &SsoExchangeRequest) -> Result<SsoExchangeResponse, ClientError> {
        self.send_json_public(self.http.post(self.url("/auth/sso/exchange")).json(request)).await
    }

    // ─── 6.7 协同 ─────────────────────────────────────────────────────────────

    /// `GET /files/{id}`:只取协同要的 `canWrite` 与评论要的 `ownerId`。
    pub async fn file_access(&self, file_id: &RemoteId) -> Result<FileAccess, ClientError> {
        self.send_json(self.http.get(self.url(&format!("/files/{file_id}")))).await
    }

    /// `PUT /files/{id}/move {folderId, targetProjectId}`:把一份文件搬到另一个项目。
    ///
    /// 这是**唯一**不靠本地 FS 完成的移动。本地 FS move 只在两个根都落了盘时才做得到,
    /// 而「移动到…」现在也列没同步到本地的项目 —— 那些目录在磁盘上根本不存在,rename 无从谈起。
    /// 内容按 sha256 存在 OSS 里,跨项目搬家一个字节都不用传,纯粹是服务端改两个字段。
    ///
    /// `target_folder_id = None` = 目标项目的根。服务端会校验目标项目的写权限,没有就 403
    /// `FORBIDDEN_TARGET` —— 移动不能成为绕过权限模型的口子,这一关不在客户端做。
    ///
    /// 移完**不动本地**:服务端会在旧项目发 FILE_DELETED、新项目发 FILE_CREATED,引擎下一轮
    /// 照常收拾(`apply_remote_delete` 删本地那份、目标项目同步到本地时再拉下来)。自己抢着删
    /// 本地文件反而危险:watcher 会把它当成一次本地删除,拿着同一个 fileId 去删服务端上刚搬过去的那份。
    pub async fn move_file(
        &self, file_id: &RemoteId, target_project_id: &RemoteId, target_folder_id: Option<&RemoteId>,
    ) -> Result<(), ClientError> {
        let result = self
            .send_void(self.http.put(self.url(&format!("/files/{file_id}/move"))).json(&serde_json::json!({
                "folderId": target_folder_id,
                "targetProjectId": target_project_id,
            })))
            .await;
        readable_forbidden(result)
    }

    /// `PUT /folders/{id}/move {parentId, targetProjectId}`:把一个目录<b>连同整棵子树</b>搬到另一个项目。
    ///
    /// 与 {@link move_file} 同一条路,但**必须是一次调用**:服务端在一个事务里把子树的目录和文件
    /// 一起改完。换成客户端遍历子树一份份调文件接口,中途失败就会留下「目录在新项目、一半文件还在
    /// 旧项目」的残局 —— 目录这一层没有任何东西能把它对回去。
    ///
    /// `target_parent_id = None` = 目标项目的根。403 `FORBIDDEN_TARGET` 同样是常规结果。
    pub async fn move_folder(
        &self, folder_id: &RemoteId, target_project_id: &RemoteId, target_parent_id: Option<&RemoteId>,
    ) -> Result<(), ClientError> {
        let result = self
            .send_void(self.http.put(self.url(&format!("/folders/{folder_id}/move"))).json(&serde_json::json!({
                "parentId": target_parent_id,
                "targetProjectId": target_project_id,
            })))
            .await;
        readable_forbidden(result)
    }

    // ─── 文件评论 ─────────────────────────────────────────────────────────────

    /// `GET /files/{fileId}/comments`:服务端直接给嵌套树,按 createdAt 升序。
    pub async fn comments(&self, file_id: &RemoteId) -> Result<Vec<FileComment>, ClientError> {
        self.send_json(self.http.get(self.url(&format!("/files/{file_id}/comments")))).await
    }

    /// `POST /files/{fileId}/comments`。只要 READ 权就能发 —— 只读文件(需走修改申请的那种)
    /// 照样能评论,评论不是改内容。
    pub async fn create_comment(
        &self, file_id: &RemoteId, request: &CreateCommentRequest,
    ) -> Result<FileComment, ClientError> {
        self.send_json(self.http.post(self.url(&format!("/files/{file_id}/comments"))).json(request)).await
    }

    /// `PUT /comments/{commentId}`:服务端只认 `body`,其余字段改不了。
    pub async fn update_comment(&self, comment_id: &RemoteId, body: &str) -> Result<(), ClientError> {
        self.send_void(
            self.http.put(self.url(&format!("/comments/{comment_id}"))).json(&serde_json::json!({ "body": body })),
        )
        .await
    }

    /// `DELETE /comments/{commentId}`:软删除;还有回复挂着时留一个墓碑。
    pub async fn delete_comment(&self, comment_id: &RemoteId) -> Result<(), ClientError> {
        self.send_void(self.http.delete(self.url(&format!("/comments/{comment_id}")))).await
    }

    /// `POST /comments/{commentId}/apply`:采纳建议替换 → 生成新版本。文件所有者(或管理员)才可以;
    /// 引文已不在当前版本时服务端回 400 `QUOTE_NOT_IN_CURRENT_VERSION`,message 就是给用户看的那句。
    pub async fn apply_comment(&self, comment_id: &RemoteId) -> Result<FileComment, ClientError> {
        self.send_json(self.http.post(self.url(&format!("/comments/{comment_id}/apply")))).await
    }

    // ─── 6.18 权限档位与协作者 ───────────────────────────────────────────────

    fn grants_path(target: &GrantTarget) -> String {
        match target.kind {
            GrantResourceKind::File => format!("/files/{}/grants", target.id),
            GrantResourceKind::Folder => format!("/folders/{}/grants", target.id),
        }
    }

    /// `GET /files|folders/{id}/grants`:READ 权即可看。顶层是对象(`grants` / `implicit` / `callerLevel`)。
    pub async fn grants(&self, target: &GrantTarget) -> Result<GrantList, ClientError> {
        self.send_json(self.http.get(self.url(&Self::grants_path(target)))).await
    }

    /// `POST /files|folders/{id}/grants`:幂等地把该主体的直接 ALLOW 行调成恰好等于这个档位。
    /// 需要 MANAGE_PERMISSION。成功时带回 GET 同一个对象;主体有直接 DENY 行 → `Custom`。
    pub async fn set_grant(
        &self, target: &GrantTarget, request: &SetGrantRequest,
    ) -> Result<GrantWriteOutcome, ClientError> {
        self.grant_write(target, self.http.post(self.url(&Self::grants_path(target))).json(request)).await
    }

    /// `DELETE /files|folders/{id}/grants/{subjectType}/{subjectId}`:只删直接行(`ALL` 走 `/ALL/0`)。
    ///
    /// 该主体在此资源上只有继承来的行时服务端回 `409 INHERITED_GRANT` 并带 `inheritedFrom` ——
    /// 这**不是错误**,是「去源头改」的引导,所以单独成一个结局而不是塞进 `ClientError::Http`。
    /// `subject_type` 按列表里给的原样回传(开放枚举,这里不做校验 —— 服务端拒不拒由它说)。
    pub async fn remove_grant(
        &self, target: &GrantTarget, subject_type: &str, subject_id: &RemoteId,
    ) -> Result<GrantWriteOutcome, ClientError> {
        let url = self.url(&format!("{}/{subject_type}/{subject_id}", Self::grants_path(target)));
        self.grant_write(target, self.http.delete(url)).await
    }

    /// POST / DELETE 共用的收尾:409 里认 `INHERITED_GRANT` / `CUSTOM_GRANT` 两个码,其余照常报错;
    /// 成功时 `data` 就是新的列表。万一服务端没带 `data`(契约初版没说死),补一趟 GET —— 列表刷新是
    /// 硬要求,不能因为响应形状差一点就让面板停在旧名单上。
    async fn grant_write(
        &self, target: &GrantTarget, request: reqwest::RequestBuilder,
    ) -> Result<GrantWriteOutcome, ClientError> {
        let response = self.send(request).await?;
        let status = response.status();
        let body = response.text().await.map_err(|error| ClientError::Transport(error.to_string()))?;
        if status == StatusCode::CONFLICT {
            match grant_conflict(&body) {
                Some(GrantConflict::Inherited(inherited_from)) => {
                    return Ok(GrantWriteOutcome::Inherited { inherited_from });
                }
                Some(GrantConflict::Custom) => return Ok(GrantWriteOutcome::Custom),
                None => {}
            }
        }
        if !status.is_success() {
            return Err(ClientError::Http { status: status.as_u16(), message: server_message(&body) });
        }
        let envelope: Envelope<GrantList> =
            serde_json::from_str(&body).map_err(|error| ClientError::Protocol(format!("{error}; body={body}")))?;
        if !envelope.success {
            return Err(ClientError::Http { status: status.as_u16(), message: server_message(&body) });
        }
        let list = match envelope.data {
            Some(list) => list,
            None => self.grants(target).await?,
        };
        Ok(GrantWriteOutcome::Applied { list })
    }

    /// `GET /departments?q=`:添加协作者时搜部门(契约 §6.18)。空关键词与搜人一样短路。
    pub async fn search_departments(&self, query: &str) -> Result<Vec<Department>, ClientError> {
        let query = query.trim();
        if query.is_empty() {
            return Ok(Vec::new());
        }
        self.send_json(self.http.get(self.url("/departments")).query(&[("q", query)])).await
    }

    // ─── 「分享给我的」 ──────────────────────────────────────────────────────

    /// `GET /shared-with-me`:**直接授给本人**的文件与目录(服务端 `GrantService#sharedWithMe`)。
    ///
    /// 口径由服务端定死:只有 USER 主体的直接授权。部门 / 全公司的集体授权**不在里面** ——
    /// 那是底权限不是「分享给我」,把三百人共有的东西也列进来,这个列表第一天就没法看了。
    ///
    /// 404 / 501 在这里**不特殊处理**,照常回 `Http` —— 「服务端还没部署这个接口」与「真的出错了」
    /// 的区分是调用方的事(见 `Engine::shared_with_me`:前者当成空表,后者要让用户看见)。
    pub async fn shared_with_me(&self) -> Result<Vec<SharedItem>, ClientError> {
        self.send_json(self.http.get(self.url("/shared-with-me"))).await
    }

    /// `GET /folders/{id}`:取这个目录的 `fullPath`(项目内位置)。
    ///
    /// `/shared-with-me` 只给 `projectId`,不给路径。网页端因此只能做到「打开所在项目」
    /// (见 `pages/shared/index.vue` 的注释);桌面端要把人送到**本地那个目录**,就得多问这一趟。
    pub async fn folder(&self, folder_id: &RemoteId) -> Result<FolderInfo, ClientError> {
        self.send_json(self.http.get(self.url(&format!("/folders/{folder_id}")))).await
    }

    // ─── 6.8 新建项目向导 ────────────────────────────────────────────────────

    pub async fn project_templates(&self) -> Result<Vec<ProjectTemplate>, ClientError> {
        self.send_json(self.http.get(self.url("/project-templates"))).await
    }

    /// 扁平部门列表(`forCurrentUser=true`:只给当前用户所在的部门)。
    pub async fn departments(&self, for_current_user: bool) -> Result<Vec<Department>, ClientError> {
        self.send_json(
            self.http.get(self.url("/departments")).query(&[("forCurrentUser", for_current_user.to_string())]),
        )
        .await
    }

    pub async fn create_project_from_template(
        &self, request: &CreateProjectFromTemplateRequest,
    ) -> Result<CreatedProject, ClientError> {
        self.send_json(self.http.post(self.url("/projects/from-template")).json(request)).await
    }

    // ─── 会话归档(上行专用根)/ 知识回流 / 版本保存 ────────────────────────────

    /// `GET /projects/by-key/{key}`:roots 里没有 `ai-session-archive` 时用它取 projectId。
    pub async fn project_by_key(&self, project_key: &str) -> Result<ProjectSummary, ClientError> {
        let encoded: String = form_urlencoded::byte_serialize(project_key.as_bytes()).collect();
        self.send_json(self.http.get(self.url(&format!("/projects/by-key/{encoded}")))).await
    }

    /// `GET /sync/me`:当前用户(SKILL 自动分发要它的部门)。响应字段名各版本不一,
    /// 交给 `parse_sync_me` 宽松解析;这个端点不存在时调用方按「拿不到部门」处理。
    pub async fn sync_me(&self) -> Result<SyncMe, ClientError> {
        let data: serde_json::Value = self.send_json(self.http.get(self.url("/sync/me"))).await?;
        Ok(parse_sync_me(&data))
    }

    /// `GET /auth/me`:归档目录前缀取邮箱前缀。
    pub async fn me(&self) -> Result<UserInfo, ClientError> {
        self.send_json(self.http.get(self.url("/auth/me"))).await
    }

    /// `POST /folders/ensure {projectId, parentId: null, relativePath}` → folderId(插件同款)。
    pub async fn ensure_folder(&self, project_id: &RemoteId, relative_path: &str) -> Result<RemoteId, ClientError> {
        self.send_json(self.http.post(self.url("/folders/ensure")).json(&serde_json::json!({
            "projectId": project_id,
            "parentId": null,
            "relativePath": relative_path,
        })))
        .await
    }

    /// `GET /projects/{id}/folder-tree`:云端的目录树。
    ///
    /// 「移动到…」那个选择器从前只列**磁盘上有**的目录(`readDirFiltered`),于是云端有、本地还没
    /// 同步下来的目录在对话框里根本不存在 —— 用户在云盘网页上看得见,在这里选不到
    /// (2026-09-15 同事实报)。索引里那张 `folders` 表顶不上这个用:它只记「本机 MKDIR 成功过的
    /// 目录」,不是云端的镜像。所以直接问服务端。
    pub async fn folder_tree(&self, project_id: &RemoteId) -> Result<Vec<CloudFolder>, ClientError> {
        let nodes: Vec<CloudFolderNode> =
            self.send_json(self.http.get(self.url(&format!("/projects/{project_id}/folder-tree")))).await?;
        let mut out = Vec::new();
        flatten_folders(&nodes, "", &mut out);
        Ok(out)
    }

    /// `GET /sync/blobs/{sha256}/uploaded`:这个 blob 服务端已经收到多少字节。
    /// `-1` = 整份都在了(秒传)。老服务端没这个接口 → 当 0 处理,退回整份上传。
    pub async fn uploaded_length(&self, sha256: &str) -> Result<i64, ClientError> {
        match self.send_json::<i64>(self.http.get(self.url(&format!("/sync/blobs/{sha256}/uploaded")))).await {
            Ok(value) => Ok(value),
            // 404 / 405 = 服务端还没上这个接口。不是错,退回老路
            Err(ClientError::Http { status: 404 | 405, .. }) => Ok(0),
            Err(error) => Err(error),
        }
    }

    /// `POST /sync/blobs/{sha256}/append?position&total`:追加一段字节。
    ///
    /// 请求体是**裸字节**(不是 multipart):每段只有几 MB,multipart 的边界与临时文件
    /// 在这条路上纯属开销。服务端收齐(position + 这一段 == total)就当场校验 sha 并转正。
    pub async fn append_blob(
        &self, sha256: &str, path: &Path, position: u64, len: u64, total: u64,
    ) -> Result<BlobUploadProgress, ClientError> {
        let mut file = tokio::fs::File::open(path)
            .await
            .map_err(|error| ClientError::Transport(format!("打开 {}: {error}", path.display())))?;
        file.seek(std::io::SeekFrom::Start(position))
            .await
            .map_err(|error| ClientError::Transport(format!("定位 {} 到 {position}: {error}", path.display())))?;
        let stream = counted_take_stream(file, len);
        self.send_json(
            self.http
                .post(self.url(&format!("/sync/blobs/{sha256}/append?position={position}&total={total}")))
                .header("content-type", "application/octet-stream")
                .header("content-length", len.to_string())
                .body(reqwest::Body::wrap_stream(stream)),
        )
        .await
    }

    /// `POST /files/upload?projectId&folderId&name&summary&changeControlled=false`(插件用的上传接口;
    /// `sync_enabled=false` 的项目 batch 返回 FORBIDDEN 时归档走这里)。
    pub async fn upload_file(
        &self, project_id: &RemoteId, folder_id: Option<&RemoteId>, name: &str, summary: &str, bytes: Vec<u8>,
    ) -> Result<UploadedFile, ClientError> {
        let boundary = format!("----yupupload{}", bytes.len());
        let (content_type, body) = multipart_file_body(&boundary, &[], name, bytes);
        let mut query: Vec<(&str, String)> = vec![
            ("projectId", project_id.as_key()),
            ("name", name.to_string()),
            ("summary", summary.to_string()),
            ("changeControlled", "false".to_string()),
        ];
        if let Some(folder_id) = folder_id {
            query.push(("folderId", folder_id.as_key()));
        }
        self.send_json(
            self.http.post(self.url("/files/upload")).query(&query).header("content-type", content_type).body(body),
        )
        .await
    }

    /// `POST /files/{id}/upload-version?summary`:已归档过的会话再传新版本。404 / 410 = 远端已删,调用方改走全量上传。
    pub async fn upload_version(
        &self, file_id: &RemoteId, name: &str, summary: &str, bytes: Vec<u8>,
    ) -> Result<UploadedFile, ClientError> {
        let boundary = format!("----yupversion{}", bytes.len());
        let (content_type, body) = multipart_file_body(&boundary, &[], name, bytes);
        self.send_json(
            self.http
                .post(self.url(&format!("/files/{file_id}/upload-version")))
                .query(&[("summary", summary)])
                .header("content-type", content_type)
                .body(body),
        )
        .await
    }

    /// `POST /files/{id}/save-content {content, baseVersionId}`:编辑器「立即保存版本」(协同中 frontmatter 改动等)。
    pub async fn save_content(
        &self, file_id: &RemoteId, content: &str, base_version_id: &RemoteId,
    ) -> Result<SavedContent, ClientError> {
        self.send_json(self.http.post(self.url(&format!("/files/{file_id}/save-content"))).json(&serde_json::json!({
            "content": content,
            "baseVersionId": base_version_id,
        })))
        .await
    }

    /// `GET /ai/search?q&kind&size`:6.10 —— 不带 mode 时 data 是数组,semantic / hybrid 时是 `{items,total}`,两种都收。
    pub async fn ai_search(&self, query: &str, kind: Option<&str>, size: u32) -> Result<Vec<AiSearchHit>, ClientError> {
        let mut params: Vec<(&str, String)> = vec![("q", query.to_string()), ("size", size.to_string())];
        if let Some(kind) = kind {
            params.push(("kind", kind.to_string()));
        }
        let data: serde_json::Value = self.send_json(self.http.get(self.url("/ai/search")).query(&params)).await?;
        let items = match data {
            serde_json::Value::Array(items) => items,
            serde_json::Value::Object(mut page) => match page.remove("items") {
                Some(serde_json::Value::Array(items)) => items,
                _ => Vec::new(),
            },
            _ => Vec::new(),
        };
        items
            .into_iter()
            .map(|item| {
                serde_json::from_value::<AiSearchHit>(item)
                    .map_err(|error| ClientError::Protocol(format!("ai/search 命中格式错误: {error}")))
            })
            .collect()
    }

    // ─── devices ──────────────────────────────────────────────────────────

    pub async fn register_device(&self, request: &RegisterDeviceRequest) -> Result<DeviceRegistration, ClientError> {
        self.send_json(self.http.post(self.url("/sync/devices/register")).json(request)).await
    }

    pub async fn heartbeat(&self, device_id: &str, client_version: &str) -> Result<(), ClientError> {
        let response = self
            .send(self.http.post(self.url("/sync/devices/heartbeat")).json(&serde_json::json!({
                "deviceId": device_id,
                "clientVersion": client_version,
            })))
            .await?;
        let status = response.status();
        if !status.is_success() {
            return Err(ClientError::Http { status: status.as_u16(), message: "心跳失败".to_string() });
        }
        Ok(())
    }

    pub async fn devices(&self) -> Result<Vec<DeviceInfo>, ClientError> {
        self.send_json(self.http.get(self.url("/sync/devices"))).await
    }

    pub async fn revoke_device(&self, device_id: &str) -> Result<(), ClientError> {
        let response = self.send(self.http.post(self.url(&format!("/sync/devices/{device_id}/revoke")))).await?;
        let status = response.status();
        if !status.is_success() {
            return Err(ClientError::Http { status: status.as_u16(), message: "吊销失败".to_string() });
        }
        Ok(())
    }
}

/// `/sync/me` 的宽松解析。契约只钉了 `{userId, displayName, employeeNo}`,部门字段是**待服务端补**
/// 的(见 docs/drive.md);在它落地之前先把几种常见写法都认一遍,一个都拿不到就返回 None ——
/// 调用方据此退化成「只自动装公司级 SKILL」。
fn parse_sync_me(data: &serde_json::Value) -> SyncMe {
    let string_at = |keys: &[&str]| -> Option<String> {
        keys.iter()
            .find_map(|key| data.get(*key).and_then(serde_json::Value::as_str))
            .map(str::to_string)
            .filter(|value| !value.trim().is_empty())
    };
    // 部门可能是嵌套对象:{department: {id, name}} / {dept: {id, name}}
    let nested = data.get("department").or_else(|| data.get("dept")).filter(|value| value.is_object());
    let nested_string = |key: &str| -> Option<String> {
        nested.and_then(|value| value.get(key)).and_then(serde_json::Value::as_str).map(str::to_string)
    };
    let id_at = |keys: &[&str]| -> Option<RemoteId> {
        keys.iter()
            .find_map(|key| data.get(*key))
            .and_then(|value| serde_json::from_value::<RemoteId>(value.clone()).ok())
    };
    SyncMe {
        user_id: id_at(&["userId", "user_id", "id"]),
        display_name: string_at(&["displayName", "display_name", "name"]),
        employee_no: string_at(&["employeeNo", "employee_no"]),
        department_id: id_at(&["departmentId", "department_id", "deptId", "dept_id"]).or_else(|| {
            nested
                .and_then(|value| value.get("id"))
                .and_then(|value| serde_json::from_value::<RemoteId>(value.clone()).ok())
        }),
        dept_name: string_at(&["deptName", "dept_name", "departmentName", "department_name"])
            .or_else(|| nested_string("name"))
            // {department: "运营部"} 这种裸字符串
            .or_else(|| data.get("department").and_then(serde_json::Value::as_str).map(str::to_string))
            .filter(|value| !value.trim().is_empty()),
    }
}

/// 下载一律要未压缩的字节。crate 没开 reqwest 的 gzip / brotli feature,自动解压根本不存在;
/// 明说 identity 是为了挡住会自作主张压一层、却把 `Content-Length` 留在压缩前的中间层 ——
/// 那正是「读响应体失败」最容易被误判成网络抖动的一种成因。
fn identity_encoding(request: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
    request.header("accept-encoding", "identity")
}

fn header_value(response: &reqwest::Response, name: &str) -> Option<String> {
    response.headers().get(name).and_then(|value| value.to_str().ok()).map(str::to_string)
}

/// `GET /jobs` 的响应形状 —— 契约只写了「列表」,没给形状。裸数组与分页包装两种都认:
/// 猜错一种就是上线才发现「建议永远是空的」,而这条路本来就没有真实样本可对。
#[derive(serde::Deserialize)]
#[serde(untagged)]
enum JobListResponse {
    Bare(Vec<Job>),
    Paged {
        #[serde(alias = "content")]
        items: Vec<Job>,
    },
}

impl JobListResponse {
    fn into_jobs(self) -> Vec<Job> {
        match self {
            JobListResponse::Bare(jobs) => jobs,
            JobListResponse::Paged { items } => items,
        }
    }
}

/// 服务端那句错误的**原话**,带上错误码:`BAD_SESSION_FOLDER_PATH: 路径非法`。
///
/// 从前只取 `message`,把 `code` 扔了。而 code 才是能查、能对着契约看的那半句 ——
/// 「部门还没有知识库」和「有多个知识库要选一个」在用户眼里是两回事,要做的动作也不同,
/// 糊成一句「任务失败」等于什么都没说(2026-09-07:静默与含糊是这套东西的主线问题)。
/// 认不出信封就把整个响应体原样带上,总比丢掉强。
#[derive(Debug, PartialEq)]
enum GrantConflict {
    Inherited(InheritedFrom),
    Custom,
}

/// 409 的信封认哪个码。`INHERITED_GRANT` 的 `inheritedFrom` 在**顶层**(服务端 fe8485d);
/// 契约初版没说死放哪,`data` 里也顺带认一下。挖不出字段也算命中,引导语少一截而已。
fn grant_conflict(body: &str) -> Option<GrantConflict> {
    let value: serde_json::Value = serde_json::from_str(body).ok()?;
    match value.get("code").and_then(|code| code.as_str()) {
        Some(CUSTOM_GRANT_CODE) => Some(GrantConflict::Custom),
        Some(INHERITED_GRANT_CODE) => {
            let raw = value
                .get("inheritedFrom")
                .or_else(|| value.get("data").and_then(|data| data.get("inheritedFrom")))
                .cloned()
                .unwrap_or(serde_json::Value::Null);
            Some(GrantConflict::Inherited(serde_json::from_value(raw).unwrap_or_default()))
        }
        _ => None,
    }
}

/// 把 403 的 message 从「整个响应体」收拾成服务端那一句话。
///
/// `send_prepared` 对 403 是直接把 body 原样塞进 `ClientError::Http.message` 的 —— 别的接口里
/// 403 是意外,糊一坨 JSON 也就糊了;但跨项目移动这条路上它是**常规结果**(没有目标项目的写权限就
/// 报 `FORBIDDEN_TARGET`),那句话是要原样念给用户听的,不能让 toast 里弹出一串 `{"success":false,…}`。
fn readable_forbidden(result: Result<(), ClientError>) -> Result<(), ClientError> {
    match result {
        Err(ClientError::Http { status: 403, message }) => {
            Err(ClientError::Http { status: 403, message: server_message(&message) })
        }
        other => other,
    }
}

fn server_message(body: &str) -> String {
    let Ok(envelope) = serde_json::from_str::<Envelope<serde_json::Value>>(body) else {
        return body.to_string();
    };
    match (envelope.code, envelope.message) {
        (Some(code), Some(message)) if !code.is_empty() && !message.is_empty() => format!("{code}: {message}"),
        (Some(code), _) if !code.is_empty() => code,
        (_, Some(message)) if !message.is_empty() => message,
        _ => body.to_string(),
    }
}

/// `Content-Range: bytes <start>-<end>/<total>` → `(start, total)`。`total` 可以是 `*`(未知),
/// 那时回 `None` —— 未知不等于出错,只是没法在结尾核对总长。
fn content_range(response: &reqwest::Response) -> Option<(u64, Option<u64>)> {
    let raw = header_value(response, "content-range")?;
    let rest = raw.trim().strip_prefix("bytes ")?;
    let (range, total) = rest.split_once('/')?;
    let start = range.split_once('-')?.0.trim().parse().ok()?;
    Some((start, total.trim().parse().ok()))
}

fn header_u64(response: &reqwest::Response, name: &str) -> Option<u64> {
    header_value(response, name).and_then(|value| value.trim().parse().ok())
}

/// 分块读响应体,把实际读到的字节数留住。`Response::bytes()` 出错时只回一句
/// 「error decoding response body」,读了多少、服务端声明了多少一概不说,现场没法判断是
/// 服务端 `Content-Length` 给错了还是连接中途断了 —— 这个函数就是为了补上那几个数字。
/// 把这一趟的响应体**追加**进 `bytes`。断在半路时 `bytes` 里已经读到的那一截**留着**,
/// 由调用方带 `Range` 接着读(见 `download_resumable`)—— 这正是断点续传的立足点。
///
/// 总长的核对不在这里做:206 的 `Content-Length` 是这一段的长度,不是整份的长度。
async fn read_chunks(mut response: reqwest::Response, url: &str, bytes: &mut Vec<u8>) -> Result<(), ClientError> {
    let status = response.status().as_u16();
    let content_length = header_u64(&response, "content-length");
    let content_encoding = header_value(&response, "content-encoding");
    // 预分配按这一段声明的长度走,但封顶 8 MiB:声明值可能是错的(正是我们在查的那种错),
    // 不能让它决定内存
    bytes.reserve(content_length.unwrap_or(0).min(8 * 1024 * 1024) as usize);
    let before = bytes.len() as u64;
    loop {
        match response.chunk().await {
            Ok(Some(chunk)) => bytes.extend_from_slice(&chunk),
            Ok(None) => break,
            Err(error) => {
                return Err(ClientError::Body {
                    url: url.to_string(),
                    status,
                    content_length,
                    content_encoding,
                    read: bytes.len() as u64,
                    message: error.to_string(),
                });
            }
        }
    }
    // 这一段声明得比实际多、hyper 却没报错的情形(服务端提前 close 而连接被当成正常结束):
    // 当场识破当成「断在半路」,让上层去续传,免得把截断的内容写进本地文件
    if let Some(declared) = content_length
        && declared != bytes.len() as u64 - before
    {
        return Err(ClientError::Body {
            url: url.to_string(),
            status,
            content_length,
            content_encoding,
            read: bytes.len() as u64,
            message: "响应体字节数与 Content-Length 不符".to_string(),
        });
    }
    Ok(())
}

/// 直链 → (绝对地址, 是否同源)。相对路径按 base_url 补全;`base_url` 后面必须跟 `/` 或 `?`
/// 才算同源,免得 `https://kb.example.com.evil.com` 这种前缀相同的域名骗到 Authorization 头。
fn resolve_download_url(base_url: &str, url: &str) -> (String, bool) {
    if !(url.starts_with("http://") || url.starts_with("https://")) {
        return (format!("{base_url}/{}", url.trim_start_matches('/')), true);
    }
    let same_origin = url
        .strip_prefix(base_url)
        .is_some_and(|rest| rest.is_empty() || rest.starts_with('/') || rest.starts_with('?'));
    (url.to_string(), same_origin)
}

/// multipart 的**组帧**:文件字节之前的那一段、之后的那一段,以及 Content-Type。
///
/// 内存上传与流式上传共用它 —— 两条路径拼出来的包体必须逐字节一致,分开各写一份 format!
/// 是「同一件事两处实现」的经典形状,改一处忘一处时服务端只会回一句语焉不详的 400。
fn multipart_frame(boundary: &str, fields: &[(&str, &str)], file_name: &str) -> (String, Vec<u8>, Vec<u8>) {
    let safe_name = file_name.replace('"', "_");
    let mut prefix = Vec::with_capacity(512);
    for (name, value) in fields {
        prefix.extend_from_slice(
            format!("--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{value}\r\n").as_bytes(),
        );
    }
    prefix.extend_from_slice(
        format!(
            "--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{safe_name}\"\r\nContent-Type: application/octet-stream\r\n\r\n"
        )
        .as_bytes(),
    );
    let suffix = format!("\r\n--{boundary}--\r\n").into_bytes();
    (format!("multipart/form-data; boundary={boundary}"), prefix, suffix)
}

/// 手拼 multipart(`file` part + 若干文本字段,不为它拉 reqwest 的 multipart feature)。
fn multipart_file_body(boundary: &str, fields: &[(&str, &str)], file_name: &str, bytes: Vec<u8>) -> (String, Vec<u8>) {
    let (content_type, prefix, suffix) = multipart_frame(boundary, fields, file_name);
    let mut body = Vec::with_capacity(prefix.len() + bytes.len() + suffix.len());
    body.extend_from_slice(&prefix);
    body.extend_from_slice(&bytes);
    body.extend_from_slice(&suffix);
    (content_type, body)
}

/// 前缀 → 文件的前 `size` 个字节 → 后缀,拼成一条流。
///
/// **精确发 `size` 个字节**,因为 Content-Length 已经按它算好了:
/// - 文件比 `size` 长(上传期间有人往里追加)→ 只发前 `size` 个,多出来的那截下一轮再说;
/// - 文件比 `size` 短(被截断 / 换成了别的)→ 当场报错终止。继续发只会拼出一个长度对不上的
///   包体,服务端要么挂起等那几个字节、要么回一句看不懂的 400。失败掉、下一轮重新扫重新算
///   哈希,是唯一说得清的处置。
fn counted_file_stream(
    file: tokio::fs::File, prefix: Vec<u8>, suffix: Vec<u8>, size: u64,
) -> impl futures_util::Stream<Item = Result<Vec<u8>, std::io::Error>> {
    /// 64 KiB:够摊薄系统调用,又不至于让单个块本身成为内存尖峰。
    const CHUNK: usize = 64 * 1024;

    enum Stage {
        Prefix,
        Body,
        Suffix,
        Done,
    }
    struct State {
        stage: Stage,
        file: tokio::fs::File,
        left: u64,
        prefix: Vec<u8>,
        suffix: Vec<u8>,
    }

    futures_util::stream::unfold(
        State { stage: Stage::Prefix, file, left: size, prefix, suffix },
        |mut state| async move {
            use tokio::io::AsyncReadExt as _;
            loop {
                match state.stage {
                    Stage::Prefix => {
                        state.stage = Stage::Body;
                        return Some((Ok(std::mem::take(&mut state.prefix)), state));
                    }
                    Stage::Body => {
                        if state.left == 0 {
                            state.stage = Stage::Suffix;
                            continue;
                        }
                        let want = CHUNK.min(state.left as usize);
                        let mut buffer = vec![0u8; want];
                        match state.file.read_exact(&mut buffer).await {
                            Ok(_) => {
                                state.left -= want as u64;
                                return Some((Ok(buffer), state));
                            }
                            Err(error) => {
                                state.stage = Stage::Done;
                                return Some((Err(error), state));
                            }
                        }
                    }
                    Stage::Suffix => {
                        state.stage = Stage::Done;
                        return Some((Ok(std::mem::take(&mut state.suffix)), state));
                    }
                    Stage::Done => return None,
                }
            }
        },
    )
}

/// `/sync/blobs` 的两 part 形式:表单 `sha256` + `file`。
fn multipart_body(boundary: &str, sha256: &str, file_name: &str, bytes: Vec<u8>) -> (String, Vec<u8>) {
    multipart_file_body(boundary, &[("sha256", sha256)], file_name, bytes)
}

#[cfg(test)]
mod tests {
    use super::*;
    use futures_util::StreamExt as _;

    /// 把流收完(测试里文件都很小)。
    async fn drain(
        stream: impl futures_util::Stream<Item = Result<Vec<u8>, std::io::Error>>,
    ) -> std::io::Result<Vec<u8>> {
        let mut out = Vec::new();
        futures_util::pin_mut!(stream);
        while let Some(chunk) = stream.next().await {
            out.extend_from_slice(&chunk?);
        }
        Ok(out)
    }

    async fn temp_file(bytes: &[u8]) -> (tempfile::TempDir, std::path::PathBuf) {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("payload.bin");
        tokio::fs::write(&path, bytes).await.unwrap();
        (dir, path)
    }

    /// **流式与内存两条路径必须拼出逐字节相同的包体。**分开各写一份 format! 是「同一件事两处
    /// 实现」,改一处忘一处时服务端只回一句语焉不详的 400,极难查。
    #[tokio::test]
    async fn 流式与内存拼出的_multipart_逐字节相同() {
        let payload = (0u8..=255).cycle().take(200 * 1024).collect::<Vec<u8>>();
        let (_dir, path) = temp_file(&payload).await;

        let (memory_type, memory_body) = multipart_file_body("BOUND", &[("sha256", "abc")], "报告.md", payload.clone());
        let (stream_type, prefix, suffix) = multipart_frame("BOUND", &[("sha256", "abc")], "报告.md");
        let file = tokio::fs::File::open(&path).await.unwrap();
        let streamed = drain(counted_file_stream(file, prefix, suffix, payload.len() as u64)).await.unwrap();

        assert_eq!(memory_type, stream_type);
        assert_eq!(streamed, memory_body);
    }

    /// Content-Length 按「前缀 + size + 后缀」算,流发出来的必须正好这么多 —— 差一个字节就是
    /// 服务端挂起等一个永远不来的字节。
    #[tokio::test]
    async fn 发出的字节数正好等于声明的长度() {
        let payload = vec![7u8; 130 * 1024];
        let (_dir, path) = temp_file(&payload).await;
        let (_type, prefix, suffix) = multipart_frame("B", &[("sha256", "s")], "a.bin");
        let declared = prefix.len() as u64 + payload.len() as u64 + suffix.len() as u64;

        let file = tokio::fs::File::open(&path).await.unwrap();
        let sent = drain(counted_file_stream(file, prefix, suffix, payload.len() as u64)).await.unwrap();
        assert_eq!(sent.len() as u64, declared);
    }

    /// 上传期间文件被追加:只发扫描时记下的那么多,多出来的下一轮再说。
    #[tokio::test]
    async fn 文件变长时只发声明的那一段() {
        let (_dir, path) = temp_file(b"0123456789abcdef").await;
        let (_type, prefix, suffix) = multipart_frame("B", &[], "a.bin");
        let file = tokio::fs::File::open(&path).await.unwrap();
        let sent = drain(counted_file_stream(file, prefix.clone(), suffix.clone(), 10)).await.unwrap();
        assert_eq!(&sent[prefix.len()..sent.len() - suffix.len()], b"0123456789");
    }

    /// 上传期间文件被截断:报错,而不是发一个长度对不上的包体。
    #[tokio::test]
    async fn 文件变短时报错而不是发半截() {
        let (_dir, path) = temp_file(b"only-8b!").await;
        let (_type, prefix, suffix) = multipart_frame("B", &[], "a.bin");
        let file = tokio::fs::File::open(&path).await.unwrap();
        let result = drain(counted_file_stream(file, prefix, suffix, 4096)).await;
        assert!(result.is_err(), "读不满声明的长度必须报错");
    }

    /// 空文件也要拼出合法的 multipart(前缀紧接后缀)。
    #[tokio::test]
    async fn 空文件拼出合法包体() {
        let (_dir, path) = temp_file(b"").await;
        let (_t, prefix, suffix) = multipart_frame("B", &[("sha256", "e3b0c4")], "空.txt");
        let (_t2, memory) = multipart_file_body("B", &[("sha256", "e3b0c4")], "空.txt", Vec::new());
        let file = tokio::fs::File::open(&path).await.unwrap();
        assert_eq!(drain(counted_file_stream(file, prefix, suffix, 0)).await.unwrap(), memory);
    }

    /// 409 `INHERITED_GRANT`:`inheritedFrom` 在顶层(服务端 fe8485d),`data` 里也顺带认;
    /// `CUSTOM_GRANT` 是另一种结局;别的 409 照常报错。
    #[test]
    fn 继承行与自定义行的_409_不是错误() {
        let top = r#"{"success":false,"code":"INHERITED_GRANT","message":"继承","inheritedFrom":{"source":"FOLDER","resourceId":17,"projectKey":"p1","display":"策略/其他收入"}}"#;
        let Some(GrantConflict::Inherited(from)) = grant_conflict(top) else { panic!("该认出继承") };
        assert_eq!(from.source, Some(crate::types::GrantSource::Folder));
        assert_eq!(from.resource_id, Some(RemoteId::Number(17)));
        assert_eq!(from.project_key.as_deref(), Some("p1"));
        assert_eq!(from.display.as_deref(), Some("策略/其他收入"));

        let nested = r#"{"success":false,"code":"INHERITED_GRANT","data":{"inheritedFrom":{"source":"SPACE","resourceId":"sp1"}}}"#;
        let Some(GrantConflict::Inherited(from)) = grant_conflict(nested) else { panic!("data 里的也该认") };
        assert_eq!(from.source, Some(crate::types::GrantSource::Space));
        assert_eq!(from.resource_id, Some(RemoteId::Text("sp1".into())));

        // 字段一个都没给:仍然命中,只是引导语少一截 —— 不能因此把删除整个报错
        let bare = r#"{"success":false,"code":"INHERITED_GRANT"}"#;
        assert_eq!(grant_conflict(bare), Some(GrantConflict::Inherited(InheritedFrom::default())));
        assert_eq!(
            grant_conflict(r#"{"success":false,"code":"CUSTOM_GRANT","message":"含拒绝规则"}"#),
            Some(GrantConflict::Custom)
        );
        // 别的 409 不认
        assert_eq!(grant_conflict(r#"{"success":false,"code":"CONFLICT"}"#), None);
    }

    #[test]
    fn push_url_换协议并编码_token() {
        let client = DriveClient::new("https://kb.example.com/", "a b&c");
        assert_eq!(client.push_url(), "wss://kb.example.com/ws/sync?token=a+b%26c");
        assert_eq!(DriveClient::new("http://127.0.0.1:8080", "t").push_url(), "ws://127.0.0.1:8080/ws/sync?token=t");
    }

    #[test]
    fn 直链解析_只有真同源才带鉴权() {
        let base = "https://kb.example.com";
        assert_eq!(
            resolve_download_url(base, "/api/v1/files/1/download"),
            ("https://kb.example.com/api/v1/files/1/download".into(), true)
        );
        assert_eq!(
            resolve_download_url(base, "api/v1/files/1/download"),
            ("https://kb.example.com/api/v1/files/1/download".into(), true)
        );
        assert_eq!(
            resolve_download_url(base, "https://kb.example.com/x?y=1"),
            ("https://kb.example.com/x?y=1".into(), true)
        );
        // 对象存储的预签名直链:不带 Authorization
        let signed = "https://oss.example.com/bucket/abc?X-Amz-Credential=k";
        assert_eq!(resolve_download_url(base, signed), (signed.to_string(), false));
        // 前缀相同但不是同一个域名:也不能带
        let lookalike = "https://kb.example.com.evil.com/steal";
        assert_eq!(resolve_download_url(base, lookalike), (lookalike.to_string(), false));
    }

    #[test]
    fn sync_me_部门字段的几种写法都认() {
        let flat = serde_json::json!({"userId": 7, "displayName": "张三", "employeeNo": "E1", "deptName": "运营部", "departmentId": 12});
        let parsed = parse_sync_me(&flat);
        assert_eq!(parsed.dept_name.as_deref(), Some("运营部"));
        assert_eq!(parsed.department_id, Some(RemoteId::Number(12)));
        assert_eq!(parsed.user_id, Some(RemoteId::Number(7)));

        let nested = serde_json::json!({"userId": "u1", "department": {"id": "d9", "name": "风控部"}});
        let parsed = parse_sync_me(&nested);
        assert_eq!(parsed.dept_name.as_deref(), Some("风控部"));
        assert_eq!(parsed.department_id, Some(RemoteId::Text("d9".into())));

        let bare = serde_json::json!({"userId": 1, "department": "财务部"});
        assert_eq!(parse_sync_me(&bare).dept_name.as_deref(), Some("财务部"));

        // 契约当前的最小响应:没有任何部门字段 —— 调用方据此只自动装公司级 SKILL
        let minimal = serde_json::json!({"userId": 1, "displayName": "张三", "employeeNo": "E1"});
        let parsed = parse_sync_me(&minimal);
        assert_eq!(parsed.dept_name, None);
        assert_eq!(parsed.department_id, None);
    }

    #[test]
    fn multipart_两个_part_顺序固定() {
        let (content_type, body) = multipart_body("B", "abc", "a \"b\".txt", b"DATA".to_vec());
        assert_eq!(content_type, "multipart/form-data; boundary=B");
        let text = String::from_utf8(body).unwrap();
        assert!(text.starts_with("--B\r\nContent-Disposition: form-data; name=\"sha256\"\r\n\r\nabc\r\n--B\r\n"));
        assert!(text.contains("filename=\"a _b_.txt\""));
        assert!(text.ends_with("\r\n\r\nDATA\r\n--B--\r\n"));
    }
}

//! 同步引擎:状态机 Idle / Scanning / Syncing / Paused / Error,上行与下行。
//!
//! 一次 `sync_once`:刷新根 → 对每个选中的根(见 `is_selected`:自己的 + 公司级 + 本人部门的 +
//! 用户点开过的,且 syncEnabled)先下行(cursor 为空走 snapshot,否则走 changes)再上行
//! (扫描 → 去重 HEAD → 上传 → batch → 写回索引)。
//! 任何一次请求撞上 `DEVICE_REVOKED` 即触发清空流程。
//!
//! 下行与上行的网络部分都是**有界并发**(`EngineConfig::transfer_concurrency`,默认
//! `DEFAULT_TRANSFER_CONCURRENCY`)。串行下载在真机上是致命的:1903 个文件一个一个来,用户
//! 盯着进度条爬了好几分钟。并发只放在「取字节」这一段,索引写入与进度计数仍然在**单一消费者**
//! 里按完成顺序做 —— 一致性不为并发让路,进度也就不会回退或跳变。
//!
//! SKILL 根**只**落在 `<skills_dir>/yup/<projectKey>/`(见 `root_local_dir`),不在 `~/YUP Drive/`
//! 下建目录:它是给机器读的,摆进用户的云盘目录树只是噪音,而且同一份东西不该有两个家。
//!
//! 6.7 协同:服务端标 `collabActive=true` 的文件(中继在线且有客户端),Yjs 文档是真相 —— 本地
//! 改动不上行(批处理跳过它),服务端物化出的新版本照常下行;角标显示 `collab`。
//!
//! `readOnly=true` 的文件(需走修改申请)**正常下载到本地**,但本地改动不上行:检测到改动时
//! 发一条 `ReadOnlyChange`,由桌面端提示用户去网页申请修改 —— 静默丢弃改动是最糟的。

use std::collections::{BTreeSet, HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};

use futures_util::StreamExt;
use tokio::sync::{broadcast, mpsc};

use crate::client::{ClientError, CloudFolder, DriveClient};
use crate::delete_guard::{DeleteDecision, DeleteGuards};
use crate::ignore::{DEFAULT_MAX_FILE_SIZE, IgnoreRules};
use crate::index::{FileErrorRow, FileRow, Index, RootRow};
use crate::naming::{
    CloudOnlyReason, PLACEHOLDER_HEADLINE, cloud_only_placeholder_content, cloud_only_placeholder_name,
    cloud_to_local_relative, conflict_copy_name, is_cloud_only_placeholder, join_cloud_path, local_to_cloud_relative,
    split_cloud_path,
};
use crate::scanner::{Previous, ScannedFile, file_mtime_ms, scan_root, sha256_file};
use crate::types::{
    BatchOp, BatchOpKind, BatchRequest, BatchResult, BatchStatus, ChangeEvent, ClientConfig, CloudOnlyRecheck,
    ConflictRecord, DiskUsage, DiskUsageFile, DiskUsageProject, EngineState, EventType, FailedUpload, FileState,
    FileStateEvent, GrantResourceKind, GrantTarget, Job, OwnershipGuard, PendingDeletes, ProjectKind, ProjectPhase,
    ProjectProgress, ProjectScope, ReadOnlyChange, RemoteId, RootInfo, SharedItem, SkillMirror, StatusSnapshot,
    SyncDirection, SyncError, SyncMe, SyncRoot, UnsyncedSummary,
};

const CHANGES_PAGE_SIZE: u32 = 500;
const BATCH_CHUNK: usize = 200;
const MAX_RECORDS: usize = 100;

/// 上行失败后的重试退避起步值:第 n 次失败之后等 `UPLOAD_BACKOFF_BASE × 2^(n-1)`,封顶
/// `UPLOAD_BACKOFF_MAX`。
///
/// 为什么必须有:2026-09-07 那条故障里,一个永远传不上去的文件被每一轮同步(60 秒一次)
/// 原样重推一遍,服务端每次都回同一句 `PARENT_FOLDER_NOT_FOUND` —— 六轮之后还是六轮,
/// 除了刷日志、占批处理名额、把真正能传的文件挤到后面去,什么也没换来。
///
/// 为什么**不是**「失败 N 次就永远不再试」:失败的原因常常在服务端那头被修好(建了目录、
/// 给了权限),客户端这边不会收到任何通知。所以退避只封顶、不封死:最慢也每 6 小时再试一次,
/// 而用户只要再动一次这个文件,退避当场作废(见 `push_root_once` 的失败行分支)。
pub const UPLOAD_BACKOFF_BASE: Duration = Duration::from_secs(60);
pub const UPLOAD_BACKOFF_MAX: Duration = Duration::from_secs(6 * 3600);

/// 「自动下载」的默认阈值:超过它的文件下行时只落一个 `.yupcloud` 占位,**等用户点了再拉**
///(2026-09-07 老板拍板:「大文件不下载,不然太影响效率了,大文件标注,按需下载」)。
///
/// 为什么是 10 MB 而不是按扩展名分:简单的规则才解释得清 ——「超过 10 MB 的不自动下,点一下
/// 再拉」用户一句话就懂;按类型分只会让人问「为什么这个下了那个没下」。
///
/// 为什么这件事要紧:2026-09-07 实报,一批 30–90 MB 的原始数据表在下行里反复重下(线上还没
/// 上 Range,每趟都从 0 开始、又在几十兆处被网关掐断),十分钟里把整个引擎的时间占满 ——
/// 而**上行排在下行后面**,于是用户在本地改的字十几分钟传不上去。阈值降下来,这批文件根本
/// 不进下载队列,下行轮立刻空掉。
pub const DEFAULT_MAX_AUTO_DOWNLOAD_BYTES: u64 = 10 * 1024 * 1024;

/// 本地协同标记的兜底寿命。它只需要盖住「开会话」到「服务端的 collabActive 拉回来」那个窗口
/// (轮询 60 秒一轮,推送更快),10 分钟是极宽松的余量。到点自动作废 —— 前端忘了调 `end`、
/// 或者中继压根没把这个文件标成协同时,最坏是退回从前的行为,而不是这份文件永远推不上去。
pub const LOCAL_COLLAB_TTL: Duration = Duration::from_secs(10 * 60);

/// 「自动下载阈值」到底用哪个数:**用户动过的 > 服务端下发的 > 内置默认**。
///
/// 服务端下发的是**默认值不是命令**(契约 §6.16 原话「仅作客户端偏好的默认值,客户端可改」),
/// 所以用户在设置页改过之后,服务端说什么都不再覆盖他 —— 一次登录把用户的偏好冲掉,
/// 是那种「他永远不知道发生了什么」的改动。
///
/// 服务端下发的是 `largeFileThresholdBytes`(`app.client.auto-download-threshold-bytes`,默认 10 MB,
/// 带启动自检:≤0 或 ≥ 上行上限直接起不来)。它与**上行上限**是两个独立的值:上行上限走
/// `maxUploadBytes`,由 `ignore::resolve_max_upload_bytes` 决定,而且优先级相反(服务端硬上限优先)。
/// 两者曾经混成一个数(那时客户端对这个字段只存不用),现在服务端两边都已改对。
///
/// `0` 是有意义的取值(不设限,全都自动下),所以只有「键不存在」才算没动过。
pub fn resolve_max_auto_download_bytes(user_megabytes: Option<u64>, server_bytes: Option<u64>) -> u64 {
    if let Some(megabytes) = user_megabytes {
        return megabytes.saturating_mul(1024 * 1024);
    }
    server_bytes.unwrap_or(DEFAULT_MAX_AUTO_DOWNLOAD_BYTES)
}

/// 单个文件的下载尝试次数(首次 + 2 次重试)。
pub const DOWNLOAD_ATTEMPTS: u32 = 3;
/// 重试退避起步值,之后翻倍(500ms → 1s)。
pub const DOWNLOAD_BACKOFF: Duration = Duration::from_millis(500);
/// 下行进度事件的节流:每这么多个文件推一条(外加每个项目的开始与结束各一条)。
const PROGRESS_EVERY: u32 = 10;
/// 插队列表的上限。用户点过但本轮同步范围里没有的 id 会留到下一轮(刚固定完、`refresh_roots`
/// 还没看到它的那一瞬),留着就得封顶,免得点过的死项目在里面越攒越多。
const MAX_PRIORITY: usize = 32;

/// 同时在飞的文件传输数(下行下载 / 上行 blob 去重与上传)的默认值。
///
/// 8 的来历:串行下行在真机上跑 1903 个文件要好几分钟(2026-09-04 实报),而每个文件的时间几乎
/// 全花在等服务端上,本地只有一次 sha256 与一次写盘。8 路能把等待叠起来,又不至于让服务端侧
/// 一个用户就占满连接池 —— 再往上加,瓶颈就从往返延迟挪到对端带宽了,收益迅速变平。
pub const DEFAULT_TRANSFER_CONCURRENCY: usize = 8;

#[derive(Debug, Clone, thiserror::Error)]
pub enum EngineError {
    #[error(transparent)]
    Client(#[from] ClientError),
    #[error("{0}")]
    Io(String),
    #[error("索引: {0}")]
    Index(String),
    #[error("设备已被吊销,本地镜像已清空")]
    Revoked,
    /// 「这一刻不方便，等会儿再来」——文件正被写到一半之类。**索引没有漂**，
    /// 所以它不该触发全量对账（那是给 Index / Io 那种「状态对不上了」用的）；
    /// 走 file_errors 的退避重试就够。分开这一类是必要的：AI 连着改文档时
    /// 每一轮都可能撞上，当成漂移的话就变成每轮一次全量对账。
    #[error("{0}")]
    Busy(String),
}

#[derive(Debug, Clone)]
pub enum EngineEvent {
    Status(StatusSnapshot),
    FileState(FileStateEvent),
    Conflict(ConflictRecord),
    /// 单个项目在同步队列里的处境(云盘面板行内状态)
    Project(ProjectProgress),
    /// 用户改了一个只读文件(改动不会上行,得去网页申请修改)
    ReadOnly(ReadOnlyChange),
    /// 「仅云端」核对跑完一轮,且**确实改了东西**(全都没漂移时不发,别打扰用户)
    CloudOnly(CloudOnlyRecheck),
    /// 批量删除安全阀触发:一批本地删除被拦下、等用户确认(见 `delete_guard`)
    PendingDeletes(PendingDeletes),
    Revoked,
}

#[derive(Debug, Clone)]
pub struct EngineConfig {
    /// `~/YUP Drive`
    pub local_root: PathBuf,
    /// None → 内存索引(测试)
    pub index_path: Option<PathBuf>,
    pub device_id: String,
    /// 冲突副本名里的用户名
    pub user_name: String,
    /// `~/.alwith/skills`;None 不做 SKILL 镜像
    pub skills_dir: Option<PathBuf>,
    /// 本地名是否做 Windows 非法字符映射
    pub windows_names: bool,
    /// 吊销后未上传内容与冲突副本的去处:`~/YUP Drive (离线残留)`
    pub residual_root: PathBuf,
    /// 同时在飞的文件传输数;0 视作 `DEFAULT_TRANSFER_CONCURRENCY`
    pub transfer_concurrency: usize,
    /// web 端地址(`https://kb.example.com`)。`.yupcloud` 占位里那条「在网页打开」要它;
    /// 拿不到就不写那条 —— 宁可少一条路,也不给一个打不开的链接
    pub web_base_url: Option<String>,
    /// 自动下载的大小上限(字节)。超过的只落占位、等用户点(见 `DEFAULT_MAX_AUTO_DOWNLOAD_BYTES`)。
    /// **0 = 不设限**(全下,即从前的行为)——设置页把它做成可调项,用户嫌占位碍事就调大。
    pub max_auto_download_bytes: u64,
    /// 单文件上行上限(字节)。超过的标 `SkippedTooLarge` 跳过,不阻塞(见 `ignore::resolve_max_upload_bytes`)。
    /// **0 = 不设限**。服务端 `/client/config` 下发 `maxUploadBytes`;拿不到时用内置默认 500 MB。
    pub max_upload_bytes: u64,
}

impl EngineConfig {
    /// 按契约默认位置组装:`~/YUP Drive`、`~/.alwith/skills`、`~/YUP Drive (离线残留)`。
    pub fn standard(home: &Path, index_path: PathBuf, device_id: String, user_name: String) -> Self {
        Self {
            local_root: home.join("YUP Drive"),
            index_path: Some(index_path),
            device_id,
            user_name,
            skills_dir: Some(home.join(".alwith").join("skills")),
            windows_names: cfg!(windows),
            residual_root: home.join("YUP Drive (离线残留)"),
            transfer_concurrency: DEFAULT_TRANSFER_CONCURRENCY,
            web_base_url: None,
            max_auto_download_bytes: DEFAULT_MAX_AUTO_DOWNLOAD_BYTES,
            max_upload_bytes: DEFAULT_MAX_FILE_SIZE,
        }
    }
}

/// snapshot 文件与 change 事件的公共部分。
struct RemoteFile {
    file_id: RemoteId,
    path: String,
    /// 服务端可能不给(老库历史行);缺了就只能靠 sha256 判定变更
    version_id: Option<RemoteId>,
    /// 服务端可能不给(老库 `file_versions.sha256` 为 NULL);缺了就按 versionId 判定变更、按 fileId 下载
    sha256: Option<String>,
    /// 索引 / 清单里记的字节数。只用于下载失败时的诊断日志(它和对象真实大小对不上,
    /// 正是「服务端 Content-Length 给错」这类故障的现场证据),不参与任何判定。
    size: Option<u64>,
    cloud_only: bool,
    /// 服务端**目前不给**这个字段;给了就照它写进占位文件,不给就由客户端判「归档项目」或「未知」
    cloud_only_reason: Option<String>,
    /// 服务端 `readOnly`:照常下载,但本地改动不上行
    read_only: bool,
    updated_by: Option<String>,
    collab_active: bool,
}

/// 「仅云端」核对发现的一处不一致,以及它属于哪一类 —— 只影响计数与提示措辞,
/// 修法是同一条(`apply_remote_file`:让本地跟上服务端此刻的说法)。
#[derive(Debug, Clone, Copy)]
enum CloudOnlyFix {
    /// 服务端已不再标 cloudOnly → 把正文拉回来、删掉占位
    Restore,
    /// 服务端新标成 cloudOnly → 写占位、把正文从盘上删掉
    Hide,
    /// 分类没变,但占位在盘上不见了 → 把占位补回来
    Repair,
}

/// 一条 batch op 的本地上下文,结果回来后据此写索引。
struct PendingOp {
    kind: BatchOpKind,
    path: String,
    new_path: Option<String>,
    scanned: Option<ScannedFile>,
    row: Option<FileRow>,
}

/// 一个项目一轮下行的计数:结束时就是「成功 N 个、失败 M 个」的汇总。
#[derive(Debug, Default, Clone, Copy)]
struct PullTally {
    total: u32,
    done: u32,
    failed: u32,
}

pub struct Engine {
    pub(crate) client: DriveClient,
    pub(crate) config: EngineConfig,
    pub(crate) index: Index,
    status: Mutex<StatusSnapshot>,
    events: broadcast::Sender<EngineEvent>,
    paused: AtomicBool,
    revoked: AtomicBool,
    /// `/ws/sync` 推送在线:主循环的定时轮询拉长为 `poll_interval * PUSH_CONNECTED_POLL_MULTIPLIER`
    push_connected: AtomicBool,
    sync_lock: tokio::sync::Mutex<()>,
    /// 用户在云盘面板上点过的项目:下一个就轮到它们(队首优先)。同步途中点也算数 ——
    /// 每处理完一个根都重新看一眼这个列表,不用等前面几十个项目排完。
    priority: Mutex<Vec<RemoteId>>,
    /// 会话归档(archive.rs)一次只跑一轮
    pub(crate) archive_lock: tokio::sync::Mutex<()>,
    /// 归属兜底防线的日志只在状态翻转时打一行,别让 60 秒一轮的同步刷屏
    guard_logged: AtomicBool,
    /// 已经提示过「这份文件要走修改申请」的 `<projectId>:<path>:<本地 sha256>`。
    /// 不去重的话,用户每改一次只读文件、之后的**每一轮**同步都会再弹一次同样的提示。
    readonly_warned: Mutex<HashSet<String>>,
    /// 批量删除安全阀的悬挂状态(见 `delete_guard`)。内存态:重启清空,那批删除下一轮重评估。
    delete_guards: Mutex<DeleteGuards>,
    /// **用户刚刚主动移走的本地路径**(`<projectId>\0<云端相对路径>`,目录记前缀)。
    ///
    /// 为什么非有不可:「把整个目录移到别的库」在磁盘上留下的痕迹,与「这份内容从来没下载过」
    /// **一模一样** —— 文件不在、父目录也不在。`never_landed` 分不出这两者,只能按更安全的那边
    /// 判(不上行删除),于是跨库移动的源文件永远留在云端,移动变成了复制(2026-09-14 实报)。
    ///
    /// 出路不是把判据调得更聪明 —— 磁盘状态里根本没有能区分它们的信息;而是**别去猜**:
    /// 移动是我们自己发起的动作,那一刻就确知它是移动,记下来告诉扫描那一轮即可。
    ///
    /// 内存态、且一轮同步之后就清:窗口只有几十秒,期间崩了最坏也只是回到原来那个行为
    ///(源没删),不会反过来误删任何东西。
    moved_away: Mutex<HashSet<String>>,
    /// **本地已经开着协同会话的文件** —— `<projectKey>\0<云端相对路径>` → 这条本地标记的过期时刻。
    ///
    /// 为什么非有不可(2026-09-07 老板实机):`collab_active` 在引擎里只有**从服务端拉回来**时
    /// 才会被写,而用户敲第一个字的那一刻文件立刻就变了。从「打开协同会话」到「下一轮 pull 把
    /// collabActive 拉回来」之间有一个窗口,窗口里引擎还当它是普通文件、照推不误,和中继几乎
    /// 同时写同一份 —— 撞出一个只差一行的冲突副本。两个协同客户端(桌面 + 网页)让这个窗口
    /// 极易命中。所以建立会话的那一刻就在本地标上,不等服务端那一趟。
    ///
    /// **只在内存里,而且带过期时刻**,这两条都是刻意的:
    /// - 只在内存 → 进程崩了标记就没了,不会留下一个「永远推不上去」的文件。那比多一个冲突
    ///   副本严重得多,而服务端那份 `collabActive` 本来就是权威。
    /// - 带过期 → 前端忘了调 `end`、或者中继根本没把这个文件标成协同,最坏也就是退回到从前的
    ///   行为(照推),而不是永久停摆。它的职责只是**盖住那个窗口**,不是替代服务端的标记。
    local_collab: Mutex<HashMap<String, Instant>>,
    /// 本进程是否已经做过一轮「仅云端」核对(见 `reconcile_root_cloud_only`)。
    /// 每轮同步都拉一遍全量 snapshot 是拿 60 秒一次的轮询去换一个几个月才发生一次的分类漂移,
    /// 不划算 —— 启动后第一轮做一次,之后要重来由用户在设置页手动点。
    cloud_only_checked: AtomicBool,
    /// 本进程是否已经做过一轮「镜像脱节」对账(见 `reconcile_root_landed`)。
    landed_checked: AtomicBool,
    /// 上一轮 SKILL 摊平的冲突文案。**装不上是持续状态,不是事件** —— 面板每轮照现状重写,
    /// 日志只在集合变了的时候记一行(见 `install_skill_mirrors`)。
    last_skill_conflicts: Mutex<Vec<String>>,
}

/// 这条错误是不是 SKILL 摊平那一路推的。前缀由 `install_skill_mirrors` 里那句 `format!` 固定。
fn is_skill_install_error(message: &str) -> bool {
    message.starts_with("SKILL「") && message.contains("没能装上")
}

/// 推送在线时仍保留一条稀疏轮询兜底(60 秒 × 10 = 10 分钟)。
pub const PUSH_CONNECTED_POLL_MULTIPLIER: u32 = 10;

fn now_iso() -> String {
    chrono::Local::now().to_rfc3339_opts(chrono::SecondsFormat::Secs, true)
}

fn io_error(context: impl std::fmt::Display, error: impl std::fmt::Display) -> EngineError {
    EngineError::Io(format!("{context}: {error}"))
}

/// 内容寻址的 blob:拿回来的字节必须真的哈希成它的名字。对不上就是响应被截断 / 串了内容 ——
/// 报成解码类错误,好让调用方换按文件的下载路径再试。
fn verify_sha256(expected: &str, bytes: &[u8], indexed_size: Option<u64>) -> Result<(), ClientError> {
    let actual = crate::scanner::sha256_bytes(bytes);
    if actual.eq_ignore_ascii_case(expected) {
        return Ok(());
    }
    Err(ClientError::Body {
        url: format!("/sync/blobs/{expected}"),
        status: 200,
        content_length: None,
        content_encoding: None,
        read: bytes.len() as u64,
        message: format!(
            "内容校验不通过:实际 sha256={actual},索引记录 size={}",
            indexed_size.map(|size| size.to_string()).unwrap_or_else(|| "<无>".to_string())
        ),
    })
}

/// 老服务端(`/sync/roots` 不返回 `isMine` / `ownerId`)下,归属判不出的 PERSONAL 根数量超过这个值,
/// 就不再无条件把它们全拉到本地磁盘,改成只同步已固定的。
///
/// 3 的来历:普通员工的个人空间通常就 1 个项目,自己多建一两个也到不了 4,阈值定在 3 让他们
/// 完全维持旧行为 —— 不能因为这道防线逼普通员工去手动固定自己的个人库。另一头,2026-09-04 生产
/// 联调里管理员账号一次拿回 279 个 PERSONAL 根(他对全公司每个人的个人知识库都有读权限),两类
/// 账号之间差着两个数量级,阈值落在 3 到几十之间效果等价,取「普通员工的上限」这一端最不误伤。
pub const LEGACY_PERSONAL_ROOT_LIMIT: usize = 3;

/// SKILL 镜像在 `<skills_dir>/` 下的落点。
///
/// **点开头是刻意的,而且必须与人写的 skill 不可能撞名。** alwith-cli 装 skill 的规矩是
/// `readdir(~/.alwith/skills)` → 每个子目录找 `<name>/SKILL.md`(`src/skills/loadSkillsDir.ts`
/// 的 `loadSkillsFromSkillsDir`):只看一层、目录名就是 skill 名、**不过滤点开头的条目**。
/// 所以 `.yup-drive/` 会被扫到、发现没有 `SKILL.md`、跳过 —— 正是我们要的「在那儿但不冒充 skill」。
///
/// 曾经落在 `yup/`。那是个真实事故:公司本来就有一个叫 `yup` 的 skill(`yup/SKILL.md`),
/// 我们在同名目录下塞项目子目录,把那个位置毁了 —— `yup` skill 从此装不上
/// (2026-09-04 实报)。落点名不能是任何人可能拿来当 skill 名的词。
pub const SKILL_MIRROR_DIR: &str = ".yup-drive";

/// 出事之前的落点。留着只为把老数据搬走,别的地方一律用 `SKILL_MIRROR_DIR`。
const LEGACY_SKILL_MIRROR_DIR: &str = "yup";

/// 索引 meta:用户在云盘面板上点过「全部同步」,显式覆盖上面那道防线(点了就按老规矩全同步)。
const META_SYNC_ALL_PERSONAL: &str = "roots.sync_all_personal";
/// 索引 meta:`/sync/me` 给的当前用户部门 id。**按 id 比对是首选口径** —— 显示名会带尾空格、
/// 会被改名,拿它判「是不是本人部门的」曾经把人挡在同步范围外。空串 = 问过了,服务端没给。
const META_MY_DEPT_ID: &str = "me.department_id";
/// 索引 meta:`/sync/me` 给的当前用户部门名。只在服务端没给 id 时用来回落。空串 = 问过了,服务端没给。
const META_MY_DEPT_NAME: &str = "me.dept_name";
/// 索引 meta:上次问 `/sync/me` 的 unix 秒。服务端补上部门字段后不必等用户重装 —— 一天问一次。
const META_MY_DEPT_AT: &str = "me.dept_at";
/// `/sync/me` 的缓存有效期。
const MY_DEPT_TTL_SECS: i64 = 24 * 60 * 60;

/// 索引 meta:`/shared-with-me` 里那些资源所在的项目 id,逗号分隔。空串 = 问过了,一条都没有。
///
/// 为什么要落盘而不是每轮现问:同步范围的判定(`is_selected`)是**同步的**,而这是个网络调用。
/// 缓存下来以后,拉不到时(离线 / 老服务端没这个接口)用的是上一次的答案 —— 比「这一轮就当
/// 没人分享给我」强得多:后者会让一个刚同步下来的项目在下一轮被移出同步集。
const META_SHARED_PROJECTS: &str = "me.shared_projects";
/// 索引 meta:上次问 `/shared-with-me` 的 unix 秒。
const META_SHARED_PROJECTS_AT: &str = "me.shared_projects_at";
/// `/shared-with-me` 的缓存有效期。**比部门短得多**:部门一年不变,而「同事刚把一个目录分享
/// 给我」正是要立刻见效的那件事 —— 用户打开云盘面板时还会强制刷一次(`Engine::shared_with_me`)。
const SHARED_PROJECTS_TTL_SECS: i64 = 5 * 60;

/// 归属判不出时怎么办。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum OwnershipFallback {
    /// 老规矩:`scope == PERSONAL` 一律当成自己的。服务端给了归属信息、个人库数量没超阈值、
    /// 或用户显式点了「全部同步」时走这条。
    #[default]
    ScopeIsOwnership,
    /// 归属判不出且个人库太多:只同步已固定的,其余一律不自动拉到本地磁盘。
    PinnedOnly,
}

/// 服务端 `isMine` 和 `ownerId` 都没给 → 桌面端没有任何依据判断这个根归谁。
///
/// 只给 `ownerId` 不给 `isMine` 的服务端这里仍算「能判断」而落回 scope:引擎手上没有当前用户 id
/// 可比对,真要覆盖这种半新不旧的服务端,得先让 `/sync/roots` 带上 `isMine`(见 docs/drive.md 待服务端)。
fn ownership_unknown(root: &RootRow) -> bool {
    root.is_mine.is_none() && root.owner_id.is_none()
}

/// 归属判不出的 PERSONAL 根数量。
pub fn unknown_personal_roots(roots: &[RootRow]) -> usize {
    roots.iter().filter(|root| root.scope == ProjectScope::Personal && ownership_unknown(root)).count()
}

/// 见 `LEGACY_PERSONAL_ROOT_LIMIT`;`sync_all_personal` 是用户的显式覆盖。
pub fn ownership_fallback(roots: &[RootRow], sync_all_personal: bool) -> OwnershipFallback {
    if sync_all_personal || unknown_personal_roots(roots) <= LEGACY_PERSONAL_ROOT_LIMIT {
        OwnershipFallback::ScopeIsOwnership
    } else {
        OwnershipFallback::PinnedOnly
    }
}

/// 判定本轮同步范围要用的两样东西:归属回退策略,以及当前用户的部门。
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Selection {
    pub fallback: OwnershipFallback,
    /// `/sync/me` 给的部门 id。首选口径 —— 有它就不看显示名
    pub my_dept_id: Option<RemoteId>,
    /// `/sync/me` 给的部门名。只在两边都没有 id 时回落
    pub my_dept_name: Option<String>,
    /// `/shared-with-me` 里出现过的项目 id(`RemoteId::as_key()`)。
    ///
    /// **只认直接授给本人的**——这正是服务端那个接口的口径(USER 主体的直接授权,部门 / 全公司
    /// 的集体授权不返回)。所以这里不需要、也不应该自己再判一遍「这是不是分享」:
    /// 把集体底权限当成分享,等于把全公司有读权限的项目全拉到每个人的磁盘上。
    pub shared_project_ids: HashSet<String>,
}

impl Selection {
    /// 「这个项目是不是本人部门的」。
    ///
    /// **优先按 id 比**:显示名会带尾空格、会被行政改名,拿它当判据把人挡在同步范围外过。
    /// 两边都有 id 就只看 id(id 不等就是不同部门,不再拿名字兜底 —— 那会把「风控部」和
    /// 隔壁重名的部门混成一个);任一边缺 id 才回落显示名,两边都 trim 并忽略大小写。
    fn same_department(&self, root: &RootRow) -> bool {
        if let (Some(mine), Some(other)) = (&self.my_dept_id, &root.department_id) {
            return mine.as_key() == other.as_key();
        }
        match (self.my_dept_name.as_deref(), root.dept_name.as_deref()) {
            (Some(mine), Some(other)) => mine.trim().eq_ignore_ascii_case(other.trim()) && !mine.trim().is_empty(),
            _ => false,
        }
    }

    /// 这个项目该不该**自动**进同步范围(不含「用户点开过」那条)。
    ///
    /// 自己的 + 公司级 + 本人部门的 + 有东西被直接分享给我的。为什么不是「全都要」:管理员对每个部门的库都有读权限,
    /// 全拉下来既撑爆磁盘,也让不同部门的 skill 描述互相撞车(运营同事干活时触发风控部写的规范)。
    /// 拿不到部门就只要公司级和自己的 —— 宁可少同步,不可乱同步;别的部门的项目仍在启动器里
    /// 看得见,用户点开的那一下就把它纳入(`pinned`)。
    pub fn auto_selected(&self, root: &RootRow) -> bool {
        root.is_mine == Some(true)
            || root.scope == ProjectScope::Company
            || self.same_department(root)
            || self.shared_with_me(root)
    }

    /// 有人**直接**把这个项目里的某个文件 / 目录分享给了我 → 整个项目进同步集。
    ///
    /// 2026-09-14 实报:同事把他资料库里的一个目录分享给用户(可管理),飞书通知也收到了,
    /// alwith 里哪儿都找不到。查下来是两个缺口,这是第二个 —— 就算把「分享给我的」这一组画出来,
    /// 点开也没有本地文件:上面那三条判据(自己的 / 公司级 / 本部门的)没有一条覆盖「别的部门
    /// 的一个目录被单独分享给我」,而同步的最小单位是**项目**,所以只能整个项目纳进来。
    ///
    /// 范围会不会过大?不会:服务端返回的 snapshot 本来就按权限裁剪,没权限的东西不会因为
    /// 项目进了同步集就下得来。
    fn shared_with_me(&self, root: &RootRow) -> bool {
        self.shared_project_ids.contains(&root.project_id.as_key())
    }
}

/// 本轮同步范围:**自己的 + 公司级 + 本人部门的 + 被直接分享给我的 + 用户点开过的**,且 `syncEnabled`。
///
/// 这条口径是「云盘 = 一个自动同步的本地文件夹」的落点:有权限、跟我有关的东西默认就在本地,
/// 用户不需要为每个项目点一次「同步」。别的部门的项目不自动拉(见 `Selection::auto_selected`),
/// 但在启动器里可见 —— 点开的那一下会把它固定下来并从此常驻本地。
///
/// - 管理员对全公司每个人的个人知识库都有读权限(`/sync/roots` 能回 280 个 PERSONAL 根),
///   只按 scope 判会把别人的库全拉下来;服务端给了 `isMine` 就按归属判,没给才回落 scope ——
///   回落时再过一道 `fallback`(见 `LEGACY_PERSONAL_ROOT_LIMIT`);
/// - 「被直接分享给我」是 2026-09-14 补的第五条(见 `Selection::shared_with_me`):单独一个
///   文件 / 目录被分享过来时,前四条一条都不沾边,东西根本不会落到本地;
/// - SKILL 与普通项目现在同一套判据。它是 DEPT / COMPANY scope、`isMine` 恒为 false,
///   曾经因为「只按 isMine 判」而一个都同步不下来(2026-09-04 回归),公司级 / 本部门这两条
///   正是为它加的 —— 现在普通项目也要这两条,两套判据自然合成了一套。
pub fn is_selected(root: &RootRow, selection: &Selection) -> bool {
    if !root.sync_enabled {
        return false;
    }
    // 用户点开过(内部仍叫 pinned):显式意图优先于任何自动判据
    if root.pinned {
        return true;
    }
    if selection.auto_selected(root) {
        return true;
    }
    // 服务端没给归属信息时的兜底:老规矩按 scope 认个人库,数量超阈值就一个都不自动拉
    root.is_mine.is_none()
        && selection.fallback == OwnershipFallback::ScopeIsOwnership
        && root.scope == ProjectScope::Personal
}

fn root_row_from_remote(remote: &SyncRoot) -> RootRow {
    RootRow {
        project_id: remote.project_id.clone(),
        project_key: remote.project_key.clone(),
        name: remote.name.clone(),
        kind: remote.kind,
        scope: remote.scope.unwrap_or(if remote.dept_name.is_some() {
            ProjectScope::Dept
        } else {
            ProjectScope::Company
        }),
        dept_name: remote.dept_name.clone(),
        // null → 空串。**空 = 不进目录树**(SKILL);is_syncable / 面板都据此挡掉
        drive_path: remote.drive_path.clone().unwrap_or_default(),
        node: remote.node.clone(),
        container: remote.container.clone(),
        node_path: remote.node_path.clone(),
        skills_path: remote.skills_path.clone(),
        sync_enabled: remote.sync_enabled,
        can_write: remote.can_write,
        cloud_only: remote.cloud_only,
        cursor: None,
        pinned: false,
        department_id: remote.department_id.clone(),
        owner_id: remote.owner_id.clone(),
        is_mine: remote.is_mine,
    }
}

impl Engine {
    pub fn new(client: DriveClient, config: EngineConfig) -> Result<Self, EngineError> {
        let index = match &config.index_path {
            Some(path) => Index::open(path),
            None => Index::open_in_memory(),
        }
        .map_err(EngineError::Index)?;
        std::fs::create_dir_all(&config.local_root)
            .map_err(|error| io_error(format!("创建 {}", config.local_root.display()), error))?;
        // 几百个选中根的一轮同步会推出上千条 Project 事件(每个根 排队 + 同步中 + 完成);
        // 容量给小了会 Lagged 丢事件,面板上的行就永远停在「同步中」
        let (events, _) = broadcast::channel(4096);
        let mut status = StatusSnapshot::default();
        status.synced = index.count_state(FileState::Synced).map_err(EngineError::Index)?;
        // 上次退出时没传上去的文件,这次起来就该看得见 —— 不必等第一轮同步跑完
        status.failed = index.count_file_errors().map_err(EngineError::Index)?;
        Ok(Self {
            client,
            config,
            index,
            status: Mutex::new(status),
            events,
            paused: AtomicBool::new(false),
            revoked: AtomicBool::new(false),
            push_connected: AtomicBool::new(false),
            sync_lock: tokio::sync::Mutex::new(()),
            priority: Mutex::new(Vec::new()),
            archive_lock: tokio::sync::Mutex::new(()),
            guard_logged: AtomicBool::new(false),
            readonly_warned: Mutex::new(HashSet::new()),
            delete_guards: Mutex::new(DeleteGuards::default()),
            moved_away: Mutex::new(HashSet::new()),
            local_collab: Mutex::new(HashMap::new()),
            cloud_only_checked: AtomicBool::new(false),
            landed_checked: AtomicBool::new(false),
            last_skill_conflicts: Mutex::new(Vec::new()),
        })
    }

    pub fn subscribe(&self) -> broadcast::Receiver<EngineEvent> {
        self.events.subscribe()
    }

    pub fn config(&self) -> &EngineConfig {
        &self.config
    }

    pub fn client(&self) -> &DriveClient {
        &self.client
    }

    pub fn status(&self) -> StatusSnapshot {
        self.status.lock().expect("status mutex").clone()
    }

    pub fn is_paused(&self) -> bool {
        self.paused.load(Ordering::SeqCst)
    }

    pub fn is_revoked(&self) -> bool {
        self.revoked.load(Ordering::SeqCst)
    }

    pub fn is_push_connected(&self) -> bool {
        self.push_connected.load(Ordering::SeqCst)
    }

    /// 推送连接状态由 `push::run_push` 的事件驱动;写进状态快照让 UI 看到「实时 / 轮询」。
    pub fn set_push_connected(&self, connected: bool) {
        self.push_connected.store(connected, Ordering::SeqCst);
        self.update_status(|status| status.push_connected = connected);
    }

    pub fn pause(&self) {
        self.paused.store(true, Ordering::SeqCst);
        self.set_state(EngineState::Paused);
    }

    pub fn resume(&self) {
        self.paused.store(false, Ordering::SeqCst);
        self.set_state(EngineState::Idle);
    }

    fn emit(&self, event: EngineEvent) {
        let _ = self.events.send(event);
    }

    fn set_state(&self, state: EngineState) {
        let snapshot = {
            let mut status = self.status.lock().expect("status mutex");
            status.state = state;
            status.clone()
        };
        self.emit(EngineEvent::Status(snapshot));
    }

    fn update_status(&self, mutate: impl FnOnce(&mut StatusSnapshot)) {
        let snapshot = {
            let mut status = self.status.lock().expect("status mutex");
            mutate(&mut status);
            status.clone()
        };
        self.emit(EngineEvent::Status(snapshot));
    }

    fn push_error(&self, project_id: Option<&RemoteId>, path: Option<&str>, message: String) {
        log::warn!("[drive-sync] {message}");
        self.push_error_quiet(project_id, path, message);
    }

    /// 同上但不写日志。给「每轮都会重算一遍」的那类错用 —— 状态没变还每 60 秒记一行,
    /// 日志会被同一句话灌满。
    fn push_error_quiet(&self, project_id: Option<&RemoteId>, path: Option<&str>, message: String) {
        let record =
            SyncError { project_id: project_id.cloned(), path: path.map(str::to_string), message, at: now_iso() };
        self.update_status(|status| {
            status.errors.push(record);
            if status.errors.len() > MAX_RECORDS {
                status.errors.remove(0);
            }
        });
    }

    pub fn clear_errors(&self) {
        self.update_status(|status| status.errors.clear());
    }

    fn clear_errors_of(&self, project_id: &RemoteId) {
        self.update_status(|status| {
            status.errors.retain(|error| error.project_id.as_ref() != Some(project_id));
        });
    }

    fn clear_global_errors(&self) {
        self.update_status(|status| status.errors.retain(|error| error.project_id.is_some()));
    }

    // ─── 路径 ─────────────────────────────────────────────────────────────

    /// 这个根在磁盘上的家。**一份文件只有一个家**:
    /// - SKILL 根 → `<skills_dir>/yup/<projectKey>/`。它是给机器读的,人不会去打开它;
    ///   以前它同时落在 `~/YUP Drive/公司/…Skill 库/` 与 skills 目录两处,用户在云盘目录树里
    ///   看到一堆自己永远不会点开的文件夹(2026-09-04 实报)。没配 `skills_dir` 就没有家 ——
    ///   `is_syncable` 会把它整个排除在同步之外,而不是退回去污染云盘目录。
    /// - 其余 → `<local_root>/<drivePath>/`。
    pub fn root_local_dir(&self, root: &RootRow) -> PathBuf {
        if root.kind == ProjectKind::Skill
            && let Some(mirror) = self.skill_mirror_dir(root)
        {
            return mirror;
        }
        // 没有 drivePath 又没有 skills 镜像 = 无处可放。`is_syncable` 已经把这种根排除在
        // 同步之外,走到这里只可能是诊断类调用,给一个**明确不存在**的路径而不是 local_root
        self.legacy_drive_dir(root)
            .unwrap_or_else(|| self.config.local_root.join(".unplaced").join(root.project_key.as_str()))
    }

    /// `<local_root>/<drivePath>/` —— 所有非 SKILL 根的家,也是 SKILL 根**曾经**的家
    /// (`sweep_legacy_skill_dirs` 靠它找到要清理的历史副本)。
    ///
    /// **`drive_path` 为空时回 None,不能回 `local_root` 本身**:服务端 7662157 起 SKILL 的
    /// `drivePath` 是 null,而 `join("")` 得到的正是整个 `~/YUP Drive` —— 历史副本清理那条路
    /// 会把**整个云盘目录**当成一份历史副本挪进暂存(被 `skill_库在云盘目录下的历史副本被挪进暂存`
    /// 当场逮到)。空路径不是「根目录」,是「没有位置」。
    fn legacy_drive_dir(&self, root: &RootRow) -> Option<PathBuf> {
        let relative = root.drive_path.trim();
        if relative.is_empty() {
            return None;
        }
        Some(self.config.local_root.join(cloud_to_local_relative(relative, self.config.windows_names)))
    }

    /// 没配 `skills_dir` 的 SKILL 根无处可放:整个跳过,别退回去在云盘目录里建它。
    /// 这个根这一轮同不同步。
    ///
    /// **`drive_path` 为空的一律不同步**(服务端 7662157 起 SKILL 的 `drivePath` 是 null):
    /// 它在盘上没有位置,`root_local_dir` 会算成 local_root 本身 —— 那等于把整个 `~/YUP Drive`
    /// 当成一个项目往里灌东西。SKILL 走 `skills_path` 装进 `~/.alwith/skills/`,与目录树无关。
    fn is_syncable(&self, root: &RootRow) -> bool {
        if root.kind == ProjectKind::Skill {
            return self.skill_mirror_dir(root).is_some();
        }
        !root.drive_path.trim().is_empty()
    }

    fn local_path_for(&self, root: &RootRow, cloud_path: &str) -> PathBuf {
        self.root_local_dir(root).join(cloud_to_local_relative(cloud_path, self.config.windows_names))
    }

    /// 老格式的 `.yupcloud` 占位(一段裸 JSON,AI 读到只会当成文件内容去分析)升级成自述文本。
    ///
    /// **只改老格式的**:已经是新格式的一律不动 —— 将来服务端给了 `cloudOnlyReason`,写进去的是
    /// `apply_remote_file` 拿到的那个值,而索引里没有这个字段,在这儿重算只会把它抹成「未知」。
    ///
    /// 重写占位**不会被当成本地改动上传**:扫描器把 `.yupcloud` 单独收进 `placeholders`,
    /// 根本不进 `files`(见 scanner.rs),上行看不到它们。
    fn upgrade_legacy_placeholders(&self, root: &RootRow) {
        if root.kind == ProjectKind::Skill {
            return;
        }
        let Ok(rows) = self.index.file_map(&root.project_id) else { return };
        for (path, row) in rows {
            if row.state != FileState::CloudOnly {
                continue;
            }
            let Some(file_id) = row.remote_file_id.clone() else { continue };
            let placeholder = self.placeholder_path_for(root, &path);
            let Ok(existing) = std::fs::read_to_string(&placeholder) else { continue };
            if existing.starts_with(PLACEHOLDER_HEADLINE) {
                continue;
            }
            let (_, name) = split_cloud_path(&path);
            let content = cloud_only_placeholder_content(
                &file_id,
                name,
                self.derived_cloud_only_reason(root),
                self.client.base_url(),
                self.config.web_base_url.as_deref(),
                0,
            );
            if let Err(error) = write_file(&placeholder, content.as_bytes()) {
                log::warn!("[drive-sync] 升级占位 {} 失败: {error}", placeholder.display());
            }
        }
    }

    /// 服务端没给原因时客户端自己能确知的那一点:归档项目整个不落盘,项目 key 就看得出来。
    /// 别的一律「未知」—— 猜一个原因写进文件比不写还糟。
    fn derived_cloud_only_reason(&self, root: &RootRow) -> CloudOnlyReason {
        if root.project_key == crate::archive::ARCHIVE_PROJECT_KEY {
            CloudOnlyReason::Archive
        } else {
            CloudOnlyReason::Unknown
        }
    }

    /// 占位文件该写什么。原因**只在确知时才填**:归档项目整个不落盘,项目 key 自己就看得出来;
    /// 「对话原文」与「没有下载权限」服务端目前不给字段(snapshot 里只有 `cloudOnly: bool`),
    /// 判不出来就写「未知」并把两种可能都说清楚 —— 猜一个原因写进文件比不写还糟。
    /// `too_large`:这一份不是「仅云端」,它下得下来,只是先没下 —— 占位里的措辞必须分开,
    /// 否则一份点一下就能拿到的表格会顶着「你可能没有下载权限」的说辞躺在那儿。
    fn placeholder_content(&self, remote: &RemoteFile, reason: CloudOnlyReason) -> String {
        let (_, name) = split_cloud_path(&remote.path);
        cloud_only_placeholder_content(
            &remote.file_id,
            name,
            reason,
            self.client.base_url(),
            self.config.web_base_url.as_deref(),
            remote.size.unwrap_or(0),
        )
    }

    fn cloud_only_placeholder(&self, root: &RootRow, remote: &RemoteFile) -> String {
        let reason = match remote.cloud_only_reason.as_deref() {
            Some(value) => CloudOnlyReason::parse(value),
            None => self.derived_cloud_only_reason(root),
        };
        self.placeholder_content(remote, reason)
    }

    fn placeholder_path_for(&self, root: &RootRow, cloud_path: &str) -> PathBuf {
        let (parent, name) = split_cloud_path(cloud_path);
        self.local_path_for(root, &join_cloud_path(parent, &cloud_only_placeholder_name(name)))
    }

    fn root_info(&self, row: &RootRow, selection: &Selection) -> RootInfo {
        RootInfo {
            project_id: row.project_id.clone(),
            project_key: row.project_key.clone(),
            name: row.name.clone(),
            kind: row.kind,
            scope: row.scope,
            dept_name: row.dept_name.clone(),
            drive_path: row.drive_path.clone(),
            node: row.node.clone(),
            container: row.container.clone(),
            node_path: row.node_path.clone(),
            skills_path: row.skills_path.clone(),
            sync_enabled: row.sync_enabled,
            can_write: row.can_write,
            cloud_only: row.cloud_only,
            cursor: row.cursor.clone(),
            pinned: row.pinned,
            department_id: row.department_id.clone(),
            owner_id: row.owner_id.clone(),
            is_mine: row.is_mine,
            local_path: self.root_local_dir(row).to_string_lossy().to_string(),
            selected: is_selected(row, selection),
        }
    }

    // ─── 根 ───────────────────────────────────────────────────────────────

    pub fn roots(&self) -> Result<Vec<RootInfo>, EngineError> {
        let rows = self.index.list_roots().map_err(EngineError::Index)?;
        let selection = self.selection(&rows)?;
        Ok(rows.iter().map(|row| self.root_info(row, &selection)).collect())
    }

    /// 本轮的判定依据:归属回退策略 + 缓存下来的当前用户部门(id 优先,名字兜底)。
    fn selection(&self, rows: &[RootRow]) -> Result<Selection, EngineError> {
        Ok(Selection {
            fallback: self.ownership_fallback(rows)?,
            my_dept_id: self.meta_non_empty(META_MY_DEPT_ID)?.map(|value| RemoteId::from_key(&value)),
            my_dept_name: self.meta_non_empty(META_MY_DEPT_NAME)?,
            shared_project_ids: self.shared_project_ids()?,
        })
    }

    /// meta 里缓存的「分享给我的」涉及的项目 id。没问过 / 一条都没有 → 空集。
    fn shared_project_ids(&self) -> Result<HashSet<String>, EngineError> {
        Ok(self
            .meta_non_empty(META_SHARED_PROJECTS)?
            .map(|value| value.split(',').filter(|part| !part.is_empty()).map(str::to_string).collect())
            .unwrap_or_default())
    }

    /// meta 里的一个值,空串当没有。空串是「问过了、服务端没给」,不是「还没问」。
    fn meta_non_empty(&self, key: &str) -> Result<Option<String>, EngineError> {
        Ok(self.index.meta_get(key).map_err(EngineError::Index)?.filter(|value| !value.trim().is_empty()))
    }

    /// 问一次 `/sync/me` 把当前用户的部门(id 与名字)存进 meta。一天一次:服务端补上部门字段后
    /// 不必等用户重装。端点不存在 / 报错都只记一行 debug —— 同步范围退化成「只要自己的和公司级」,
    /// 不该拖垮整轮同步。
    async fn refresh_my_department(&self) -> Result<(), EngineError> {
        let now = chrono::Utc::now().timestamp();
        let fetched_at = self
            .index
            .meta_get(META_MY_DEPT_AT)
            .map_err(EngineError::Index)?
            .and_then(|value| value.parse::<i64>().ok());
        if fetched_at.is_some_and(|at| now - at < MY_DEPT_TTL_SECS) {
            return Ok(());
        }
        match self.client.sync_me().await {
            Ok(SyncMe { dept_name, department_id, .. }) => {
                let dept = dept_name.unwrap_or_default();
                let dept_id = department_id.map(|id| id.as_key()).unwrap_or_default();
                if dept.trim().is_empty() && dept_id.is_empty() {
                    log::info!(
                        "[drive-sync] /sync/me 既没给 departmentId 也没给 deptName,本人部门的项目不会自动同步\
                         (公司级与自己的照常);待服务端在 /sync/me 与 /sync/roots 补上这两个字段"
                    );
                }
                self.index.meta_set(META_MY_DEPT_ID, &dept_id).map_err(EngineError::Index)?;
                self.index.meta_set(META_MY_DEPT_NAME, dept.trim()).map_err(EngineError::Index)?;
                self.index.meta_set(META_MY_DEPT_AT, &now.to_string()).map_err(EngineError::Index)?;
            }
            Err(error) if error.is_fatal() => return self.guard_revoked(Err(error)).await,
            Err(error) => {
                log::debug!("[drive-sync] /sync/me 不可用({error}),本人部门的项目暂不自动同步");
                // 不写 fetched_at:下一轮还会再试(端点可能只是暂时不通)
            }
        }
        Ok(())
    }

    // ─── 「分享给我的」 ────────────────────────────────────────────────────────

    /// 「分享给我的」那张列表(云盘面板上的一组),**并顺手把同步范围更新掉**。
    ///
    /// 两件事一起做是有意的:面板打开的那一刻正是用户最想看到「同事刚分享的东西」的时候,
    /// 而同一份数据既画列表也定同步范围 —— 分两条路各问一次,只会让两边不一致。
    ///
    /// 每一行补两样服务端不给的东西:
    /// - FOLDER 的项目内相对路径(多问一趟 `GET /folders/{id}`)。服务端那条记录只说「哪个资源、
    ///   在哪个项目」,网页端因此只能做到「打开所在项目」;桌面端要把人送到**本地那个目录**;
    /// - 本地绝对路径。**不校验它存不存在**:项目还没同步下来时这正是「同步完会落在哪」,
    ///   前端据此在拉取完成后定位。项目不在索引里(见下)则为 null。
    ///
    /// 单条目录的路径查询失败只让那一行退化成「只知道项目」,不让整张列表报错 ——
    /// 一条查不到就什么都看不到,是这次要修的那个毛病的翻版。
    pub async fn shared_with_me(&self) -> Result<Vec<SharedItem>, EngineError> {
        let items = match self.guard_revoked(self.client.shared_with_me().await).await {
            Ok(items) => items,
            // 老服务端没有这个端点:当成「没有分享给我的东西」,不是故障(与网页端 isNotDeployed 同口径)。
            // 真出错了照常往上抛 —— 静默吞掉才是这次要修的毛病
            Err(EngineError::Client(ClientError::Http { status: 404 | 501, .. })) => Vec::new(),
            Err(error) => return Err(error),
        };
        self.store_shared_projects(&items)?;

        let roots = self.index.list_roots().map_err(EngineError::Index)?;
        let mut out = Vec::with_capacity(items.len());
        for mut item in items {
            if item.resource_type == GrantResourceKind::Folder {
                match self.client.folder(&item.resource_id).await {
                    Ok(folder) => item.folder_path = Some(folder.rel_path()),
                    Err(error) => {
                        log::debug!("[drive-sync] 取目录 {} 的路径失败({error}),这一行只能停在项目根", item.resource_id)
                    }
                }
            }
            item.local_path = self.shared_item_local_path(&roots, &item);
            out.push(item);
        }
        Ok(out)
    }

    /// 一条「分享给我的」在本地磁盘的落点。
    ///
    /// - FILE:索引里有这个 fileId 就用它记的云端路径(**这是唯一可靠的来源** —— 服务端那条
    ///   记录只给文件名,不给它在项目里的哪一层);
    /// - FOLDER:项目根 + 上面查到的相对路径;路径没查到就退回项目根(网页端的行为)。
    ///
    /// 项目不在索引里 → None。这不是异常:服务端的项目列表把**别人的 PERSONAL 项目**挡在
    /// `/sync/roots` 之外(owner-only,见 `ProjectService#listByFilters`),所以「同事把他个人
    /// 资料库里的一个目录分享给我」这一种,桌面端根本没有那个根可同步 —— 前端据此回落网页版。
    fn shared_item_local_path(&self, roots: &[RootRow], item: &SharedItem) -> Option<String> {
        let project_id = item.project_id.as_ref()?;
        let root = roots.iter().find(|row| row.project_id.as_key() == project_id.as_key())?;
        let cloud_path = match item.resource_type {
            GrantResourceKind::File => {
                let (owner, path) = self.index.find_by_remote_file_id(&item.resource_id).ok().flatten()?;
                // 索引里那一行必须属于这个项目,否则拼出来的是别的项目根下的路径
                if owner.as_key() != project_id.as_key() {
                    return None;
                }
                path
            }
            GrantResourceKind::Folder => item.folder_path.clone().unwrap_or_default(),
        };
        Some(self.local_path_for(root, &cloud_path).to_string_lossy().to_string())
    }

    /// 同步范围要用的那份缓存:`/shared-with-me` 涉及的项目 id 写进 meta。
    ///
    /// 拿到空表也照写(空串),并且照样更新时间戳 —— 「问过了,一条都没有」与「还没问过」
    /// 是两回事:分不开的话,取消分享之后那个项目会永远留在同步集里。
    fn store_shared_projects(&self, items: &[SharedItem]) -> Result<(), EngineError> {
        let mut ids: Vec<String> = Vec::new();
        for item in items {
            if let Some(project_id) = &item.project_id {
                let key = project_id.as_key();
                if !ids.contains(&key) {
                    ids.push(key);
                }
            }
        }
        self.index.meta_set(META_SHARED_PROJECTS, &ids.join(",")).map_err(EngineError::Index)?;
        self.index
            .meta_set(META_SHARED_PROJECTS_AT, &chrono::Utc::now().timestamp().to_string())
            .map_err(EngineError::Index)?;
        Ok(())
    }

    /// 每轮同步开头刷一次「分享给我的」涉及哪些项目(TTL 内跳过)。
    ///
    /// 与 `refresh_my_department` 同一个位置、同一套写法:**放在拉根之前**,同一轮里算出来的
    /// `selected` 才是对的。拉不到就沿用 meta 里上一次的答案,只记一行 debug ——
    /// 这个接口不通不该拖垮整轮同步。
    async fn refresh_shared_projects(&self) -> Result<(), EngineError> {
        let now = chrono::Utc::now().timestamp();
        let fetched_at = self
            .index
            .meta_get(META_SHARED_PROJECTS_AT)
            .map_err(EngineError::Index)?
            .and_then(|value| value.parse::<i64>().ok());
        if fetched_at.is_some_and(|at| now - at < SHARED_PROJECTS_TTL_SECS) {
            return Ok(());
        }
        match self.client.shared_with_me().await {
            Ok(items) => self.store_shared_projects(&items)?,
            // 老服务端没这个端点:与「问过了、一条都没有」同样处理(含写时间戳),否则每一轮
            // 同步都要白问一趟。TTL 只有五分钟,服务端部署上之后很快就会被认出来
            Err(ClientError::Http { status: 404 | 501, .. }) => self.store_shared_projects(&[])?,
            Err(error) if error.is_fatal() => return self.guard_revoked(Err(error)).await,
            Err(error) => {
                log::debug!("[drive-sync] /shared-with-me 不可用({error}),分享给我的项目沿用上一次的结果");
                // 不写 fetched_at:下一轮还会再试
            }
        }
        Ok(())
    }

    /// 用户是否显式点过「全部同步」(覆盖归属兜底防线)。
    pub fn sync_all_personal(&self) -> Result<bool, EngineError> {
        Ok(self.index.meta_get(META_SYNC_ALL_PERSONAL).map_err(EngineError::Index)?.as_deref() == Some("1"))
    }

    /// 云盘面板上的「全部同步」/ 撤销:写进索引 meta,下一轮同步立刻生效。
    pub fn set_sync_all_personal(&self, value: bool) -> Result<(), EngineError> {
        self.index.meta_set(META_SYNC_ALL_PERSONAL, if value { "1" } else { "0" }).map_err(EngineError::Index)?;
        self.guard_logged.store(false, Ordering::SeqCst);
        Ok(())
    }

    /// 本轮的归属兜底策略。防线第一次生效(以及解除)时记一行 info,说明为什么少同步了东西。
    fn ownership_fallback(&self, rows: &[RootRow]) -> Result<OwnershipFallback, EngineError> {
        let fallback = ownership_fallback(rows, self.sync_all_personal()?);
        let degraded = fallback == OwnershipFallback::PinnedOnly;
        if degraded != self.guard_logged.swap(degraded, Ordering::SeqCst) {
            if degraded {
                log::info!(
                    "[drive-sync] 服务端未提供归属信息且个人库数量为 {},为避免把他人个人库拉到本地,仅同步已固定的项目",
                    unknown_personal_roots(rows)
                );
            } else {
                log::info!("[drive-sync] 归属信息已可判断(或用户选择了全部同步),恢复按归属同步个人库");
            }
        }
        Ok(fallback)
    }

    /// 给设置页 / 云盘面板看的防线状态。
    pub fn ownership_guard(&self) -> Result<OwnershipGuard, EngineError> {
        let rows = self.index.list_roots().map_err(EngineError::Index)?;
        let unknown = unknown_personal_roots(&rows);
        let sync_all = self.sync_all_personal()?;
        Ok(OwnershipGuard {
            unknown_personal_roots: unknown as u32,
            threshold: LEGACY_PERSONAL_ROOT_LIMIT as u32,
            sync_all_personal: sync_all,
            active: !sync_all && unknown > LEGACY_PERSONAL_ROOT_LIMIT,
        })
    }

    /// 每一轮的第一步:拉根清单。**网络抖一下不该让整轮同步作废。**
    ///
    /// 从前这里一失败就 `return Err`,整轮什么都不做 —— 连上行也不跑,用户本地刚改的东西
    /// 就这么被一个与他无关的网络抖动扣住了(2026-09-15:一个人界面上四条「拉取根清单失败」,
    /// 每一条背后都是一整轮白跑)。境外办公的同事网络本来就不稳,这个代价一天要付很多次。
    ///
    /// 两层兜底:
    /// 1. 可重试的错(传输层、5xx)退避再试两次 —— 1s、3s,盖住绝大多数瞬时抖动;
    /// 2. 还是不行就**用索引里上一轮的根继续跑**。拿不到最新清单不等于不能同步:根清单
    ///    变化(新项目、权限调整)晚一轮知道无所谓,本地改动传不上去才是真事故。
    ///
    /// 鉴权类(吊销、设备不符、令牌过期)不在此列:那种情况继续跑只会一路 401,照旧往上抛。
    async fn refresh_roots_resilient(&self) -> Result<Vec<RootInfo>, EngineError> {
        const RETRY_WAITS: [Duration; 2] = [Duration::from_secs(1), Duration::from_secs(3)];
        let mut last = match self.refresh_roots().await {
            Ok(roots) => return Ok(roots),
            Err(error) => error,
        };
        for wait in RETRY_WAITS {
            if !matches!(&last, EngineError::Client(error) if error.is_retryable()) {
                break;
            }
            tokio::time::sleep(wait).await;
            match self.refresh_roots().await {
                Ok(roots) => {
                    log::info!("[drive-sync] 根清单重试成功");
                    return Ok(roots);
                }
                Err(error) => last = error,
            }
        }
        if matches!(&last, EngineError::Revoked | EngineError::Client(_) if is_fatal_engine_error(&last)) {
            return Err(last);
        }
        let cached = self.roots()?;
        if cached.is_empty() {
            return Err(last);
        }
        log::warn!("[drive-sync] 拉根清单没成({last}),先用索引里上一轮的 {} 个根继续这一轮", cached.len());
        self.push_error_quiet(
            None,
            None,
            format!("这一轮没能刷新云盘目录清单，先按上次的接着同步。{}", humanize(&last)),
        );
        Ok(cached)
    }

    pub async fn refresh_roots(&self) -> Result<Vec<RootInfo>, EngineError> {
        // SKILL 自动分发要知道用户在哪个部门。放在拉根之前:同一轮里算出来的 selected 才是对的
        self.refresh_my_department().await?;
        // 同理:被分享给我的资源所在项目要进同步集,这份名单也得在算 selected 之前就位
        self.refresh_shared_projects().await?;
        let remote = self.guard_revoked(self.client.roots().await).await?;
        let mut seen = Vec::new();
        for root in &remote {
            self.index.upsert_root(&root_row_from_remote(root)).map_err(EngineError::Index)?;
            seen.push(root.project_id.clone());
        }
        // 服务端不再返回的根(失去权限 / 项目删除):索引里的根与文件行一起删;本地目录保留不动
        for stale in self.index.list_roots().map_err(EngineError::Index)? {
            if !seen.contains(&stale.project_id) {
                self.index.delete_root(&stale.project_id).map_err(EngineError::Index)?;
            }
        }
        self.roots()
    }

    /// 用户在云盘面板上点了某个项目 → 插到同步队列**队首**。
    ///
    /// 几百个项目排队时,让用户点的那个排在最后是最糟的体验(点了没反应,等几分钟也不落盘)。
    /// 立刻推一条 `Queued` 让行内状态先亮起来 —— 点击必须当场可见,不能等到一轮同步结束。
    pub fn prioritize(&self, project_id: &RemoteId) {
        {
            let mut priority = self.priority.lock().expect("priority mutex");
            priority.retain(|id| id.as_key() != project_id.as_key());
            priority.insert(0, project_id.clone());
            priority.truncate(MAX_PRIORITY);
        }
        self.emit_project(project_id, ProjectPhase::Queued, 0, 0, 0, None);
    }

    /// 下一个该同步哪个根:先看用户点过的(队首优先),没有就按原顺序。
    ///
    /// 本轮范围里没有的 id **留着不丢**:用户点「在此项目中工作」时先固定再插队,而本轮的
    /// `pending` 是这一轮开头 `refresh_roots` 算出来的 —— 刚固定的项目要到下一轮才进得来。
    /// 这里若把它当垃圾丢掉,插队就白插了,用户看到的还是「点了没反应」。
    fn next_in_queue(&self, pending: &mut Vec<RemoteId>) -> Option<RemoteId> {
        {
            let mut priority = self.priority.lock().expect("priority mutex");
            if let Some(index) =
                priority.iter().position(|wanted| pending.iter().any(|id| id.as_key() == wanted.as_key()))
            {
                let wanted = priority.remove(index);
                let at = pending.iter().position(|id| id.as_key() == wanted.as_key()).expect("刚确认过在里面");
                return Some(pending.remove(at));
            }
        }
        if pending.is_empty() { None } else { Some(pending.remove(0)) }
    }

    fn emit_project(
        &self, project_id: &RemoteId, phase: ProjectPhase, done: u32, total: u32, failed: u32, message: Option<String>,
    ) {
        self.emit(EngineEvent::Project(ProjectProgress {
            project_id: project_id.clone(),
            phase,
            done,
            total,
            failed,
            message,
            at: now_iso(),
        }));
    }

    pub fn pin_root(&self, project_id: &RemoteId, pinned: bool) -> Result<(), EngineError> {
        self.index.set_pinned(project_id, pinned).map_err(EngineError::Index)
    }

    /// 设置页「已装的部门 Skill」:SKILL 项目不进云盘列表(给机器读的),但要能查到装在哪。
    pub fn skill_mirrors(&self) -> Result<Vec<SkillMirror>, EngineError> {
        let rows = self.index.list_roots().map_err(EngineError::Index)?;
        let selection = self.selection(&rows)?;
        Ok(rows
            .into_iter()
            .filter(|root| root.kind == ProjectKind::Skill)
            .map(|root| {
                let local_path = self.root_local_dir(&root);
                let skills_path = self.skill_mirror_dir(&root);
                SkillMirror {
                    installed: skills_path.as_ref().is_some_and(|path| path.exists()) || local_path.exists(),
                    // 自动装的(公司级 / 本人部门)与用户手动点开过的要能分辨:装错部门的规范
                    // 是会让人做错事的,用户得看得出这一条是谁的主意
                    auto_installed: selection.auto_selected(&root),
                    pinned: root.pinned,
                    dept_name: root.dept_name.clone(),
                    project_id: root.project_id.clone(),
                    project_key: root.project_key.clone(),
                    name: root.name.clone(),
                    local_path: local_path.to_string_lossy().to_string(),
                    skills_path: skills_path.map(|path| path.to_string_lossy().to_string()),
                }
            })
            .collect())
    }

    /// 本地云盘占了多少、都被谁占了(设置页「磁盘占用」)。
    ///
    /// **看不见就管不了**:真机上 2.9 GB 里 2.69 GB 是一个人目录下的原始数据表(1848 个文件),
    /// 真正的文档加起来才几兆。数字取自索引而不是遍历磁盘 —— 几千个文件 stat 一遍会让设置页卡住。
    pub fn disk_usage(&self, limit: u32) -> Result<DiskUsage, EngineError> {
        let roots: HashMap<String, RootRow> = self
            .index
            .list_roots()
            .map_err(EngineError::Index)?
            .into_iter()
            .map(|row| (row.project_id.as_key(), row))
            .collect();
        let (total_bytes, total_files) = self.index.usage_total().map_err(EngineError::Index)?;
        let projects = self
            .index
            .usage_by_project(limit)
            .map_err(EngineError::Index)?
            .into_iter()
            .filter_map(|(project_id, bytes, files)| {
                let root = roots.get(&project_id.as_key())?;
                Some(DiskUsageProject {
                    project_id,
                    name: root.name.clone(),
                    drive_path: root.drive_path.clone(),
                    local_path: self.root_local_dir(root).to_string_lossy().to_string(),
                    bytes,
                    files,
                })
            })
            .collect();
        let files = self
            .index
            .largest_files(limit)
            .map_err(EngineError::Index)?
            .into_iter()
            .filter_map(|(project_id, path, bytes)| {
                let root = roots.get(&project_id.as_key())?;
                Some(DiskUsageFile {
                    local_path: self.local_path_for(root, &path).to_string_lossy().to_string(),
                    project_name: root.name.clone(),
                    project_id,
                    path,
                    bytes,
                })
            })
            .collect();
        Ok(DiskUsage { total_bytes, total_files, projects, files })
    }

    /// 协同会话建起来了:**当场**在本地标上,不等服务端那一趟(见 `local_collab`)。
    pub fn begin_local_collab(&self, project_id: &RemoteId, cloud_path: &str) {
        let deadline = Instant::now() + LOCAL_COLLAB_TTL;
        self.local_collab.lock().expect("local_collab lock").insert(local_collab_key(project_id, cloud_path), deadline);
        log::debug!("[drive-sync] {cloud_path} 进入协同,本轮起不上行");
    }

    /// 协同会话结束(编辑器销毁 / 断连 / 切走文件):撤销本地标记,让它恢复正常上行。
    /// **撤销一定要发生** —— 标记赖着不走的后果是这份文件永远推不上去,比多一个冲突副本严重得多。
    /// 这是主路径;`LOCAL_COLLAB_TTL` 是前端没调到时的兜底,不是替代品。
    pub fn end_local_collab(&self, project_id: &RemoteId, cloud_path: &str) {
        self.local_collab.lock().expect("local_collab lock").remove(&local_collab_key(project_id, cloud_path));
        log::debug!("[drive-sync] {cloud_path} 退出协同,恢复上行");
    }

    /// 这个项目此刻有哪些文件被本地标成了协同(顺手把过期的清掉)。
    /// 这份文件此刻在本地开着协同会话吗 —— 也就是**磁盘桥在不在**。
    /// 桥在编辑器里:开着编辑器,磁盘上的改动会被并进 Yjs;没开就没有桥。
    fn locally_collab(&self, project_id: &RemoteId, cloud_path: &str) -> bool {
        let now = Instant::now();
        let mut live = self.local_collab.lock().expect("local_collab lock");
        live.retain(|_, deadline| *deadline > now);
        live.contains_key(&local_collab_key(project_id, cloud_path))
    }

    fn locally_collab_paths(&self, project_id: &RemoteId) -> HashSet<String> {
        let now = Instant::now();
        let mut live = self.local_collab.lock().expect("local_collab lock");
        live.retain(|_, deadline| *deadline > now);
        let prefix = format!("{}\0", project_id.as_key());
        live.keys().filter_map(|key| key.strip_prefix(&prefix).map(str::to_string)).collect()
    }

    /// 服务端下发的客户端配置(契约 §6.16)。**拿不到不算错** —— 老服务端没有这个接口,
    /// 新服务端也可能只配了一半;调用方安静回落到本地那套,行为退回今天。
    pub async fn client_config(&self) -> Result<ClientConfig, EngineError> {
        Ok(self.guard_revoked(self.client.client_config().await).await?)
    }

    // ─── 沉淀(condense)──────────────────────────────────────────────────

    /// **沉淀前的对账**:把这个项目的本地改动当场推上去,再回报还剩什么没上云。
    ///
    /// 为什么不能省:执行器拉的是**云端**的项目快照 zip。用户刚干完的活如果还没同步上去,
    /// 沉淀就是在旧内容上跑 —— 产出一份看起来没问题、实际漏了今天全部工作的草稿。
    /// **这比失败更糟**:失败看得见,这个看不见,而它偏偏长得像成功(2026-09-07)。
    ///
    /// 只推不拉:我们要确认的是「**我的**东西上去了没有」,把远端的新东西拉下来是另一件事,
    /// 不该让用户为它多等。
    ///
    /// `scope_path`:只看这个目录 / 这份文件之内的。一个 77 个文件的项目里别人有 5 个没传上去,
    /// 不该拦住我沉淀自己那一份 —— 对账的范围必须和沉淀的范围一样大。
    pub async fn settle_before_condense(
        &self, project_id: &RemoteId, scope_path: Option<&str>,
    ) -> Result<UnsyncedSummary, EngineError> {
        // 索引里还没有这个根(刚登录、还没跑过一轮同步)就现拉一次根清单 —— 用户点的是他眼前
        // 列着的项目,不该因为「引擎还没轮到它」而被拒
        if self.index.get_root(project_id).map_err(EngineError::Index)?.is_none() {
            self.refresh_roots().await?;
        }
        let _guard = self.sync_lock.lock().await;
        let root = self
            .index
            .get_root(project_id)
            .map_err(EngineError::Index)?
            .ok_or_else(|| EngineError::Io(format!("项目 {project_id} 不在同步范围里")))?;
        // 只读的根本来就不上行,没什么可对账的
        if root.can_write && root.sync_enabled && !root.cloud_only && root.kind != ProjectKind::Skill {
            // 推失败不往上抛:失败的那些本来就要出现在下面这份清单里,让用户看见比让他看见一个
            // 异常有用得多
            if let Err(error) = self.push_root(&root).await {
                if is_fatal_engine_error(&error) {
                    return Err(error);
                }
                log::warn!("[drive-sync] 沉淀前对账推送 {} 失败: {error}", root.drive_path);
            }
        }
        self.unsynced_summary(project_id, scope_path)
    }

    /// 这个项目(或其中一个范围)还有什么没上云。纯读索引,不碰网络。
    pub fn unsynced_summary(
        &self, project_id: &RemoteId, scope_path: Option<&str>,
    ) -> Result<UnsyncedSummary, EngineError> {
        let rows = self.index.list_files(project_id).map_err(EngineError::Index)?;
        let scope = scope_path.map(|scope| scope.trim_matches('/').to_string()).filter(|scope| !scope.is_empty());
        let mut summary = UnsyncedSummary::default();
        for row in rows {
            // 范围外的不算:scope 是一份文件时只看它自己,是目录时看它底下的
            if let Some(scope) = &scope
                && row.path != *scope
                && !row.path.starts_with(&format!("{scope}/"))
            {
                continue;
            }
            // 「没上云」只算**本地有、云端没有(或不是这一版)**的那些:
            // cloudOnly / notDownloaded / downloading 是反过来的方向,ignored 是用户自己排除的。
            // 不列 Conflict:索引行从来不会是这个状态(它只作为事件与 `status.conflicts` 存在),
            // 而冲突副本本身是一份新的本地文件,上面那趟 push 已经把它推上去了
            // Forbidden 也算:服务端不收它,它就不在云端 —— 沉淀同样看不见它,用户得知道
            let unsynced = matches!(
                row.state,
                FileState::Pending | FileState::Uploading | FileState::Error | FileState::Forbidden
            );
            if !unsynced {
                continue;
            }
            summary.pending += 1;
            if matches!(row.state, FileState::Error | FileState::Forbidden) {
                summary.failed += 1;
            }
            if summary.paths.len() < 20 {
                summary.paths.push(row.path);
            }
        }
        Ok(summary)
    }

    /// 发起一次沉淀 —— 建一条服务端 condense job(契约 §2)。
    ///
    /// **不在本地跑 kb-condense**:知识过期检测、`recondense`、网页那个「建议沉淀」列表全挂在
    /// 这条 job 链上,客户端另跑一份就会分叉成两种质量的知识。客户端的职责是「从他干活的地方
    /// 发起」+「把草稿领回来给他改」。
    pub async fn start_condense(&self, project_id: &RemoteId, scope_path: Option<&str>) -> Result<Job, EngineError> {
        Ok(self.guard_revoked(self.client.create_condense_job(project_id, scope_path).await).await?)
    }

    /// 沉淀产出的那份草稿在本地的绝对路径 —— 找不到就是这个知识库项目还没同步到本地。
    ///
    /// 「把草稿在编辑器里打开让他当场改」是这件事的一半价值:让他改完还得先去网页找一遍,
    /// 就又回到了「入口不在他干活的地方」。找不到时调用方退回 `humanUrl`,并说清为什么。
    pub fn local_path_of_remote_file(&self, file_id: &RemoteId) -> Result<Option<String>, EngineError> {
        let Some((project_id, cloud_path)) = self.index.find_by_remote_file_id(file_id).map_err(EngineError::Index)?
        else {
            return Ok(None);
        };
        let Some(root) = self.index.get_root(&project_id).map_err(EngineError::Index)? else {
            return Ok(None);
        };
        let local = self.local_path_for(&root, &cloud_path);
        Ok(local.is_file().then(|| local.to_string_lossy().to_string()))
    }

    /// 这个项目上待批准的沉淀建议。空表就是没有 —— 不提示。
    pub async fn proposed_condense(&self, project_id: &RemoteId) -> Result<Vec<Job>, EngineError> {
        let jobs = self.guard_revoked(self.client.proposed_jobs(project_id).await).await?;
        // 只认沉淀那一种:同一条队列上还跑着飞书导入、文本抽取之类,拿它们去问用户毫无意义
        Ok(jobs.into_iter().filter(|job| job.r#type.as_deref().is_none_or(|kind| kind == "condense")).collect())
    }

    /// 一键接受一条建议:PROPOSED → PENDING,执行器随后领走。
    pub async fn approve_job(&self, job_id: &RemoteId) -> Result<(), EngineError> {
        Ok(self.guard_revoked(self.client.approve_job(job_id).await).await?)
    }

    /// 丢掉 / 取消一条任务。「别再问」与「取消正在跑的沉淀」都走它。
    pub async fn cancel_job(&self, job_id: &RemoteId) -> Result<(), EngineError> {
        Ok(self.guard_revoked(self.client.cancel_job(job_id).await).await?)
    }

    /// 轮询一条任务。
    pub async fn job(&self, job_id: &RemoteId) -> Result<Job, EngineError> {
        Ok(self.guard_revoked(self.client.job(job_id).await).await?)
    }

    /// 索引里这一行的原样 —— 大小 / sha / 远端 id / 状态。文件树上那个占位要显示「多大」,
    /// 按需下载要知道「去哪拿」,都从这里读,不必为每一样再开一个命令。
    pub fn indexed_file(&self, project_id: &RemoteId, cloud_path: &str) -> Result<Option<FileRow>, EngineError> {
        self.index.get_file(project_id, cloud_path).map_err(EngineError::Index)
    }

    /// 只给测试用:把一行从索引里抹掉,模拟「老版本下载失败之后什么痕迹都不留」的烂摊子。
    #[doc(hidden)]
    pub fn forget_file_for_test(&self, project_id: &RemoteId, cloud_path: &str) {
        let _ = self.index.delete_file(project_id, cloud_path);
    }

    /// 本地路径 → 同步状态。目录返回 None;不在任何根下返回 None。
    pub fn file_state(&self, local_path: &Path) -> Result<Option<FileStateEvent>, EngineError> {
        if local_path.is_dir() {
            return Ok(None);
        }
        for root in self.index.list_roots().map_err(EngineError::Index)? {
            let dir = self.root_local_dir(&root);
            let Ok(relative) = local_path.strip_prefix(&dir) else { continue };
            // 大小与事件那条同源:占位那一行要显示「多大」,查一次索引就有
            let make = |state: FileState, path: String| {
                let size = self.index.get_file(&root.project_id, &path).ok().flatten().map(|row| row.size).unwrap_or(0);
                Some(FileStateEvent {
                    project_id: root.project_id.clone(),
                    path,
                    local_path: local_path.to_string_lossy().to_string(),
                    state,
                    size,
                })
            };
            if is_cloud_only_placeholder(relative) {
                let original = local_to_cloud_relative(relative, self.config.windows_names);
                let cloud_path = original.trim_end_matches(".yupcloud").to_string();
                // 占位有两种,**不能都报成 cloudOnly**:一种是「这份内容不许落到你盘上」
                //(权限 / 会话原文 / 归档),点多少下都不会来;另一种是「太大了先没下」,
                // 点一下就能拿到。文件树按这个状态决定那一行点不点得动 —— 报错了,
                // 用户就会对着一个其实能下的文件干瞪眼(2026-09-07 大文件按需下载)。
                let state = self
                    .index
                    .get_file(&root.project_id, &cloud_path)
                    .map_err(EngineError::Index)?
                    .map(|row| row.state)
                    .filter(|state| matches!(state, FileState::NotDownloaded | FileState::Downloading))
                    .unwrap_or(FileState::CloudOnly);
                return Ok(make(state, cloud_path));
            }
            let cloud_path = local_to_cloud_relative(relative, self.config.windows_names);
            if let Some(row) = self.index.get_file(&root.project_id, &cloud_path).map_err(EngineError::Index)? {
                // 只读优先于协同标记:两者同时成立时用户最需要知道的是「这份文件改不了」
                let state = match (row.read_only, row.collab_active) {
                    (true, _) => FileState::ReadOnly,
                    (false, true) => FileState::Collab,
                    (false, false) => row.state,
                };
                return Ok(make(state, cloud_path));
            }
            let rules =
                IgnoreRules::load(&dir).map_err(EngineError::Io)?.with_max_file_size(self.config.max_upload_bytes);
            let state = if rules.is_ignored(relative, false) { FileState::Ignored } else { FileState::Pending };
            return Ok(make(state, cloud_path));
        }
        Ok(None)
    }

    /// 本地路径对应的索引行(协同会话按它取 fileId)。不在任何根下 / 索引里没有返回 None。
    pub fn file_row(&self, local_path: &Path) -> Result<Option<(RootRow, FileRow)>, EngineError> {
        for root in self.index.list_roots().map_err(EngineError::Index)? {
            let dir = self.root_local_dir(&root);
            let Ok(relative) = local_path.strip_prefix(&dir) else { continue };
            let cloud_path = local_to_cloud_relative(relative, self.config.windows_names);
            return Ok(self
                .index
                .get_file(&root.project_id, &cloud_path)
                .map_err(EngineError::Index)?
                .map(|row| (root, row)));
        }
        Ok(None)
    }

    pub fn remote_file_id(&self, local_path: &Path) -> Result<Option<RemoteId>, EngineError> {
        Ok(self.file_row(local_path)?.and_then(|(_, row)| row.remote_file_id))
    }

    /// 这棵本地子树里有没有「索引里还没有」的文件 —— 即还没上云的内容。
    ///
    /// 口径与上行那条路一致:忽略规则先过一遍(不然 `.DS_Store` 这种会把一个本来干净的目录判成
    /// 「没同步完」)，剩下的按 cloud 相对路径去索引里对。空目录、只剩被忽略文件的目录都算干净。
    fn has_unsynced_local_file(&self, root: &RootRow, root_dir: &Path, subtree: &Path) -> Result<bool, EngineError> {
        if !subtree.is_dir() {
            return Ok(false);
        }
        let rows = self.index.file_map(&root.project_id).map_err(EngineError::Index)?;
        let rules =
            IgnoreRules::load(root_dir).map_err(EngineError::Io)?.with_max_file_size(self.config.max_upload_bytes);
        for entry in walkdir::WalkDir::new(subtree).into_iter().filter_map(Result::ok) {
            if !entry.file_type().is_file() {
                continue;
            }
            let Ok(relative) = entry.path().strip_prefix(root_dir) else { continue };
            if is_cloud_only_placeholder(relative) || rules.is_ignored(relative, false) {
                continue;
            }
            if !rows.contains_key(&local_to_cloud_relative(relative, self.config.windows_names)) {
                return Ok(true);
            }
        }
        Ok(false)
    }

    /// 这条本地路径落在哪个项目下(不在任何根下 → None)。
    ///
    /// 只看根前缀,不查索引 —— 目录压根不进文件索引,而跨项目移动完要唤醒**源项目**去收本地那一份,
    /// 文件和目录两条路得用同一个口径回答「它原来属于谁」。
    pub fn project_of(&self, local_path: &Path) -> Result<Option<RemoteId>, EngineError> {
        for root in self.index.list_roots().map_err(EngineError::Index)? {
            let dir = self.root_local_dir(&root);
            if local_path.strip_prefix(&dir).is_ok() {
                return Ok(Some(root.project_id));
            }
        }
        Ok(None)
    }

    /// 右键那一行在服务端是哪个资源(权限面板用,契约 §6.18)。
    ///
    /// 文件走索引。目录索引里只记路径不记 id,所以拿 `POST /folders/ensure` 去换 —— 对已经同步过的
    /// 目录它就是查询;还没上云的目录会顺手建出来,而同步引擎下一轮本来也要发那条 MKDIR。
    /// 项目根本身回 None:根不是一条相对路径,`ensure_folder("")` 的语义契约没定,不去赌。
    /// `.yupcloud` 占位由调用方先剥成真实路径再传进来(与评论同一个道理:针对的是云端那份)。
    pub async fn grant_target(&self, local_path: &Path) -> Result<Option<GrantTarget>, EngineError> {
        if !local_path.is_dir() {
            return Ok(self.remote_file_id(local_path)?.map(|id| GrantTarget { kind: GrantResourceKind::File, id }));
        }
        for root in self.index.list_roots().map_err(EngineError::Index)? {
            let dir = self.root_local_dir(&root);
            let Ok(relative) = local_path.strip_prefix(&dir) else { continue };
            let cloud_path = local_to_cloud_relative(relative, self.config.windows_names);
            if cloud_path.is_empty() {
                return Ok(None);
            }
            let id = self.guard_revoked(self.client.ensure_folder(&root.project_id, &cloud_path).await).await?;
            return Ok(Some(GrantTarget { kind: GrantResourceKind::Folder, id }));
        }
        Ok(None)
    }

    /// 「立即保存版本」:把本地文件当前内容(含 frontmatter)经 `POST /files/{id}/save-content` 存成一个版本,
    /// 索引随即记为 synced(协同中的文件同步引擎本来不上行,frontmatter 改动靠这条路上云)。
    /// 文件不在索引里 / 没有远端 id 返回 None。
    pub async fn save_content(&self, local_path: &Path) -> Result<Option<RemoteId>, EngineError> {
        let Some((root, row)) = self.file_row(local_path)? else { return Ok(None) };
        let (Some(file_id), Some(base_version)) = (row.remote_file_id.clone(), row.remote_version_id.clone()) else {
            return Ok(None);
        };
        let content = std::fs::read_to_string(local_path)
            .map_err(|error| io_error(format!("读 {}", local_path.display()), error))?;
        let saved = self.guard_revoked(self.client.save_content(&file_id, &content, &base_version).await).await?;
        let version_id = saved.new_version_id.unwrap_or(base_version);
        self.record_synced(
            &root,
            &row.path,
            local_path,
            Some(file_id),
            Some(version_id.clone()),
            row.collab_active,
            row.read_only,
            None,
        )?;
        Ok(Some(version_id))
    }

    /// 跨项目移动一份文件 —— 「移动到…」选中了一个**还没同步到本地**的项目时走这条路。
    ///
    /// 本地 FS move 只在源和目标都落了盘时才做得到,而对话框现在把「有写权限但没同步」的项目
    /// 也列出来了(从前只列已同步的,于是左栏里看得见的库在移动对话框里选不到)。那些目录在磁盘上
    /// 压根不存在,rename 无从谈起,只能让服务端改元数据 —— 内容按 sha256 存在 OSS 里,一个字节都不用传。
    ///
    /// **移完不碰本地。** 服务端会在旧项目发 FILE_DELETED、新项目发 FILE_CREATED,
    /// `apply_remote_delete` 下一轮自然会把本地这一份和索引行一起收掉。自己抢着删本地文件是个陷阱:
    /// watcher 会把它当成一次本地删除,拿着同一个 fileId 去删服务端上刚搬过去的那份 —— 移动变成删除。
    /// 调用方负责在成功后唤醒引擎,让这一轮马上发生,而不是等下次轮询。
    ///
    /// 返回 None 的两种情况都是「服务端还不知道有这份东西」:不在任何根下,或者在索引里但还没上过云
    /// (也包括目录 —— 目录不进文件索引)。调用方据此说人话,不要当成失败弹红。
    /// `target_folder_id = None` = 目标项目的**根**。给了就是移进那个目录 —— 选择器现在也列
    /// 云端有、本地还没落盘的目录(见 `cloud_folders`),落到那儿的移动只能走这条路。
    pub async fn move_file_to_project(
        &self, local_path: &Path, target_project_id: &RemoteId, target_folder_id: Option<&RemoteId>,
    ) -> Result<Option<RemoteId>, EngineError> {
        let Some((root, row)) = self.file_row(local_path)? else { return Ok(None) };
        let Some(file_id) = row.remote_file_id.clone() else { return Ok(None) };
        // 已经在目标项目**的根**上了:当成功报,别让调用方为一次空操作弹错。
        // 指定了目标目录时不能这么短路 —— 同项目内换目录是真的要搬。
        if root.project_id == *target_project_id && target_folder_id.is_none() {
            return Ok(Some(file_id));
        }
        self.guard_revoked(self.client.move_file(&file_id, target_project_id, target_folder_id).await).await?;
        Ok(Some(file_id))
    }

    /// 一个项目在**云端**的目录清单(拍平成相对路径 + folderId)。
    ///
    /// 「移动到…」用它补上磁盘上没有的那些目录。拿不到就让调用方回落到本地 FS —— 离线时
    /// 选择器还能用,只是列不出没下载的目录。
    pub async fn cloud_folders(&self, project_id: &RemoteId) -> Result<Vec<CloudFolder>, EngineError> {
        Ok(self.guard_revoked(self.client.folder_tree(project_id).await).await?)
    }

    /// 跨项目移动一个<b>目录</b>(连同整棵子树)。文件那条见 [`Self::move_file_to_project`]。
    ///
    /// 目录**不进文件索引**,所以拿不到现成的 id。走 `POST /folders/ensure` 换 —— 对已经同步过的
    /// 目录它就是查询,还没上云的目录会顺手建出来(与 `grant_target` 同一个办法,不另造一套)。
    ///
    /// 只调<b>一次</b>服务端:子树的目录和文件由服务端在一个事务里改完。换成这边遍历子树一份份调
    /// 文件接口,中途失败就会留下「目录在新项目、一半文件还在旧项目」的残局,而目录这一层没有任何
    /// 东西能把它对回去。
    ///
    /// 和文件那条一样**移完不碰本地**:服务端在旧项目发 FOLDER_DELETED / FILE_DELETED,引擎下一轮
    /// 自然收拾。自己删本地目录会被 watcher 当成一次本地删除,拿着同一批 id 去删服务端上刚搬过去的那份。
    ///
    /// 返回 None:不在任何根下,或者指的就是项目根本身(根不是一条相对路径,`ensure_folder("")`
    /// 的语义契约没定,不去赌 —— 与 `grant_target` 同一个判断)。
    /// `target_parent_id = None` = 目标项目的根。同 [`Self::move_file_to_project`]。
    pub async fn move_folder_to_project(
        &self, local_path: &Path, target_project_id: &RemoteId, target_parent_id: Option<&RemoteId>,
    ) -> Result<Option<RemoteId>, EngineError> {
        for root in self.index.list_roots().map_err(EngineError::Index)? {
            let dir = self.root_local_dir(&root);
            let Ok(relative) = local_path.strip_prefix(&dir) else { continue };
            let cloud_path = local_to_cloud_relative(relative, self.config.windows_names);
            if cloud_path.is_empty() {
                return Ok(None);
            }
            // 本地还有没上云的文件就别搬。`ensure_folder` 是「查不到就建」——对一个还没同步上去的
            // 目录，它会在**源项目**凭空建一个空目录，然后我们把这个空壳搬到目标项目：用户在那边
            // 看到一个空文件夹，东西全留在原地(引擎随后把它们传进**源**项目)。不是丢数据
            // (FolderDeleted 只删索引里有的行、只删空目录)，但这个结果没法跟用户解释。
            // 宁可回 None 让前端说「还没上传到云端，等它同步完再移」。
            if self.has_unsynced_local_file(&root, &dir, local_path)? {
                return Ok(None);
            }
            let folder_id = self.guard_revoked(self.client.ensure_folder(&root.project_id, &cloud_path).await).await?;
            // 已经在目标项目**的根**上了:当成功报(与文件那条同口径)
            if root.project_id == *target_project_id && target_parent_id.is_none() {
                return Ok(Some(folder_id));
            }
            self.guard_revoked(self.client.move_folder(&folder_id, target_project_id, target_parent_id).await).await?;
            return Ok(Some(folder_id));
        }
        Ok(None)
    }

    // ─── 主循环 ───────────────────────────────────────────────────────────

    /// 由 watcher 批次、推送唤醒与定时轮询驱动;wake 通道关闭即退出。推送在线时轮询拉长。
    pub async fn run(
        self: std::sync::Arc<Self>, mut wake: mpsc::UnboundedReceiver<Vec<PathBuf>>, poll_interval: Duration,
    ) {
        loop {
            let interval =
                if self.is_push_connected() { poll_interval * PUSH_CONNECTED_POLL_MULTIPLIER } else { poll_interval };
            tokio::select! {
                batch = wake.recv() => match batch {
                    Some(_) => {}
                    None => return,
                },
                _ = tokio::time::sleep(interval) => {}
            }
            if self.is_revoked() {
                return;
            }
            if let Err(error) = self.sync_once().await {
                log::warn!("[drive-sync] 同步失败: {error}");
            }
        }
    }

    /// 吊销即清空;其它客户端错误原样透传。
    pub(crate) async fn guard_revoked<T>(&self, result: Result<T, ClientError>) -> Result<T, EngineError> {
        match result {
            Ok(value) => Ok(value),
            Err(ClientError::Revoked) => {
                self.purge_after_revoke()?;
                Err(EngineError::Revoked)
            }
            Err(ClientError::DeviceMismatch) => {
                self.set_state(EngineState::Error { message: crate::client::DEVICE_MISMATCH_CODE.to_string() });
                Err(EngineError::Client(ClientError::DeviceMismatch))
            }
            Err(error) => Err(EngineError::Client(error)),
        }
    }

    pub async fn sync_once(&self) -> Result<(), EngineError> {
        let _guard = self.sync_lock.lock().await;
        if self.is_paused() {
            return Ok(());
        }
        if self.is_revoked() {
            return Err(EngineError::Revoked);
        }
        self.set_state(EngineState::Scanning);
        // 全局错误不属于任何项目，必须在新一轮开始时单独清理；若问题仍在，本轮会重新记录。
        self.clear_global_errors();
        let roots = match self.refresh_roots_resilient().await {
            Ok(roots) => roots,
            Err(EngineError::Revoked) => return Err(EngineError::Revoked),
            Err(EngineError::Client(ClientError::DeviceMismatch)) => {
                self.push_error(None, None, ClientError::DeviceMismatch.to_string());
                return Err(EngineError::Client(ClientError::DeviceMismatch));
            }
            Err(error) => {
                log::warn!("[drive-sync] 拉取根清单失败(原文): {error}");
                self.push_error_quiet(None, None, format!("取不到云盘目录清单。{}", humanize(&error)));
                self.set_state(EngineState::Error { message: error.to_string() });
                return Err(error);
            }
        };
        self.set_state(EngineState::Syncing);
        let mut failed: Option<String> = None;
        // 启动后第一轮顺带做的「仅云端」核对(见 `reconcile_root_cloud_only`)的累计结果
        let mut recheck = CloudOnlyRecheck::default();
        // 同上,「镜像脱节」对账的累计:(扫过的 synced 行, 退回待下载的行)
        let mut landed = (0_u32, 0_u32);
        // 本轮要跑的根。用户点过的插到队首,并且每跑完一个就重新问一次队列 ——
        // 同步途中点的项目下一个就轮到,不必等前面几十个排完。
        let mut pending: Vec<RemoteId> =
            roots.iter().filter(|root| root.selected).map(|root| root.project_id.clone()).collect();
        // SKILL 根改成只落 skills 目录之后,`~/YUP Drive/` 下的历史副本得有人收走
        self.sweep_legacy_skill_dirs();
        // 曾经落在 `<skills_dir>/yup/` —— 那是别人 skill 的位置,搬走
        self.migrate_legacy_skill_mirror();
        for id in &pending {
            self.emit_project(id, ProjectPhase::Queued, 0, 0, 0, None);
        }
        while let Some(project_id) = self.next_in_queue(&mut pending) {
            let root = self.index.get_root(&project_id).map_err(EngineError::Index)?.expect("root just refreshed");
            // 没配 skills_dir 的 SKILL 根无处可放:跳过,别退回去在云盘目录里建它
            if !self.is_syncable(&root) {
                self.emit_project(&project_id, ProjectPhase::Done, 0, 0, 0, None);
                continue;
            }
            self.emit_project(&project_id, ProjectPhase::Syncing, 0, 0, 0, None);
            // 清理该项目上一轮的面板错误。本轮的新错误会在随后同步中重新写入。
            self.clear_errors_of(&project_id);
            let mut tally = PullTally::default();
            match self.sync_root(&root, &mut tally, &mut recheck, &mut landed).await {
                Ok(()) => {
                    log::info!(
                        "[drive-sync] {} 同步完成:成功 {} 个、失败 {} 个",
                        root.drive_path,
                        tally.done,
                        tally.failed
                    );
                    self.emit_project(&project_id, ProjectPhase::Done, tally.done, tally.total, tally.failed, None);
                }
                Err(EngineError::Revoked) => return Err(EngineError::Revoked),
                Err(EngineError::Client(ClientError::DeviceMismatch)) => {
                    self.push_error(Some(&root.project_id), None, ClientError::DeviceMismatch.to_string());
                    self.emit_project(
                        &project_id,
                        ProjectPhase::Failed,
                        tally.done,
                        tally.total,
                        tally.failed,
                        Some(ClientError::DeviceMismatch.to_string()),
                    );
                    return Err(EngineError::Client(ClientError::DeviceMismatch));
                }
                Err(error) => {
                    log::warn!("[drive-sync] {} 同步失败(原文): {error}", root.drive_path);
                    self.push_error_quiet(
                        Some(&root.project_id),
                        None,
                        format!("{} 没同步成功。{}", root.drive_path, humanize(&error)),
                    );
                    self.emit_project(
                        &project_id,
                        ProjectPhase::Failed,
                        tally.done,
                        tally.total,
                        tally.failed,
                        Some(error.to_string()),
                    );
                    failed = Some(error.to_string());
                }
            }
        }
        // 摊平 SKILL 镜像:CLI 只扫一层,不摊平的话各部门的 skill 一个都不生效(见 skills.rs)
        self.install_skill_mirrors();
        // 这一轮**确实核对过**至少一个根才落标记。空落一次的代价是永久的:引擎起来时可能还没
        // 拉到根清单、或者手上的根全是 cursor 为空的新根(那一轮走全量 snapshot,本来就不用核对),
        // 那时候把标记落下去,这个进程就再也不会核对了 —— 而漂移正躺在下一轮才出现的那些根上。
        if recheck.projects > 0 && !self.cloud_only_checked.swap(true, Ordering::SeqCst) {
            self.finish_recheck(recheck, "启动首轮");
        }
        // 「镜像脱节」对账跑完就落标记:每进程一次,别每轮全表扫。
        // 扫到过行才落 —— 与 cloudOnly 同一个道理:根清单还没拉到时空落一次,这个进程就再也不对账了。
        // 这条 INFO 必须留:下次再出脱节,得能从日志看出「扫了多少、补了几条」,而不是又去翻 sqlite
        if landed.0 > 0 && !self.landed_checked.swap(true, Ordering::SeqCst) {
            log::info!("[drive-sync] 镜像脱节对账(启动首轮):扫过 {} 条 synced 行,退回待下载 {} 条", landed.0, landed.1);
        }
        let synced = self.index.count_state(FileState::Synced).map_err(EngineError::Index)?;
        let failed_files = self.index.count_file_errors().map_err(EngineError::Index)?;
        self.update_status(|status| {
            status.synced = synced;
            status.failed = failed_files;
            status.pending = 0;
            status.uploading = 0;
            status.last_sync_at = Some(now_iso());
            status.state = match failed {
                Some(message) => EngineState::Error { message },
                None => EngineState::Idle,
            };
        });
        Ok(())
    }

    async fn sync_root(
        &self, root: &RootRow, tally: &mut PullTally, recheck: &mut CloudOnlyRecheck, landed: &mut (u32, u32),
    ) -> Result<(), EngineError> {
        let dir = self.root_local_dir(root);
        std::fs::create_dir_all(&dir).map_err(|error| io_error(format!("创建 {}", dir.display()), error))?;

        // 「镜像脱节」对账:每个根在本进程里只做一次。**排在下行之前、且不看下行成不成** ——
        // 这些行的特征正是「云端再没动过它们」,等下行去碰是等不到的;而下行失败(非致命)时
        // 本轮照样会走到末尾的 `fetch_pending_downloads`,对账标好的行在同一轮就能补回来。
        if !self.landed_checked.load(Ordering::SeqCst) {
            let (scanned, restored) = self.reconcile_root_landed(root)?;
            landed.0 += scanned;
            landed.1 += restored;
        }
        // cursor 为空的根这一轮本来就走全量 snapshot,分类是现拉的,不必再核对一遍
        let incremental = root.cursor.is_some();

        // ── 上行不能被下行饿死(2026-09-07 实报)────────────────────────────────
        //
        // 从前这里是 `self.pull_root(...).await?` —— 那个 `?` 意味着**下行一出错,这一轮上行
        // 根本不跑**;即使不出错,上行也排在整个下行之后。于是线上那批下不完的大文件(还没上
        // Range,每趟从 0 重下、又在几十兆处被网关掐断)把每一轮占满,用户在本地改的一个字
        // 十几分钟传不上去 —— 而界面上一片安静。
        //
        // 现在:下行的错**就地记下**(每个文件进 file_errors,整体故障才往上抛),上行照跑。
        // 判据是「任何一个文件的下载失败,都不能阻止其他文件的上传」。
        //
        // 顺序仍是先下后上:先把远端已有的改动落到本地,上行再据此规划,冲突判定不变
        //(反过来会让「远端已删、本地还在」的文件被当成新文件重新传上去)。真正让这个顺序
        // 变得无害的是另外两件事:大文件不自动下(队列里根本没有那批文件)、下行失败按退避
        // 不再每轮全速重试 —— 下行不再可能占满一轮。
        let pull_result = self.pull_root(root, tally).await;
        if let Err(error) = pull_result {
            // 整体性故障(吊销 / 设备不匹配)照旧中止整个根:那不是某个文件的事,上行也做不成
            if is_fatal_engine_error(&error) {
                return Err(error);
            }
            log::warn!("[drive-sync] {} 下行失败(原文): {error}", root.drive_path);
            self.push_error_quiet(
                Some(&root.project_id),
                None,
                format!("{} 没能从云端取下来（你改的东西照常往上传）。{}", root.drive_path, humanize(&error)),
            );
        } else {
            // 这两件事都建立在「这一轮下行是完整的」之上:半截的下行去核对 cloudOnly 分类,
            // 会把还没拉到的文件误判成漂移
            self.upgrade_legacy_placeholders(root);
            if incremental && !self.cloud_only_checked.load(Ordering::SeqCst) {
                recheck.merge(self.reconcile_root_cloud_only(root).await?);
            }
        }
        // 整个根只读:没有写权限 / 仅云端 / SKILL(给机器读的镜像,人改了也不该上行)
        let read_only = !root.can_write || root.cloud_only || root.kind == ProjectKind::Skill;
        if !read_only {
            self.push_root(root).await?;
        }
        // 补下「云端有、本地还没有」的那些(阈值放宽后够得着的 + 上一轮没下下来的)。
        // **排在上行之后**:它们重要,但没有「用户刚改的字要传上去」重要 —— 绝不能再把上行
        // 挤到后面去,那正是这次故障的形状。
        self.fetch_pending_downloads(root).await?;
        Ok(())
    }

    // ─── 下行 ─────────────────────────────────────────────────────────────

    async fn pull_root(&self, root: &RootRow, tally: &mut PullTally) -> Result<(), EngineError> {
        let root = self.index.get_root(&root.project_id).map_err(EngineError::Index)?.expect("root exists");
        match root.cursor.clone() {
            None => {
                let snapshot = self.guard_revoked(self.client.snapshot(&root.project_id).await).await?;
                for folder in &snapshot.folders {
                    let local = self.local_path_for(&root, &folder.path);
                    std::fs::create_dir_all(&local)
                        .map_err(|error| io_error(format!("创建 {}", local.display()), error))?;
                    // **在本地建出来了就登记。** folders 登记簿从前只记「本客户端 MKDIR 成功」
                    // 的那批,而 RMDIR 只从登记簿里挑候选 —— 云端来的目录(网页建的、AI 跑出来的
                    // 报告目录)于是永远删不掉:里面的文件删干净了,那个空壳还留在网页上
                    // (2026-09-22 实报)。登记的含义是「这个目录我们在本地建出来过」,
                    // 正是 RMDIR 需要的前提;没建出来过的(没选中的根、没下载的分支)不在表里,
                    // 照样一个字都不会碰。
                    self.index.put_folder(&root.project_id, &folder.path).map_err(EngineError::Index)?;
                }
                tally.total += snapshot.files.len() as u32;
                self.emit_project(&root.project_id, ProjectPhase::Syncing, tally.done, tally.total, tally.failed, None);
                self.pull_snapshot_files(&root, &snapshot.files, tally).await?;
                self.index.set_cursor(&root.project_id, &snapshot.cursor).map_err(EngineError::Index)?;
            }
            Some(mut cursor) => {
                // 一条事件落地失败、cursor 却照样往前推,那条变更就**永久丢了** —— 变更流是
                // 一次性的,没人会再发一遍(2026-09-15 实撞:一个人 54 条失败,「昨天的文件都没
                // 同步」不是卡住,是丢了)。所以凡是伤到索引一致性的失败,记下来,这一轮走完把
                // cursor 清空,下一轮改走 snapshot 全量对账 —— 它按 sha256 逐个比对、一致就跳过,
                // 是幂等的,不会重下一遍。
                //
                // 认 Io:本地文件没动成,索引与远端就此对不上,而这条**不会**中断这一轮
                //(不是 fatal),cursor 照推 —— 丢事件就是从这里丢的。
                // Index 列在这里是防御性的:它当前是 fatal,`fail_one_file` 会直接往上抛,
                // 这一页的 set_cursor 根本执行不到(所以 UNIQUE 那种卡死是**原地重放**,
                // 不是丢事件);哪天它不再 fatal 了,这里也接得住。
                // Client 类(网络、404)不伤索引一致性,内容没拿到而已,file_errors 那套退避管得了。
                // Busy(文件正被写)更不算:它每一轮都可能发生,当成漂移就成了每轮一次全量对账。
                let mut drifted = false;
                loop {
                    let page = self
                        .guard_revoked(self.client.changes(&root.project_id, &cursor, CHANGES_PAGE_SIZE).await)
                        .await?;
                    tally.total += page.events.len() as u32;
                    for event in page.events {
                        let path = event.path.clone();
                        match self.apply_event(&root, event).await {
                            Ok(()) => tally.done += 1,
                            Err(error) => {
                                drifted |= is_drift(&error);
                                self.fail_one_file(&root, &path, error)?;
                                tally.failed += 1;
                            }
                        }
                        self.tick_progress(&root.project_id, tally);
                    }
                    cursor = page.next_cursor;
                    self.index.set_cursor(&root.project_id, &cursor).map_err(EngineError::Index)?;
                    if !page.has_more {
                        if drifted {
                            log::warn!("[drive-sync] {} 这一轮有事件没落地,清 cursor,下一轮全量对账", root.drive_path);
                            self.index.clear_cursor(&root.project_id).map_err(EngineError::Index)?;
                        }
                        break;
                    }
                }
            }
        }
        Ok(())
    }

    /// 首轮 snapshot 的下行:**有界并发**取字节,单一消费者按完成顺序结账。
    ///
    /// 为什么这么切:一个文件的时间几乎全花在等服务端上,串行跑 1903 个文件要好几分钟
    /// (2026-09-04 真机实报,进度条卡在 1750/1903)。并发只放在 `apply_remote_file` 这一段 ——
    /// 它内部的索引写走 `Index` 的连接锁、写盘各写各的路径、冲突副本判定只看自己这一个文件,
    /// 并发下都成立。而 `tally` 与进度事件留在这个 `while` 里做,是**单线程**的:
    /// 进度只会按完成一个加一个,不会回退,也不会两个任务同时 +1 撞掉一个。
    ///
    /// 单个文件失败仍然不拖垮整个项目(`fail_one_file`);吊销、设备不匹配这类整体故障照旧往上抛,
    /// 此时提前 `return` 会把还在飞的下载一起 drop 掉 —— 正是想要的。
    async fn pull_snapshot_files(
        &self, root: &RootRow, files: &[crate::types::SnapshotFile], tally: &mut PullTally,
    ) -> Result<(), EngineError> {
        let concurrency = self.transfer_concurrency();
        self.update_status(|status| status.downloading = files.len() as u32);
        // 每个任务只拿**自有**数据(不从 `files` 借路径):借用会让这些 future 的 Send 推不出来,
        // spawn 到 tauri 的 runtime 上就编不过(rustc 的高阶生命周期限制)
        let tasks: Vec<_> = files
            .iter()
            .map(|file| {
                let remote = remote_file_from_snapshot(file);
                let path = file.path.clone();
                async move { (path, self.apply_remote_file(root, remote).await) }
            })
            .collect();
        let mut in_flight = futures_util::stream::iter(tasks).buffer_unordered(concurrency);

        let mut remaining = files.len() as u32;
        while let Some((path, result)) = in_flight.next().await {
            match result {
                Ok(()) => tally.done += 1,
                Err(error) => {
                    // 整体性故障在这里往上抛:提前退出会 drop 掉 in_flight,还在飞的下载一并取消
                    self.fail_one_file(root, &path, error)?;
                    tally.failed += 1;
                }
            }
            remaining = remaining.saturating_sub(1);
            // 状态快照与项目进度都按同一个节流走:1903 个文件不该刷出 1903 条事件
            if (tally.done + tally.failed).is_multiple_of(PROGRESS_EVERY) {
                self.update_status(|status| status.downloading = remaining);
            }
            self.tick_progress(&root.project_id, tally);
        }
        self.update_status(|status| status.downloading = 0);
        Ok(())
    }

    // ─── 「仅云端」核对 ───────────────────────────────────────────────────

    /// 拿 snapshot 把一个根的 `cloudOnly` **分类**重新比一遍,只处理漂移的那些文件。
    ///
    /// 为什么非要有这个动作:`cloudOnly` 是分类,不是内容。服务端 2026-09-05 把一批
    /// 「需走修改申请」的文件从 cloudOnly 改判成正常 —— 这些文件本身一个字节都没变,
    /// 于是不会产生任何 `file_events`。走 cursor 增量的客户端**永远**收不到通知:已经同步过的
    /// 机器会一直守着 111 个 `.yupcloud` 占位,只有全新装机才正常。反向(权限被收回 → 变成
    /// cloudOnly)同理,而且那一侧是安全要求 —— 本地那份内容必须从盘上消失。
    ///
    /// 一个项目**一次请求**(`/sync/snapshot`)搞定,不逐个文件去问:111 个占位就是 111 次
    /// 往返,而 snapshot 本来就是首轮下行走的那条路。
    /// 启动后跑一次的「镜像脱节」对账 —— `reconcile_root_cloud_only` 的兄弟,但**纯本地**
    /// (只看索引 + 盘),不请求服务端。
    ///
    /// 为什么非得有它:那两处「从没落盘」的修补都挂在**走不到的路**上 ——
    /// `apply_remote_file`(下行)只在这个文件**这一轮有新变更**时才被调用,增量同步只处理
    /// cursor 之后变过的文件;`push_root_once`(上行)只在能写的根上跑。一条「索引 synced、
    /// 盘上从没落盘」的行,如果此后云端再没动过它,两条路一条都轮不到它。
    /// 2026-09-11 实机:重启之后现场纹丝不动,project 355 整个进程 0 条日志。所以要有一次
    /// **主动**的全表对账去找它们。
    ///
    /// 判据沿用那条**窄的** `never_landed`(文件不在 **且** 所在目录整个不存在),一个字不放宽:
    /// 放宽会把「删掉目录里最后一个文件」「把文件移出目录」误判成脱节(踩过三条用例)。
    ///
    /// 命中的行退回 `NotDownloaded`,同一轮末尾的 `fetch_pending_downloads` 就会把它们拉回来
    /// —— 那一步对**所有**根都跑,不看写权限,所以 `can_write=0` 的根(355 正是)一样能自愈。
    ///
    /// 返回 (扫过的 synced 行数, 退回待下载的行数)。
    fn reconcile_root_landed(&self, root: &RootRow) -> Result<(u32, u32), EngineError> {
        let mut scanned = 0;
        let mut restored = 0;
        for row in self.index.list_files(&root.project_id).map_err(EngineError::Index)? {
            if row.state != FileState::Synced {
                continue;
            }
            scanned += 1;
            if !self.looks_never_landed(root, &row.path) {
                continue;
            }
            self.index.set_state(&root.project_id, &row.path, FileState::NotDownloaded).map_err(EngineError::Index)?;
            restored += 1;
            log::warn!("[drive-sync] {}/{} 索引标着 synced 却从没落盘,退回待下载", root.drive_path, row.path);
        }
        Ok((scanned, restored))
    }

    async fn reconcile_root_cloud_only(&self, root: &RootRow) -> Result<CloudOnlyRecheck, EngineError> {
        // SKILL 镜像按设计不写 `.yupcloud`(它是给机器读的,塞占位只会让 CLI 扫到一堆不是 skill
        // 的东西),所以它不参加「补占位」那个方向 —— 但**必须**参加「恢复」方向:
        // 真机实据(2026-09-05)索引里 38 条 cloudOnly 全在「公司 Skill 库」,把整个 SKILL 根排除
        // 掉就等于服务端改判之后没有任何一条路会去拉真实内容,那些 skill 文件永远不在本地。
        let writes_placeholders = root.kind != ProjectKind::Skill;
        let snapshot = self.guard_revoked(self.client.snapshot(&root.project_id).await).await?;
        let rows = self.index.file_map(&root.project_id).map_err(EngineError::Index)?;
        let mut tally = CloudOnlyRecheck { projects: 1, ..CloudOnlyRecheck::default() };
        for file in &snapshot.files {
            let placeholder_on_disk = writes_placeholders && self.placeholder_path_for(root, &file.path).is_file();
            let action = match rows.get(&file.path) {
                // 分类翻了
                Some(row) if (row.state == FileState::CloudOnly) != file.cloud_only => {
                    Some(if file.cloud_only { CloudOnlyFix::Hide } else { CloudOnlyFix::Restore })
                }
                // 分类没变,但这份 cloudOnly 文件在盘上**彻底没影**了:正文本来就不该有,占位也没了。
                // 于是它所在的目录成了空目录 —— 用户看到的是「这个文件夹里什么都没有」,而不是
                // 「这些文件只能在云端看」。cloudOnly 的正确终态是**只有占位、没有正文**,
                // 缺了占位就得补回来(2026-09-05 真机:占位全没了、索引还剩 38 条、149 个空目录)
                Some(row) if writes_placeholders && row.state == FileState::CloudOnly && !placeholder_on_disk => {
                    Some(CloudOnlyFix::Repair)
                }
                Some(_) => None,
                // 索引里没有这一行:只有盘上确实躺着一个占位才算漂移(占位还在、索引丢了)。
                // 其余的「索引缺行」是漏事件那类问题,不归这个动作管 —— 一个动作只修一件事
                None => (!file.cloud_only && placeholder_on_disk).then_some(CloudOnlyFix::Restore),
            };
            // ── 顺路把「云端有、这边什么都没有」的那些捞回来(2026-09-07)──────────────
            //
            // 这不是分类漂移,是**下行漏了**:一次下载失败之后 cursor 已经往前走,那条 change
            // 事件不会再来第二次,而索引里连一行都没有 —— 这份文件就此人间蒸发,服务端日后
            // 把 Range 部署上也不会自愈。老板机器上那批下不完的大文件正卡在这个形状里
            //(升级前的版本失败时什么痕迹都不留)。
            //
            // 这里是**唯一**一处每次开机都会把服务端清单整份看一遍的地方,顺手补一条登记:
            // 记成 NotDownloaded(带上 fileId / sha / size),之后 `fetch_pending_downloads`
            // 按阈值与退避决定是自动拉回来、还是留个占位等用户点。不在这里下载 —— 那会让
            // 开机第一轮又背上一堆大文件,正是要根治的病。
            if action.is_none()
                && !file.cloud_only
                && rows.get(&file.path).is_none()
                && !placeholder_on_disk
                && !self.local_path_for(root, &file.path).is_file()
            {
                self.mark_not_downloaded(root, &remote_file_from_snapshot(file))?;
                tally.relisted += 1;
                continue;
            }
            let Some(action) = action else { continue };
            let path = file.path.clone();
            // 三种修法都是「让本地跟上服务端此刻的说法」,同一条路径:
            // cloudOnly=true 写占位并收走正文,cloudOnly=false 拉正文并删占位
            match self.apply_remote_file(root, remote_file_from_snapshot(file)).await {
                Ok(()) => match action {
                    CloudOnlyFix::Restore => tally.restored += 1,
                    CloudOnlyFix::Hide => tally.hidden += 1,
                    CloudOnlyFix::Repair => tally.repaired += 1,
                },
                // 单个文件失败不拖垮核对;吊销 / 设备不匹配这类整体故障照旧往上抛
                Err(error) => self.fail_one_file(root, &path, error)?,
            }
        }
        if !tally.is_empty() {
            log::info!(
                "[drive-sync] {} 仅云端核对:恢复 {} 个、转为仅云端 {} 个、补回占位 {} 个、重新登记 {} 个",
                root.drive_path,
                tally.restored,
                tally.hidden,
                tally.repaired,
                tally.relisted
            );
        }
        Ok(tally)
    }

    /// 设置页「重新核对仅云端文件」:对**所有**选中的根重新比一遍分类。
    ///
    /// 与启动首轮那次的区别只有范围:首轮跳过「这一轮本来就走全量 snapshot」的根(那些根的
    /// 分类是现拉的),手动这次一个不落 —— 用户点它就是因为怀疑手上的东西不对。
    /// 拿 `sync_lock` 是为了不和正在跑的同步抢同一批索引行。
    pub async fn recheck_cloud_only(&self) -> Result<CloudOnlyRecheck, EngineError> {
        let _guard = self.sync_lock.lock().await;
        if self.is_revoked() {
            return Err(EngineError::Revoked);
        }
        let rows = self.index.list_roots().map_err(EngineError::Index)?;
        let selection = self.selection(&rows)?;
        let mut total = CloudOnlyRecheck::default();
        for root in rows.iter().filter(|row| is_selected(row, &selection) && self.is_syncable(row)) {
            total.merge(self.reconcile_root_cloud_only(root).await?);
        }
        // 手动点过就算「这个进程已经核对过了」,免得紧接着的一轮同步再全量比一遍
        self.cloud_only_checked.store(true, Ordering::SeqCst);
        self.finish_recheck(total, "手动");
        Ok(total)
    }

    /// 核对收尾:日志一条;真改了东西才发事件 —— 什么都没漂移时弹一句「已恢复 0 个」是噪音。
    fn finish_recheck(&self, tally: CloudOnlyRecheck, how: &str) {
        log::info!(
            "[drive-sync] 仅云端核对({how}):比对 {} 个项目,恢复 {} 个、转为仅云端 {} 个、补回占位 {} 个",
            tally.projects,
            tally.restored,
            tally.hidden,
            tally.repaired
        );
        if !tally.is_empty() {
            self.emit(EngineEvent::CloudOnly(tally));
        }
    }

    /// 同时在飞的传输数。配 0(或忘了配)按默认值。
    fn transfer_concurrency(&self) -> usize {
        match self.config.transfer_concurrency {
            0 => DEFAULT_TRANSFER_CONCURRENCY,
            value => value,
        }
    }

    /// 进度事件节流:每 PROGRESS_EVERY 个文件推一条,别让 500 个文件的首轮 snapshot 刷出 500 条事件。
    fn tick_progress(&self, project_id: &RemoteId, tally: &PullTally) {
        if (tally.done + tally.failed) % PROGRESS_EVERY == 0 {
            self.emit_project(project_id, ProjectPhase::Syncing, tally.done, tally.total, tally.failed, None);
        }
    }

    /// 下行时单个文件出错:整体性故障(吊销 / 设备不匹配 / 索引坏了)往上抛,其余只记一条错误接着走。
    /// 单个文件的下行失败:整体性故障往上抛,其余留一条**持久**记录(方向 download)。
    ///
    /// 从前这里只 `push_error` 进内存 ring —— 重启即空,于是「下载卡死」在界面上一片安静。
    fn fail_one_file(&self, root: &RootRow, path: &str, error: EngineError) -> Result<(), EngineError> {
        if is_fatal_engine_error(&error) {
            return Err(error);
        }
        self.mark_download_failed(root, path, &error)
    }

    async fn apply_event(&self, root: &RootRow, event: ChangeEvent) -> Result<(), EngineError> {
        match event.event_type {
            EventType::FileCreated | EventType::FileUpdated => {
                let remote = remote_file_from_event(&event)?;
                self.apply_remote_file(root, remote).await
            }
            EventType::FileRenamed | EventType::FileMoved => {
                let old_path =
                    event.old_path.clone().ok_or_else(|| EngineError::Io(format!("事件 {} 缺 oldPath", event.seq)))?;
                let old_local = self.local_path_for(root, &old_path);
                let new_local = self.local_path_for(root, &event.path);
                if old_local.exists() {
                    if let Some(parent) = new_local.parent() {
                        std::fs::create_dir_all(parent)
                            .map_err(|error| io_error(format!("创建 {}", parent.display()), error))?;
                    }
                    std::fs::rename(&old_local, &new_local).map_err(|error| {
                        io_error(format!("重命名 {} → {}", old_local.display(), new_local.display()), error)
                    })?;
                }
                let old_placeholder = self.placeholder_path_for(root, &old_path);
                if old_placeholder.exists() {
                    std::fs::remove_file(&old_placeholder)
                        .map_err(|error| io_error(format!("删除 {}", old_placeholder.display()), error))?;
                }
                self.index.move_path(&root.project_id, &old_path, &event.path).map_err(EngineError::Index)?;
                let remote = remote_file_from_event(&event)?;
                self.apply_remote_file(root, remote).await
            }
            EventType::FileDeleted => self.apply_remote_delete(root, &event.path),
            EventType::FolderCreated => {
                let local = self.local_path_for(root, &event.path);
                std::fs::create_dir_all(&local)
                    .map_err(|error| io_error(format!("创建 {}", local.display()), error))?;
                // 同快照分支:在本地建出来了就登记,否则这个目录以后删不掉
                self.index.put_folder(&root.project_id, &event.path).map_err(EngineError::Index)
            }
            EventType::FolderRenamed | EventType::FolderMoved => {
                let old_path =
                    event.old_path.clone().ok_or_else(|| EngineError::Io(format!("事件 {} 缺 oldPath", event.seq)))?;
                let old_local = self.local_path_for(root, &old_path);
                let new_local = self.local_path_for(root, &event.path);
                if old_local.is_dir() {
                    if let Some(parent) = new_local.parent() {
                        std::fs::create_dir_all(parent)
                            .map_err(|error| io_error(format!("创建 {}", parent.display()), error))?;
                    }
                    std::fs::rename(&old_local, &new_local).map_err(|error| {
                        io_error(format!("移动目录 {} → {}", old_local.display(), new_local.display()), error)
                    })?;
                }
                self.index.move_path(&root.project_id, &old_path, &event.path).map_err(EngineError::Index)
            }
            EventType::FolderDeleted => {
                let prefix = format!("{}/", event.path);
                for row in self.index.list_files(&root.project_id).map_err(EngineError::Index)? {
                    if row.path.starts_with(&prefix) {
                        self.apply_remote_delete(root, &row.path)?;
                    }
                }
                let local = self.local_path_for(root, &event.path);
                remove_empty_dirs(&local);
                Ok(())
            }
        }
    }

    /// 远端有这个版本 → 让本地跟上。本地有未上传的改动就先另存冲突副本。
    async fn apply_remote_file(&self, root: &RootRow, remote: RemoteFile) -> Result<(), EngineError> {
        let local = self.local_path_for(root, &remote.path);
        let existing = self.index.get_file(&root.project_id, &remote.path).map_err(EngineError::Index)?;
        // 上一轮没下下来的,按退避等到点再试(2026-09-07:同一个 blob 十分钟被试了 12 次,
        // 把整个引擎的时间占满,上行因此永远排不上)。退避表与上行共用一套,「立刻重试」照样能打断。
        //
        // **远端换了新版本就当场再试** —— 那是新的内容,不是同一次失败的重复。比不出来
        //(本地压根没有这份文件的索引行)时按退避等:宁可晚一点,也不要回到每轮空转。
        if let Some(failure) = self.index.file_error(&root.project_id, &remote.path).map_err(EngineError::Index)?
            && failure.direction == SyncDirection::Download
            && !retry_due(Some(&failure), now_ms())
        {
            let newer_version = existing
                .as_ref()
                .is_some_and(|row| row.sha256 != remote.sha256 || row.remote_version_id != remote.version_id);
            if !newer_version {
                log::debug!("[drive-sync] {} 在下行退避窗口里(已试 {} 次),这一轮跳过", remote.path, failure.attempts);
                return Ok(());
            }
        }
        if remote.cloud_only {
            let placeholder = self.placeholder_path_for(root, &remote.path);
            // 占位是给**人和 AI**看的:「这不是内容,真内容在云端,这样去拿」。SKILL 镜像是纯给
            // 机器读的,往里塞一堆占位只是噪音
            if root.kind != ProjectKind::Skill {
                write_file(&placeholder, self.cloud_only_placeholder(root, &remote).as_bytes())?;
            }
            // 服务端改口说这份文件只能在云端看(权限被收回、转成会话原文……):本地那份真实内容
            // **必须从盘上消失**。「云端已经不给你看了、本地那份还躺着」是最糟的一种同步结果 ——
            // 这是安全要求,不是整洁问题,所以哪怕本地有未上行的改动也照删,只是要留一条错误记录,
            // 别让改动无声无息地没了。
            if local.is_file() {
                let unsaved = match &existing {
                    Some(row) => !local_matches_row(&local, row).unwrap_or(false),
                    None => true,
                };
                std::fs::remove_file(&local).map_err(|error| io_error(format!("删除 {}", local.display()), error))?;
                log::info!("[drive-sync] {} 已被服务端改为仅云端可见,本地内容已删除", remote.path);
                if unsaved {
                    self.push_error(
                        Some(&root.project_id),
                        Some(&remote.path),
                        format!("{} 已被服务端改为「仅云端可见」,本地那份(含还没上传的改动)已按要求删除", remote.path),
                    );
                }
            }
            self.index
                .upsert_file(&FileRow {
                    project_id: root.project_id.clone(),
                    path: remote.path.clone(),
                    remote_file_id: Some(remote.file_id),
                    remote_version_id: remote.version_id,
                    sha256: None,
                    size: 0,
                    mtime_ms: 0,
                    state: FileState::CloudOnly,
                    collab_active: remote.collab_active,
                    // `.yupcloud` 占位只属于真正的 cloudOnly(本地压根没有内容)。
                    // readOnly 是另一回事:内容照常落盘,只是不许上行
                    read_only: false,
                })
                .map_err(EngineError::Index)?;
            self.emit_file_state(root, &remote.path, &placeholder, FileState::CloudOnly);
            return Ok(());
        }
        // 有 sha256:web 编辑 5 分钟合并窗口内 versionId 不变但 sha256 会变,必须比内容,不能只比版本。
        // 没有 sha256(老库历史行为 NULL):内容寻址不可用,退化成按 versionId 判定变更;本地文件被删掉时
        // 还要重新拉,所以额外要求本地确实在。
        let unchanged = match (&existing, &remote.sha256) {
            (Some(row), Some(sha256)) => {
                row.remote_version_id == remote.version_id
                    && row.sha256.as_deref() == Some(sha256.as_str())
                    && row.state == FileState::Synced
                    // 索引说 synced、盘上却从没落下来过 → **不能**当「没变」跳过,否则这条脱节
                    // 永远自愈不了:每一轮都在这里 return,文件一辈子下不来,而上行那侧还会
                    // 把它当成「用户删了」推 DELETE(2026-09-11 实机两条,其中一条在有写权限的
                    // 自己库里)。注意只放行「从没落盘」的,用户真删掉的文件仍然算没变 ——
                    // 那条要留给上行去删,不能在这里又把它下回来
                    && !self.looks_never_landed(root, &remote.path)
            }
            (Some(row), None) => {
                remote.version_id.is_some()
                    && row.remote_version_id == remote.version_id
                    && row.state == FileState::Synced
                    && local.is_file()
            }
            (None, _) => false,
        };
        if unchanged {
            let row = existing.as_ref().expect("unchanged 只在有索引行时成立");
            // 内容没变但只读 / 协同标记翻了:得让角标跟上,否则用户手上的「能不能改」是过期的
            if row.collab_active != remote.collab_active || row.read_only != remote.read_only {
                self.index
                    .upsert_file(&FileRow {
                        collab_active: remote.collab_active,
                        read_only: remote.read_only,
                        ..row.clone()
                    })
                    .map_err(EngineError::Index)?;
                self.emit_file_state(root, &remote.path, &local, synced_state(remote.read_only, remote.collab_active));
            }
            return Ok(());
        }
        // 超过阈值的大文件:**不自动下**,只落一个占位,等用户点(2026-09-07 老板拍板)。
        //
        // 判据里的 `!local.is_file()` 是「存量不动」那一条:已经在盘上的大文件留着,阈值降下来
        // 不许把它删掉或退回占位 —— 那是「自动腾退」,还没拍板。只对**还没下的**生效。
        if self.skip_auto_download(root, &remote) && !local.is_file() {
            self.mark_not_downloaded(root, &remote)?;
            return Ok(());
        }
        if local.is_file() {
            let metadata =
                std::fs::metadata(&local).map_err(|error| io_error(format!("stat {}", local.display()), error))?;
            let local_sha = match &existing {
                Some(row)
                    if row.mtime_ms == file_mtime_ms(&metadata)
                        && row.size == metadata.len()
                        && row.sha256.is_some() =>
                {
                    row.sha256.clone().expect("checked")
                }
                _ => sha256_file(&local).map_err(EngineError::Io)?,
            };
            // 缺 sha256 时没法确认本地已经是远端那份,只能下载
            if remote.sha256.as_deref() == Some(local_sha.as_str()) {
                self.record_synced(
                    root,
                    &remote.path,
                    &local,
                    Some(remote.file_id),
                    remote.version_id,
                    remote.collab_active,
                    remote.read_only,
                    remote.sha256.as_deref(),
                )?;
                return Ok(());
            }
            let locally_modified = match &existing {
                Some(row) => row.sha256.as_deref() != Some(local_sha.as_str()),
                None => true,
            };
            // 文件正被写到一半的时候不能判冲突。AI 改文档普遍是「先清空再写」,下行要是恰好
            // 撞进 truncate 之后、内容写回之前那个窗口,读到的就是一个空文件 —— 据此存下来的
            // 「冲突副本」保护的是一份根本不存在的改动。2026-09-15 实撞:同一份文档连出 3 个
            // 副本,其中 2 个是 0 字节,用户的原话是「用 ai 改文档就会一直出现冲突副本」。
            //
            // 判据是**读之前与读之后的 mtime / size 是否一致**:对不上就说明这一刻还有人在写,
            // 这一轮索性不动它(远端那份也不落盘),下一轮文件静下来了再说。
            if locally_modified {
                log::info!(
                    "[drive-sync] {} 判成本地有改动:索引 sha={} 盘上 sha={} 远端 sha={}",
                    remote.path,
                    existing.as_ref().and_then(|row| row.sha256.as_deref()).unwrap_or("(无)"),
                    &local_sha[..local_sha.len().min(12)],
                    remote.sha256.as_deref().unwrap_or("(无)"),
                );
                // **协同会话开着的时候，Yjs 才是真相。**
                //
                // 磁盘桥已经把这边写盘的改动并进 Yjs 了（契约 §6.7），中继物化出来的就是它的
                // 归宿 —— 远端那份直接覆盖本地是对的，不欠一份副本。而且这条路上「本地与远端
                // 对不上」几乎是必然：AI 写的原始 markdown 经 ProseMirror 往返一趟，序列化出来
                // 的字节和原文本来就不同（空格、转义、列表标记）。照旧存副本的结果是**AI 每改
                // 一次就多一个副本**（2026-09-15 线上实撞，用户原话「用 ai 对文档进行修改，就会
                // 一直出现冲突副本」）。
                //
                // 只认**本地**的会话：桥在才跳过。服务端那个 collabActive 可能是别人开的、也可能
                // 是没清干净的僵尸会话，那种情况下这边没有桥，本地改动必须留一份副本才不会丢。
                let bridged = self.locally_collab(&root.project_id, &remote.path);
                let known_size = existing.as_ref().map_or(0, |row| row.size);
                if bridged {
                    log::debug!("[drive-sync] {} 协同中（磁盘桥在），远端那份直接落盘，不留副本", remote.path);
                } else if !worth_conflict_copy(&local, known_size) || self.still_writing(&local, &metadata)? {
                    // **不能当成功返回**:cursor 已经往前推了,这条 change 不会再来第二次,
                    // 就这么放过远端那份新内容就永远落不了盘。走失败通道 —— 记 file_errors
                    // 按退避重试,同时触发这一轮的「清 cursor、下一轮全量对账」。
                    return Err(EngineError::Busy(format!("{} 正在被写入,这一轮先不动它", remote.path)));
                } else {
                    let copy = self.make_conflict_copy(&local)?;
                    self.record_conflict(root, &remote.path, &local, Some(copy), remote.updated_by.clone());
                }
            }
        }
        // 「正在下载这一份」——**只发事件,不写索引**:状态栏那个面板要列出此刻在传哪些文件,
        // 而不是只给一个数字(用户原话「重试、成功都最好能看到」)。按需下载那条路早就发这条了,
        // 批量下行这条一直没发,于是初次同步时面板里一个文件名都看不到。
        // 不碰索引状态是刻意的:落盘成败由下面几行决定,这里只是让界面跟得上。
        self.emit_file_state(root, &remote.path, &local, FileState::Downloading);
        let bytes = match self.download_remote(&remote.file_id, remote.sha256.as_deref(), remote.size).await {
            Ok(bytes) => bytes,
            Err(error) => {
                // **把这份文件是什么记下来**(fileId / sha256 / size),否则它就永远回不来了:
                // cursor 已经往前走,这条 change 事件不会再来第二次,而索引里连一行都没有 ——
                // 服务端日后把 Range 部署上,这些卡住的文件也不会自愈(2026-09-07)。
                // 记成 NotDownloaded,下一轮 `fetch_pending_downloads` 按退避把它捞回来。
                //
                // **只在本地没有这份内容时才改写索引行**。本地还留着旧内容时改写是危险的:
                // 新行的 sha 是**远端**那份的,而盘上是旧的 —— 上行规划器看到「索引与盘上不一致」
                // 就会把旧内容当成用户的新改动推上去,把远端更新的那一版盖掉。宁可这一份晚点
                // 才更新,也不能拿一次下载失败去换一次覆盖。
                if !local.is_file() {
                    self.mark_not_downloaded(root, &remote)?;
                }
                return Err(error);
            }
        };
        write_file(&local, &bytes)?;
        // 刚从云端取下来的那份的 sha —— 落盘之后核一遍,对不上不记 synced(见 record_synced)
        let expected_sha = remote.sha256.clone();
        self.record_synced(
            root,
            &remote.path,
            &local,
            Some(remote.file_id),
            remote.version_id,
            remote.collab_active,
            remote.read_only,
            expected_sha.as_deref(),
        )?;
        Ok(())
    }

    /// 这份远端文件要不要跳过自动下载。阈值 0 = 不设限(从前的行为);拿不到 size 时**照下** ——
    /// 服务端没说多大就不该替它猜一个「太大」,那会让文件凭空变成占位。
    ///
    /// **SKILL 镜像一律不跳过**:它是给 CLI 扫的机器镜像,不写 `.yupcloud` 占位(占位会让 CLI
    /// 扫到一堆不是 skill 的东西),于是「跳过」的结果是这份 skill 在界面上根本看不见、也没有
    /// 任何一行可以点 —— 只能靠用户去改阈值。按需下载对没有「需」的那一方不成立。
    fn skip_auto_download(&self, root: &RootRow, remote: &RemoteFile) -> bool {
        if root.kind == ProjectKind::Skill {
            return false;
        }
        let limit = self.config.max_auto_download_bytes;
        limit > 0 && remote.size.is_some_and(|size| size > limit)
    }

    /// 落一个「点一下就拉」的占位:盘上写 `.yupcloud`,索引记 `NotDownloaded`(连同 fileId /
    /// sha256 / size —— 用户点的时候要靠它们去下,不必再跑一趟 snapshot)。
    ///
    /// 与 cloudOnly 的占位共用一套文件命名,但**状态是两回事**:cloudOnly 是「不许落到你盘上」,
    /// 这个只是「先没下」。文件树按状态分别渲染,不能混。
    fn mark_not_downloaded(&self, root: &RootRow, remote: &RemoteFile) -> Result<(), EngineError> {
        let placeholder = self.placeholder_path_for(root, &remote.path);
        // SKILL 镜像是给机器读的,塞占位只会让 CLI 扫到一堆不是 skill 的东西(同 cloudOnly 那条)
        if root.kind != ProjectKind::Skill {
            write_file(&placeholder, self.placeholder_content(remote, CloudOnlyReason::TooLarge).as_bytes())?;
        }
        self.index
            .upsert_file(&FileRow {
                project_id: root.project_id.clone(),
                path: remote.path.clone(),
                remote_file_id: Some(remote.file_id.clone()),
                remote_version_id: remote.version_id.clone(),
                // sha256 / size 是「点一下就拉」那条路的全部依据,必须记下
                sha256: remote.sha256.clone(),
                size: remote.size.unwrap_or(0),
                mtime_ms: 0,
                state: FileState::NotDownloaded,
                collab_active: remote.collab_active,
                read_only: remote.read_only,
            })
            .map_err(EngineError::Index)?;
        self.emit_file_state(root, &remote.path, &placeholder, FileState::NotDownloaded);
        Ok(())
    }

    /// 用户点了那个占位:**把这一份立刻拉下来**。
    ///
    /// 这条路是「大文件不自动下」能不能成立的**全部关键**。占位符体验做砸过一次
    ///(2026-09 老板:「知识库全是空壳、都不能打开」),所以这次的判据是:点一下 → 有进度 →
    /// 下完就能开,不需要第二次操作、不需要去别处找按钮。
    ///
    /// 不走 snapshot:fileId / sha256 / size 在落占位时就记进索引行了,点的时候直接用。
    /// 失败照样进 `file_errors`(状态栏看得见),并把状态退回 `NotDownloaded` —— 用户还能再点。
    pub async fn download_on_demand(&self, project_id: &RemoteId, path: &str) -> Result<(), EngineError> {
        let root = self
            .index
            .get_root(project_id)
            .map_err(EngineError::Index)?
            .ok_or_else(|| EngineError::Io(format!("项目 {project_id} 不在同步范围里")))?;
        let row = self
            .index
            .get_file(project_id, path)
            .map_err(EngineError::Index)?
            .ok_or_else(|| EngineError::Io(format!("{path} 不在索引里")))?;
        let file_id =
            row.remote_file_id.clone().ok_or_else(|| EngineError::Io(format!("{path} 在云端还没有版本,下不了")))?;
        let local = self.local_path_for(&root, path);
        // 先把「下载中」摆出来:几十兆的文件要等一会儿,这段时间界面上不能一片安静
        self.index.set_state(project_id, path, FileState::Downloading).map_err(EngineError::Index)?;
        self.emit_file_state(&root, path, &self.placeholder_path_for(&root, path), FileState::Downloading);
        self.update_status(|status| status.downloading = status.downloading.saturating_add(1));
        let result =
            self.download_remote(&file_id, row.sha256.as_deref(), Some(row.size).filter(|size| *size > 0)).await;
        self.update_status(|status| status.downloading = status.downloading.saturating_sub(1));
        let bytes = match result {
            Ok(bytes) => bytes,
            Err(error) => {
                // 退回占位态:用户还能再点。失败原因进 file_errors,状态栏与文件树都说得出话
                self.mark_download_failed(&root, path, &error)?;
                return Err(error);
            }
        };
        write_file(&local, &bytes)?;
        // record_synced 顺手收走旁边那个 `.yupcloud`,并广播「已同步」——文件树据此换回正常图标
        self.record_synced(
            &root,
            path,
            &local,
            Some(file_id),
            row.remote_version_id.clone(),
            row.collab_active,
            row.read_only,
            row.sha256.as_deref(),
        )?;
        self.index.clear_file_error(project_id, path).map_err(EngineError::Index)?;
        self.refresh_failed_count()?;
        log::info!("[drive-sync] 按需下载 {path} 完成({} 字节)", bytes.len());
        Ok(())
    }

    // ─── 批量删除安全阀:确认 / 取消 / 查询 ─────────────────────────────────

    /// 用户确认「是,从云端也删」:标记放行,下一轮同步真的把那批删除上行。
    /// 返回是否真有一条悬挂(没有则调用方无须触发同步)。
    /// 记下「用户刚把这些本地路径移走了」。目录传自己就行,子树按前缀命中。
    ///
    /// 由「移动到…」跨库那条路调用(本地 FS move 完成之后)。**不做网络请求**:只是给下一轮
    /// 扫描补上它自己看不出来的那条信息,删除仍然走原来的批处理与安全阀。
    pub fn mark_moved_away(&self, local_paths: &[PathBuf]) -> usize {
        let rows = match self.index.list_roots() {
            Ok(rows) => rows,
            Err(error) => {
                log::warn!("[drive-sync] 记录移走的路径时读不到根: {error}");
                return 0;
            }
        };
        let mut marked = self.moved_away.lock().expect("moved_away mutex");
        let mut count = 0;
        for local in local_paths {
            for root in &rows {
                let root_dir = self.root_local_dir(root);
                let Ok(relative) = local.strip_prefix(&root_dir) else { continue };
                let cloud = local_to_cloud_relative(relative, self.config.windows_names);
                if cloud.is_empty() {
                    continue;
                }
                marked.insert(format!("{}\0{}", root.project_id, cloud));
                count += 1;
                break;
            }
        }
        count
    }

    /// 用户在**桌面端里**删掉了这些本地路径(目录传自己就行,子树按前缀命中)。
    ///
    /// 和 `mark_moved_away` 是同一件事:告诉引擎「这不是镜像脱节,是人主动干的」。
    /// 单独起个名字是因为两个调用方的语义完全不同,共用一个「移走」的名字会让下一个人读不懂。
    ///
    /// **为什么非要这一句**:删整个文件夹会让父目录消失,而「从没落盘」的判据恰好是
    /// 「文件不在、父目录也不在」(见 `never_landed`)—— 于是文件夹里每个文件都被判成从没落盘,
    /// 不但不上行删除,反而退回待下载**又全下回来**,文件夹跟着重建。
    /// 2026-09-22 实报:「云盘的文件夹,我删了好几次,才删掉」,回网页一看还在。
    ///
    /// 磁盘上**没有**能区分这两种情况的信息(跨库移动那次已经得出过同样的结论),
    /// 所以出路只能是:做这件事的人自己说一声。从 Finder / 资源管理器删的仍然走脱节那条路
    /// —— 那时候确实没人能证明是故意的,保守对待是对的。
    pub fn mark_user_removed(&self, local_paths: &[PathBuf]) -> usize {
        self.mark_moved_away(local_paths)
    }

    /// 这条路径(或它的某个祖先目录)是不是用户刚移走的。
    fn was_moved_away(&self, root: &RootRow, path: &str) -> bool {
        let marked = self.moved_away.lock().expect("moved_away mutex");
        if marked.is_empty() {
            return false;
        }
        let prefix = format!("{}\0", root.project_id);
        marked.iter().any(|key| {
            let Some(rest) = key.strip_prefix(&prefix) else { return false };
            // 记的是目录时,子树里的每一条都算 —— 目录搬走了,它底下的文件当然也搬走了
            path == rest || path.starts_with(&format!("{rest}/"))
        })
    }

    /// 「从没落盘」的语境版:**用户主动移走的不算**。
    ///
    /// 三个调用点都必须走这一个,而不是裸 `never_landed` —— 漏掉任何一个,那条路径要么被当成
    /// 「补下来」重新下回源库,要么被当成「从没落盘」不删源库,两种都让跨库移动退化成复制。
    fn looks_never_landed(&self, root: &RootRow, path: &str) -> bool {
        !self.was_moved_away(root, path) && never_landed(&self.local_path_for(root, path))
    }

    /// 这一轮把这个根上的标记清掉 —— 它们已经被当成删除处理过了,留着只会在下一轮
    /// 把无关的同名路径也放行。
    fn clear_moved_away(&self, root: &RootRow) {
        let prefix = format!("{}\0", root.project_id);
        self.moved_away.lock().expect("moved_away mutex").retain(|key| !key.starts_with(&prefix));
    }

    pub fn confirm_deletes(&self, project_id: &RemoteId) -> bool {
        self.delete_guards.lock().expect("delete guard mutex").confirm(project_id)
    }

    /// 用户取消「别删,我是误删」:丢弃悬挂,并把被保护的那批 path 从云端逐个拉回本地。
    /// 返回成功恢复的文件数。单个恢复失败不中断(它进 file_errors,下一轮补下会再试);
    /// 吊销这类整体故障照旧上抛。
    pub async fn cancel_deletes(&self, project_id: &RemoteId) -> Result<usize, EngineError> {
        let paths = self.delete_guards.lock().expect("delete guard mutex").cancel(project_id);
        let mut restored = 0;
        for path in &paths {
            match self.download_on_demand(project_id, path).await {
                Ok(()) => restored += 1,
                Err(error) if is_fatal_engine_error(&error) => return Err(error),
                Err(error) => log::warn!("[drive-sync] 恢复误删的 {path} 失败(已记下,按退避再试): {error}"),
            }
        }
        Ok(restored)
    }

    /// 当前还没确认的删除悬挂(供前端查询,late-mount 的 UI 也能补到状态)。
    pub fn pending_deletes(&self) -> Vec<PendingDeletes> {
        let pending = self.delete_guards.lock().expect("delete guard mutex").pending();
        pending
            .into_iter()
            .map(|(project_id, count)| {
                let drive_path = self
                    .index
                    .get_root(&project_id)
                    .ok()
                    .flatten()
                    .map(|root| root.drive_path)
                    .unwrap_or_else(|| project_id.as_key());
                PendingDeletes { project_id, drive_path, count: count as u32 }
            })
            .collect()
    }

    /// 每轮把「云端有、本地还没有、而且**现在够得着**」的那些补下来。
    ///
    /// `NotDownloaded` 这一状态下躺着两类行,它们要的正是同一件事:
    /// - **超过阈值被跳过的** —— 用户把阈值调大就是为了要它们,不该还得逐个去点;
    /// - **上一轮没下下来的** —— cursor 已经往前走,那条 change 事件不会再来第二次。不在这里
    ///   捞,它就永远卡着:服务端日后把 Range 部署上也不会自愈,用户永远等不到那份文件
    ///   (2026-09-07 老板实机撞到的正是这一批)。
    ///
    /// 按退避挑,不到点的一个都不碰 —— 否则又回到「同一个 blob 十分钟被试 12 次」。
    /// 「立刻重试」把退避清零,下一轮这里就会全部再试一遍,那就是手动的自愈开关。
    async fn fetch_pending_downloads(&self, root: &RootRow) -> Result<(), EngineError> {
        let limit = self.config.max_auto_download_bytes;
        let errors = self.index.file_error_map(&root.project_id).map_err(EngineError::Index)?;
        let now = now_ms();
        let pending: Vec<FileRow> = self
            .index
            .list_files(&root.project_id)
            .map_err(EngineError::Index)?
            .into_iter()
            .filter(|row| row.state == FileState::NotDownloaded)
            .filter(|row| limit == 0 || row.size <= limit)
            .filter(|row| retry_due(errors.get(&row.path), now))
            .collect();
        for row in pending {
            // 单个补下失败不拖垮整轮:它已经进 file_errors 了,下一轮按退避再来
            if let Err(error) = self.download_on_demand(&root.project_id, &row.path).await {
                if is_fatal_engine_error(&error) {
                    return Err(error);
                }
                log::warn!("[drive-sync] 补下 {} 失败(已记下,按退避再试): {error}", row.path);
            }
        }
        Ok(())
    }

    /// 下行取字节:有 sha256 走内容寻址的 blob,缺了(老库历史行 NULL)走按文件的下载接口。
    ///
    /// 最多 `DOWNLOAD_ATTEMPTS` 次。两种失败区别对待:
    /// - **解码类**(`error decoding response body`:服务端 `Content-Length` 与实体不符 / 中途断连 /
    ///   chunked 框架错)与**确定性 4xx**:这条路径本身给不出东西,立刻换 `/files/{id}/download-url`
    ///   的直链(或 `/files/{id}/download` 的 302),不在 `/sync/blobs/{sha}` 上死磕,也不必先退避;
    /// - **同一条路径再试**:指数退避,起步 `DOWNLOAD_BACKOFF`(500ms → 1s)。
    ///
    /// blob 拿回来还要验一遍 sha256:内容寻址的响应必须哈希成它的名字,不等就是被截断了
    /// (`Content-Length` 比实体**短**时 hyper 不报错,只会悄悄少给几个字节)。
    async fn download_remote(
        &self, file_id: &RemoteId, sha256: Option<&str>, indexed_size: Option<u64>,
    ) -> Result<Vec<u8>, EngineError> {
        // 缺 sha256 的老库历史行没有内容寻址可走,一开始就按文件下载
        let mut by_file = sha256.is_none();
        if by_file {
            log::debug!("[drive-sync] 文件 {file_id} 远端缺 sha256,改走按文件下载");
        }
        let mut backoff_before_next = false;
        let mut last: Option<ClientError> = None;
        for attempt in 0..DOWNLOAD_ATTEMPTS {
            if backoff_before_next {
                tokio::time::sleep(DOWNLOAD_BACKOFF * 2u32.pow(attempt.saturating_sub(1))).await;
            }
            let route = match (by_file, sha256) {
                (false, Some(sha256)) => self
                    .client
                    .download_blob(sha256)
                    .await
                    .and_then(|bytes| verify_sha256(sha256, &bytes, indexed_size).map(|()| bytes)),
                _ => self.client.download_file(file_id).await,
            };
            let error = match route {
                Ok(bytes) => {
                    if attempt > 0 {
                        log::info!(
                            "[drive-sync] 文件 {file_id} 第 {} 次尝试下载成功({} 字节)",
                            attempt + 1,
                            bytes.len()
                        );
                    }
                    return Ok(bytes);
                }
                Err(error) if error.is_fatal() => return self.guard_revoked(Err(error)).await,
                Err(error) => error,
            };
            log::warn!(
                "[drive-sync] 下载 file={file_id} sha256={} 第 {}/{DOWNLOAD_ATTEMPTS} 次失败(路径 {},索引记录 size={}): {error}",
                sha256.unwrap_or("<无>"),
                attempt + 1,
                if by_file { "/files/{id}/download" } else { "/sync/blobs/{sha256}" },
                indexed_size.map(|size| size.to_string()).unwrap_or_else(|| "<无>".to_string()),
            );
            // 这条路径给不出东西了 → 换按文件下载(换路径就不必先退避);已经在按文件下载
            // 且错误是确定性的,再试也是同一个答案,直接收工
            let switch_route = !by_file && (error.is_body_decode() || !error.is_retryable());
            if switch_route {
                log::info!("[drive-sync] 文件 {file_id} 改走按文件的下载路径重试");
                by_file = true;
                backoff_before_next = false;
            } else if !error.is_retryable() {
                return self.guard_revoked(Err(error)).await;
            } else {
                backoff_before_next = true;
            }
            last = Some(error);
        }
        self.guard_revoked(Err(last.expect("循环至少失败一次"))).await
    }

    fn apply_remote_delete(&self, root: &RootRow, cloud_path: &str) -> Result<(), EngineError> {
        let local = self.local_path_for(root, cloud_path);
        let row = self.index.get_file(&root.project_id, cloud_path).map_err(EngineError::Index)?;
        let placeholder = self.placeholder_path_for(root, cloud_path);
        if placeholder.is_file() {
            std::fs::remove_file(&placeholder)
                .map_err(|error| io_error(format!("删除 {}", placeholder.display()), error))?;
        }
        if local.is_file() {
            let unchanged = match &row {
                Some(row) => local_matches_row(&local, row)?,
                None => false,
            };
            // 本地改过的文件不跟着远端删:留下来,下一轮作为新文件上云
            if unchanged {
                std::fs::remove_file(&local).map_err(|error| io_error(format!("删除 {}", local.display()), error))?;
            }
        }
        self.index.delete_file(&root.project_id, cloud_path).map_err(EngineError::Index)?;
        self.emit_file_state(root, cloud_path, &local, FileState::Pending);
        Ok(())
    }

    // ─── 上行 ─────────────────────────────────────────────────────────────

    async fn push_root(&self, root: &RootRow) -> Result<(), EngineError> {
        // 冲突副本产生后紧跟着再推一轮,让「两份都上云」在同一次同步里完成
        for _pass in 0..2 {
            let conflicts = self.push_root_once(root).await?;
            if conflicts == 0 {
                break;
            }
        }
        Ok(())
    }

    /// 返回本轮产生的冲突数。
    async fn push_root_once(&self, root: &RootRow) -> Result<usize, EngineError> {
        let dir = self.root_local_dir(root);
        let rules = IgnoreRules::load(&dir).map_err(EngineError::Io)?.with_max_file_size(self.config.max_upload_bytes);
        let rows = self.index.file_map(&root.project_id).map_err(EngineError::Index)?;
        let previous: HashMap<String, Previous> = rows
            .iter()
            .filter_map(|(path, row)| {
                row.sha256
                    .as_ref()
                    .map(|sha| (path.clone(), Previous { mtime_ms: row.mtime_ms, size: row.size, sha256: sha.clone() }))
            })
            .collect();
        let windows_names = self.config.windows_names;
        let scan_dir = dir.clone();
        let scan = tokio::task::spawn_blocking(move || scan_root(&scan_dir, &rules, &previous, windows_names))
            .await
            .map_err(|error| EngineError::Io(format!("扫描任务崩溃: {error}")))?
            .map_err(EngineError::Io)?;

        for path in &scan.too_large {
            let local = self.local_path_for(root, path);
            self.index
                .upsert_file(&FileRow {
                    project_id: root.project_id.clone(),
                    path: path.clone(),
                    remote_file_id: rows.get(path).and_then(|row| row.remote_file_id.clone()),
                    remote_version_id: rows.get(path).and_then(|row| row.remote_version_id.clone()),
                    sha256: None,
                    size: 0,
                    mtime_ms: 0,
                    state: FileState::SkippedTooLarge,
                    collab_active: rows.get(path).is_some_and(|row| row.collab_active),
                    read_only: rows.get(path).is_some_and(|row| row.read_only),
                })
                .map_err(EngineError::Index)?;
            self.emit_file_state(root, path, &local, FileState::SkippedTooLarge);
        }

        // 失败记录一次取齐:上一轮失败的行要不要在这一轮再试,由它说了算(见下面的失败行分支)
        let errors = self.index.file_error_map(&root.project_id).map_err(EngineError::Index)?;
        let now = now_ms();

        // 本地已经开着协同会话的那些文件(见 `local_collab`)。一次取齐,不做 per-file 查询
        let live_collab = self.locally_collab_paths(&root.project_id);
        let present: HashMap<&str, &ScannedFile> = scan.files.iter().map(|file| (file.path.as_str(), file)).collect();
        let mut creates: Vec<ScannedFile> = Vec::new();
        let mut updates: Vec<(ScannedFile, FileRow)> = Vec::new();
        let mut deletes: Vec<FileRow> = Vec::new();
        for file in &scan.files {
            match rows.get(&file.path) {
                None => creates.push(file.clone()),
                Some(row) if row.state == FileState::CloudOnly => {}
                // 只读(需走修改申请):内容在本地、能看能读,但改了不上行。静默丢弃是最糟的 ——
                // 用户以为存上去了。这里报一条,桌面端提示他去网页申请修改
                Some(row) if row.read_only => {
                    if row.sha256.as_deref() != Some(file.sha256.as_str()) {
                        self.warn_read_only_change(root, row, file);
                    }
                }
                // 协同中:磁盘上的改动由编辑器的磁盘桥并进 Yjs,再由中继物化成版本,不从这里上行。
                // **本地标记与服务端标记任一为真就算**:服务端那份要等下一轮 pull 才到,
                // 而用户敲第一个字是立刻的 —— 中间那个窗口正是冲突副本的来源(见 `local_collab`)
                Some(row) if row.collab_active || live_collab.contains(&file.path) => {}
                // 上一轮失败的行。改之前这里是两个极端:失败的 CREATE(没有 remoteFileId)会被下面
                // 那条分支每一轮原样再推一次,而失败的 UPDATE 因为 sha 没变,落到最后的 `Some(_) => {}`
                // 里**再也没人碰**。前者是空转刷屏,后者是静默丢改动 —— 2026-09-07 那条故障两头都占了。
                // 现在统一成一条规矩:内容变了 = 新的改动,退避作废立刻再试;没变就按退避表等到点
                Some(row) if matches!(row.state, FileState::Error | FileState::Forbidden) => {
                    let changed = row.sha256.as_deref() != Some(file.sha256.as_str());
                    if changed || retry_due(errors.get(&file.path), now) {
                        match row.remote_file_id {
                            Some(_) => updates.push((file.clone(), row.clone())),
                            None => creates.push(file.clone()),
                        }
                    }
                }
                Some(row) if row.remote_file_id.is_none() => creates.push(file.clone()),
                Some(row) if row.sha256.as_deref() != Some(file.sha256.as_str()) => {
                    updates.push((file.clone(), row.clone()))
                }
                Some(_) => {}
            }
        }
        for row in rows.values() {
            // 只读文件在本地被删掉也不上行删除请求:服务端会 FORBIDDEN,而下一轮下行会把它拉回来
            //
            // `NotDownloaded` / `Downloading` 同样**必须**在这里挡掉,而且这条是保命的:
            // 这两种行按设计就是「盘上只有占位、没有真内容」,而这个循环的判据是「索引里有、
            // 盘上没有 = 用户删了它」—— 不挡就会把一份**用户根本没碰过**的云端文件当成本地
            // 删除,一条 DELETE 发上去,云端那份就没了。大文件默认不下载之后,这种行会成批
            // 出现(2026-09-07 被 `并发下单个文件失败不拖垮整个项目` 当场逮到)
            if row.state == FileState::CloudOnly
                || row.state == FileState::NotDownloaded
                || row.state == FileState::Downloading
                || row.collab_active
                || live_collab.contains(&row.path)
                || row.read_only
                || present.contains_key(row.path.as_str())
            {
                continue;
            }
            if scan.too_large.contains(&row.path) {
                continue;
            }
            if row.remote_file_id.is_none() {
                // 从未上云的行(如上次报错)直接丢
                self.index.delete_file(&root.project_id, &row.path).map_err(EngineError::Index)?;
                continue;
            }
            deletes.push(row.clone());
        }

        // 重命名 / 移动:同 sha256 且旧路径消失
        let mut ops: Vec<PendingOp> = Vec::new();
        let mut remaining_deletes = Vec::new();
        for row in deletes {
            let matched = row.sha256.as_ref().and_then(|sha| creates.iter().position(|file| &file.sha256 == sha));
            match matched {
                Some(position) => {
                    let file = creates.remove(position);
                    let kind = if split_cloud_path(&row.path).0 == split_cloud_path(&file.path).0 {
                        BatchOpKind::Rename
                    } else {
                        BatchOpKind::Move
                    };
                    ops.push(PendingOp {
                        kind,
                        path: row.path.clone(),
                        new_path: Some(file.path.clone()),
                        scanned: Some(file),
                        row: Some(row),
                    });
                }
                None => remaining_deletes.push(row),
            }
        }

        // ── 镜像脱节不是删除 ────────────────────────────────────────────────
        // 索引说 synced、盘上却**连目录都没有** —— 这是下行没把文件写下来,不是用户删了它。
        // 当成删除上行就会把云端那份删进回收站:2026-09-11 实机抓到两条这样的行,其中一条在
        // **有写权限的自己库里**(服务端不会拒),而且只有一条、连批量删除安全阀的阈值
        // (10 条 / 半数)都够不着 —— 子弹已经上膛。退回待下载,交给 `fetch_pending_downloads`
        // 补下来;下行侧的 `unchanged` 用的是同一条判据,两侧一致(见 `never_landed`)。
        //
        // **放在重命名/移动配对之后**:移动会让旧路径的目录空掉甚至消失,配对之前就拦会把
        // 「移动」整个拆散(实撞:三条既有用例当场挂)。这里只面对真正剩下的那些删除。
        let mut confirmed_deletes = Vec::new();
        for row in remaining_deletes {
            if self.looks_never_landed(root, &row.path) {
                log::warn!(
                    "[drive-sync] {} 索引标着 synced 但从没落盘(所在目录不存在),按待下载处理,**不**上行删除",
                    row.path
                );
                self.index
                    .set_state(&root.project_id, &row.path, FileState::NotDownloaded)
                    .map_err(EngineError::Index)?;
                continue;
            }
            confirmed_deletes.push(row);
        }
        // 标记只为这一轮服务:已经被当成删除收下了,留着只会在下一轮把无关的同名路径也放行
        self.clear_moved_away(root);
        let remaining_deletes = confirmed_deletes;

        // ── 批量删除安全阀 ──────────────────────────────────────────────────
        // 清空/误删整个文件夹会把「已下载」的文件逐个当成删除、一条 DELETE 上行 → 云端全进
        // 回收站。这里在**净删除**(已排除占位/只读/未下载/重命名移动)真正变成 DELETE op 前
        // 过一道闸:够批量就挂起、发事件请用户确认,阈值以下照旧即时删。tracked 用索引里该项目
        // 的行数当分母(占比判据)。确认/取消由 confirm_deletes / cancel_deletes 驱动。
        let delete_paths: Vec<String> = remaining_deletes.iter().map(|row| row.path.clone()).collect();
        let tracked = rows.len();
        let decision =
            self.delete_guards.lock().expect("delete guard mutex").gate(&root.project_id, delete_paths, tracked);
        let allowed_deletes: HashSet<String> = match decision {
            DeleteDecision::Proceed(paths) => paths.into_iter().collect(),
            DeleteDecision::Hold { count, first } => {
                if first {
                    log::warn!(
                        "[drive-sync] {} 一轮检测到 {count} 个本地删除(共 {tracked} 个跟踪文件),疑似误删 —— 已挂起,等用户确认是否从云端删除",
                        root.drive_path
                    );
                    self.emit(EngineEvent::PendingDeletes(PendingDeletes {
                        project_id: root.project_id.clone(),
                        drive_path: root.drive_path.clone(),
                        count: count as u32,
                    }));
                }
                HashSet::new()
            }
        };
        for row in remaining_deletes {
            if !allowed_deletes.contains(&row.path) {
                continue;
            }
            ops.push(PendingOp {
                kind: BatchOpKind::Delete,
                path: row.path.clone(),
                new_path: None,
                scanned: None,
                row: Some(row),
            });
        }
        for file in creates {
            ops.push(PendingOp {
                kind: BatchOpKind::Create,
                path: file.path.clone(),
                new_path: None,
                scanned: Some(file),
                row: None,
            });
        }
        for (file, row) in updates {
            ops.push(PendingOp {
                kind: BatchOpKind::Update,
                path: file.path.clone(),
                new_path: None,
                scanned: Some(file),
                row: Some(row),
            });
        }
        // `pending` 只数文件操作:MKDIR 不是「一个待传的文件」,把它算进去会让状态栏虚报
        self.update_status(|status| status.pending = ops.len() as u32);
        // **补目录必须排在「没事可做」的早退之前**:一个空文件夹推不出任何文件 op,
        // 早退一次它就永远上不去 —— 那正是这条 bug 本身(2026-09-07)
        let registered = self.index.list_folders(&root.project_id).map_err(EngineError::Index)?;
        prepend_mkdirs(&mut ops, &rows, &scan.directories, &registered, &errors, now);
        // 空文件夹删除:本地删掉的空目录发 RMDIR(与 MKDIR 对称,补上「只上不下」的缺口)。
        // 排在文件 op 之后 —— 但 folders_to_rmdir 只挑「云端零文件」的目录,与本轮任何文件删除
        // 都不相干,顺序其实无所谓,放这里只是让目录清理跟在文件之后读起来顺
        let on_disk_dirs: HashSet<String> = scan.directories.iter().cloned().collect();
        for dir in folders_to_rmdir(&registered, &on_disk_dirs, &rows, &errors, now) {
            ops.push(PendingOp { kind: BatchOpKind::Rmdir, path: dir, new_path: None, scanned: None, row: None });
        }
        // ── 销案:那些「已经不需要做」的失败记录 ────────────────────────────────
        //
        // 退避到点了、这一轮却**没有**被排进 ops —— 说明这件事已经不用做了:目录又回来了、
        // 文件被删了、冲突自己消了。记录留着就是一条既不会成功、也不会消失的红字,UI 上还
        // 写着「下一轮就再试」,而它永远不会再试。
        //
        // 2026-09-15 实机逮到的就是这一条:本地删掉的 `飞书导入/session` 被服务端以
        // FOLDER_NOT_EMPTY 挡下,归位把目录对回了本地 —— 于是「登记了但盘上没有」不再成立,
        // RMDIR 再也不会发出,那条失败就永远挂在面板上。
        //
        // 还在退避窗口里的不动(那是**故意**没进 ops,等着下一轮再试)。
        let planned: HashSet<&str> = ops.iter().map(|op| op.path.as_str()).collect();
        for (path, row) in &errors {
            if row.direction == SyncDirection::Upload && retry_due(Some(row), now) && !planned.contains(path.as_str()) {
                self.index.clear_file_error(&root.project_id, path).map_err(EngineError::Index)?;
                log::info!("[drive-sync] {path} 的失败记录销案:这件事这一轮已经不需要做了");
                self.refresh_failed_count()?;
            }
        }

        // 文件一个都没动、目录也一个都不缺 → 这一轮真的没事可做
        if ops.is_empty() {
            return Ok(0);
        }

        // 去重探测 + 上传。索引与角标先一次性写完(纯本地,快),真正要等服务端的 `ensure_blob`
        // 才并发跑 —— 与下行同一个道理:等待可以叠起来,一致性不为它让路。
        let transfers: Vec<ScannedFile> = ops
            .iter()
            .filter(|op| matches!(op.kind, BatchOpKind::Create | BatchOpKind::Update))
            .map(|op| op.scanned.clone().expect("create/update carries scanned file"))
            .collect();
        for op in ops.iter().filter(|op| matches!(op.kind, BatchOpKind::Create | BatchOpKind::Update)) {
            let file = op.scanned.as_ref().expect("create/update carries scanned file");
            self.index
                .upsert_file(&FileRow {
                    project_id: root.project_id.clone(),
                    path: file.path.clone(),
                    remote_file_id: op.row.as_ref().and_then(|row| row.remote_file_id.clone()),
                    remote_version_id: op.row.as_ref().and_then(|row| row.remote_version_id.clone()),
                    sha256: Some(file.sha256.clone()),
                    size: file.size,
                    mtime_ms: file.mtime_ms,
                    state: FileState::Uploading,
                    collab_active: false,
                    read_only: false,
                })
                .map_err(EngineError::Index)?;
            self.emit_file_state(root, &file.path, &file.local_path, FileState::Uploading);
        }
        let total = transfers.len() as u32;
        self.update_status(|status| status.uploading = total);
        let uploads: Vec<_> = transfers.iter().map(|file| self.ensure_blob(file)).collect();
        let mut uploads = futures_util::stream::iter(uploads).buffer_unordered(self.transfer_concurrency());
        let mut left = total;
        while let Some(result) = uploads.next().await {
            result?;
            left = left.saturating_sub(1);
            if left.is_multiple_of(PROGRESS_EVERY) {
                self.update_status(|status| status.uploading = left);
            }
        }
        self.update_status(|status| status.uploading = 0);

        let mut conflicts = 0;
        let mut pending_ops = ops;
        for attempt in 0..2 {
            let mut next_retry = Vec::new();
            for chunk in pending_ops.chunks(BATCH_CHUNK) {
                let request = BatchRequest {
                    project_id: root.project_id.clone(),
                    device_id: self.config.device_id.clone(),
                    ops: chunk.iter().enumerate().map(|(index, op)| batch_op(index, op)).collect(),
                };
                let response = self.guard_revoked(self.client.batch(&request).await).await?;
                let by_id: HashMap<&str, &BatchResult> =
                    response.results.iter().map(|result| (result.op_id.as_str(), result)).collect();
                for (index, op) in chunk.iter().enumerate() {
                    let op_id = op_id(index, op);
                    let result =
                        by_id.get(op_id.as_str()).ok_or_else(|| EngineError::Io(format!("batch 响应缺少 {op_id}")))?;
                    match self.apply_batch_result(root, op, result).await? {
                        Outcome::Done => {}
                        Outcome::Conflict => conflicts += 1,
                        Outcome::RetryAfterUpload => {
                            if attempt == 0 {
                                next_retry.push(PendingOp {
                                    kind: op.kind,
                                    path: op.path.clone(),
                                    new_path: op.new_path.clone(),
                                    scanned: op.scanned.clone(),
                                    row: op.row.clone(),
                                });
                            } else {
                                self.mark_failed(root, op, FileState::Error, "服务端两次报 MISSING_BLOB".to_string())?;
                            }
                        }
                    }
                }
            }
            if next_retry.is_empty() {
                break;
            }
            for op in &next_retry {
                let file = op.scanned.as_ref().expect("retry only for create/update");
                self.upload_one(file).await?;
            }
            pending_ops = next_retry;
        }
        // 每推完一个根就把计数刷新一次:几百个根的一轮同步要跑很久,状态栏不该等到最后才说话
        let failed_files = self.index.count_file_errors().map_err(EngineError::Index)?;
        self.update_status(|status| {
            status.pending = 0;
            status.failed = failed_files;
        });
        Ok(conflicts)
    }

    async fn ensure_blob(&self, file: &ScannedFile) -> Result<(), EngineError> {
        if self.guard_revoked(self.client.blob_exists(&file.sha256).await).await? {
            return Ok(());
        }
        self.upload_one(file).await
    }

    /// 传一个文件的字节。**边读边传**,不把它整个读进内存 —— 传输并发是 8,单文件上限 500 MB,
    /// 从前的 `std::fs::read` 让内存峰值等于「并发数 × 文件大小」(2026-09-14 查出)。
    ///
    /// 长度用**扫描时记下的 size**,不是此刻 stat 出来的:Content-Length 要和实际发出去的字节
    /// 严格一致,而这两个数在文件正被人编辑时会打架。读不满就当场失败,下一轮重新扫。
    async fn upload_one(&self, file: &ScannedFile) -> Result<(), EngineError> {
        if file.size >= RESUMABLE_UPLOAD_THRESHOLD {
            return self.upload_resumable(file).await;
        }
        let name = split_cloud_path(&file.path).1.to_string();
        self.guard_revoked(self.client.upload_blob_from_file(&file.sha256, &name, &file.local_path, file.size).await)
            .await?;
        Ok(())
    }

    /// 大文件**分段上传**,断了从断点接着传。
    ///
    /// 为什么非有不可:生产上大 blob 会被上游(公司 HTTPS 网关 / 对象存储)在传输中途掐断。
    /// 下载方向早就用 HTTP Range 续上了,上传方向从前只能整份重来 —— 140 MB 传到一半被掐,
    /// 重试从 0 开始,再被掐,那个文件永远传不上去(2026-09-15 实报:一个人的同步面板上
    /// 16 条「同步失败: 网络错误」)。
    ///
    /// 每一段传完都问一次服务端「现在收到多少了」再续 —— 不拿本地的累加值当真:中间层可能
    /// 只吃进去一半,自己数的那个数会越飘越远。老服务端没有这两个接口时 `uploaded_length`
    /// 回 0、`append_blob` 报 404,这里退回整份上传,行为与从前一致。
    async fn upload_resumable(&self, file: &ScannedFile) -> Result<(), EngineError> {
        let mut position = match self.guard_revoked(self.client.uploaded_length(&file.sha256).await).await {
            Ok(-1) => return Ok(()), // 整份都在了(别人刚传完 / 秒传)
            Ok(value) => value.max(0) as u64,
            Err(error) => {
                log::debug!("[drive-sync] 问不到 {} 的已传长度({error}),退回整份上传", file.path);
                return self.upload_whole(file).await;
            }
        };
        if position > file.size {
            // 服务端那份比我们要传的还长 = 残留的脏数据,从头来
            log::warn!("[drive-sync] {} 服务端已收 {position} > 本地 {},从头传", file.path, file.size);
            position = 0;
        }
        log::info!("[drive-sync] {} 分段上传,从 {position}/{} 开始", file.path, file.size);
        while position < file.size {
            let len = RESUMABLE_CHUNK_BYTES.min(file.size - position);
            let progress = match self
                .guard_revoked(self.client.append_blob(&file.sha256, &file.local_path, position, len, file.size).await)
                .await
            {
                Ok(progress) => progress,
                // 老服务端没这个接口:退回整份上传
                Err(EngineError::Client(ClientError::Http { status: 404 | 405, .. })) => {
                    return self.upload_whole(file).await;
                }
                // 位置过期(并发续传/中间层吃了一半):重新问一次再续,不盲目重试
                Err(EngineError::Client(ClientError::Http { status: 409, .. })) => {
                    position = self.guard_revoked(self.client.uploaded_length(&file.sha256).await).await?.max(0) as u64;
                    continue;
                }
                Err(error) => return Err(error),
            };
            if progress.complete {
                return Ok(());
            }
            if progress.uploaded <= position {
                return Err(EngineError::Io(format!(
                    "{} 上传没有前进(服务端仍在 {}),这一轮先停",
                    file.path, progress.uploaded
                )));
            }
            position = progress.uploaded;
        }
        Ok(())
    }

    /// 整份上传(小文件,以及服务端还不支持分段时的退路)。
    async fn upload_whole(&self, file: &ScannedFile) -> Result<(), EngineError> {
        let name = split_cloud_path(&file.path).1.to_string();
        self.guard_revoked(self.client.upload_blob_from_file(&file.sha256, &name, &file.local_path, file.size).await)
            .await?;
        Ok(())
    }

    /// batch CONFLICT 里拿远端那份:同样容忍 `remote.sha256` 为空(fileId 从结果或索引行里取)。
    async fn download_remote_of(
        &self, op: &PendingOp, file_id: Option<&RemoteId>, sha256: Option<&str>,
    ) -> Result<Vec<u8>, EngineError> {
        match (sha256, file_id.cloned().or_else(|| op.row.as_ref().and_then(|row| row.remote_file_id.clone()))) {
            (Some(sha256), _) => Ok(self.guard_revoked(self.client.download_blob(sha256).await).await?),
            (None, Some(file_id)) => self.download_remote(&file_id, None, None).await,
            (None, None) => Err(EngineError::Io(format!("{} 的冲突结果既没有 sha256 也没有 fileId", op.path))),
        }
    }

    async fn apply_batch_result(
        &self, root: &RootRow, op: &PendingOp, result: &BatchResult,
    ) -> Result<Outcome, EngineError> {
        // MKDIR 的回执对应的是一个**目录**,不是任何一行文件 —— 无论服务端怎么答,都不能拿它去把
        // 某个文件行标成失败:`mark_failed` 会按 op.path 去写索引,而目录根本没有索引行,写下去
        // 只会在 UI 上凭空多出一条「这个目录没传上去」。
        //
        // 而「目录已经在了」在不同服务端上有 OK / CONFLICT / ERROR 三种面孔(我们发整条链时,
        // 上面几级通常本来就存在)。对我们全都是成功:要的只是「这个目录存在」这个结果。
        // 真正致命的失败会由依赖它的那条 CREATE / MOVE 自己带着服务端原话报出来,不会被漏掉。
        if op.kind == BatchOpKind::Mkdir {
            if result.status == BatchStatus::Ok || mkdir_already_exists(result) {
                // 登记「服务端上已经有它了」。空文件夹底下没有文件,不记的话每一轮都会重发一遍 MKDIR
                self.index.put_folder(&root.project_id, &op.path).map_err(EngineError::Index)?;
                // 建成了就销案:之前那条「这个目录建不出来」留着,状态栏会一直挂着一件已经办完的事
                self.index.clear_file_error(&root.project_id, &op.path).map_err(EngineError::Index)?;
            } else {
                let message = result.message.clone().unwrap_or_else(|| format!("{:?}", result.status));
                // 目录建不出来也要**看得见**、也要退避。空文件夹没有任何依赖它的 CREATE 替它说话 ——
                // 不记的话,用户建的那个文件夹既上不去、界面上也一个字都没有,而引擎每轮重发一遍
                //(2026-09-07:沉默仍是主线问题)。只写 file_errors,不碰 files ——
                // 目录在 files 里本来就没有行,往那儿写会凭空长出一条不存在的「文件」
                // 按**回执状态**定状态,不要拿消息文本去猜:服务端回的是 FORBIDDEN 时,
                // 记成 Error 会让它进退避表无限重试(见 next_retry_at 只认 Forbidden),
                // 于是面板上挂着「已试 4 次 · 下一轮就再试」,用户点「重试」也没用
                // —— 没有写权限,再试一万次都是同一个答案(2026-09-23 实报,24 条)。
                let state =
                    if result.status == BatchStatus::Forbidden { FileState::Forbidden } else { FileState::Error };
                self.record_file_error(&root.project_id, &op.path, state, SyncDirection::Upload, &message)?;
                self.push_error_quiet(
                    Some(&root.project_id),
                    Some(&op.path),
                    format!("建目录 {} 没成功：{message}", op.path),
                );
            }
            return Ok(Outcome::Done);
        }
        // RMDIR 同 MKDIR:回执对应一个**目录**,不能拿去把某个文件行标失败(目录没有文件行)。
        // 「目录已经不在了」在不同服务端上有 OK / CONFLICT / ERROR 三种面孔,对我们都算成功 ——
        // 要的结果就是「这个空目录在云端没了」。成功就销登记;真出错才记 file_errors 退避重试。
        if op.kind == BatchOpKind::Rmdir {
            if result.status == BatchStatus::Ok || rmdir_already_gone(result) {
                self.index.delete_folder(&root.project_id, &op.path).map_err(EngineError::Index)?;
                self.index.clear_file_error(&root.project_id, &op.path).map_err(EngineError::Index)?;
            } else {
                let message = result.message.clone().unwrap_or_else(|| format!("{:?}", result.status));
                if settled_by_server(&message) {
                    // 最常见的是 FOLDER_NOT_EMPTY:云端那个目录里还有**我们这边没有**的东西 ——
                    // 别人后加的,或者本地压根没下载的 cloud-only 文件。本地的删除不该扩散过去,
                    // 服务端拒绝是对的。
                    //
                    // 光停手不够,那会留下一条永远删不掉的红字,而本地和云端还是对不上。
                    //
                    // **归位分两步**:
                    // 1. 本地把目录建回来 —— 这一步是**立刻**打破循环的关键。RMDIR 的前提是
                    //    「登记了、盘上没有」,目录回来了这个操作就不会再发出。只靠下面那句
                    //    清 cursor 的话,要等一整轮全量对账才重建;那轮要是因为网络没跑成,
                    //    下一轮又发 RMDIR、又清 cursor —— 变成每轮一次全量对账。
                    // 2. 清 cursor:云端那个目录里有我们这边没有的文件,靠对账把它们拉下来。
                    //    第 1 步已经保证这里最多执行一次。
                    let local_dir = self.local_path_for(root, &op.path);
                    if let Err(error) = std::fs::create_dir_all(&local_dir) {
                        log::warn!("[drive-sync] 归位时重建 {} 失败: {error}", local_dir.display());
                    }
                    self.index.clear_file_error(&root.project_id, &op.path).map_err(EngineError::Index)?;
                    self.index.clear_cursor(&root.project_id).map_err(EngineError::Index)?;
                    self.push_error_quiet(
                        Some(&root.project_id),
                        Some(&op.path),
                        format!("目录「{}」在云端还有别的东西，没有跟着删掉。下一轮会把云端那份对回本地；要真删，去网页端删。", op.path),
                    );
                    log::info!("[drive-sync] RMDIR {} 被服务端挡下({message}),清 cursor 走对账归位", op.path);
                } else {
                    self.record_file_error(
                        &root.project_id,
                        &op.path,
                        FileState::Error,
                        SyncDirection::Upload,
                        &message,
                    )?;
                    log::warn!("[drive-sync] RMDIR {} 失败(空目录清理,按退避再试): {message}", op.path);
                }
            }
            return Ok(Outcome::Done);
        }
        match result.status {
            BatchStatus::Ok => {
                match op.kind {
                    BatchOpKind::Create | BatchOpKind::Update => {
                        let file = op.scanned.as_ref().expect("scanned");
                        let file_id = result
                            .file_id
                            .clone()
                            .or_else(|| op.row.as_ref().and_then(|row| row.remote_file_id.clone()));
                        let version_id = result
                            .version_id
                            .clone()
                            .or_else(|| result.remote.as_ref().map(|remote| remote.version_id.clone()));
                        self.record_synced(
                            root,
                            &file.path,
                            &file.local_path,
                            file_id,
                            version_id,
                            false,
                            false,
                            None,
                        )?;
                    }
                    BatchOpKind::Delete => {
                        self.index.delete_file(&root.project_id, &op.path).map_err(EngineError::Index)?;
                    }
                    BatchOpKind::Rename | BatchOpKind::Move => {
                        let file = op.scanned.as_ref().expect("scanned");
                        self.index.move_path(&root.project_id, &op.path, &file.path).map_err(EngineError::Index)?;
                        let file_id = result
                            .file_id
                            .clone()
                            .or_else(|| op.row.as_ref().and_then(|row| row.remote_file_id.clone()));
                        let version_id = result
                            .version_id
                            .clone()
                            .or_else(|| result.remote.as_ref().map(|remote| remote.version_id.clone()))
                            .or_else(|| op.row.as_ref().and_then(|row| row.remote_version_id.clone()));
                        self.record_synced(
                            root,
                            &file.path,
                            &file.local_path,
                            file_id,
                            version_id,
                            false,
                            false,
                            None,
                        )?;
                    }
                    BatchOpKind::Mkdir | BatchOpKind::Rmdir => {}
                }
                Ok(Outcome::Done)
            }
            BatchStatus::Conflict => {
                // remote=null = 远端已删除:本地这份按「未上传的新文件」处理,索引行删掉,下一遍 CREATE
                let Some(remote) = result.remote.clone() else {
                    self.index.delete_file(&root.project_id, &op.path).map_err(EngineError::Index)?;
                    let local = op
                        .scanned
                        .as_ref()
                        .map(|file| file.local_path.clone())
                        .unwrap_or_else(|| self.local_path_for(root, &op.path));
                    if local.is_file() {
                        self.emit_file_state(root, &op.path, &local, FileState::Pending);
                    }
                    return Ok(Outcome::Conflict);
                };
                let file_id =
                    result.file_id.clone().or_else(|| op.row.as_ref().and_then(|row| row.remote_file_id.clone()));
                match op.kind {
                    BatchOpKind::Create | BatchOpKind::Update => {
                        let file = op.scanned.as_ref().expect("scanned");
                        // 同下行那处:此刻磁盘上是个空文件的话,那是 truncate 之后还没写回的
                        // 中间态,存下来的副本保护的是一份不存在的改动。远端那份照常覆盖下来,
                        // AI 手上的内容马上会再写一遍,不会丢。
                        let copy = worth_conflict_copy(&file.local_path, op.row.as_ref().map_or(0, |row| row.size))
                            .then(|| self.make_conflict_copy(&file.local_path))
                            .transpose()?;
                        self.record_conflict(root, &file.path, &file.local_path, copy, remote.updated_by.clone());
                        let bytes = self.download_remote_of(op, file_id.as_ref(), remote.sha256.as_deref()).await?;
                        write_file(&file.local_path, &bytes)?;
                        self.record_synced(
                            root,
                            &file.path,
                            &file.local_path,
                            file_id,
                            Some(remote.version_id),
                            false,
                            false,
                            remote.sha256.as_deref(),
                        )?;
                    }
                    BatchOpKind::Delete => {
                        // 我们删了、远端又改了:远端赢,拉回来
                        let local = self.local_path_for(root, &op.path);
                        let bytes = self.download_remote_of(op, file_id.as_ref(), remote.sha256.as_deref()).await?;
                        write_file(&local, &bytes)?;
                        self.record_conflict(root, &op.path, &local, None, remote.updated_by.clone());
                        self.record_synced(
                            root,
                            &op.path,
                            &local,
                            file_id,
                            Some(remote.version_id),
                            false,
                            false,
                            remote.sha256.as_deref(),
                        )?;
                    }
                    BatchOpKind::Rename | BatchOpKind::Move => {
                        // 旧路径远端已前进:旧路径拉回远端版本,新路径留作下一轮 CREATE
                        let old_local = self.local_path_for(root, &op.path);
                        let bytes = self.download_remote_of(op, file_id.as_ref(), remote.sha256.as_deref()).await?;
                        write_file(&old_local, &bytes)?;
                        let new_local = op.scanned.as_ref().map(|file| file.local_path.clone());
                        self.record_conflict(root, &op.path, &old_local, new_local, remote.updated_by.clone());
                        self.record_synced(
                            root,
                            &op.path,
                            &old_local,
                            file_id,
                            Some(remote.version_id),
                            false,
                            false,
                            remote.sha256.as_deref(),
                        )?;
                    }
                    BatchOpKind::Mkdir | BatchOpKind::Rmdir => {}
                }
                Ok(Outcome::Conflict)
            }
            BatchStatus::MissingBlob => Ok(Outcome::RetryAfterUpload),
            BatchStatus::Forbidden => {
                let message = result.message.clone().unwrap_or_else(|| "FORBIDDEN".to_string());
                self.mark_failed(root, op, FileState::Forbidden, message)?;
                Ok(Outcome::Done)
            }
            BatchStatus::Error => {
                let message = result.message.clone().unwrap_or_else(|| "ERROR".to_string());
                self.mark_failed(root, op, FileState::Error, message)?;
                Ok(Outcome::Done)
            }
        }
    }

    /// 记下失败态。
    ///
    /// 除了把 `files.state` 打成 Error / Forbidden,还要往 `file_errors` 里落一条:服务端原话、
    /// 试了第几次、下次什么时候再试。2026-09-07 之前只有前半截,于是一个传不上去的文件在 UI 上
    /// 与「已同步」长得一模一样 —— 用户以为存上去了,而它在索引里躺了六轮 error。
    fn mark_failed(
        &self, root: &RootRow, op: &PendingOp, state: FileState, message: String,
    ) -> Result<(), EngineError> {
        if let Some(file) = &op.scanned {
            self.index
                .upsert_file(&FileRow {
                    project_id: root.project_id.clone(),
                    path: file.path.clone(),
                    remote_file_id: op.row.as_ref().and_then(|row| row.remote_file_id.clone()),
                    remote_version_id: op.row.as_ref().and_then(|row| row.remote_version_id.clone()),
                    sha256: Some(file.sha256.clone()),
                    size: file.size,
                    mtime_ms: file.mtime_ms,
                    state,
                    collab_active: false,
                    // 只读文件从来不会进上行队列,走到这里的一定是可写的
                    read_only: false,
                })
                .map_err(EngineError::Index)?;
            self.emit_file_state(root, &file.path, &file.local_path, state);
        } else {
            self.index.set_state(&root.project_id, &op.path, state).map_err(EngineError::Index)?;
        }
        self.record_upload_error(root, &op.path, state, &message)?;
        self.push_error(Some(&root.project_id), Some(&op.path), format!("{:?} {} 失败: {message}", op.kind, op.path));
        Ok(())
    }

    /// 往 `file_errors` 落一条(或把已有那条往前推一次):次数 +1,下次重试时间按退避表算。
    fn record_upload_error(
        &self, root: &RootRow, path: &str, state: FileState, message: &str,
    ) -> Result<(), EngineError> {
        self.record_file_error(&root.project_id, path, state, SyncDirection::Upload, message)
    }

    /// 下行失败:落一条同样的记录(方向 download)+ 状态退回 `NotDownloaded`,让用户还能再点。
    ///
    /// 2026-09-07 之前下行失败只走 `push_error`(内存 ring,重启即空),于是「同一个 blob
    /// 十分钟被试了 12 次」在界面上一个字都没有 —— 引擎在疯狂重试,用户以为一切正常。
    /// 沉默是这套东西最大的问题,下行必须和上行进同一套可见性。
    fn mark_download_failed(&self, root: &RootRow, path: &str, error: &EngineError) -> Result<(), EngineError> {
        // 退回占位态而不是 Error:这份文件在云端好好的,只是这次没拿下来,点一下还能再试。
        // 同上:**本地还留着内容时不动状态** —— 索引行说「本地没有」而盘上有,上行会把旧内容
        // 推上去盖掉远端更新的那一版
        if !self.local_path_for(root, path).is_file() {
            self.index.set_state(&root.project_id, path, FileState::NotDownloaded).map_err(EngineError::Index)?;
            self.emit_file_state(root, path, &self.placeholder_path_for(root, path), FileState::NotDownloaded);
        }
        // 404 是例外:云端那份已经没了(被删,或者你的权限被收回 —— 服务端两种都回 404)。
        // 上面那句「云端好好的,点一下还能再试」对它不成立,再怎么试都是 404。从前照普通退避
        // 重试,用户界面上就挂着一条「已试 21 次」的红字(2026-09-15 实撞)。这里直接给封顶退避
        // —— 记录留着(用户要知道这份没拿到),但不再空转。
        let gone = matches!(error, EngineError::Client(ClientError::Http { status: 404, .. }));
        let message = humanize(error);
        // 技术原文只进日志:排查要它,用户不需要看见
        log::warn!("[drive-sync] 下行 {path} 失败(原文): {error}");
        if gone {
            // 云端那份已经没了(被删,或者权限被收回 —— 服务端两种都回 404)。
            // 索引行还指着一个不存在的 fileId,留着它只会每隔几小时再去要一次同样的 404。
            //
            // **归位**:本地文件在就留着(那是用户的东西,下一轮扫描会当成新文件重新推上去,
            // 推不上去自会有 403 说话),索引行删掉。这条失败就此销案 —— 「要么成功,要么清掉」。
            let local = self.local_path_for(root, path);
            self.index.delete_file(&root.project_id, path).map_err(EngineError::Index)?;
            if local.is_file() {
                self.emit_file_state(root, path, &local, FileState::Pending);
                log::info!("[drive-sync] {path} 云端已不存在,索引行销掉,本地那份留着重新上行");
            } else {
                log::info!("[drive-sync] {path} 云端已不存在,本地也没有,索引行一并销掉");
            }
            self.push_error_quiet(Some(&root.project_id), Some(path), format!("{path}: {message}"));
            return self.refresh_failed_count();
        }
        self.record_file_error_with(&root.project_id, path, FileState::Error, SyncDirection::Download, &message, None)?;
        self.push_error_quiet(Some(&root.project_id), Some(path), format!("{path}: {message}"));
        self.refresh_failed_count()
    }

    /// 这个文件此刻还在被写吗?拿**读之前**的 metadata 和现在再读一次的比:mtime 或 size
    /// 对不上,说明刚才算 sha 的那段时间里文件还在变,算出来的东西不能用来做任何判断。
    ///
    /// 只用在冲突判定这一处:那是唯一一个「判错了就留下垃圾」的地方 —— 上行判错最多晚一轮,
    /// 下行判错会凭空造出一个文件。
    fn still_writing(&self, local: &Path, before: &std::fs::Metadata) -> Result<bool, EngineError> {
        let after = std::fs::metadata(local).map_err(|error| io_error(format!("stat {}", local.display()), error))?;
        Ok(file_mtime_ms(&after) != file_mtime_ms(before) || after.len() != before.len())
    }

    /// `StatusSnapshot::failed` 与索引对齐。上行那边在每轮末尾刷,按需下载 / 补下这类**轮外**
    /// 动作也要各自刷一次,否则状态栏要等到下一轮才说话。
    fn refresh_failed_count(&self) -> Result<(), EngineError> {
        let failed = self.index.count_file_errors().map_err(EngineError::Index)?;
        self.update_status(|status| status.failed = failed);
        Ok(())
    }

    fn record_file_error(
        &self, project_id: &RemoteId, path: &str, state: FileState, direction: SyncDirection, message: &str,
    ) -> Result<(), EngineError> {
        self.record_file_error_with(project_id, path, state, direction, message, None)
    }

    /// `hold` 给定时用它代替按 attempts 算出来的退避。`None` 且服务端已经把话说死
    /// (见 `settled_by_server`)则直接停手 —— 那种失败再退避多久都是同一个答案。
    fn record_file_error_with(
        &self, project_id: &RemoteId, path: &str, state: FileState, direction: SyncDirection, message: &str,
        hold: Option<Duration>,
    ) -> Result<(), EngineError> {
        let now = now_ms();
        let previous = self.index.file_error(project_id, path).map_err(EngineError::Index)?;
        let attempts = previous.as_ref().map_or(0, |row| row.attempts).saturating_add(1);
        self.index
            .put_file_error(&FileErrorRow {
                project_id: project_id.clone(),
                path: path.to_string(),
                state,
                message: message.to_string(),
                attempts,
                direction,
                first_at_ms: previous.map_or(now, |row| row.first_at_ms),
                last_at_ms: now,
                next_at_ms: match hold {
                    Some(wait) => now.saturating_add(wait.as_millis() as i64),
                    None if settled_by_server(message) || state == FileState::Forbidden => NEVER_RETRY,
                    None => now.saturating_add(upload_backoff(attempts).as_millis() as i64),
                },
            })
            .map_err(EngineError::Index)?;
        Ok(())
    }

    /// UI 那张「没传上去的文件」清单:路径 + 服务端原话 + 试了几次 + 下次什么时候再试。
    /// 计数在 `StatusSnapshot::failed`,明细在这里 —— 状态栏点开就是这一份。
    pub fn failed_uploads(&self) -> Result<Vec<FailedUpload>, EngineError> {
        let rows = self.index.list_file_errors().map_err(EngineError::Index)?;
        let mut roots: HashMap<String, Option<RootRow>> = HashMap::new();
        let mut list = Vec::with_capacity(rows.len());
        for row in rows {
            let key = row.project_id.as_key();
            if !roots.contains_key(&key) {
                roots.insert(key.clone(), self.index.get_root(&row.project_id).map_err(EngineError::Index)?);
            }
            // 根已经不在索引里(被移出同步范围 / 刚删掉)时给空串:少一个本地路径也比整份清单取不出来强
            let local_path = roots[&key]
                .as_ref()
                .map(|root| self.local_path_for(root, &row.path).to_string_lossy().to_string())
                .unwrap_or_default();
            list.push(FailedUpload {
                project_id: row.project_id,
                name: split_cloud_path(&row.path).1.to_string(),
                path: row.path,
                local_path,
                state: row.state,
                message: row.message,
                attempts: row.attempts,
                direction: row.direction,
                first_at: iso_from_ms(row.first_at_ms),
                last_at: iso_from_ms(row.last_at_ms),
                retryable: row.next_at_ms != NEVER_RETRY,
                next_attempt_at: iso_from_ms(row.next_at_ms),
            });
        }
        Ok(list)
    }

    /// 「立刻重试」:把所有失败行的退避清零,下一轮同步全部再试一遍。给 UI 上那个按钮用 ——
    /// 用户在网页上把目录建好 / 把权限要到之后,不该还得干等最长 6 小时的退避。
    pub fn retry_failed_uploads(&self) -> Result<u32, EngineError> {
        self.index.clear_file_error_backoff().map_err(EngineError::Index)
    }

    /// 只重试**一条**:面板上逐条那颗「重试」。与全局那颗同一个机制(退避清零 + 催一轮同步),
    /// 区别只在作用范围 —— 想单独再试一个文件时,不该把其余几十条也一起拉起来。
    pub fn retry_failed_upload(&self, project_id: &RemoteId, path: &str) -> Result<u32, EngineError> {
        self.index.clear_file_error_backoff_of(project_id, path).map_err(EngineError::Index)
    }

    /// 「重新对账」:把本地索引跟云端从头核对一遍。
    ///
    /// 什么时候用它:界面上挂着一堆说不清的同步错误、或者明明云端有的东西本地就是不出现。
    /// 做法是清掉 cursor —— 下一轮不再走增量变更流,改走 snapshot 全量比对。
    ///
    /// **为什么需要人工入口:**变更流是一次性的。一条事件落地失败,那条变更就没有第二次
    /// 投递机会(引擎现在会自己察觉并清 cursor,但那是这一版才有的;更早留下的漂移、以及
    /// 谁也没预料到的情况,都得有一个"从头核一遍"的按钮兜着)。
    ///
    /// 对账**不会重新下载**已经一致的文件:snapshot 逐个比 sha256,一样就跳过。
    /// 传 `None` 表示所有根一起对。返回被标记的根数。
    pub fn reconcile(&self, project_id: Option<&RemoteId>) -> Result<u32, EngineError> {
        let roots = self.index.list_roots().map_err(EngineError::Index)?;
        let mut marked = 0;
        for root in roots {
            if project_id.is_some_and(|wanted| &root.project_id != wanted) {
                continue;
            }
            self.index.clear_cursor(&root.project_id).map_err(EngineError::Index)?;
            marked += 1;
        }
        // 上一轮留下的失败记录一并放行:对账要是把东西修好了,它们不该还被退避挡在门外
        self.index.clear_file_error_backoff().map_err(EngineError::Index)?;
        self.clear_errors();
        log::info!("[drive-sync] 重新对账:{marked} 个根的 cursor 已清,下一轮走全量比对");
        Ok(marked)
    }

    // ─── 索引写回 / 事件 ──────────────────────────────────────────────────

    /// 成功一次就销案:失败记录留着,UI 上就会一直挂着一条「没传上去」,而它明明已经传上去了。
    #[allow(clippy::too_many_arguments)]
    /// `expected_sha`:刚从云端取下来的那份内容的 sha。下行路径都该传 —— 传了就核对落盘结果,
    /// 对不上不记 synced(见函数体)。本地侧的调用(上传成功回执、协同保存)没有这个概念,传 None。
    fn record_synced(
        &self, root: &RootRow, cloud_path: &str, local: &Path, file_id: Option<RemoteId>, version_id: Option<RemoteId>,
        collab_active: bool, read_only: bool, expected_sha: Option<&str>,
    ) -> Result<(), EngineError> {
        self.index.clear_file_error(&root.project_id, cloud_path).map_err(EngineError::Index)?;
        let metadata =
            std::fs::metadata(local).map_err(|error| io_error(format!("stat {}", local.display()), error))?;
        let sha256 = sha256_file(local).map_err(EngineError::Io)?;
        // 下行落盘完整性:调用方给了云端那份的 sha 就核一遍,对不上**绝不记 synced**。
        // `synced` 这个状态在上行侧是「盘上没有 = 用户删了它」的判据,记错一条的代价是
        // 云端那份被删 —— 所以这一格宁可报错重来,也不能记一条与云端不符的 synced
        // (2026-09-11 镜像脱节)。对不上就当下载失败:退避之后自然重下。
        if let Some(expected) = expected_sha
            && expected != sha256
        {
            return Err(EngineError::Io(format!(
                "{} 落盘内容与云端不符(期望 {expected}、实际 {sha256}),不记 synced",
                local.display()
            )));
        }
        // **没有远端 id 就不是「已同步」。**
        //
        // 「已同步」这个状态对用户的承诺是三件事:网页上能找到、同事能看见、能复制出链接。
        // 这三件事全都要 remote_file_id。少了它而照样记 synced,文件树上就会挂一个绿勾,
        // 而用户点「复制链接」得到的是「这份文件还没同步到云盘」—— 自相矛盾,
        // 且他根本不知道该怎么办(2026-09-23 实报:「整个右边显示 ✅,但网页版找不到,
        // 其他人也看不到」)。
        //
        // 宁可留在待上传:下一轮会重新推一次,角标也老老实实显示「还没传上去」。
        // 旧行依然保留(带着它原来的 id),不会因为这一次没拿到 id 就把已经有的抹掉。
        if file_id.is_none()
            && let Some(existing) = self.index.get_file(&root.project_id, cloud_path).ok().flatten()
            && existing.remote_file_id.is_none()
        {
            log::warn!("[drive-sync] {} 回执里没有 fileId,不记 synced —— 留在待上传,下一轮重推", cloud_path);
            return Ok(());
        }
        self.index
            .upsert_file(&FileRow {
                project_id: root.project_id.clone(),
                path: cloud_path.to_string(),
                // 这一次没拿到 id 不代表它没有 —— 保住旧行上已有的那个,别越记越空
                remote_file_id: file_id.or_else(|| {
                    self.index.get_file(&root.project_id, cloud_path).ok().flatten().and_then(|row| row.remote_file_id)
                }),
                remote_version_id: version_id,
                sha256: Some(sha256),
                size: metadata.len(),
                mtime_ms: file_mtime_ms(&metadata),
                state: FileState::Synced,
                collab_active,
                read_only,
            })
            .map_err(EngineError::Index)?;
        // 这份文件现在有真实内容了,旁边那个 `.yupcloud` 就是过期的 —— 无论它是怎么留下的
        // (服务端把分类从 cloudOnly 改判回正常、权限重新给回来、核对动作补拉),都在这里收走。
        // 放在 `record_synced` 而不是某一条下行路径里:凡是「已同步」成立,占位就一定该没了
        let placeholder = self.placeholder_path_for(root, cloud_path);
        if placeholder.is_file() {
            std::fs::remove_file(&placeholder)
                .map_err(|error| io_error(format!("删除 {}", placeholder.display()), error))?;
        }
        // 刚下来的这份内容与云端一致,可只读文件的角标要一直是「只读」—— 它比「已同步」更该被看见
        self.emit_file_state(root, cloud_path, local, synced_state(read_only, collab_active));
        // 云端换了新版本 → 之前对这个文件提过的「要走修改申请」作废,改了还得再提一次
        self.forget_readonly_warning(&root.project_id, cloud_path);
        Ok(())
    }

    /// 已经与云端一致的文件该显示成什么。只读优先:用户最需要知道的是「这份文件改不了」。
    fn forget_readonly_warning(&self, project_id: &RemoteId, cloud_path: &str) {
        let prefix = format!("{}:{cloud_path}:", project_id.as_key());
        self.readonly_warned.lock().expect("readonly warned mutex").retain(|key| !key.starts_with(&prefix));
    }

    /// 用户改了一份只读文件。每个 (文件, 内容) 只报一次 —— 不去重的话每一轮同步都会再弹一次。
    fn warn_read_only_change(&self, root: &RootRow, row: &FileRow, file: &ScannedFile) {
        let key = format!("{}:{}:{}", root.project_id.as_key(), file.path, file.sha256);
        if !self.readonly_warned.lock().expect("readonly warned mutex").insert(key) {
            return;
        }
        log::info!("[drive-sync] {} 是只读文件,本地改动不会上行(要改请在网页发起修改申请)", file.path);
        self.emit(EngineEvent::ReadOnly(ReadOnlyChange {
            project_id: root.project_id.clone(),
            path: file.path.clone(),
            local_path: file.local_path.to_string_lossy().to_string(),
            name: split_cloud_path(&file.path).1.to_string(),
            file_id: row.remote_file_id.clone(),
        }));
        self.emit_file_state(root, &file.path, &file.local_path, FileState::ReadOnly);
    }

    fn emit_file_state(&self, root: &RootRow, cloud_path: &str, local: &Path, state: FileState) {
        // 大小从索引现读:占位那一行要显示「多大」,而这是唯一一处所有状态变化都经过的咽喉,
        // 在这里带上,前端不必为一个数字再开一趟往返
        let size = self.index.get_file(&root.project_id, cloud_path).ok().flatten().map(|row| row.size).unwrap_or(0);
        self.emit(EngineEvent::FileState(FileStateEvent {
            project_id: root.project_id.clone(),
            path: cloud_path.to_string(),
            local_path: local.to_string_lossy().to_string(),
            state,
            size,
        }));
    }

    fn record_conflict(
        &self, root: &RootRow, cloud_path: &str, local: &Path, copy: Option<PathBuf>, updated_by: Option<String>,
    ) {
        let record = ConflictRecord {
            project_id: root.project_id.clone(),
            path: cloud_path.to_string(),
            local_path: local.to_string_lossy().to_string(),
            conflict_copy_path: copy.as_ref().map(|path| path.to_string_lossy().to_string()),
            remote_updated_by: updated_by,
            at: now_iso(),
        };
        self.update_status(|status| {
            status.conflicts.push(record.clone());
            if status.conflicts.len() > MAX_RECORDS {
                status.conflicts.remove(0);
            }
        });
        self.emit(EngineEvent::Conflict(record));
        if let Some(copy) = copy {
            self.emit_file_state(root, cloud_path, &copy, FileState::Conflict);
        }
    }

    pub fn clear_conflicts(&self) {
        self.update_status(|status| status.conflicts.clear());
    }

    /// 本地文件改名为冲突副本(同目录),返回副本路径。
    fn make_conflict_copy(&self, local: &Path) -> Result<PathBuf, EngineError> {
        let file_name = local.file_name().expect("file has a name").to_string_lossy().to_string();
        let base = conflict_copy_name(&file_name, &self.config.user_name, chrono::Local::now());
        let parent = local.parent().expect("file has a parent");
        let mut candidate = parent.join(&base);
        let mut counter = 2;
        while candidate.exists() {
            let (stem, extension) = crate::naming::split_extension(&base);
            candidate = parent.join(format!("{stem} ({counter}){extension}"));
            counter += 1;
        }
        std::fs::rename(local, &candidate)
            .map_err(|error| io_error(format!("另存冲突副本 {} → {}", local.display(), candidate.display()), error))?;
        Ok(candidate)
    }

    // ─── SKILL 镜像 ───────────────────────────────────────────────────────

    /// `<skills_dir>/.yup-drive/<projectKey>/`。
    ///
    /// **落点由客户端定,不听服务端的 `skillsPath`**(它给的是 `yup/<projectKey>`)。
    /// 服务端不知道这台机器上还装着哪些 skill,没有资格去挑一个可能与人写的 skill 撞名的
    /// 目录名 —— 撞了就是把别人的 skill 顶掉(见 `SKILL_MIRROR_DIR`)。字段照常解析、
    /// 迁移时还要用它找老目录,只是不拿它拼新落点。
    pub fn skill_mirror_dir(&self, root: &RootRow) -> Option<PathBuf> {
        let skills_dir = self.config.skills_dir.as_ref()?;
        let relative = format!("{SKILL_MIRROR_DIR}/{}", root.project_key);
        Some(skills_dir.join(cloud_to_local_relative(&relative, self.config.windows_names)))
    }

    /// 出事之前的落点:服务端给的 `skillsPath`,没给就是 `yup/<projectKey>`。只有迁移用它。
    fn legacy_skill_mirror_dir(&self, root: &RootRow) -> Option<PathBuf> {
        let skills_dir = self.config.skills_dir.as_ref()?;
        let relative =
            root.skills_path.clone().unwrap_or_else(|| format!("{LEGACY_SKILL_MIRROR_DIR}/{}", root.project_key));
        Some(skills_dir.join(cloud_to_local_relative(&relative, self.config.windows_names)))
    }

    /// 把镜像下来的 SKILL 项目摊平成 CLI 能扫到的一层(为什么、怎么定名、怎么处理重名,见 skills.rs)。
    ///
    /// 放在**整轮同步之后**而不是每个根之后:名字要在全部已同步的 skill 之间去重,收走失效的
    /// 也要看到完整清单 —— 一个根一个根地做,会把「别的项目还占着这个名字」漏掉,或者把
    /// 还活着的目录当成孤儿删掉。
    ///
    /// 不参与同步的 SKILL 根(别的部门的、没固定的)压根没有镜像目录,于是自然不会被装 ——
    /// 「部门的 skill 只装给本部门的人」这条由 `is_selected` 兜住,不需要在这里再判一次。
    fn install_skill_mirrors(&self) {
        let Some(skills_dir) = self.config.skills_dir.clone() else { return };
        let Ok(rows) = self.index.list_roots() else { return };
        let Ok(selection) = self.selection(&rows) else { return };
        let mut sources = Vec::new();
        let mut fallback = String::new();
        for root in rows.iter().filter(|row| row.kind == ProjectKind::Skill && is_selected(row, &selection)) {
            let Some(mirror) = self.skill_mirror_dir(root) else { continue };
            if !mirror.is_dir() {
                continue;
            }
            fallback.clone_from(&root.project_key);
            sources.extend(crate::skills::find_skills(&mirror, &root.name));
        }
        if sources.is_empty() && !skills_dir.is_dir() {
            return;
        }
        let report = crate::skills::install(&skills_dir, &sources, &fallback);
        if !report.written.is_empty() || !report.removed.is_empty() {
            log::info!(
                "[drive-sync] SKILL 摊平:现有 {} 个、本轮重写 {} 个、收走 {} 个、部门补充 {} 条({}) → {}",
                report.installed.len(),
                report.written.len(),
                report.removed.len(),
                report.overlaid.len(),
                report.overlaid.join("、"),
                skills_dir.display()
            );
        }
        // 装不上却不吭声是这件事的原罪:每一条冲突都摆到用户面前。
        //
        // **先撤掉上一轮的同类,再放这一轮的** —— 装不上是个**持续状态**(手工装的 yup-kb 一直
        // 在那儿占着名字),不是发生过一次的事件。原来无条件 push,而这个函数每轮同步都跑:
        // 同一句话每 60 秒进一条,一小时 60 条,很快就把 MAX_RECORDS 占满、把真正的失败顶出去
        // (2026-09-08 实机:两轮同步 → 面板上「错误(2)」,两条一模一样)。
        let current: Vec<String> = report
            .conflicts
            .iter()
            .map(|conflict| {
                let why = match conflict.reason {
                    crate::skills::SkillConflictReason::Duplicate => "同名的另一份已经装上了",
                    crate::skills::SkillConflictReason::Occupied => "这个名字被一份手工安装的 skill 占着,不覆盖",
                    crate::skills::SkillConflictReason::MissingBase => "这是一份部门补充,但本机没有同名基座可拼",
                    crate::skills::SkillConflictReason::Unreadable => "文件读不出来或写不进去",
                };
                format!("SKILL「{}」没能装上({why}):{}", conflict.dir_name, conflict.rejected)
            })
            .collect();
        let changed = {
            let mut last = self.last_skill_conflicts.lock().expect("skill conflicts mutex");
            let changed = *last != current;
            if changed {
                last.clone_from(&current);
            }
            changed
        };
        self.update_status(|status| status.errors.retain(|error| !is_skill_install_error(&error.message)));
        for message in &current {
            // 只有集合变了才写日志 —— 面板要的是「现在是什么样」,日志要的是「什么时候变的」
            if changed {
                log::warn!("[drive-sync] {message}");
            }
            self.push_error_quiet(None, None, message.clone());
        }
    }

    /// 把老落点 `<skills_dir>/yup/<projectKey>/` 搬到 `.yup-drive/` 下,搬完收走空掉的 `yup/`。
    ///
    /// **`yup/SKILL.md` 存在就一个字节都不碰那个目录** —— 那是公司自己那个 `yup` skill,
    /// 是我们挤掉它、不是它占了我们的位置。同理只在目录**真的空了**才删,里面还剩东西就留着
    /// 让人自己看(房规:移动不是删除,不确定就别动)。
    fn migrate_legacy_skill_mirror(&self) {
        let Some(skills_dir) = self.config.skills_dir.as_ref() else { return };
        let Ok(roots) = self.index.list_roots() else { return };
        for root in roots.iter().filter(|root| root.kind == ProjectKind::Skill) {
            let (Some(legacy), Some(current)) = (self.legacy_skill_mirror_dir(root), self.skill_mirror_dir(root))
            else {
                continue;
            };
            if legacy == current || !legacy.is_dir() {
                continue;
            }
            if current.exists() {
                log::warn!(
                    "[drive-sync] SKILL 库 {} 新旧落点都在,老的留着不动: {}",
                    root.project_key,
                    legacy.display()
                );
                continue;
            }
            if let Some(parent) = current.parent()
                && let Err(error) = std::fs::create_dir_all(parent)
            {
                log::warn!("[drive-sync] 建 SKILL 落点 {} 失败: {error}", parent.display());
                continue;
            }
            match std::fs::rename(&legacy, &current) {
                Ok(()) => log::info!(
                    "[drive-sync] SKILL 库 {} 已从 {} 搬到 {}",
                    root.project_key,
                    legacy.display(),
                    current.display()
                ),
                Err(error) => log::warn!("[drive-sync] 搬 {} → {} 失败: {error}", legacy.display(), current.display()),
            }
        }
        remove_empty_legacy_skill_dir(&skills_dir.join(LEGACY_SKILL_MIRROR_DIR));
    }

    /// SKILL 根改成只落 skills 目录之前,`~/YUP Drive/<drivePath>/` 下也有一份 —— 同一份东西
    /// 两个家。把历史副本挪到暂存目录(不是删:房规是「移动不是删除」),用户不必自己去找。
    ///
    /// 为什么自动做而不是让用户点「清理未选中的本地副本」:那个入口只扫「不在同步范围内」的根,
    /// 而 SKILL 根往往正在同步范围内,它永远扫不到;况且这份副本是纯粹的云端镜像,没有任何
    /// 只存在于本地的东西会被挪丢。每轮同步开头跑一次,目录不在就是个 `is_dir()`,几乎不花钱。
    fn sweep_legacy_skill_dirs(&self) {
        let Ok(roots) = self.index.list_roots() else { return };
        let staging = self.cleanup_staging_dir();
        for root in roots.iter().filter(|root| root.kind == ProjectKind::Skill) {
            // 新服务端不再给 SKILL 的 drivePath → 算不出历史位置,这一条就没得清。
            // 目录结构整个换了之后本来就要重新同步,残留由「重新同步」那条路承担
            let Some(legacy) = self.legacy_drive_dir(root) else { continue };
            // skills_dir 没配时 root_local_dir 回落到的正是 legacy —— 那它就不是历史副本,别动
            if !legacy.is_dir() || legacy == self.root_local_dir(root) {
                continue;
            }
            match self.move_to_staging(&legacy, &staging) {
                Ok(()) => log::info!(
                    "[drive-sync] SKILL 库 {} 只该装在 skills 目录,云盘目录下的历史副本已移到 {}",
                    root.drive_path,
                    staging.display()
                ),
                Err(error) => log::warn!("[drive-sync] 移走 {} 的云盘侧历史副本失败: {error}", root.drive_path),
            }
        }
    }

    // ─── 吊销清空 ─────────────────────────────────────────────────────────

    /// 删除本地索引与 `~/YUP Drive/` 下所有已同步内容;冲突副本与未上传文件挪到残留目录。
    pub fn purge_after_revoke(&self) -> Result<(), EngineError> {
        self.revoked.store(true, Ordering::SeqCst);
        for root in self.index.list_roots().map_err(EngineError::Index)? {
            let dir = self.root_local_dir(&root);
            if !dir.is_dir() {
                continue;
            }
            let rows = self.index.file_map(&root.project_id).map_err(EngineError::Index)?;
            for entry in walkdir::WalkDir::new(&dir).into_iter().filter_map(Result::ok) {
                if !entry.file_type().is_file() {
                    continue;
                }
                let relative = entry.path().strip_prefix(&dir).expect("under root");
                if is_cloud_only_placeholder(relative) {
                    std::fs::remove_file(entry.path())
                        .map_err(|error| io_error(format!("删除 {}", entry.path().display()), error))?;
                    continue;
                }
                let cloud_path = local_to_cloud_relative(relative, self.config.windows_names);
                let synced = match rows.get(&cloud_path) {
                    Some(row) if row.state == FileState::Synced => local_matches_row(entry.path(), row)?,
                    _ => false,
                };
                if synced {
                    std::fs::remove_file(entry.path())
                        .map_err(|error| io_error(format!("删除 {}", entry.path().display()), error))?;
                } else {
                    let destination = self
                        .config
                        .residual_root
                        .join(cloud_to_local_relative(&root.drive_path, self.config.windows_names))
                        .join(relative);
                    if let Some(parent) = destination.parent() {
                        std::fs::create_dir_all(parent)
                            .map_err(|error| io_error(format!("创建 {}", parent.display()), error))?;
                    }
                    std::fs::rename(entry.path(), &destination).map_err(|error| {
                        io_error(format!("挪走 {} → {}", entry.path().display(), destination.display()), error)
                    })?;
                }
            }
            remove_empty_dirs(&dir);
        }
        remove_empty_dirs(&self.config.local_root);
        self.index.clear_all().map_err(EngineError::Index)?;
        self.update_status(|status| {
            status.synced = 0;
            status.failed = 0;
            status.pending = 0;
            status.uploading = 0;
            status.state = EngineState::Error { message: crate::client::DEVICE_REVOKED_CODE.to_string() };
        });
        self.emit(EngineEvent::Revoked);
        Ok(())
    }
}

enum Outcome {
    Done,
    Conflict,
    RetryAfterUpload,
}

/// 整体性故障(吊销 / 设备不匹配 / 未授权 / 索引坏了):**不是某一个文件的事**,再往下跑
/// 只会把同一个错刷成几百条。单个文件的失败一律不算。
fn is_fatal_engine_error(error: &EngineError) -> bool {
    matches!(
        error,
        EngineError::Revoked
            | EngineError::Index(_)
            | EngineError::Client(ClientError::Revoked | ClientError::DeviceMismatch | ClientError::Unauthorized(_))
    )
}

fn local_collab_key(project_id: &RemoteId, cloud_path: &str) -> String {
    format!("{}\0{cloud_path}", project_id.as_key())
}

fn now_ms() -> i64 {
    chrono::Local::now().timestamp_millis()
}

fn iso_from_ms(ms: i64) -> String {
    chrono::DateTime::from_timestamp_millis(ms)
        .map(|time| time.with_timezone(&chrono::Local).to_rfc3339_opts(chrono::SecondsFormat::Secs, true))
        .unwrap_or_default()
}

/// 多大的文件走分段上传。小文件整份传更省事(一次请求),大文件被掐断的概率高,值得分段。
/// 32 MB 是个折中:低于它的文件在公司网络上基本一次能过。
const RESUMABLE_UPLOAD_THRESHOLD: u64 = 32 * 1024 * 1024;

/// 每段多大。8 MB:段太小请求次数多、段太大被掐断时白费的字节多。
const RESUMABLE_CHUNK_BYTES: u64 = 8 * 1024 * 1024;

/// 「不会再自己试了」。写进 `file_errors.next_at_ms`,`retry_due` 永远算不到它头上。
///
/// 为什么需要这么一个东西:从前所有失败一律按 60s → 2m → 4m …封顶 6 小时的退避重试,
/// 包括那些**再试一万次也是同一个答案**的 —— 目录非空、没有权限、云端那份已经被删。
/// 用户看到的就是一条「已试 21 次」的红字永远挂在那儿,既不成功也不消失
/// (2026-09-15 用户原话:「理论上我的重试应该会成功 或者清掉,但是现在还是有问题」)。
/// 停手不等于不管:UI 会说明白这条要人处理,「立刻重试」和「重新对账」都还能把它重新拉起来。
const NEVER_RETRY: i64 = i64::MAX;

/// 服务端在批量结果里回的业务错误码,哪些是「再问一遍还是同一个答案」。
///
/// 判据是**这件事的成败取决于云端的状态,而那个状态不会因为我再试一次就改变**:
/// 目录里还有别的东西、上级目录不在了、名字被占着、没有权限、那份文件已经没了。
/// 反过来,超时 / 5xx / 存储层抖动这些留给退避,它们确实可能下一次就好了。
fn settled_by_server(message: &str) -> bool {
    // **大小写不敏感。** 服务端有些地方回的是 i18n key 原文(`common.forbidden`、
    // `common.not_found`),和这里列的大写常量对不上,于是「服务端把话说死了」的失败
    // 被当成可重试,永远空转(2026-09-23:24 条 MKDIR 挂在那儿「下一轮就再试」)。
    let message = &message.to_ascii_uppercase();
    const SETTLED: [&str; 10] = [
        "FOLDER_NOT_EMPTY",
        "PARENT_FOLDER_NOT_FOUND",
        "FILE_NOT_FOUND",
        "FOLDER_NOT_FOUND",
        "NAME_CONFLICT",
        "FORBIDDEN",
        "READ_ONLY",
        "COMMON.FORBIDDEN",
        "COMMON.NOT_FOUND",
        "CHANGE_CONTROLLED",
    ];
    SETTLED.iter().any(|code| message.contains(code))
}

/// 这个失败要不要让这一轮结束后清 cursor(下一轮走 snapshot 全量对账)。
///
/// 判据是**索引与远端是不是就此对不上了**:
/// - `Io` —— 本地文件没动成。它不是 fatal,不中断这一轮,cursor 照推 —— 丢事件就从这里丢。
/// - `Index` —— 列在这里是防御性的。它当前是 fatal,`fail_one_file` 直接往上抛,那一页的
///   set_cursor 根本执行不到(所以 UNIQUE 那种卡死是**原地重放**,不是丢事件);哪天它不再
///   fatal,这里也接得住。
/// - `Busy` —— 文件正被写到一半,等会儿再来就是了,索引没有漂。**这条必须排除**:AI 连着改
///   文档时每一轮都可能撞上,当成漂移就成了每轮一次全量对账。
/// - `Client` —— 网络、404。内容没拿到而已,不伤索引一致性,file_errors 那套退避管得了。
fn is_drift(error: &EngineError) -> bool {
    matches!(error, EngineError::Index(_) | EngineError::Io(_))
}

/// 此刻的本地文件值不值得存一份冲突副本。
///
/// 空文件几乎必然是「truncate 之后还没写回」的中间态 —— AI 改文档普遍是这个写法。
/// 拿它存一份副本,保护的是一份根本不存在的改动:2026-09-15 线上同一份文档连出 3 个
/// 冲突副本,其中 2 个是 0 字节(用户原话:「用 ai 对文档进行修改,就会一直出现冲突副本」)。
///
/// 索引里记着的本来就是空文件(`known_size == 0`)时不适用 —— 那是真的空,不是中间态。
fn worth_conflict_copy(local: &Path, known_size: u64) -> bool {
    if known_size == 0 {
        return true;
    }
    std::fs::metadata(local).map(|meta| meta.len() > 0).unwrap_or(true)
}

/// 把引擎内部的错误翻成**用户看得懂的一句话**。
///
/// 这套东西的错误从前是直接把内部消息摆给用户:
/// 「错误 · 索引: 移动索引 Zhongwei Tian/…/主窗口_MOB2_cashloan_….csv 失败:
///   UNIQUE constraint failed: files.project_id, files.path」
/// —— 里面没有一个词是给人看的,用户只知道"红了"。技术原文一律进日志,排查照样有。
///
/// 认不出来的**原样透出**:宁可露出技术细节,也不要用一句"同步失败"把线索抹干净。
fn humanize(error: &EngineError) -> String {
    let raw = error.to_string();
    match error {
        EngineError::Revoked => "这台设备的授权被收回了，重新登录一次。".into(),
        EngineError::Client(ClientError::Revoked) => "这台设备的授权被收回了，重新登录一次。".into(),
        EngineError::Client(ClientError::DeviceMismatch) => "设备身份对不上，重新登录一次。".into(),
        EngineError::Client(ClientError::Unauthorized(_)) => "登录过期了，重新登录一次。".into(),
        EngineError::Client(ClientError::Transport(_)) => "连不上服务器。网络恢复后会自动重试。".into(),
        EngineError::Client(ClientError::Body { .. }) => "从服务器取内容时断了，会自动重试。".into(),
        // 服务端有些地方把 i18n key 原样当消息回过来(`common.forbidden`)。
        // 用户看到一串点号分隔的英文,只会更懵 —— 这里翻成他能照做的一句话。
        EngineError::Client(ClientError::Http { status, .. }) => match status {
            404 => "云端已经没有这个文件了（被删除，或者你对它的权限被收回）。".into(),
            403 => "你没有这个文件的权限。要用的话去网页端申请。".into(),
            413 => "文件太大，超过了服务端允许的上限。".into(),
            500..=599 => "服务端出错了，会自动重试。".into(),
            _ => format!("服务端返回 HTTP {status}，会自动重试。"),
        },
        EngineError::Index(detail) if detail.contains("UNIQUE constraint") => {
            "本地记录和另一个文件撞在了同一个位置。点「重新对账」让它跟云端核对一遍就好。".into()
        }
        EngineError::Index(_) => "本地记录没更新成功。点「重新对账」跟云端核对一遍。".into(),
        EngineError::Busy(_) => "这个文件刚才正在被改写，这一轮先跳过，稍后会自动再来一次。".into(),
        EngineError::Io(detail) if detail.contains("Permission denied") => {
            "本地文件没有读写权限，检查一下这个目录的权限设置。".into()
        }
        EngineError::Io(detail) if detail.contains("No space left") => "磁盘空间不够了。".into(),
        EngineError::Io(_) => format!("本地文件操作失败：{raw}"),
        EngineError::Client(ClientError::Protocol(_)) => "服务端返回的内容看不懂，可能版本不一致。".into(),
    }
}

/// 第 `attempts` 次失败之后要等多久:60s → 2m → 4m …,封顶 6 小时。见 `UPLOAD_BACKOFF_BASE`。
fn upload_backoff(attempts: u32) -> Duration {
    let steps = attempts.saturating_sub(1).min(16);
    UPLOAD_BACKOFF_MAX.min(UPLOAD_BACKOFF_BASE * 2u32.saturating_pow(steps))
}

/// 这一行现在能不能再试一次。**没有失败记录就是能试** —— 老库升上来时那些已经卡在 error 的行
/// 一条记录都没有,正好在升级后的第一轮全部重新推一遍(这才是把用户机器解卡的那一下)。
fn retry_due(error: Option<&FileErrorRow>, now: i64) -> bool {
    error.is_none_or(|row| now >= row.next_at_ms)
}

/// `a/b/c.md` → `["a", "a/b"]`(从浅到深)。
fn ancestors_of(path: &str) -> Vec<String> {
    let mut parts: Vec<&str> = path.split('/').collect();
    parts.pop();
    let mut prefix = String::new();
    parts
        .into_iter()
        .map(|part| {
            if !prefix.is_empty() {
                prefix.push('/');
            }
            prefix.push_str(part);
            prefix.clone()
        })
        .collect()
}

/// 服务端上**已知存在**的目录:索引里任何一行带 `remote_file_id` 的文件,它的每一级上级目录
/// 在服务端上就一定存在(那个文件正是服务端建出来的)。
///
/// 这个判断纯本地做。为了发 MKDIR 先去问一次「这个目录在不在」,等于给每一次新建目录都加一个
/// 网络往返,而这个信息我们本来就有。
fn known_remote_dirs(rows: &HashMap<String, FileRow>) -> HashSet<String> {
    let mut dirs = HashSet::new();
    for row in rows.values().filter(|row| row.remote_file_id.is_some()) {
        dirs.extend(ancestors_of(&row.path));
    }
    dirs
}

/// 把这一批 op 需要、而服务端还没有的目录,整条链压到队首。
///
/// 2026-09-07 实报:用户在本地一口气建了三级目录再往里放文件,服务端每一轮都回
/// `PARENT_FOLDER_NOT_FOUND: 上级目录不存在: …（请先 MKDIR）`。根因是 `BatchOpKind::Mkdir`
/// 在契约里躺了很久,发送端一次都没构造过 —— 服务端不会替我们建上级目录。
///
/// 两个细节:
/// - **BTreeSet**:字典序天然让上级排在下级前面(`a/b` 是 `a/b/c` 的前缀,一定更小),
///   顺手还去了重。三级目录一次发齐,用户不用等三轮同步。
/// - **压到队首**:`chunks(BATCH_CHUNK)` 保序,全部 MKDIR 压在最前面就不可能出现
///   「CREATE 在前一个分片、它依赖的 MKDIR 在后一个分片」这种拆法。
fn prepend_mkdirs(
    ops: &mut Vec<PendingOp>, rows: &HashMap<String, FileRow>, directories: &[String], registered: &HashSet<String>,
    errors: &HashMap<String, FileErrorRow>, now: i64,
) {
    let mut known = known_remote_dirs(rows);
    // 已经建过的(上一次 MKDIR 拿到成功回执时记下的)不必再建。空文件夹底下永远没有文件,
    // 光靠 `known_remote_dirs` 推不出来,不记就会每轮重发一遍
    known.extend(registered.iter().cloned());
    let mut missing: BTreeSet<String> = BTreeSet::new();
    // **目录本身也是内容**:本地有这个目录、服务端没有,就该建 —— 不管它里面有没有文件。
    // 从前 MKDIR 完全从文件操作反推,于是一个空文件夹推不出任何 op、永远不上行,用户得先
    // 往里放东西它才出现(2026-09-07 老板实机:项目根建了个 `test`,云端 9 个文件夹里没有它)。
    for directory in directories {
        if is_server_managed_dir(directory) {
            continue;
        }
        // 上一次建不出来的(受管控目录之类)按退避等 —— 否则一个建不成的目录会每一轮重发一遍
        // MKDIR,又变成空转。它建不成这件事本身有 file_errors 那条记录在说话
        if !retry_due(errors.get(directory), now) {
            continue;
        }
        if !known.contains(directory) {
            missing.insert(directory.clone());
        }
        missing.extend(ancestors_of(directory).into_iter().filter(|dir| !known.contains(dir)));
    }
    for op in ops.iter() {
        // 写到哪儿就看哪儿的上级:CREATE / UPDATE 看 path,RENAME / MOVE 的落点是 newPath ——
        // 移动到一个服务端还没有的目录撞的是同一堵墙
        let destination = match op.kind {
            BatchOpKind::Rename | BatchOpKind::Move => op.new_path.as_deref(),
            BatchOpKind::Create | BatchOpKind::Update => Some(op.path.as_str()),
            BatchOpKind::Delete | BatchOpKind::Mkdir | BatchOpKind::Rmdir => None,
        };
        let Some(destination) = destination else { continue };
        missing.extend(ancestors_of(destination).into_iter().filter(|dir| !known.contains(dir)));
    }
    if missing.is_empty() {
        return;
    }
    let mut planned: Vec<PendingOp> = missing
        .into_iter()
        .map(|path| PendingOp { kind: BatchOpKind::Mkdir, path, new_path: None, scanned: None, row: None })
        .collect();
    planned.append(ops);
    *ops = planned;
}

/// 本地已消失、且**云端零文件**在其下的已登记目录 —— 这些空目录该发 RMDIR,让「删掉空文件夹」
/// 也能同步到云端(与空文件夹上行 MKDIR 对称;从前只上不下,空目录删了云端永远留着)。
///
/// 三重保守,确保永不误删:
/// - 只看 `registered`(本客户端 MKDIR 成功后登记的目录):服务端下发建在本地的目录不在其中,
///   哪怕本地被删也绝不 RMDIR —— 把「删空文件夹」这件事严格限定在自己造的那批;
/// - 底下**只要还有一条文件行**(含占位/只读/未下载)就跳过:那些文件各有各的删除判定
///   (占位受保护、已下载的走逐文件删除 + 批量删除安全阀),目录等它们清干净、下一轮再成候选。
///   据此 RMDIR 永远删不到任何文件;
/// - 上一轮 RMDIR 失败的按退避等(同 MKDIR),不每轮重发。
///
/// 深的排前:嵌套空目录先删子再删父,服务端看到的每一个都是空的。
fn folders_to_rmdir(
    registered: &HashSet<String>, on_disk: &HashSet<String>, rows: &HashMap<String, FileRow>,
    errors: &HashMap<String, FileErrorRow>, now: i64,
) -> Vec<String> {
    let mut targets: Vec<String> = registered
        .iter()
        .filter(|dir| !on_disk.contains(dir.as_str()))
        .filter(|dir| !is_server_managed_dir(dir))
        .filter(|dir| retry_due(errors.get(dir.as_str()), now))
        .filter(|dir| {
            let prefix = format!("{dir}/");
            !rows.keys().any(|path| path.starts_with(&prefix))
        })
        .cloned()
        .collect();
    targets.sort_by(|left, right| right.len().cmp(&left.len()));
    targets
}

/// 服务端自己管的目录,客户端一个字都别插手。
///
/// 项目根下的 `session/` 由归档接口按需建(契约 §6.12),而且它整个不进同步集 —— 我们去建它
/// 只会和服务端抢同一个位置。深层的同名目录是用户自己的东西,照常同步。
fn is_server_managed_dir(path: &str) -> bool {
    path == "session"
}

/// 「目录已经存在」的各种说法。服务端在这一格上没有统一约定(OK / CONFLICT / ERROR 都见过),
/// 而我们发的是整条链,上面几级本来就大概率已经在了 —— 认出来就静默当成功。
fn mkdir_already_exists(result: &BatchResult) -> bool {
    if result.status == BatchStatus::Conflict {
        return true;
    }
    let message = result.message.as_deref().unwrap_or_default();
    message.to_ascii_uppercase().contains("EXIST") || message.contains("已存在")
}

/// RMDIR 遇到「目录本来就没了」当成功:目标状态(云端没这个空目录)已经达成。
/// 覆盖 CONFLICT(远端已删)与各类「NOT FOUND / 不存在」措辞。
fn rmdir_already_gone(result: &BatchResult) -> bool {
    if result.status == BatchStatus::Conflict {
        return true;
    }
    let message = result.message.as_deref().unwrap_or_default();
    let upper = message.to_ascii_uppercase();
    upper.contains("NOT_FOUND") || upper.contains("NOT FOUND") || message.contains("不存在")
}

fn op_id(index: usize, op: &PendingOp) -> String {
    format!("{index}:{}", op.path)
}

fn batch_op(index: usize, op: &PendingOp) -> BatchOp {
    let scanned = op.scanned.as_ref();
    BatchOp {
        op_id: op_id(index, op),
        op: op.kind,
        path: op.path.clone(),
        new_path: op.new_path.clone(),
        sha256: scanned.map(|file| file.sha256.clone()),
        size: scanned.map(|file| file.size),
        mime_type: None,
        base_version_id: op.row.as_ref().and_then(|row| row.remote_version_id.clone()),
        file_id: op.row.as_ref().and_then(|row| row.remote_file_id.clone()),
    }
}

fn remote_file_from_snapshot(file: &crate::types::SnapshotFile) -> RemoteFile {
    RemoteFile {
        file_id: file.file_id.clone(),
        path: file.path.clone(),
        version_id: file.version_id.clone(),
        sha256: file.sha256.clone(),
        size: file.size,
        cloud_only: file.cloud_only,
        cloud_only_reason: file.cloud_only_reason.clone(),
        read_only: file.read_only,
        updated_by: None,
        collab_active: file.collab_active,
    }
}

fn remote_file_from_event(event: &ChangeEvent) -> Result<RemoteFile, EngineError> {
    Ok(RemoteFile {
        file_id: event.file_id.clone().ok_or_else(|| EngineError::Io(format!("事件 {} 缺 fileId", event.seq)))?,
        path: event.path.clone(),
        version_id: event.version_id.clone(),
        sha256: event.sha256.clone(),
        size: event.size,
        cloud_only: event.cloud_only,
        cloud_only_reason: event.cloud_only_reason.clone(),
        read_only: event.read_only,
        updated_by: event.actor_id.as_ref().map(|actor| actor.as_key()),
        collab_active: event.collab_active,
    })
}

/// 已经与云端一致的文件该显示成什么状态。只读优先于协同:两者同时成立时,用户最需要知道的
/// 是「这份文件我改不了」,而不是「有人正在一起编辑」。
fn synced_state(read_only: bool, collab_active: bool) -> FileState {
    match (read_only, collab_active) {
        (true, _) => FileState::ReadOnly,
        (false, true) => FileState::Collab,
        (false, false) => FileState::Synced,
    }
}

fn local_matches_row(local: &Path, row: &FileRow) -> Result<bool, EngineError> {
    let metadata = std::fs::metadata(local).map_err(|error| io_error(format!("stat {}", local.display()), error))?;
    if row.mtime_ms == file_mtime_ms(&metadata) && row.size == metadata.len() {
        return Ok(true);
    }
    let sha = sha256_file(local).map_err(EngineError::Io)?;
    Ok(row.sha256.as_deref() == Some(sha.as_str()))
}

/// 「这份文件**从来没落到盘上**」还是「落过、又被用户删了」—— 推送删除前必须分清的那条线。
///
/// 判据:文件不在,**而且它所在的目录整个不存在**。
/// - *从没落盘*(镜像脱节):下行连目录都没建出来 —— 目录不存在;
/// - *用户删文件*:他删的是文件,目录是他打开过、还在用的 —— 目录仍在。
///
/// 判成「从没落盘」时**绝不当成删除上行**(那会把云端那份删进回收站),而是退回待下载补下来。
///
/// **为什么判据只到「目录不存在」为止**:一版曾把「目录在、但空着」也算进来,当场打挂三条既有
/// 用例 —— 「删掉一个目录里最后一个文件」「把文件移出目录(旧目录空了)」都是天天在做的正常操作,
/// 全被误判成没落盘。宁可判据窄一点、漏掉「目录在但空着」那种脱节(那种由下行侧的重下兜),
/// 也不能把用户正常的删除与移动废掉。
fn never_landed(local: &Path) -> bool {
    if local.exists() {
        return false;
    }
    // 目录不存在(或读不了)= 这条行的内容从来没有落下来过
    local.parent().is_some_and(|parent| !parent.is_dir())
}

fn write_file(path: &Path, bytes: &[u8]) -> Result<(), EngineError> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).map_err(|error| io_error(format!("创建 {}", parent.display()), error))?;
    }
    std::fs::write(path, bytes).map_err(|error| io_error(format!("写 {}", path.display()), error))
}

/// 自底向上删空目录(不删非空的)。
fn remove_empty_dirs(dir: &Path) {
    if !dir.is_dir() {
        return;
    }
    if let Ok(entries) = std::fs::read_dir(dir) {
        for entry in entries.flatten() {
            if entry.path().is_dir() {
                remove_empty_dirs(&entry.path());
            }
        }
    }
    let _ = std::fs::remove_dir(dir);
}

/// 搬完之后收走空掉的老落点 `<skills_dir>/yup/`。
///
/// **有 `SKILL.md` 就一个字节都不碰** —— 那是公司自己那个 `yup` skill,我们本来就不该
/// 占这个名字。里面还剩别的东西也不动:不确定是谁的,就留给人自己看(移动不是删除,
/// 而这里连移都不移)。只有「确实空了」才 `remove_dir`(它对非空目录本来就会失败)。
fn remove_empty_legacy_skill_dir(legacy_root: &Path) {
    if !legacy_root.is_dir() || legacy_root.join("SKILL.md").exists() {
        return;
    }
    let Ok(mut entries) = std::fs::read_dir(legacy_root) else { return };
    if entries.next().is_some() {
        return;
    }
    let _ = std::fs::remove_dir(legacy_root);
}

#[cfg(test)]
mod threshold_tests {
    use super::{DEFAULT_MAX_AUTO_DOWNLOAD_BYTES, resolve_max_auto_download_bytes as resolve};

    #[test]
    fn 阈值优先级_用户动过的最大() {
        // 用户在设置页改过 → 服务端说什么都不覆盖他(下发的是默认值,不是命令)
        assert_eq!(resolve(Some(50), Some(10 * 1024 * 1024)), 50 * 1024 * 1024);
        // 0 是有意义的取值:不设限、全都自动下。不能被当成「没设过」
        assert_eq!(resolve(Some(0), Some(10 * 1024 * 1024)), 0);
        // 没动过 → 跟服务端走
        assert_eq!(resolve(None, Some(20 * 1024 * 1024)), 20 * 1024 * 1024);
        // 服务端也没给(老服务端 / 接口挂)→ 内置默认,行为退回今天
        assert_eq!(resolve(None, None), DEFAULT_MAX_AUTO_DOWNLOAD_BYTES);
        assert_eq!(DEFAULT_MAX_AUTO_DOWNLOAD_BYTES, 10 * 1024 * 1024);
    }
}

#[cfg(test)]
mod rmdir_tests {
    use std::collections::{HashMap, HashSet};

    use super::{FileRow, folders_to_rmdir};
    use crate::types::{FileState, RemoteId};

    fn dirs(paths: &[&str]) -> HashSet<String> {
        paths.iter().map(|p| p.to_string()).collect()
    }

    fn rows_with(paths: &[&str]) -> HashMap<String, FileRow> {
        paths
            .iter()
            .map(|p| {
                (
                    p.to_string(),
                    FileRow {
                        project_id: RemoteId::Number(1),
                        path: p.to_string(),
                        remote_file_id: Some(RemoteId::Number(1)),
                        remote_version_id: None,
                        sha256: Some("x".into()),
                        size: 1,
                        mtime_ms: 0,
                        state: FileState::Synced,
                        collab_active: false,
                        read_only: false,
                    },
                )
            })
            .collect()
    }

    #[test]
    fn 本地消失且云端零文件的登记目录_才发rmdir() {
        let registered = dirs(&["a", "b/c"]);
        let on_disk = dirs(&["b"]); // a 和 b/c 都从盘上没了;b 还在
        let rows = HashMap::new();
        let mut out = folders_to_rmdir(&registered, &on_disk, &rows, &HashMap::new(), 0);
        out.sort();
        assert_eq!(out, vec!["a".to_string(), "b/c".to_string()]);
    }

    #[test]
    fn 底下还有文件行的目录_一律不碰() {
        // a 从盘上没了,但云端 a/ 下还有文件(占位/只读/已下载都算)→ 不 RMDIR,让文件删除先走
        let registered = dirs(&["a"]);
        let on_disk = HashSet::new();
        let rows = rows_with(&["a/keep.md"]);
        assert!(folders_to_rmdir(&registered, &on_disk, &rows, &HashMap::new(), 0).is_empty());
    }

    #[test]
    fn 还在盘上的目录_不发rmdir() {
        let registered = dirs(&["a"]);
        let on_disk = dirs(&["a"]);
        assert!(folders_to_rmdir(&registered, &on_disk, &HashMap::new(), &HashMap::new(), 0).is_empty());
    }

    #[test]
    fn 未登记的目录_绝不rmdir() {
        // 服务端下发建在本地的目录不在 registered 里:哪怕本地删了、云端也没文件,也不碰
        let registered = HashSet::new();
        let on_disk = HashSet::new();
        assert!(folders_to_rmdir(&registered, &on_disk, &HashMap::new(), &HashMap::new(), 0).is_empty());
    }

    #[test]
    fn 嵌套空目录_深的排前() {
        let registered = dirs(&["a", "a/b", "a/b/c"]);
        let on_disk = HashSet::new();
        let out = folders_to_rmdir(&registered, &on_disk, &HashMap::new(), &HashMap::new(), 0);
        // 先子后父:每个 RMDIR 时目标都是空的
        assert_eq!(out, vec!["a/b/c".to_string(), "a/b".to_string(), "a".to_string()]);
    }
}

#[cfg(test)]
mod drift_tests {
    use super::*;

    #[test]
    fn 路径里的字不该被当成错误原因() {
        let in_my_space = EngineError::Io("重命名 /Users/x/YUP Drive/我的空间/知识库/指标分析/a.md 失败".into());
        let text = humanize(&in_my_space);
        assert!(!text.contains("磁盘空间"), "路径里有「空间」两个字,不等于磁盘满:{text}");
        assert!(text.contains("我的空间/知识库/指标分析"), "认不出来的就原样透出:{text}");
        assert!(humanize(&EngineError::Io("write: No space left on device".into())).contains("磁盘空间不够"));
        assert!(humanize(&EngineError::Io("open: Permission denied".into())).contains("没有读写权限"));
    }

    /// 服务端把话说死的那些失败,不能再进退避表空转。判据写在 `settled_by_server` 上,
    /// 这里盯住它别被人随手加错 —— 超时 / 5xx / 存储抖动都可能下一次就好了,不属于这一类。
    #[test]
    fn 服务端说死的失败不再重试() {
        assert!(settled_by_server("FOLDER_NOT_EMPTY: 目录非空（含 1 个文件 / 0 个子目录），请使用递归删除"));
        assert!(settled_by_server("PARENT_FOLDER_NOT_FOUND: 上级目录不存在"));
        assert!(settled_by_server("FORBIDDEN"));
        // 服务端有些地方回的是 i18n key 原文,大小写和这里的常量对不上 ——
        // 对不上就会被当成「可重试」,于是 24 条 MKDIR 永远挂在「下一轮就再试」
        // 而用户根本没有写权限(2026-09-23 实报)
        assert!(settled_by_server("common.forbidden"), "i18n key 原文也要认出来");
        assert!(settled_by_server("common.not_found"));
        assert!(settled_by_server("NAME_CONFLICT: 同名文件已存在"));

        assert!(!settled_by_server("TIMEOUT: 上游超时"), "超时下一次可能就好了");
        assert!(!settled_by_server("INTERNAL_ERROR: 存储层异常"), "5xx 留给退避");
        assert!(!settled_by_server("OK"));
    }

    /// 「等会儿再来」和「索引对不上了」是两回事。混为一谈的后果是 AI 连着改文档时
    /// 每一轮都触发一次全量对账(2026-09-15 自查时逮到,当时 Busy 还是 Io)。
    #[test]
    fn 只有索引真的漂了才值得全量对账() {
        assert!(is_drift(&EngineError::Io("写盘失败".into())));
        assert!(is_drift(&EngineError::Index("写索引失败".into())));
        assert!(!is_drift(&EngineError::Busy("正在被写入".into())), "等会儿再来 ≠ 索引漂了");
        assert!(!is_drift(&EngineError::Client(ClientError::Transport("断网".into()))));
        assert!(!is_drift(&EngineError::Client(ClientError::Http { status: 404, message: String::new() })));
    }
}

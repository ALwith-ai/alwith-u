//! 文件名约定:冲突副本、`.yupcloud` 占位、Windows 非法字符映射。
//!
//! 云端路径一律 `/` 分隔、不以 `/` 开头;索引里保存云端原名,本地名只在落盘时映射。

use std::path::{Path, PathBuf};

use chrono::{DateTime, Local};

pub const CLOUD_ONLY_EXTENSION: &str = "yupcloud";

/// Windows 非法字符 → 全角同形字(`: * ? " < > |`)。
const WINDOWS_ILLEGAL: [(char, char); 7] =
    [(':', '：'), ('*', '＊'), ('?', '？'), ('"', '＂'), ('<', '＜'), ('>', '＞'), ('|', '｜')];

/// 冲突副本:`<stem>（冲突副本 · <用户名> · <YYYY-MM-DD HHmm>）<ext>`。
/// 隐藏文件(`.gitignore`)的前导点不算扩展名。
pub fn conflict_copy_name(file_name: &str, user_name: &str, at: DateTime<Local>) -> String {
    let (stem, extension) = split_extension(file_name);
    format!("{stem}（冲突副本 · {user_name} · {}）{extension}", at.format("%Y-%m-%d %H%M"))
}

/// 拆 `stem` / `.ext`(ext 含点;无扩展名或隐藏文件 → ext 为空)。
pub fn split_extension(file_name: &str) -> (&str, &str) {
    match file_name.rfind('.') {
        Some(index) if index > 0 => (&file_name[..index], &file_name[index..]),
        _ => (file_name, ""),
    }
}

/// cloudOnly 文件本地占位名:`<name>.yupcloud`。
pub fn cloud_only_placeholder_name(name: &str) -> String {
    format!("{name}.{CLOUD_ONLY_EXTENSION}")
}

pub fn is_cloud_only_placeholder(path: &Path) -> bool {
    path.extension().is_some_and(|extension| extension == CLOUD_ONLY_EXTENSION)
}

/// 「仅云端」的原因。**服务端目前不给这个字段**(snapshot / changes 里只有 `cloudOnly: bool`),
/// 客户端只在自己确知时才填,其余一律 `Unknown` —— 猜一个原因写进文件,比不写还糟。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CloudOnlyReason {
    /// 归档项目(`ai-session-archive`)整个不落盘。项目 key 客户端自己就能看出来
    Archive,
    /// AI 对话原文(服务端 `ContentKind.isSession`)。**要等服务端给字段**,客户端判不出来
    Session,
    /// 对这个文件没有 DOWNLOAD 权(水印 / 禁下载)。同上,要等服务端给字段
    NoDownloadPermission,
    /// 服务端没说。别猜
    Unknown,
    /// **不是「仅云端」** —— 它下得下来,只是超过了自动下载阈值,先没下(2026-09-07 老板拍板:
    /// 大文件不自动下载,标注,按需下载)。占位里那句话必须说清这一点:
    /// 挂 cloudOnly 那套说辞(「可能你没有下载权限 / 可能是 AI 对话原文」)是**反的**,
    /// 会让人和 AI 都以为这份文件根本拿不到,而它点一下就来。
    TooLarge,
}

impl CloudOnlyReason {
    /// 机器可读的取值,与服务端将来要给的 `cloudOnlyReason` 对齐
    pub fn as_str(self) -> &'static str {
        match self {
            CloudOnlyReason::Archive => "archive",
            CloudOnlyReason::Session => "session",
            CloudOnlyReason::NoDownloadPermission => "no_download_permission",
            CloudOnlyReason::Unknown => "unknown",
            CloudOnlyReason::TooLarge => "too_large",
        }
    }

    /// 服务端将来给了 `cloudOnlyReason` 就照它来;认不出的取值当没说
    pub fn parse(value: &str) -> Self {
        match value {
            "archive" => CloudOnlyReason::Archive,
            "session" => CloudOnlyReason::Session,
            "no_download_permission" => CloudOnlyReason::NoDownloadPermission,
            "too_large" => CloudOnlyReason::TooLarge,
            _ => CloudOnlyReason::Unknown,
        }
    }

    fn human(self) -> &'static str {
        match self {
            CloudOnlyReason::Archive => "它属于 AI 对话归档项目,按规定只留在云端,不落任何人的盘。",
            CloudOnlyReason::Session => "它是一份 AI 对话原文,按规定只留在云端,不落任何人的盘。",
            CloudOnlyReason::NoDownloadPermission => "你对这个文件没有下载权限(水印 / 禁止下载)。",
            CloudOnlyReason::TooLarge => {
                "它超过了自动下载的大小阈值,所以先没下 —— **不是拿不到**。在 alwith 的文件树里点这一行就会下载它,下完自动打开。"
            }
            CloudOnlyReason::Unknown => {
                "服务端没有说明原因。可能是你对它没有下载权限,也可能它是一份 AI 对话原文(这类内容按规定不落盘)。"
            }
        }
    }
}

/// 占位文件的内容。
///
/// **人话在前、JSON 在后**,而且第一句就说「这不是文件内容」—— AI 是从头读的。以前这里只有
/// 一段裸 JSON(`{fileId, humanUrl}`),AI 在项目里读到 `README.md.yupcloud` 看到的就是那 102 个
/// 字节:既不知道这不是正文,也不知道怎么拿到正文,最糟的情况是把这段 JSON 当文档去分析,
/// 而且不自知(2026-09-04 实报)。
///
/// 下一步必须是**可执行**的,所以三条路都给完整地址,不让读者自己去拼。
/// 占位文件新格式的第一句。用来认出老格式(一段裸 JSON)好把它升级掉。
pub const PLACEHOLDER_HEADLINE: &str = "这不是文件内容。";

pub fn cloud_only_placeholder_content(
    file_id: &crate::types::RemoteId, file_name: &str, reason: CloudOnlyReason, base_url: &str,
    web_base_url: Option<&str>, size: u64,
) -> String {
    let content_url = format!("{}/api/v1/ai/files/content?fileId={file_id}", base_url.trim_end_matches('/'));
    let human_url = web_base_url.map(|web| format!("{}/file/{file_id}", web.trim_end_matches('/')));

    let mut text = String::new();
    text.push_str(PLACEHOLDER_HEADLINE);
    // 「太大先没下」与「仅云端」是两件事,开头这句就得分开说 —— 一份点一下就能拿到的表格,
    // 顶着「仅云端」三个字会让人(和读目录的 AI)直接放弃它
    if reason == CloudOnlyReason::TooLarge {
        text.push_str("这是 YUP Drive 的「尚未下载」占位符 —— 真实文件在云端,还没下到本地。\n\n");
    } else {
        text.push_str("这是 YUP Drive 的「仅云端」占位符 —— 同名的真实文件没有下载到本地。\n\n");
    }
    text.push_str(&format!("文件名:{file_name}\n"));
    if size > 0 {
        text.push_str(&format!("大小:{size} 字节\n"));
    }
    text.push_str(&format!("为什么没下载:{}\n\n", reason.human()));
    text.push_str("要读到真实内容,任选其一:\n");
    text.push_str(&format!("  1. 用 yup-kb skill:搜索「{file_name}」,或直接按 fileId {file_id} 读取\n"));
    text.push_str(&format!("  2. 调接口:GET {content_url}\n"));
    if let Some(human_url) = &human_url {
        text.push_str(&format!("  3. 在网页打开:{human_url}\n"));
    }
    text.push_str("\n--- 机器可读 ---\n");
    let mut machine = serde_json::json!({
        "placeholder": "yup-drive",
        "fileId": file_id,
        "fileName": file_name,
        "reason": reason.as_str(),
        "contentUrl": content_url,
        // 文件树上那一行要显示「多大」,而占位文件本身是唯一一份冷启动时不必问引擎就有的来源
        "size": size,
    });
    // 拿不到 web 端地址就不写这个字段 —— 宁可没有,也不给一个打不开的链接
    if let Some(human_url) = human_url {
        machine["humanUrl"] = serde_json::Value::String(human_url);
    }
    text.push_str(&serde_json::to_string_pretty(&machine).expect("placeholder json is serializable"));
    text.push('\n');
    text
}

/// 云端文件名 → 本地文件名。`windows_names` 为真时把非法字符映射成全角。
pub fn to_local_component(name: &str, windows_names: bool) -> String {
    if !windows_names {
        return name.to_string();
    }
    name.chars()
        .map(|character| WINDOWS_ILLEGAL.iter().find(|(from, _)| *from == character).map_or(character, |(_, to)| *to))
        .collect()
}

/// 本地文件名 → 云端文件名(全角还原)。
pub fn to_cloud_component(name: &str, windows_names: bool) -> String {
    if !windows_names {
        return name.to_string();
    }
    name.chars()
        .map(|character| WINDOWS_ILLEGAL.iter().find(|(_, to)| *to == character).map_or(character, |(from, _)| *from))
        .collect()
}

/// 云端相对路径 → 本地相对路径。
pub fn cloud_to_local_relative(cloud_path: &str, windows_names: bool) -> PathBuf {
    cloud_path
        .split('/')
        .filter(|segment| !segment.is_empty())
        .map(|segment| to_local_component(segment, windows_names))
        .collect()
}

/// 本地相对路径 → 云端相对路径(`/` 分隔)。
pub fn local_to_cloud_relative(local_relative: &Path, windows_names: bool) -> String {
    local_relative
        .components()
        .map(|component| to_cloud_component(&component.as_os_str().to_string_lossy(), windows_names))
        .collect::<Vec<_>>()
        .join("/")
}

/// 云端路径的父目录与文件名。
pub fn split_cloud_path(cloud_path: &str) -> (&str, &str) {
    match cloud_path.rfind('/') {
        Some(index) => (&cloud_path[..index], &cloud_path[index + 1..]),
        None => ("", cloud_path),
    }
}

pub fn join_cloud_path(parent: &str, name: &str) -> String {
    if parent.is_empty() { name.to_string() } else { format!("{parent}/{name}") }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::TimeZone;

    #[test]
    fn 冲突副本按契约命名() {
        let at = Local.with_ymd_and_hms(2026, 9, 4, 15, 7, 0).unwrap();
        assert_eq!(conflict_copy_name("报告.md", "张三", at), "报告（冲突副本 · 张三 · 2026-09-04 1507）.md");
        assert_eq!(
            conflict_copy_name("archive.tar.gz", "张三", at),
            "archive.tar（冲突副本 · 张三 · 2026-09-04 1507）.gz"
        );
        assert_eq!(conflict_copy_name(".gitignore", "张三", at), ".gitignore（冲突副本 · 张三 · 2026-09-04 1507）");
        assert_eq!(conflict_copy_name("Makefile", "张三", at), "Makefile（冲突副本 · 张三 · 2026-09-04 1507）");
    }

    #[test]
    fn windows_非法字符映射为全角且可还原() {
        let cloud = "附录1: 专题分析规范方案*?.md";
        let local = to_local_component(cloud, true);
        assert_eq!(local, "附录1： 专题分析规范方案＊？.md");
        assert_eq!(to_cloud_component(&local, true), cloud);
        assert_eq!(to_local_component(cloud, false), cloud);
        assert_eq!(cloud_to_local_relative("a:b/c|d.txt", true), PathBuf::from("a：b").join("c｜d.txt"));
        assert_eq!(local_to_cloud_relative(&PathBuf::from("a：b").join("c｜d.txt"), true), "a:b/c|d.txt");
    }

    #[test]
    fn 占位文件名() {
        assert_eq!(cloud_only_placeholder_name("secret.pdf"), "secret.pdf.yupcloud");
        assert!(is_cloud_only_placeholder(Path::new("x/secret.pdf.yupcloud")));
        assert!(!is_cloud_only_placeholder(Path::new("x/secret.pdf")));
    }

    fn placeholder(reason: CloudOnlyReason) -> String {
        cloud_only_placeholder_content(
            &crate::types::RemoteId::Number(4098),
            "README_知识库导览.md",
            reason,
            "https://kb.example.com",
            Some("https://web.example.com"),
            0,
        )
    }

    /// 占位文件是给**人和 AI**读的:第一句就得说清「这不是文件内容」,而且拿真内容的路要可执行。
    #[test]
    fn 占位内容先说人话再给机器读的_json() {
        let content = placeholder(CloudOnlyReason::Unknown);
        assert!(content.starts_with(PLACEHOLDER_HEADLINE), "AI 是从头读的,第一句必须是「这不是文件内容」");
        let headline_at = 0;
        let json_at = content.find("--- 机器可读 ---").expect("要有机器可读段");
        assert!(headline_at < json_at, "人话在前、JSON 在后");

        // 光有 fileId 人看不懂,文件名要带上
        assert!(content.contains("README_知识库导览.md"));
        // 三条路都得是能直接照着做的,不让读者自己拼地址
        assert!(content.contains("https://kb.example.com/api/v1/ai/files/content?fileId=4098"));
        assert!(content.contains("https://web.example.com/file/4098"));
        assert!(content.contains("yup-kb skill"));

        let machine: serde_json::Value = serde_json::from_str(&content[json_at + "--- 机器可读 ---".len()..]).unwrap();
        assert_eq!(machine["placeholder"], "yup-drive");
        assert_eq!(machine["fileId"], 4098);
        assert_eq!(machine["fileName"], "README_知识库导览.md");
        assert_eq!(machine["reason"], "unknown");
        assert_eq!(machine["contentUrl"], "https://kb.example.com/api/v1/ai/files/content?fileId=4098");
        assert_eq!(machine["humanUrl"], "https://web.example.com/file/4098");
    }

    /// 三种真实原因各有各的说法;服务端没给就写「未知」并把可能性列清楚,**不猜**。
    #[test]
    fn 三种原因各有各的人话_未知时不瞎猜() {
        let archive = placeholder(CloudOnlyReason::Archive);
        assert!(archive.contains("AI 对话归档项目"));
        assert!(archive.contains("\"reason\": \"archive\""));

        let session = placeholder(CloudOnlyReason::Session);
        assert!(session.contains("AI 对话原文"));
        assert!(session.contains("\"reason\": \"session\""));

        let denied = placeholder(CloudOnlyReason::NoDownloadPermission);
        assert!(denied.contains("没有下载权限"));
        assert!(denied.contains("\"reason\": \"no_download_permission\""));

        let unknown = placeholder(CloudOnlyReason::Unknown);
        assert!(unknown.contains("服务端没有说明原因"), "不知道就说不知道");
        assert!(unknown.contains("\"reason\": \"unknown\""));
    }

    /// 拿不到 web 端地址时不写那条 —— 宁可少一条路,也不给一个打不开的链接。
    #[test]
    fn 没有_web_端地址时不给打不开的链接() {
        let content = cloud_only_placeholder_content(
            &crate::types::RemoteId::Number(7),
            "a.md",
            CloudOnlyReason::Archive,
            "https://kb.example.com",
            None,
            0,
        );
        assert!(!content.contains("在网页打开"));
        assert!(!content.contains("humanUrl"));
        // 另外两条路照给
        assert!(content.contains("contentUrl"));
    }

    /// 服务端将来给了 `cloudOnlyReason` 就照它来;没见过的取值当作没说,不要整帧丢掉。
    #[test]
    fn 原因取值与服务端对齐() {
        assert_eq!(CloudOnlyReason::parse("archive"), CloudOnlyReason::Archive);
        assert_eq!(CloudOnlyReason::parse("session"), CloudOnlyReason::Session);
        assert_eq!(CloudOnlyReason::parse("no_download_permission"), CloudOnlyReason::NoDownloadPermission);
        assert_eq!(CloudOnlyReason::parse("something_new"), CloudOnlyReason::Unknown);
        assert_eq!(CloudOnlyReason::Archive.as_str(), "archive");
    }

    #[test]
    fn 云端路径拆分() {
        assert_eq!(split_cloud_path("a/b/c.txt"), ("a/b", "c.txt"));
        assert_eq!(split_cloud_path("c.txt"), ("", "c.txt"));
        assert_eq!(join_cloud_path("", "c.txt"), "c.txt");
        assert_eq!(join_cloud_path("a", "c.txt"), "a/c.txt");
    }
}

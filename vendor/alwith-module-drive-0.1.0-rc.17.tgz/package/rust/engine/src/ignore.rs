//! 忽略规则:`.yupignore`(gitignore 语法)+ 契约默认排除 + 单文件上行上限(服务端下发,内置默认 500 MB)。

use std::path::Path;

use ignore::gitignore::{Gitignore, GitignoreBuilder};

/// 契约默认排除。
pub const DEFAULT_IGNORES: &[&str] = &[
    ".git",
    ".alwith",
    ".claude",
    "node_modules",
    "dist",
    "build",
    "target",
    "__pycache__",
    ".DS_Store",
    ".env*",
    "*.lock",
    "*.log",
    "*.zip",
    "*.tar*",
    "*.7z",
    "*.rar",
    // Office / WPS / LibreOffice 保存时留下的机器垃圾。用户在 Word 里改一份 docx,同目录会多出
    // 一个 `~$方案.docx`(属主锁)和一个 `Word Work File D_1.tmp`(保存中转)——它们几秒后就没了,
    // 但同步引擎的一轮扫描完全可能撞上,于是这些东西被推到公司知识库里。
    //
    // **故意没有加宽到 `*.tmp`**:知识库里可能真有人存了一份 `.tmp`,而新增忽略规则会让已经
    // 同步过的那份被当成「本地删了」推一条删除上去 —— 为了扫掉噪音去删别人云端的文件不划算。
    "~$*",
    ".~lock.*#",
    "Word Work File *",
];

pub const YUPIGNORE_FILE: &str = ".yupignore";

/// 单文件上行上限的**内置默认**:超过标记 `SKIPPED_TOO_LARGE`,不阻塞。
///
/// 真正生效的数由 `resolve_max_upload_bytes` 决定 —— 服务端 `GET /client/config` 下发
/// `maxUploadBytes`,拿到就用它;这个常量只在首次启动还没问到配置时兜底。
///
/// 为什么是 500 MB:这就是服务端的真实上限。它从前写成 200 MB 是抄错了(2026-09-07 实报),
/// 于是 200–500 MB 的文件被客户端提前判成 `TooLarge` 跳过,用户看到「太大不同步」,
/// 而服务端本来收得下。
pub const DEFAULT_MAX_FILE_SIZE: u64 = 500 * 1024 * 1024;

/// 「上行上限」到底用哪个数:**服务端下发的 > 用户显式设置的 > 内置默认**。
///
/// 与自动下载阈值(`engine::resolve_max_auto_download_bytes`)的顺序**相反**,因为性质不同:
/// 那个是偏好,服务端给的只是默认值;这个是服务端的硬上限 —— 用户填得再大服务端也不收,
/// 填得更小则是他自找的。所以服务端一旦说了话就以它为准。
///
/// `0` 一律是**不设限**,不是「一个字节都不许传」:服务端契约就这么定义,用户设成 0 也照此理解。
/// 服务端没给(老服务端 / 首次启动还没问到)才轮到用户的值,再没有才用内置默认。
pub fn resolve_max_upload_bytes(server_bytes: Option<u64>, user_megabytes: Option<u64>) -> u64 {
    if let Some(bytes) = server_bytes {
        return bytes;
    }
    if let Some(megabytes) = user_megabytes {
        return megabytes.saturating_mul(1024 * 1024);
    }
    DEFAULT_MAX_FILE_SIZE
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Verdict {
    Sync,
    Ignored,
    TooLarge,
}

pub struct IgnoreRules {
    matcher: Gitignore,
    /// 单文件上行上限(字节)。**0 = 不设限**
    max_file_size: u64,
}

impl IgnoreRules {
    /// 读根目录下的 `.yupignore`(可缺席)并叠上默认排除。
    pub fn load(root: &Path) -> Result<Self, String> {
        let mut builder = GitignoreBuilder::new(root);
        for pattern in DEFAULT_IGNORES {
            builder.add_line(None, pattern).map_err(|error| format!("默认排除规则 {pattern} 非法: {error}"))?;
        }
        let yupignore = root.join(YUPIGNORE_FILE);
        if yupignore.is_file()
            && let Some(error) = builder.add(&yupignore)
        {
            return Err(format!("解析 {} 失败: {error}", yupignore.display()));
        }
        let matcher = builder.build().map_err(|error| format!("构建忽略规则失败: {error}"))?;
        Ok(Self { matcher, max_file_size: DEFAULT_MAX_FILE_SIZE })
    }

    /// 换上真正生效的上行上限(见 `resolve_max_upload_bytes`)。**0 = 不设限**。
    pub fn with_max_file_size(mut self, max_file_size: u64) -> Self {
        self.max_file_size = max_file_size;
        self
    }

    pub fn max_file_size(&self) -> u64 {
        self.max_file_size
    }

    /// `relative` 为相对根目录的路径。
    pub fn is_ignored(&self, relative: &Path, is_directory: bool) -> bool {
        // 逐级检查:父目录被忽略,子孙一律忽略(gitignore 语义)
        let mut current = std::path::PathBuf::new();
        let components: Vec<_> = relative.components().collect();
        for (index, component) in components.iter().enumerate() {
            current.push(component);
            let last = index + 1 == components.len();
            let directory = if last { is_directory } else { true };
            if self.matcher.matched(&current, directory).is_ignore() {
                return true;
            }
        }
        false
    }

    pub fn classify(&self, relative: &Path, size: u64) -> Verdict {
        if self.is_ignored(relative, false) {
            Verdict::Ignored
        } else if self.max_file_size != 0 && size > self.max_file_size {
            Verdict::TooLarge
        } else {
            Verdict::Sync
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn 默认排除生效() {
        let root = tempfile::tempdir().unwrap();
        let rules = IgnoreRules::load(root.path()).unwrap();
        for path in [
            ".git/HEAD",
            ".alwith/settings.json",
            ".claude/x",
            "node_modules/a/b.js",
            "dist/app.js",
            "build/x",
            "target/debug/a",
            "src/__pycache__/a.pyc",
            ".DS_Store",
            ".env",
            ".env.local",
            "bun.lock",
            "app.log",
            "a.zip",
            "a.tar",
            "a.tar.gz",
            "a.7z",
            "a.rar",
        ] {
            assert!(rules.is_ignored(Path::new(path), false), "{path} 应被忽略");
        }
        for path in ["README.md", "01_input/data.csv", "src/main.rs", "environment.md", "locks/notes.txt"] {
            assert!(!rules.is_ignored(Path::new(path), false), "{path} 不应被忽略");
        }
    }

    #[test]
    fn yupignore_叠加在默认之上() {
        let root = tempfile::tempdir().unwrap();
        std::fs::write(root.path().join(".yupignore"), "raw/\n*.parquet\n!keep.parquet\n").unwrap();
        let rules = IgnoreRules::load(root.path()).unwrap();
        assert!(rules.is_ignored(Path::new("raw/a.csv"), false));
        assert!(rules.is_ignored(Path::new("raw"), true));
        assert!(rules.is_ignored(Path::new("data/big.parquet"), false));
        assert!(!rules.is_ignored(Path::new("data/keep.parquet"), false));
        assert!(rules.is_ignored(Path::new("node_modules/x"), false));
        assert!(!rules.is_ignored(Path::new(".yupignore"), false));
    }

    #[test]
    fn 阈值判定() {
        let root = tempfile::tempdir().unwrap();
        let rules = IgnoreRules::load(root.path()).unwrap();
        assert_eq!(rules.classify(Path::new("a.bin"), DEFAULT_MAX_FILE_SIZE), Verdict::Sync);
        assert_eq!(rules.classify(Path::new("a.bin"), DEFAULT_MAX_FILE_SIZE + 1), Verdict::TooLarge);
        assert_eq!(rules.classify(Path::new("a.zip"), 1), Verdict::Ignored);
    }

    const MB: u64 = 1024 * 1024;

    #[test]
    fn 上行上限_服务端下发500mb时300mb的文件要同步() {
        let root = tempfile::tempdir().unwrap();
        // 从前常量写死 200 MB,这份文件会被提前判成 TooLarge —— 而服务端本来收得下
        let rules =
            IgnoreRules::load(root.path()).unwrap().with_max_file_size(resolve_max_upload_bytes(Some(500 * MB), None));
        assert_eq!(rules.classify(Path::new("a.bin"), 300 * MB), Verdict::Sync);
        assert_eq!(rules.classify(Path::new("a.bin"), 500 * MB), Verdict::Sync);
        assert_eq!(rules.classify(Path::new("a.bin"), 500 * MB + 1), Verdict::TooLarge);
    }

    #[test]
    fn 上行上限_0是不设限而不是一个字节都不许传() {
        let root = tempfile::tempdir().unwrap();
        let rules = IgnoreRules::load(root.path()).unwrap().with_max_file_size(resolve_max_upload_bytes(Some(0), None));
        assert_eq!(rules.classify(Path::new("a.bin"), 1), Verdict::Sync);
        assert_eq!(rules.classify(Path::new("a.bin"), 10 * 1024 * MB), Verdict::Sync);
        // 用户自己设成 0 也是同一个意思
        assert_eq!(resolve_max_upload_bytes(None, Some(0)), 0);
        // 忽略规则不受上限影响
        assert_eq!(rules.classify(Path::new("a.zip"), 1), Verdict::Ignored);
    }

    #[test]
    fn 上行上限_优先级_服务端大于用户大于内置默认() {
        // 服务端说了就以它为准,用户填得再大也没用(硬上限,不是偏好)
        assert_eq!(resolve_max_upload_bytes(Some(500 * MB), Some(900)), 500 * MB);
        // 服务端没给 → 用户的
        assert_eq!(resolve_max_upload_bytes(None, Some(100)), 100 * MB);
        // 都没有(首次启动还没问到配置 / 老服务端)→ 内置默认 500 MB
        assert_eq!(resolve_max_upload_bytes(None, None), DEFAULT_MAX_FILE_SIZE);
        assert_eq!(DEFAULT_MAX_FILE_SIZE, 500 * MB);
        let root = tempfile::tempdir().unwrap();
        let rules = IgnoreRules::load(root.path()).unwrap();
        assert_eq!(rules.max_file_size(), DEFAULT_MAX_FILE_SIZE);
        assert_eq!(rules.classify(Path::new("a.bin"), 300 * MB), Verdict::Sync);
    }
}

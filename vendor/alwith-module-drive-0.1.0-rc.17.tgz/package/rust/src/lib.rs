//! Shared Drive service. Hosts own window policy and agent/session integration.
pub use drive_sync as sync;
pub mod contract;
pub mod ownership;
pub mod profile;
pub mod service;

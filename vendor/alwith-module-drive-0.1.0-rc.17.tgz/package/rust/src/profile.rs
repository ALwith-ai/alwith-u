use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::io::Write;
use std::path::{Path, PathBuf};

#[derive(Clone, Serialize, Deserialize)]
pub struct Profile {
    pub base_url: String,
    pub token: String,
    pub device_id: String,
    pub user_name: String,
    pub user_id: String,
    pub local_root: PathBuf,
    pub web_base_url: Option<String>,
    #[serde(default)]
    pub max_auto_download_mb: Option<u64>,
    #[serde(default)]
    pub preferences: crate::contract::Preferences,
    #[serde(default)]
    pub client_config: drive_sync::types::ClientConfig,
}

impl Profile {
    pub fn identity(&self) -> String {
        hex::encode(Sha256::digest(format!("{}\0{}\0{}", self.base_url, self.user_id, self.local_root.display())))
    }
}

pub fn validate_url(raw: &str) -> Result<String, String> {
    let url = url::Url::parse(raw.trim()).map_err(|_| "Invalid Drive server URL")?;
    if !url.username().is_empty() || url.password().is_some() || url.query().is_some() || url.fragment().is_some() {
        return Err("Drive server URL must not contain credentials, query, or fragment".into());
    }
    if url.scheme() != "https"
        && !(url.scheme() == "http" && matches!(url.host_str(), Some("localhost" | "127.0.0.1" | "[::1]")))
    {
        return Err("Drive requires HTTPS (HTTP is allowed only for loopback tests)".into());
    }
    Ok(url.as_str().trim_end_matches('/').to_owned())
}

pub fn save(path: &Path, profile: &Option<Profile>) -> Result<(), String> {
    let parent = path.parent().ok_or("Profile must have a parent directory")?;
    std::fs::create_dir_all(parent).map_err(|error| error.to_string())?;
    let mut temporary = tempfile::NamedTempFile::new_in(parent).map_err(|error| error.to_string())?;
    serde_json::to_writer(&mut temporary, profile).map_err(|error| error.to_string())?;
    temporary.flush().map_err(|error| error.to_string())?;
    temporary.as_file().sync_all().map_err(|error| error.to_string())?;
    temporary.persist(path).map_err(|error| error.to_string())?;
    Ok(())
}

pub fn load(path: &Path) -> Result<Option<Profile>, String> {
    match std::fs::read(path) {
        Ok(bytes) => {
            let profile: Option<Profile> =
                serde_json::from_slice(&bytes).map_err(|error| format!("Invalid Drive profile: {error}"))?;
            if let Some(profile) = &profile {
                validate_url(&profile.base_url)?;
                if profile.token.is_empty()
                    || profile.user_id.is_empty()
                    || profile.device_id.is_empty()
                    || !profile.local_root.is_absolute()
                {
                    return Err("Invalid Drive profile identity".into());
                }
            }
            Ok(profile)
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Err(error) => Err(error.to_string()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn credentials_cannot_be_embedded_in_server_url() {
        assert!(validate_url("https://user:secret@kb.example.com").is_err());
        assert!(validate_url("http://kb.example.com").is_err());
        assert_eq!(validate_url("https://kb.example.com/").unwrap(), "https://kb.example.com");
        assert!(validate_url("http://127.0.0.1:1234").is_ok());
    }
}

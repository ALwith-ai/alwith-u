use drive_sync::types::*;
use serde::{Deserialize, Serialize};
use specta::Type;

pub const CONTRACT_VERSION: u32 = 1;

#[derive(Deserialize, Type)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum AccessRequestType {
    FileAccess,
    ProjectJoin,
}

#[derive(Serialize, Type)]
#[serde(rename_all = "camelCase")]
pub enum AccessRequestOutcome {
    Submitted,
    AlreadyPending,
}

#[derive(Clone, Serialize, Deserialize, Type)]
#[serde(rename_all = "camelCase")]
pub struct Snapshot {
    pub version: u32,
    pub generation: u32,
    pub sequence: u32,
    pub configured: bool,
    pub running: bool,
    pub base_url: String,
    pub local_root: String,
    pub web_base_url: Option<String>,
    pub status: Option<StatusSnapshot>,
    pub roots: Vec<RootInfo>,
    pub pending_deletes: Vec<PendingDeletes>,
    pub files: Vec<FileStateEvent>,
    pub projects: Vec<ProjectProgress>,
    pub error: Option<String>,
}

#[derive(Clone, Serialize, Deserialize, Type)]
#[serde(tag = "type", content = "data", rename_all = "camelCase")]
pub enum Payload {
    Snapshot(Snapshot),
    Status(StatusSnapshot),
    File(FileStateEvent),
    Project(ProjectProgress),
    Conflict(ConflictRecord),
    ReadOnly(ReadOnlyChange),
    Changed(Vec<String>),
    Reconcile,
    Comment(CommentEvent),
    Error(String),
}

#[derive(Clone, Serialize, Deserialize, Type)]
#[serde(rename_all = "camelCase")]
pub struct DriveEvent {
    pub version: u32,
    pub generation: u32,
    pub sequence: u32,
    pub payload: Payload,
}

#[derive(Clone, Serialize, Deserialize, Type)]
#[serde(rename_all = "camelCase")]
pub struct CommentEvent {
    pub file_id: RemoteId,
    pub comment_id: RemoteId,
    pub action: String,
    pub actor_id: Option<RemoteId>,
    pub at: Option<String>,
}

#[derive(Serialize, Type)]
#[serde(rename_all = "camelCase")]
pub struct Configuration {
    pub device_id: Option<String>,
    pub user_name: Option<String>,
    pub user_id: Option<String>,
    pub client_config: Option<ClientConfig>,
}

#[derive(Serialize, Type)]
#[serde(rename_all = "camelCase")]
pub struct CollabSession {
    pub file_id: RemoteId,
    pub server_url: String,
    pub room: String,
    pub token: String,
    pub can_write: bool,
}

#[derive(Serialize, Type)]
pub struct McpHeader {
    pub name: String,
    pub value: String,
}

#[derive(Serialize, Type)]
pub struct McpSessionConfig {
    pub url: String,
    pub headers: Vec<McpHeader>,
}

#[derive(Deserialize, Type)]
#[serde(tag = "type", rename_all = "camelCase", rename_all_fields = "camelCase")]
pub enum DriveRequest {
    Preferences,
    ArchivePrivateSessions,
    SetArchivePrivate {
        session_id: String,
        private: bool,
    },
    SetPreferences {
        session_archive: bool,
        knowledge_inject: bool,
    },
    ArchiveSession {
        expected_generation: u32,
        session_id: String,
        cwd: String,
        title: String,
        updated_at: String,
        content: String,
    },
    Configuration,
    Reconfigure {
        local_root: String,
        user_name: String,
    },
    RefreshClientConfig,
    McpSessionConfig,
    RetryUpload {
        project_id: RemoteId,
        path: String,
    },
    CloudFolders {
        project_id: RemoteId,
    },
    FileRemoteId {
        path: String,
    },
    CommentContext {
        path: String,
    },
    Comments {
        file_id: RemoteId,
    },
    CommentCreate {
        file_id: RemoteId,
        request: CreateCommentRequest,
    },
    CommentUpdate {
        comment_id: RemoteId,
        body: String,
    },
    CommentDelete {
        comment_id: RemoteId,
    },
    CommentApply {
        comment_id: RemoteId,
    },
    CommentWatch {
        owner_id: String,
        file_ids: Vec<RemoteId>,
    },
    CollabSession {
        path: String,
        owner_id: String,
    },
    CollabEnd {
        path: String,
        owner_id: String,
    },
    CondensePreflight {
        project_id: RemoteId,
        scope_path: Option<String>,
    },
    CondenseStart {
        project_id: RemoteId,
        scope_path: Option<String>,
    },
    Job {
        job_id: RemoteId,
    },
    ProposedCondense {
        project_id: RemoteId,
    },
    ApproveJob {
        job_id: RemoteId,
    },
    CancelJob {
        job_id: RemoteId,
    },
    KnowledgeContext {
        cwd: String,
    },
    SkillMirrors,
    ArchiveStatus,
    SyncProject {
        project_id: RemoteId,
    },
    Snapshot,
    MoveBetweenProjects {
        source: String,
        destination: String,
    },
    Login {
        base_url: String,
        token: String,
        local_root: String,
    },
    SsoConfig {
        base_url: String,
    },
    SsoLogin {
        base_url: String,
        local_root: String,
    },
    Logout,
    Start,
    Stop,
    MaxAutoDownloadMb,
    SetMaxAutoDownloadMb {
        megabytes: u64,
    },
    Pause {
        paused: bool,
    },
    Sync,
    Roots,
    Pin {
        project_id: RemoteId,
        pinned: bool,
    },
    Land {
        project_id: RemoteId,
    },
    File {
        path: String,
    },
    Download {
        project_id: RemoteId,
        path: String,
    },
    ConfirmDeletes {
        project_id: RemoteId,
    },
    CancelDeletes {
        project_id: RemoteId,
    },
    Templates,
    Departments,
    CreateProject {
        request: CreateProjectFromTemplateRequest,
    },
    Shared,
    FailedUploads,
    RetryUploads,
    Reconcile {
        project_id: Option<RemoteId>,
    },
    RecheckCloudOnly,
    DiskUsage {
        limit: u32,
    },
    CleanupScan,
    Cleanup {
        paths: Vec<String>,
    },
    OwnershipGuard,
    SyncAllPersonal {
        enabled: bool,
    },
    GrantTarget {
        path: String,
    },
    Grants {
        target: GrantTarget,
    },
    SetGrant {
        target: GrantTarget,
        request: SetGrantRequest,
    },
    RemoveGrant {
        target: GrantTarget,
        subject_type: String,
        subject_id: RemoteId,
    },
    SearchUsers {
        query: String,
    },
    SearchDepartments {
        query: String,
    },
    RequestAccess {
        request_type: AccessRequestType,
        target_id: RemoteId,
        message: Option<String>,
    },
    SaveVersion {
        path: String,
    },
    LocalPath {
        file_id: RemoteId,
    },
}

#[derive(Serialize, Type)]
#[serde(tag = "type", content = "data", rename_all = "camelCase")]
pub enum DriveResponse {
    ArchivePrivateSessions(Vec<String>),
    Preferences(Preferences),
    Configuration(Configuration),
    ClientConfig(ClientConfig),
    McpSessionConfig(Option<McpSessionConfig>),
    CloudFolders(Vec<drive_sync::CloudFolder>),
    CommentContext(Option<CommentContext>),
    Comments(Vec<FileComment>),
    Comment(FileComment),
    CollabSession(Option<CollabSession>),
    Unsynced(UnsyncedSummary),
    Job(Job),
    Jobs(Vec<Job>),
    Text(Option<String>),
    SkillMirrors(Vec<SkillMirror>),
    ArchiveStatus(ArchiveStatus),
    Count(u32),
    MaxAutoDownloadMb(u64),
    Snapshot(Snapshot),
    SsoConfig(SsoConfig),
    Roots(Vec<RootInfo>),
    Root(RootInfo),
    File(Option<FileStateEvent>),
    Templates(Vec<ProjectTemplate>),
    Departments(Vec<Department>),
    Shared(Vec<SharedItem>),
    FailedUploads(Vec<FailedUpload>),
    DiskUsage(DiskUsage),
    Cleanup(CleanupReport),
    OwnershipGuard(OwnershipGuard),
    GrantTarget(Option<GrantTarget>),
    Grants(GrantList),
    GrantWrite(GrantWriteOutcome),
    Users(Vec<UserBrief>),
    AccessRequest(AccessRequestOutcome),
    Id(Option<RemoteId>),
    Path(Option<String>),
    Done,
}

#[derive(Clone, Default, Serialize, Deserialize, Type)]
#[serde(rename_all = "camelCase")]
pub struct Preferences {
    pub session_archive: bool,
    pub knowledge_inject: bool,
}

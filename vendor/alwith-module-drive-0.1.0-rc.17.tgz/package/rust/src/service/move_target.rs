//! Move To policy for local destinations and cloud directories that have not landed.

use super::*;
use drive_sync::CloudFolder;
use drive_sync::index::FileRow;
use drive_sync::naming::local_to_cloud_relative;
use drive_sync::scanner::sha256_file;

fn project_path(root: &RootInfo, drive_root: &Path) -> Result<PathBuf, String> {
    let path = canonical_target(Path::new(&root.local_path))?;
    if path == drive_root || !path.starts_with(drive_root) {
        return Err("Drive project path escapes its owned directory".into());
    }
    Ok(path)
}

fn writable_project(root: &RootInfo) -> Result<(), String> {
    if !root.can_write || !root.sync_enabled || root.cloud_only || root.kind == ProjectKind::Skill {
        return Err("Move requires writable Drive projects".into());
    }
    Ok(())
}

fn containing_project<'a>(
    roots: &'a [RootInfo], path: &Path, drive_root: &Path,
) -> Result<Option<&'a RootInfo>, String> {
    let mut found = None;
    let mut longest = 0;
    for root in roots {
        if root.kind == ProjectKind::Skill || root.local_path.is_empty() {
            continue;
        }
        let candidate = project_path(root, drive_root)?;
        if path.starts_with(&candidate) && candidate.components().count() > longest {
            longest = candidate.components().count();
            found = Some(root);
        }
    }
    Ok(found)
}

fn cloud_directory_id(relative: &str, folders: &[CloudFolder]) -> Result<Option<RemoteId>, String> {
    if relative.is_empty() {
        return Ok(None);
    }
    if relative.split('/').any(|part| part.is_empty() || matches!(part, "." | "..")) {
        return Err("Invalid cloud directory path".into());
    }
    folders
        .iter()
        .find(|folder| folder.path == relative)
        .map(|folder| Some(folder.folder_id.clone()))
        .ok_or_else(|| "Cloud destination directory no longer exists".into())
}

fn uploaded_file(row: Option<&FileRow>, hash: &str) -> Result<(), String> {
    let row = row.ok_or("Upload the source before moving it to a cloud directory")?;
    if row.remote_file_id.is_none() || row.state != FileState::Synced || row.sha256.as_deref() != Some(hash) {
        return Err("Finish uploading the current source contents before moving to a cloud directory".into());
    }
    if row.read_only || row.collab_active {
        return Err("This file is read-only or being collaboratively edited".into());
    }
    Ok(())
}

fn check_uploaded_tree(engine: &Engine, path: &Path) -> Result<(), String> {
    let metadata = std::fs::symlink_metadata(path).map_err(|error| error.to_string())?;
    if metadata.file_type().is_symlink() {
        return Err("Symbolic links are not supported in Drive moves".into());
    }
    if metadata.is_dir() {
        for entry in std::fs::read_dir(path).map_err(|error| error.to_string())? {
            check_uploaded_tree(engine, &entry.map_err(|error| error.to_string())?.path())?;
        }
        Ok(())
    } else if metadata.is_file() {
        let row = engine.file_row(path).map_err(|error| error.to_string())?;
        uploaded_file(row.as_ref().map(|(_, row)| row), &sha256_file(path)?)
    } else {
        Err("Drive moves support files and directories only".into())
    }
}

impl DriveService {
    /// A Move To confirmation permits a local cross-project move with new remote identity.
    /// The host must grant both filesystem roots and preflight every destination before invoking this method.
    pub async fn with_move_to_filesystem<T, F>(
        &self, sources: &[PathBuf], directory: &Path, operation: F,
    ) -> Result<T, String>
    where
        F: std::future::Future<Output = Result<T, String>>,
    {
        let _operation = self.operations.lock().await;
        let inner = self.inner.lock().await;
        let Some(profile) = &inner.profile else {
            return operation.await;
        };
        let directory = canonical_target(directory)?;
        let sources = sources.iter().map(|path| canonical_target(path)).collect::<Result<Vec<_>, _>>()?;
        let managed = directory.starts_with(&profile.local_root)
            || sources.iter().any(|path| path.starts_with(&profile.local_root) || profile.local_root.starts_with(path));
        let Some(running) = &inner.running else {
            if managed {
                return Err("Start Drive before changing its files".into());
            }
            return operation.await;
        };
        let _gate = running.gate.lock().await;
        if managed {
            if running.engine.is_revoked() || !self.snapshot().running {
                return Err("Drive is not available".into());
            }
            let roots = running.engine.roots().map_err(|error| error.to_string())?;
            for source in &sources {
                if profile.local_root.starts_with(source) {
                    return Err("Cannot move the owned Drive directory or its ancestor".into());
                }
                if !source.starts_with(&profile.local_root) {
                    continue;
                }
                let root = containing_project(&roots, source, &profile.local_root)?
                    .ok_or("Cannot move the Drive container")?;
                writable_project(root)?;
                if *source == project_path(root, &profile.local_root)? {
                    return Err("Cannot move a Drive project root".into());
                }
                check_writable(&running.engine, source)?;
            }
            if directory.starts_with(&profile.local_root) {
                let root = containing_project(&roots, &directory, &profile.local_root)?
                    .ok_or("Cannot move into the Drive container")?;
                writable_project(root)?;
                if !root.selected || !directory.is_dir() {
                    return Err("Use the cloud move route for an unlanded destination".into());
                }
            }
        }
        let result = operation.await;
        if managed {
            // A failed batch may already have moved earlier entries. Mark only those absent on disk.
            let mut moved = Vec::new();
            for source in &sources {
                if !source.try_exists().map_err(|error| format!("Cannot reconcile move result: {error}"))? {
                    moved.push(source.clone());
                }
            }
            if !moved.is_empty() {
                running.engine.mark_user_removed(&moved);
                running.wake.send(()).map_err(|_| "Filesystem move completed; Drive worker stopped")?;
            }
        }
        result
    }

    /// Preserve cloud IDs for moves into indexed directories that are not available locally.
    /// Never upload, synchronize, or delete local sources as part of a server move.
    pub async fn move_to_cloud_directory(
        &self, sources: &[PathBuf], directory: &Path,
    ) -> Result<(usize, Option<String>), String> {
        let mut shutdown = self.shutdown_signal.subscribe();
        let _operation = interruptible(&mut shutdown, self.operations.lock()).await?;
        let inner = self.inner.lock().await;
        let profile = inner.profile.as_ref().ok_or("Drive is not configured")?;
        let running = inner.running.as_ref().ok_or("Drive is not running")?;
        let _gate = interruptible(&mut shutdown, running.gate.lock()).await?;
        let engine = &running.engine;
        if engine.is_revoked() || !self.snapshot().running {
            return Err("Drive is not available".into());
        }
        let directory = canonical_target(directory)?;
        let roots = engine.roots().map_err(|error| error.to_string())?;
        let target = containing_project(&roots, &directory, &profile.local_root)?
            .ok_or("Cloud move target is not an indexed Drive project")?;
        writable_project(target)?;
        if target.selected && directory.is_dir() {
            return Err("Use a local move for a landed destination".into());
        }
        let target_root = project_path(target, &profile.local_root)?;
        let relative = local_to_cloud_relative(
            directory.strip_prefix(&target_root).map_err(|error| error.to_string())?,
            cfg!(windows),
        );
        let target_folders = if relative.is_empty() {
            Vec::new()
        } else {
            interruptible(&mut shutdown, engine.cloud_folders(&target.project_id))
                .await?
                .map_err(|error| error.to_string())?
        };
        let folder = cloud_directory_id(&relative, &target_folders)?;
        let mut prepared = Vec::new();
        let mut names = HashSet::new();
        for source in sources {
            let source = canonical_target(source)?;
            let from = containing_project(&roots, &source, &profile.local_root)?
                .ok_or("Upload the source to Drive before moving to a cloud directory")?;
            writable_project(from)?;
            let from_root = project_path(from, &profile.local_root)?;
            if source == from_root || directory.starts_with(&source) {
                return Err("Cannot move a project root or move a folder into itself".into());
            }
            let name = source.file_name().ok_or("Move source has no name")?.to_os_string();
            if !names.insert(name) {
                return Err("Move sources have conflicting destination names".into());
            }
            if prepared
                .iter()
                .any(|(path, _, _): &(PathBuf, bool, RemoteId)| source.starts_with(path) || path.starts_with(&source))
            {
                return Err("Move selection contains overlapping sources".into());
            }
            check_writable(engine, &source)?;
            check_uploaded_tree(engine, &source)?;
            let is_directory = source.is_dir();
            if is_directory {
                let folders = interruptible(&mut shutdown, engine.cloud_folders(&from.project_id))
                    .await?
                    .map_err(|error| error.to_string())?;
                let relative = local_to_cloud_relative(
                    source.strip_prefix(&from_root).map_err(|error| error.to_string())?,
                    cfg!(windows),
                );
                cloud_directory_id(&relative, &folders)
                    .map_err(|_| "Upload the source folder before moving it to a cloud directory")?;
            }
            prepared.push((source, is_directory, from.project_id.clone()));
        }
        let mut moved = 0;
        for (source, is_directory, from) in prepared {
            // Recheck bytes immediately before each request; a queued batch must not move a stale cloud version.
            let result = interruptible(&mut shutdown, async {
                check_uploaded_tree(engine, &source)?;
                let id = if from == target.project_id && folder.is_none() {
                    // The engine treats a same-project root request as a no-op, even for nested sources.
                    // Resolve the uploaded ID and use the same server mutation for this actual relocation.
                    if is_directory {
                        let from_root = project_path(target, &profile.local_root)?;
                        let relative = local_to_cloud_relative(
                            source.strip_prefix(from_root).map_err(|error| error.to_string())?,
                            cfg!(windows),
                        );
                        let folders = engine.cloud_folders(&from).await.map_err(|error| error.to_string())?;
                        let id = cloud_directory_id(&relative, &folders)?.ok_or("Cannot move a project root")?;
                        engine
                            .client()
                            .move_folder(&id, &target.project_id, None)
                            .await
                            .map_err(|error| error.to_string())?;
                        Some(id)
                    } else {
                        let id = engine
                            .remote_file_id(&source)
                            .map_err(|error| error.to_string())?
                            .ok_or("Source is no longer uploaded")?;
                        engine
                            .client()
                            .move_file(&id, &target.project_id, None)
                            .await
                            .map_err(|error| error.to_string())?;
                        Some(id)
                    }
                } else if is_directory {
                    engine
                        .move_folder_to_project(&source, &target.project_id, folder.as_ref())
                        .await
                        .map_err(|error| error.to_string())?
                } else {
                    engine
                        .move_file_to_project(&source, &target.project_id, folder.as_ref())
                        .await
                        .map_err(|error| error.to_string())?
                };
                id.ok_or("Source is not uploaded".to_owned())?;
                Ok::<(), String>(())
            })
            .await?;
            if let Err(error) = result {
                let wake_error =
                    if moved > 0 { running.wake.send(()).err().map(|_| "; Drive worker stopped") } else { None };
                return Ok((
                    moved,
                    Some(format!(
                        "Moved {moved} of {} items on the server; remaining items were not moved: {}{}",
                        sources.len(),
                        error.replace(engine.client().token(), "[redacted]"),
                        wake_error.unwrap_or("")
                    )),
                ));
            }
            moved += 1;
        }
        if moved > 0 && running.wake.send(()).is_err() {
            return Ok((
                moved,
                Some(format!("Moved {moved} items on the server; Drive worker stopped before local reconciliation")),
            ));
        }
        self.projection.lock().expect("Drive projection poisoned").emit(Payload::Reconcile);
        Ok((moved, None))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn project(path: &Path) -> RootInfo {
        RootInfo {
            project_id: RemoteId::Number(1),
            project_key: "project".into(),
            name: "Project".into(),
            kind: ProjectKind::Material,
            scope: ProjectScope::Personal,
            dept_name: None,
            drive_path: "project".into(),
            node: None,
            container: None,
            node_path: None,
            skills_path: None,
            sync_enabled: true,
            can_write: true,
            cloud_only: false,
            cursor: None,
            pinned: false,
            department_id: None,
            owner_id: None,
            is_mine: Some(true),
            local_path: path.to_string_lossy().into_owned(),
            selected: false,
        }
    }

    #[test]
    fn writable_unselected_projects_remain_valid_cloud_targets() {
        let directory = tempfile::tempdir().unwrap();
        let root = directory.path().canonicalize().unwrap();
        let mut target = project(&root.join("project"));
        assert!(writable_project(&target).is_ok());
        assert_eq!(project_path(&target, &root).unwrap(), root.join("project"));
        target.can_write = false;
        assert!(writable_project(&target).is_err());
        target.can_write = true;
        target.cloud_only = true;
        assert!(writable_project(&target).is_err());
        target.cloud_only = false;
        target.kind = ProjectKind::Skill;
        assert!(writable_project(&target).is_err());
        target.local_path = root.parent().unwrap().join("escape").to_string_lossy().into_owned();
        assert!(project_path(&target, &root).is_err());
    }

    #[test]
    fn cloud_folder_must_match_the_requested_directory() {
        let folders = vec![CloudFolder { path: "reports/2026".into(), folder_id: RemoteId::Number(8) }];
        assert_eq!(cloud_directory_id("", &folders).unwrap(), None);
        assert_eq!(cloud_directory_id("reports/2026", &folders).unwrap(), Some(RemoteId::Number(8)));
        assert!(cloud_directory_id("reports/missing", &folders).is_err());
        assert!(cloud_directory_id("../reports/2026", &folders).is_err());
    }

    #[test]
    fn cloud_move_requires_the_uploaded_current_contents() {
        let mut row = FileRow {
            project_id: RemoteId::Number(1),
            path: "a.txt".into(),
            remote_file_id: Some(RemoteId::Number(2)),
            remote_version_id: Some(RemoteId::Number(3)),
            sha256: Some("current".into()),
            size: 1,
            mtime_ms: 0,
            state: FileState::Synced,
            collab_active: false,
            read_only: false,
        };
        assert!(uploaded_file(Some(&row), "current").is_ok());
        assert!(uploaded_file(Some(&row), "edited").is_err());
        assert!(uploaded_file(None, "current").is_err());
        row.state = FileState::Pending;
        assert!(uploaded_file(Some(&row), "current").is_err());
        row.state = FileState::Synced;
        row.remote_file_id = None;
        assert!(uploaded_file(Some(&row), "current").is_err());
    }
}

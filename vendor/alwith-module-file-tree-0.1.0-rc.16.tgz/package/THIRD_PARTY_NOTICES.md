# Third-party notices

React, Base UI, Iconify, TanStack Virtual and vscode-icons retain their MIT licenses.
Lucide and Codicons retain their distribution licenses. They are npm dependencies
and their original license files are distributed with those packages.

The vendored icon associations and collections are the same snapshots used by
ALwith Desktop: vscode-icons associations (v12.18.0 theme), Catppuccin Latte/Mocha,
and Material Icon Theme. Their upstream projects are:

- https://github.com/vscode-icons/vscode-icons (MIT)
- https://github.com/catppuccin/vscode-icons (MIT)
- https://github.com/PKief/vscode-material-icon-theme (MIT)

The association resolver is adapted from Desktop's
`src/features/project/components/shared/file-visual.ts`. The pointer drag hook and
preview are adapted from Desktop's `src/features/file-tree/hooks/use-tree-drag.ts`
and `src/features/file-tree/components/drag-preview.tsx`.

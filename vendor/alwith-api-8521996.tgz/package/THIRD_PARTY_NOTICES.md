# Third-party notices — @alwith/api

ALwith's proprietary license applies only to its own material. Third-party
material retains its original license and rights; the package license does not
replace or restrict those rights. Preserve applicable notices when redistributing.

## External direct dependencies and peers

These are external imports, not bundled dependency implementations in this npm
artifact. Versions below record the local release-preparation inventory; declared
ranges can resolve to different versions. Keep the notices from the versions
actually distributed by your application, including transitive dependencies.

| Package | Inspected version | License | Included license copy |
| --- | --- | --- | --- |
| @agentclientprotocol/sdk | 1.4.0 | Apache-2.0 | `licenses/_agentclientprotocol_sdk-LICENSE` |
| @tauri-apps/api | 2.11.1 | Apache-2.0 OR MIT | `licenses/_tauri-apps_api-LICENSE_APACHE-2.0`, `licenses/_tauri-apps_api-LICENSE_MIT` |

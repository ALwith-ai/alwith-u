use alwith_extension::filesystem::{
    FileOperation, FileRequest, FileResponse, MAX_BYTES, perform_file, read_scoped,
};
use std::fs;

fn request(operation: FileOperation, path: &str) -> FileRequest {
    FileRequest {
        operation,
        scope: None,
        path: path.into(),
        body: None,
        recursive: false,
    }
}

#[test]
fn binary_files_support_write_read_list_stat_and_remove() {
    let temp = tempfile::tempdir().unwrap();
    let root = fs::canonicalize(temp.path()).unwrap();
    let mut mkdir = request(FileOperation::Mkdir, "nested/files");
    mkdir.recursive = true;
    perform_file(&root, mkdir).unwrap();
    let mut write = request(FileOperation::Write, "nested/files/data.bin");
    write.body = Some(vec![0, 128, 255]);
    perform_file(&root, write).unwrap();
    assert_eq!(
        read_scoped(&root, "nested/files/data.bin").unwrap(),
        [0, 128, 255]
    );
    let FileResponse::Stat {
        exists,
        size,
        is_file,
        is_directory,
        mtime,
    } = perform_file(&root, request(FileOperation::Stat, "nested/files/data.bin")).unwrap()
    else {
        panic!("stat");
    };
    assert!(exists && is_file && !is_directory && mtime.is_some());
    assert_eq!(size, 3);
    let FileResponse::List { entries } =
        perform_file(&root, request(FileOperation::List, "nested/files")).unwrap()
    else {
        panic!("list");
    };
    assert_eq!(entries.len(), 1);
    assert_eq!(entries[0].name, "data.bin");
    assert!(entries[0].is_file && !entries[0].is_directory);
    perform_file(
        &root,
        request(FileOperation::Remove, "nested/files/data.bin"),
    )
    .unwrap();
    let FileResponse::Stat { exists, .. } =
        perform_file(&root, request(FileOperation::Stat, "nested/files/data.bin")).unwrap()
    else {
        panic!("missing stat");
    };
    assert!(!exists);
}

#[test]
fn denies_escape_root_removal_and_oversized_content() {
    let temp = tempfile::tempdir().unwrap();
    let root = fs::canonicalize(temp.path()).unwrap();
    for path in [
        "../outside",
        "/absolute",
        "nested/../../outside",
        r"C:\outside",
        r"nested\..\outside",
    ] {
        assert!(
            perform_file(&root, request(FileOperation::Mkdir, path)).is_err(),
            "{path}"
        );
    }
    let mut remove = request(FileOperation::Remove, ".");
    remove.recursive = true;
    assert!(perform_file(&root, remove).is_err());
    let file = fs::File::create(root.join("too-large")).unwrap();
    file.set_len(MAX_BYTES as u64 + 1).unwrap();
    assert!(read_scoped(&root, "too-large").is_err());
    let mut write = request(FileOperation::Write, "too-large-write");
    write.body = Some(vec![0; MAX_BYTES + 1]);
    assert!(perform_file(&root, write).is_err());
    assert!(!root.join("too-large-write").exists());
    assert!(root.exists());
}

#[cfg(unix)]
#[test]
fn refuses_symlink_files_and_ancestors() {
    let temp = tempfile::tempdir().unwrap();
    let outside = tempfile::tempdir().unwrap();
    fs::write(outside.path().join("secret"), b"secret").unwrap();
    std::os::unix::fs::symlink(outside.path(), temp.path().join("escape")).unwrap();
    std::os::unix::fs::symlink(outside.path().join("secret"), temp.path().join("link")).unwrap();
    let root = fs::canonicalize(temp.path()).unwrap();
    assert!(read_scoped(&root, "escape/secret").is_err());
    assert!(read_scoped(&root, "link").is_err());
}

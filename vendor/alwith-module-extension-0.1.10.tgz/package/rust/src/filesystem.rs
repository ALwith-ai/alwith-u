//! Bounded binary file operations rooted in a host-authorized directory.
//! Hosts own installation checks, directory grants, and private data locations.
use cap_std::{
    ambient_authority,
    fs::{Dir, OpenOptions},
};
use serde::{Deserialize, Serialize};
use std::{
    fs,
    io::{Read, Write},
    path::{Component, Path, PathBuf},
    time::UNIX_EPOCH,
};

pub const MAX_BYTES: usize = 64 * 1024 * 1024;

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum FileOperation {
    Read,
    Write,
    Mkdir,
    Remove,
    List,
    Stat,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct FileRequest {
    pub operation: FileOperation,
    pub scope: Option<String>,
    pub path: String,
    pub body: Option<Vec<u8>>,
    #[serde(default)]
    pub recursive: bool,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct FileEntry {
    pub name: String,
    pub is_file: bool,
    pub is_directory: bool,
}

#[derive(Serialize)]
#[serde(
    tag = "type",
    rename_all = "camelCase",
    rename_all_fields = "camelCase"
)]
pub enum FileResponse {
    Read {
        body: Vec<u8>,
    },
    List {
        entries: Vec<FileEntry>,
    },
    Stat {
        exists: bool,
        size: u64,
        mtime: Option<u64>,
        is_file: bool,
        is_directory: bool,
    },
    Ok,
}

pub fn open_scope(root: &Path) -> Result<Dir, String> {
    let canonical =
        fs::canonicalize(root).map_err(|error| format!("Open authorized directory: {error}"))?;
    if canonical != root
        || fs::symlink_metadata(root)
            .map_err(|error| error.to_string())?
            .file_type()
            .is_symlink()
    {
        return Err(
            "Authorized directory was moved or replaced by a symbolic link; select it again".into(),
        );
    }
    Dir::open_ambient_dir(canonical, ambient_authority())
        .map_err(|error| format!("Open authorized directory: {error}"))
}

pub fn scoped_path(directory: &Dir, value: &str) -> Result<PathBuf, String> {
    // Reject Windows separators on every platform so grants cannot change meaning on migration.
    if value.contains('\\') || value.contains('\0') || value.contains(':') {
        return Err(
            "Extension file paths must be relative paths inside the authorized directory".into(),
        );
    }
    let mut path = PathBuf::new();
    for part in Path::new(value).components() {
        match part {
            Component::Normal(name) => path.push(name),
            Component::CurDir => continue,
            _ => return Err("Extension file paths cannot leave the authorized directory".into()),
        }
        match directory.symlink_metadata(&path) {
            Ok(metadata) if metadata.file_type().is_symlink() => {
                return Err("Extension file paths cannot contain symbolic links".into());
            }
            Ok(_) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => return Err(format!("Inspect extension file path: {error}")),
        }
    }
    if path.as_os_str().is_empty() {
        path.push(".");
    }
    Ok(path)
}

pub fn read_scoped(root: &Path, path: &str) -> Result<Vec<u8>, String> {
    let directory = open_scope(root)?;
    let path = scoped_path(&directory, path)?;
    let file = directory
        .open(path)
        .map_err(|error| format!("Open extension file: {error}"))?;
    let metadata = file
        .metadata()
        .map_err(|error| format!("Inspect extension file: {error}"))?;
    if !metadata.is_file() {
        return Err("Extension reads require a regular file".into());
    }
    if metadata.len() > MAX_BYTES as u64 {
        return Err("Extension file exceeds 64 MiB".into());
    }
    let mut body = Vec::new();
    file.take(MAX_BYTES as u64 + 1)
        .read_to_end(&mut body)
        .map_err(|error| format!("Read extension file: {error}"))?;
    if body.len() > MAX_BYTES {
        return Err("Extension file exceeds 64 MiB".into());
    }
    Ok(body)
}

pub fn perform_file(root: &Path, request: FileRequest) -> Result<FileResponse, String> {
    let directory = open_scope(root)?;
    let path = scoped_path(&directory, &request.path)?;
    match request.operation {
        FileOperation::Read => Ok(FileResponse::Read {
            body: read_scoped(root, &request.path)?,
        }),
        FileOperation::Write => {
            let body = request.body.ok_or("Extension write requires binary body")?;
            if body.len() > MAX_BYTES {
                return Err("Extension file exceeds 64 MiB".into());
            }
            let mut options = OpenOptions::new();
            options.write(true).create(true).truncate(true);
            let mut file = directory
                .open_with(&path, &options)
                .map_err(|error| format!("Open extension file for writing: {error}"))?;
            file.write_all(&body)
                .map_err(|error| format!("Write extension file: {error}"))?;
            Ok(FileResponse::Ok)
        }
        FileOperation::Mkdir => {
            let result = if request.recursive {
                directory.create_dir_all(&path)
            } else {
                directory.create_dir(&path)
            };
            result.map_err(|error| format!("Create extension directory: {error}"))?;
            Ok(FileResponse::Ok)
        }
        FileOperation::Remove => {
            if path == Path::new(".") {
                return Err("Cannot remove an authorized directory root".into());
            }
            let metadata = directory
                .symlink_metadata(&path)
                .map_err(|error| format!("Inspect extension removal target: {error}"))?;
            let result = if metadata.is_dir() {
                if request.recursive {
                    directory.remove_dir_all(&path)
                } else {
                    directory.remove_dir(&path)
                }
            } else {
                directory.remove_file(&path)
            };
            result.map_err(|error| format!("Remove extension file: {error}"))?;
            Ok(FileResponse::Ok)
        }
        FileOperation::List => {
            let mut entries = directory
                .read_dir(&path)
                .map_err(|error| format!("List extension directory: {error}"))?
                .map(|entry| {
                    let entry = entry
                        .map_err(|error| format!("Read extension directory entry: {error}"))?;
                    let kind = entry
                        .file_type()
                        .map_err(|error| format!("Inspect extension directory entry: {error}"))?;
                    Ok(FileEntry {
                        name: entry
                            .file_name()
                            .into_string()
                            .map_err(|_| "Extension directory entry is not valid UTF-8")?,
                        is_file: kind.is_file(),
                        is_directory: kind.is_dir(),
                    })
                })
                .collect::<Result<Vec<_>, String>>()?;
            entries.sort_by(|a, b| a.name.cmp(&b.name));
            Ok(FileResponse::List { entries })
        }
        FileOperation::Stat => match directory.metadata(&path) {
            Ok(metadata) => Ok(FileResponse::Stat {
                exists: true,
                size: metadata.len(),
                mtime: metadata
                    .modified()
                    .ok()
                    .and_then(|time| time.into_std().duration_since(UNIX_EPOCH).ok())
                    .and_then(|duration| u64::try_from(duration.as_millis()).ok()),
                is_file: metadata.is_file(),
                is_directory: metadata.is_dir(),
            }),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(FileResponse::Stat {
                exists: false,
                size: 0,
                mtime: None,
                is_file: false,
                is_directory: false,
            }),
            Err(error) => Err(format!("Inspect extension file: {error}")),
        },
    }
}

//! Binary HTTP transport shared by modern extensions and compatibility hosts.
//! Hosts supply URL authorization and validate installation authority before and
//! after calling this module. Requests never use host cookies or follow redirects.
//! Native requests have a 120-second timeout (20 seconds to connect). There is no
//! native cancellation handle yet; aborting JavaScript delivery does not stop I/O.
use reqwest::{
    Client, Method, Url,
    header::{HeaderName, HeaderValue},
};
use serde::{Deserialize, Serialize};
use std::{collections::BTreeMap, time::Duration};

pub const MAX_HTTP_BYTES: usize = 64 * 1024 * 1024;

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct HttpRequest {
    pub url: String,
    pub method: Option<String>,
    #[serde(default)]
    pub headers: BTreeMap<String, String>,
    pub body: Option<Vec<u8>>,
}

#[derive(Serialize)]
pub struct HttpResponse {
    pub status: u16,
    pub url: String,
    pub headers: BTreeMap<String, String>,
    pub body: Vec<u8>,
}

fn build_request(
    client: &Client,
    request: HttpRequest,
    validate_url: impl FnOnce(&str) -> Result<Url, String>,
) -> Result<reqwest::Request, String> {
    let url = validate_url(&request.url)?;
    let method = Method::from_bytes(request.method.as_deref().unwrap_or("GET").as_bytes())
        .map_err(|error| format!("Invalid extension HTTP method: {error}"))?;
    if !matches!(
        method,
        Method::GET
            | Method::HEAD
            | Method::POST
            | Method::PUT
            | Method::PATCH
            | Method::DELETE
            | Method::OPTIONS
    ) {
        return Err("Extension HTTP method is not allowed".into());
    }
    let mut builder = client.request(method, url);
    for (name, value) in request.headers {
        let name = HeaderName::from_bytes(name.as_bytes())
            .map_err(|error| format!("Invalid HTTP header: {error}"))?;
        if matches!(
            name.as_str(),
            "host"
                | "connection"
                | "transfer-encoding"
                | "content-length"
                | "proxy-authorization"
                | "proxy-connection"
                | "upgrade"
        ) {
            return Err(format!(
                "Extension HTTP cannot override transport header {name}"
            ));
        }
        let value = HeaderValue::from_str(&value)
            .map_err(|error| format!("Invalid HTTP header value: {error}"))?;
        builder = builder.header(name, value);
    }
    if let Some(body) = request.body {
        if body.len() > MAX_HTTP_BYTES {
            return Err("Extension HTTP request exceeds 64 MiB".into());
        }
        builder = builder.body(body);
    }
    builder
        .build()
        .map_err(|error| format!("Build extension HTTP request: {error}"))
}

/// Execute a bounded binary request after the host authorizes its URL.
pub async fn execute(
    request: HttpRequest,
    validate_url: impl FnOnce(&str) -> Result<Url, String>,
) -> Result<HttpResponse, String> {
    // Never share the host's client/cookies or forward credentials across redirects.
    let client = Client::builder()
        .redirect(reqwest::redirect::Policy::none())
        .timeout(Duration::from_secs(120))
        .connect_timeout(Duration::from_secs(20))
        .build()
        .map_err(|error| format!("Create extension HTTP client: {error}"))?;
    let request = build_request(&client, request, validate_url)?;
    let mut response = client
        .execute(request)
        .await
        .map_err(|error| format!("Extension HTTP request failed: {}", error.without_url()))?;
    if response
        .content_length()
        .is_some_and(|length| length > MAX_HTTP_BYTES as u64)
    {
        return Err("Extension HTTP response exceeds 64 MiB".into());
    }
    let status = response.status().as_u16();
    let url = response.url().to_string();
    let headers = response
        .headers()
        .iter()
        .map(|(name, value)| {
            value
                .to_str()
                .map(|value| (name.to_string(), value.to_owned()))
                .map_err(|error| format!("Invalid extension response header: {error}"))
        })
        .collect::<Result<BTreeMap<_, _>, _>>()?;
    let mut body = Vec::new();
    while let Some(chunk) = response
        .chunk()
        .await
        .map_err(|error| format!("Read extension HTTP response: {}", error.without_url()))?
    {
        append_chunk(&mut body, &chunk)?;
    }
    Ok(HttpResponse {
        status,
        url,
        headers,
        body,
    })
}

fn append_chunk(body: &mut Vec<u8>, chunk: &[u8]) -> Result<(), String> {
    if chunk.len() > MAX_HTTP_BYTES.saturating_sub(body.len()) {
        return Err("Extension HTTP response exceeds 64 MiB".into());
    }
    body.extend_from_slice(chunk);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn request() -> HttpRequest {
        HttpRequest {
            url: "https://api.github.com/data".into(),
            method: None,
            headers: BTreeMap::new(),
            body: None,
        }
    }

    fn allow(value: &str) -> Result<Url, String> {
        Url::parse(value).map_err(|error| error.to_string())
    }

    #[test]
    fn preserves_binary_multipart_body_and_explicit_auth_headers() {
        let body = b"--boundary\r\nContent-Disposition: form-data; name=\"file\"\r\n\r\n\x00\x80\xff\r\n--boundary--\r\n".to_vec();
        let request = build_request(
            &Client::new(),
            HttpRequest {
                method: Some("POST".into()),
                headers: BTreeMap::from([
                    (
                        "Content-Type".into(),
                        "multipart/form-data; boundary=boundary".into(),
                    ),
                    ("Authorization".into(), "Bearer extension-secret".into()),
                ]),
                body: Some(body.clone()),
                ..request()
            },
            allow,
        )
        .unwrap();
        assert_eq!(request.method(), Method::POST);
        assert_eq!(
            request.headers()["content-type"],
            "multipart/form-data; boundary=boundary"
        );
        assert_eq!(
            request.headers()["authorization"],
            "Bearer extension-secret"
        );
        assert_eq!(request.body().unwrap().as_bytes().unwrap(), body);
    }

    #[test]
    fn rejects_transport_header_overrides_and_unsafe_methods() {
        for name in [
            "Host",
            "Connection",
            "Content-Length",
            "Proxy-Authorization",
            "Proxy-Connection",
            "Transfer-Encoding",
            "Upgrade",
        ] {
            let result = build_request(
                &Client::new(),
                HttpRequest {
                    headers: BTreeMap::from([(name.into(), "invalid".into())]),
                    ..request()
                },
                allow,
            );
            assert!(result.unwrap_err().contains("transport header"), "{name}");
        }
        let result = build_request(
            &Client::new(),
            HttpRequest {
                method: Some("CONNECT".into()),
                ..request()
            },
            allow,
        );
        assert!(result.unwrap_err().contains("method is not allowed"));
    }

    #[test]
    fn respects_host_url_policy_before_building_request() {
        let result = build_request(&Client::new(), request(), |_| Err("host denied".into()));
        assert_eq!(result.unwrap_err(), "host denied");
    }

    #[test]
    fn rejects_invalid_headers_and_oversized_request() {
        let result = build_request(
            &Client::new(),
            HttpRequest {
                headers: BTreeMap::from([(
                    "Authorization".into(),
                    "Bearer secret\r\nInjected: true".into(),
                )]),
                ..request()
            },
            allow,
        );
        assert!(result.unwrap_err().contains("Invalid HTTP header value"));
        let result = build_request(
            &Client::new(),
            HttpRequest {
                body: Some(vec![0; MAX_HTTP_BYTES + 1]),
                ..request()
            },
            allow,
        );
        assert!(result.unwrap_err().contains("request exceeds"));
    }

    #[test]
    fn bounds_accumulated_binary_response_without_partial_append() {
        let mut body = vec![0; MAX_HTTP_BYTES - 2];
        append_chunk(&mut body, &[128, 255]).unwrap();
        assert_eq!(&body[MAX_HTTP_BYTES - 2..], &[128, 255]);
        assert!(append_chunk(&mut body, &[1]).is_err());
        assert_eq!(body.len(), MAX_HTTP_BYTES);
    }
}

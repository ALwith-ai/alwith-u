# Third-party notices

React is supplied by the host under the MIT license. Native filesystem dependencies retain their original licenses.

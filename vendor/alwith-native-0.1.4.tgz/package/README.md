# @alwith/native

Closed native implementations for ALwith applications. npm installs the matching
platform binary; no private Cargo source or account server is required to build.

At build time call `stageNative(targetTriple, nativeResourceDirectory, licensesDirectory)`
from `@alwith/native/stage`. Bundle the result with Tauri resources. The application
uses a thin C ABI v1 bridge (see ALwith U); a WebView cannot load a native library directly.
No background process, credential migration or Runtime dependency is introduced.

Auth refresh retains the same shared cache/mutex implementation used by Desktop.
Each application retains its own credential storage. Native app discovery is desktop-only.
These desktop binaries do not claim iOS or Android support.

Cross builds must install optional packages for the target too:
`bun install --os='*' --cpu='*'`. Normal native builds need only `bun install`.

Private Rust implementation sources are not included. The staging script and C ABI
contract contain no authentication implementation. See LICENSE and per-platform notices.

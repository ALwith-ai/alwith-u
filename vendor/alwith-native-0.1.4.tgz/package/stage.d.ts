/** Build-time only. Copies the pinned, verified platform binary and its licences. */
export declare function stageNative(target: string, destination: string, licenses: string): string;

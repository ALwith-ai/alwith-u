use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fs::{File, OpenOptions};
use std::io::{Read, Seek, Write};
use std::path::{Path, PathBuf};

pub struct RootLease {
    file: File,
    previous_owner: Option<Vec<u8>>,
}

#[derive(Serialize, Deserialize)]
struct Owner {
    root: PathBuf,
    identity: String,
}

fn open(path: &Path) -> Result<File, String> {
    let mut options = OpenOptions::new();
    options.read(true).write(true).create(true).truncate(false);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.mode(0o600);
    }
    options.open(path).map_err(|error| error.to_string())
}

pub fn canonical_target(path: &Path) -> Result<PathBuf, String> {
    if !path.is_absolute() || path.components().any(|part| matches!(part, std::path::Component::ParentDir)) {
        return Err("Drive root must be an absolute path without parent traversal".into());
    }
    if path.exists() {
        return path.canonicalize().map_err(|error| error.to_string());
    }
    let parent = path.parent().ok_or("Drive root must have a parent")?;
    Ok(canonical_target(parent)?.join(path.file_name().ok_or("Invalid Drive root")?))
}

impl RootLease {
    pub fn acquire(registry: &Path, root: &Path, identity: &str) -> Result<Self, String> {
        Self::acquire_inner(registry, root, identity, false, false)
    }

    pub(crate) fn acquire_existing(registry: &Path, root: &Path, identity: &str) -> Result<Self, String> {
        Self::acquire_inner(registry, root, identity, true, false)
    }

    pub(crate) fn acquire_confirmed(registry: &Path, root: &Path, identity: &str) -> Result<Self, String> {
        Self::acquire_inner(registry, root, identity, true, true)
    }

    pub(crate) fn commit(&mut self) {
        self.previous_owner = None;
    }

    fn acquire_inner(
        registry: &Path, root: &Path, identity: &str, allow_existing: bool, confirmed: bool,
    ) -> Result<Self, String> {
        let root = canonical_target(root)?;
        if root.exists() && !root.is_dir() {
            return Err("Drive root must be a directory".into());
        }
        std::fs::create_dir_all(registry).map_err(|error| error.to_string())?;
        let registry_lock = open(&registry.join("registry.lock"))?;
        registry_lock.lock().map_err(|error| error.to_string())?;
        let key = hex::encode(Sha256::digest(root.to_string_lossy().as_bytes()));
        let target = registry.join(format!("{key}.owner"));
        if !allow_existing
            && !target.exists()
            && root.exists()
            && (!root.is_dir() || std::fs::read_dir(&root).map_err(|error| error.to_string())?.next().is_some())
        {
            return Err("Choose an empty directory for a new Drive profile".into());
        }
        for entry in std::fs::read_dir(registry).map_err(|error| error.to_string())? {
            let path = entry.map_err(|error| error.to_string())?.path();
            if path.extension().and_then(|value| value.to_str()) != Some("owner") {
                continue;
            }
            let bytes = std::fs::read(&path).map_err(|error| error.to_string())?;
            if bytes.is_empty() {
                continue;
            }
            let owner: Owner =
                serde_json::from_slice(&bytes).map_err(|error| format!("Invalid Drive ownership record: {error}"))?;
            if owner.root == root {
                if owner.identity != identity && !confirmed {
                    return Err("Drive directory belongs to another profile; choose a new directory".into());
                }
            } else if owner.root.starts_with(&root) || root.starts_with(&owner.root) {
                return Err("Drive directory overlaps another registered profile".into());
            }
        }
        let mut file = open(&target)?;
        file.try_lock().map_err(|_| "Drive directory is already owned by another running service")?;
        let mut existing = String::new();
        file.read_to_string(&mut existing).map_err(|error| error.to_string())?;
        let previous_owner = if confirmed { Some(existing.as_bytes().to_vec()) } else { None };
        let mut lease = Self { file, previous_owner };
        if existing.is_empty() || confirmed {
            let bytes = serde_json::to_vec(&Owner { root, identity: identity.to_string() })
                .map_err(|error| error.to_string())?;
            lease.write_owner(&bytes)?;
        }
        Ok(lease)
    }
}

impl RootLease {
    fn write_owner(&mut self, bytes: &[u8]) -> Result<(), String> {
        self.file.rewind().map_err(|error| error.to_string())?;
        self.file.write_all(bytes).map_err(|error| error.to_string())?;
        self.file.set_len(bytes.len() as u64).map_err(|error| error.to_string())?;
        self.file.sync_all().map_err(|error| error.to_string())
    }
}

impl Drop for RootLease {
    fn drop(&mut self) {
        if let Some(previous) = self.previous_owner.take()
            && let Err(error) = self.write_owner(&previous)
        {
            log::error!("Cannot restore Drive directory ownership: {error}");
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn overlapping_roots_cannot_have_two_writers() {
        let data = tempfile::tempdir().unwrap();
        let registry = data.path().join("registry");
        let root = data.path().join("files");
        std::fs::create_dir_all(&root).unwrap();
        let owner = RootLease::acquire(&registry, &root, "account-a").unwrap();
        assert!(RootLease::acquire(&registry, &root, "account-a").is_err());
        assert!(RootLease::acquire(&registry, &root.join("nested"), "account-a").is_err());
        assert!(RootLease::acquire(&registry, data.path(), "account-a").is_err());
        drop(owner);
        assert!(RootLease::acquire(&registry, &root, "account-a").is_ok());
    }

    #[test]
    fn root_identity_survives_lease_release() {
        let data = tempfile::tempdir().unwrap();
        let registry = data.path().join("registry");
        let root = data.path().join("files");
        std::fs::create_dir(&root).unwrap();
        drop(RootLease::acquire(&registry, &root, "account-a").unwrap());
        assert!(RootLease::acquire(&registry, &root, "account-b").is_err());
    }

    #[test]
    fn lease_excludes_a_separate_process() {
        let data = tempfile::tempdir().unwrap();
        let root = data.path().join("files");
        let registry = data.path().join("owners");
        let _lease = RootLease::acquire(&registry, &root, "account").unwrap();
        let output = std::process::Command::new(std::env::current_exe().unwrap())
            .args(["--exact", "ownership::tests::lease_child", "--ignored"])
            .env("DRIVE_TEST_ROOT", &root)
            .env("DRIVE_TEST_REGISTRY", &registry)
            .output()
            .unwrap();
        assert!(output.status.success(), "{}", String::from_utf8_lossy(&output.stdout));
        assert!(String::from_utf8_lossy(&output.stdout).contains("1 passed"), "The child lease assertion must run");
    }

    #[test]
    #[ignore = "Invoked by the cross-process ownership test"]
    fn lease_child() {
        let root = std::env::var_os("DRIVE_TEST_ROOT").expect("parent supplies test root");
        let registry = std::env::var_os("DRIVE_TEST_REGISTRY").expect("parent supplies registry");
        assert!(RootLease::acquire(Path::new(&registry), Path::new(&root), "account").is_err());
    }

    #[test]
    fn existing_files_are_not_adopted_as_a_new_profile() {
        let data = tempfile::tempdir().unwrap();
        let root = data.path().join("files");
        std::fs::create_dir(&root).unwrap();
        std::fs::write(root.join("offline.md"), "keep me").unwrap();
        assert!(RootLease::acquire(&data.path().join("owners"), &root, "account").err().unwrap().contains("empty"));
        assert_eq!(std::fs::read_to_string(root.join("offline.md")).unwrap(), "keep me");
    }

    #[test]
    fn existing_directory_adoption_preserves_files_and_keeps_exclusive_ownership() {
        let data = tempfile::tempdir().unwrap();
        let root = data.path().join("YUP Drive");
        let registry = data.path().join("owners");
        std::fs::create_dir(&root).unwrap();
        std::fs::write(root.join("offline.md"), "keep me").unwrap();
        let lease = RootLease::acquire_existing(&registry, &root, "account-a").unwrap();
        assert_eq!(std::fs::read_to_string(root.join("offline.md")).unwrap(), "keep me");
        assert!(RootLease::acquire(&registry, &root, "account-a").is_err());
        drop(lease);
        assert!(RootLease::acquire(&registry, &root, "account-b").is_err());
        assert!(RootLease::acquire(&registry, &root, "account-a").is_ok());
    }

    #[test]
    fn confirmed_adoption_requires_an_idle_root_and_preserves_files() {
        let data = tempfile::tempdir().unwrap();
        let root = data.path().join("files");
        let registry = data.path().join("owners");
        std::fs::create_dir(&root).unwrap();
        let old = RootLease::acquire(&registry, &root, "old").unwrap();
        std::fs::write(root.join("note.md"), "keep").unwrap();
        assert!(RootLease::acquire_confirmed(&registry, &root, "new").is_err());
        drop(old);
        // An uncommitted adoption rolls back if profile persistence fails.
        drop(RootLease::acquire_confirmed(&registry, &root, "new").unwrap());
        drop(RootLease::acquire(&registry, &root, "old").unwrap());
        let mut adopted = RootLease::acquire_confirmed(&registry, &root, "new").unwrap();
        adopted.commit();
        assert!(RootLease::acquire(&registry, &root, "new").is_err());
        drop(adopted);
        assert!(RootLease::acquire(&registry, &root, "old").is_err());
        assert!(RootLease::acquire(&registry, &root, "new").is_ok());
        assert_eq!(std::fs::read_to_string(root.join("note.md")).unwrap(), "keep");
        assert!(RootLease::acquire_confirmed(&registry, &root.join("nested"), "new").is_err());
    }

    #[cfg(unix)]
    #[test]
    fn root_aliases_share_one_lease() {
        let data = tempfile::tempdir().unwrap();
        let root = data.path().join("files");
        std::fs::create_dir(&root).unwrap();
        let alias = data.path().join("alias");
        std::os::unix::fs::symlink(&root, &alias).unwrap();
        let registry = data.path().join("owners");
        let _lease = RootLease::acquire(&registry, &root, "account").unwrap();
        assert!(RootLease::acquire(&registry, &alias, "account").is_err());
    }
}

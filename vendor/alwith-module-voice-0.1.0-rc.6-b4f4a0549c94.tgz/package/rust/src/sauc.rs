//! 豆包（火山引擎）大模型流式语音识别 —— SAUC v3 二进制协议编解码。
//!
//! 帧结构（整数一律大端）：
//!   4 字节头 →（消息类型带序列号时）4 字节 sequence → 4 字节 payload_size → payload
//! 头四个字节的位划分：
//!   byte0 = 协议版本(4) | 头长度(4，单位 4 字节)
//!   byte1 = 消息类型(4) | 消息类型特定标志(4)
//!   byte2 = 序列化方式(4) | 压缩方式(4)
//!   byte3 = 保留
//!
//! 错误帧的布局与响应帧不同：头之后是 error_code:u32 + message_size:u32 + message。

use std::io::Read;

const PROTOCOL_VERSION: u8 = 0b0001;
/// 头长度字段以 4 字节为单位，0b0001 = 4 字节头。
const HEADER_SIZE_UNITS: u8 = 0b0001;
const HEADER_UNIT_BYTES: usize = 4;

const MESSAGE_TYPE_FULL_CLIENT_REQUEST: u8 = 0b0001;
const MESSAGE_TYPE_AUDIO_ONLY_REQUEST: u8 = 0b0010;
const MESSAGE_TYPE_FULL_SERVER_RESPONSE: u8 = 0b1001;
const MESSAGE_TYPE_SERVER_ACK: u8 = 0b1011;
const MESSAGE_TYPE_SERVER_ERROR: u8 = 0b1111;

const FLAG_NO_SEQUENCE: u8 = 0b0000;
const FLAG_POSITIVE_SEQUENCE: u8 = 0b0001;
const FLAG_LAST_NO_SEQUENCE: u8 = 0b0010;
const FLAG_LAST_NEGATIVE_SEQUENCE: u8 = 0b0011;

const SERIALIZATION_RAW: u8 = 0b0000;
const SERIALIZATION_JSON: u8 = 0b0001;

const COMPRESSION_NONE: u8 = 0b0000;
const COMPRESSION_GZIP: u8 = 0b0001;

/// 服务端帧。`Ack` 是纯确认（没有 payload），`Response` 的 payload 是 JSON 识别结果。
#[derive(Debug, PartialEq)]
pub enum ServerFrame {
    Response { is_last: bool, payload: Vec<u8> },
    Ack,
    Error { code: u32, message: String },
}

fn encode_header(message_type: u8, flags: u8, serialization: u8, compression: u8) -> [u8; 4] {
    [(PROTOCOL_VERSION << 4) | HEADER_SIZE_UNITS, (message_type << 4) | flags, (serialization << 4) | compression, 0]
}

/// 首帧：JSON 形式的音频元信息与识别参数。
pub fn build_full_client_request(payload: &[u8]) -> Vec<u8> {
    let mut frame = Vec::with_capacity(8 + payload.len());
    frame.extend_from_slice(&encode_header(
        MESSAGE_TYPE_FULL_CLIENT_REQUEST,
        FLAG_NO_SEQUENCE,
        SERIALIZATION_JSON,
        COMPRESSION_NONE,
    ));
    frame.extend_from_slice(&(payload.len() as u32).to_be_bytes());
    frame.extend_from_slice(payload);
    frame
}

/// 音频帧。`is_last` 打末包标志，服务端据此收尾并返回最终结果。
pub fn build_audio_request(audio: &[u8], is_last: bool) -> Vec<u8> {
    let flags = if is_last { FLAG_LAST_NO_SEQUENCE } else { FLAG_NO_SEQUENCE };
    let mut frame = Vec::with_capacity(8 + audio.len());
    frame.extend_from_slice(&encode_header(
        MESSAGE_TYPE_AUDIO_ONLY_REQUEST,
        flags,
        SERIALIZATION_RAW,
        COMPRESSION_NONE,
    ));
    frame.extend_from_slice(&(audio.len() as u32).to_be_bytes());
    frame.extend_from_slice(audio);
    frame
}

fn read_u32(data: &[u8], cursor: &mut usize) -> Result<u32, String> {
    let end = *cursor + 4;
    if data.len() < end {
        return Err(format!("SAUC 帧截断：需要 {end} 字节，实际 {}", data.len()));
    }
    let value = u32::from_be_bytes([data[*cursor], data[*cursor + 1], data[*cursor + 2], data[*cursor + 3]]);
    *cursor = end;
    Ok(value)
}

fn decompress(payload: Vec<u8>, compression: u8) -> Result<Vec<u8>, String> {
    match compression {
        COMPRESSION_NONE => Ok(payload),
        COMPRESSION_GZIP => {
            let mut decoded = Vec::new();
            flate2::read::GzDecoder::new(payload.as_slice())
                .take(1_048_577)
                .read_to_end(&mut decoded)
                .map_err(|error| format!("SAUC payload gzip 解压失败：{error}"))?;
            if decoded.len() > 1_048_576 {
                return Err("SAUC payload too large".into());
            }
            Ok(decoded)
        }
        other => Err(format!("SAUC 未知压缩方式：{other:#06b}")),
    }
}

pub fn parse_server_frame(data: &[u8]) -> Result<ServerFrame, String> {
    if data.len() < HEADER_UNIT_BYTES {
        return Err(format!("SAUC 帧过短：{} 字节", data.len()));
    }
    if data[0] >> 4 != PROTOCOL_VERSION {
        return Err("Unsupported SAUC version".into());
    }
    let header_size = (data[0] & 0x0F) as usize * HEADER_UNIT_BYTES;
    if header_size < HEADER_UNIT_BYTES || data.len() < header_size {
        return Err(format!("SAUC 头长度非法：声明 {header_size} 字节，实际帧 {} 字节", data.len()));
    }
    let message_type = (data[1] >> 4) & 0x0F;
    let flags = data[1] & 0x0F;
    let compression = data[2] & 0x0F;
    let mut cursor = header_size;

    match message_type {
        MESSAGE_TYPE_SERVER_ERROR => {
            let code = read_u32(data, &mut cursor)?;
            let size = read_u32(data, &mut cursor)? as usize;
            let end = cursor + size;
            if data.len() < end {
                return Err(format!("SAUC 错误帧截断：声明 {size} 字节消息，实际剩余 {}", data.len() - cursor));
            }
            let raw = decompress(data[cursor..end].to_vec(), compression)?;
            Ok(ServerFrame::Error { code, message: String::from_utf8_lossy(&raw).into_owned() })
        }
        MESSAGE_TYPE_FULL_SERVER_RESPONSE => {
            // 带序列号的标志位后面多 4 字节 sequence，跳过即可 —— 我们按到达顺序处理，
            // 不做乱序重排（WebSocket 本身保证同一连接内的帧序）。
            if flags == FLAG_POSITIVE_SEQUENCE || flags == FLAG_LAST_NEGATIVE_SEQUENCE {
                read_u32(data, &mut cursor)?;
            }
            let size = read_u32(data, &mut cursor)? as usize;
            let end = cursor + size;
            if data.len() < end {
                return Err(format!("SAUC 响应帧截断：声明 {size} 字节 payload，实际剩余 {}", data.len() - cursor));
            }
            let payload = decompress(data[cursor..end].to_vec(), compression)?;
            let is_last = flags == FLAG_LAST_NO_SEQUENCE || flags == FLAG_LAST_NEGATIVE_SEQUENCE;
            Ok(ServerFrame::Response { is_last, payload })
        }
        MESSAGE_TYPE_SERVER_ACK => Ok(ServerFrame::Ack),
        other => Err(format!("SAUC 未知消息类型：{other:#06b}")),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn header_of(frame: &[u8]) -> (u8, u8, u8, u8) {
        ((frame[0] >> 4) & 0x0F, frame[1] >> 4, frame[1] & 0x0F, (frame[2] >> 4) & 0x0F)
    }

    #[test]
    fn full_client_request_has_json_header_and_big_endian_size() {
        let frame = build_full_client_request(br#"{"a":1}"#);
        let (version, message_type, flags, serialization) = header_of(&frame);
        assert_eq!(version, PROTOCOL_VERSION);
        assert_eq!(message_type, MESSAGE_TYPE_FULL_CLIENT_REQUEST);
        assert_eq!(flags, FLAG_NO_SEQUENCE);
        assert_eq!(serialization, SERIALIZATION_JSON);
        assert_eq!(frame[0] & 0x0F, HEADER_SIZE_UNITS);
        assert_eq!(&frame[4..8], &7u32.to_be_bytes());
        assert_eq!(&frame[8..], br#"{"a":1}"#);
    }

    #[test]
    fn audio_request_marks_last_packet_only_when_asked() {
        let normal = build_audio_request(&[1, 2, 3, 4], false);
        assert_eq!(normal[1] & 0x0F, FLAG_NO_SEQUENCE);
        assert_eq!((normal[2] >> 4) & 0x0F, SERIALIZATION_RAW);
        assert_eq!(&normal[8..], &[1, 2, 3, 4]);

        let last = build_audio_request(&[], true);
        assert_eq!(last[1] & 0x0F, FLAG_LAST_NO_SEQUENCE);
        assert_eq!(&last[4..8], &0u32.to_be_bytes());
        assert_eq!(last.len(), 8);
    }

    fn server_response(flags: u8, payload: &[u8], with_sequence: bool) -> Vec<u8> {
        let mut frame =
            encode_header(MESSAGE_TYPE_FULL_SERVER_RESPONSE, flags, SERIALIZATION_JSON, COMPRESSION_NONE).to_vec();
        if with_sequence {
            frame.extend_from_slice(&1u32.to_be_bytes());
        }
        frame.extend_from_slice(&(payload.len() as u32).to_be_bytes());
        frame.extend_from_slice(payload);
        frame
    }

    #[test]
    fn parses_response_without_sequence() {
        let frame = server_response(FLAG_NO_SEQUENCE, br#"{"result":{}}"#, false);
        assert_eq!(
            parse_server_frame(&frame).unwrap(),
            ServerFrame::Response { is_last: false, payload: br#"{"result":{}}"#.to_vec() }
        );
    }

    #[test]
    fn skips_sequence_field_and_detects_last_packet() {
        let frame = server_response(FLAG_LAST_NEGATIVE_SEQUENCE, br#"{"result":{"text":"x"}}"#, true);
        let parsed = parse_server_frame(&frame).unwrap();
        assert_eq!(parsed, ServerFrame::Response { is_last: true, payload: br#"{"result":{"text":"x"}}"#.to_vec() });
    }

    #[test]
    fn parses_error_frame() {
        let message = "invalid request";
        let mut frame =
            encode_header(MESSAGE_TYPE_SERVER_ERROR, FLAG_NO_SEQUENCE, SERIALIZATION_JSON, COMPRESSION_NONE).to_vec();
        frame.extend_from_slice(&45_000_001u32.to_be_bytes());
        frame.extend_from_slice(&(message.len() as u32).to_be_bytes());
        frame.extend_from_slice(message.as_bytes());
        assert_eq!(
            parse_server_frame(&frame).unwrap(),
            ServerFrame::Error { code: 45_000_001, message: message.to_string() }
        );
    }

    #[test]
    fn parses_gzip_compressed_payload() {
        use std::io::Write;
        let mut encoder = flate2::write::GzEncoder::new(Vec::new(), flate2::Compression::default());
        encoder.write_all(br#"{"result":{"text":"gz"}}"#).unwrap();
        let compressed = encoder.finish().unwrap();

        let mut frame =
            encode_header(MESSAGE_TYPE_FULL_SERVER_RESPONSE, FLAG_NO_SEQUENCE, SERIALIZATION_JSON, COMPRESSION_GZIP)
                .to_vec();
        frame.extend_from_slice(&(compressed.len() as u32).to_be_bytes());
        frame.extend_from_slice(&compressed);

        assert_eq!(
            parse_server_frame(&frame).unwrap(),
            ServerFrame::Response { is_last: false, payload: br#"{"result":{"text":"gz"}}"#.to_vec() }
        );
    }

    #[test]
    fn truncated_frames_are_errors_not_silent_defaults() {
        assert!(parse_server_frame(&[0x11, 0x90]).is_err());
        let mut frame = server_response(FLAG_NO_SEQUENCE, b"payload", false);
        frame.truncate(frame.len() - 3);
        assert!(parse_server_frame(&frame).is_err());
    }

    #[test]
    fn unknown_message_type_is_an_error() {
        let frame = encode_header(0b0111, FLAG_NO_SEQUENCE, SERIALIZATION_JSON, COMPRESSION_NONE);
        assert!(parse_server_frame(&frame).is_err());
    }
}

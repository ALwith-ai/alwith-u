use serde::{Deserialize, Serialize};
use std::{
    collections::{HashMap, VecDeque},
    sync::{Arc, Condvar, Mutex},
    time::Duration,
};
use tokio::{runtime::Runtime, sync::mpsc};
use tokio_util::sync::CancellationToken;

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Start {
    pub owner: String,
    pub recording_id: String,
    pub provider: String,
    pub key: String,
    pub hotwords: Vec<String>,
    pub smooth: bool,
    pub resource_id: Option<String>,
    #[serde(skip)]
    pub request_id: String,
}
pub enum Audio {
    Pcm(Vec<u8>),
    Finish,
}
struct Session {
    owner: String,
    provider: String,
    cancel: CancellationToken,
    tx: mpsc::Sender<Audio>,
    sequence: u32,
    finishing: bool,
}
#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct Event {
    pub owner: String,
    pub recording_id: String,
    #[serde(rename = "type")]
    pub kind: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub text: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub message: Option<String>,
    pub generation: u32,
    pub sequence: u32,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error: Option<Failure>,
}
#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct Failure {
    stage: String,
    category: String,
    code: String,
    request_id: Option<String>,
}
impl Failure {
    fn sanitized(message: &str) -> Self {
        let (stage, category, code) = match message {
            "connect_timeout" => ("connect", "timeout", "connect_timeout"),
            "send_timeout" => ("stream", "timeout", "send_timeout"),
            "final_timeout" => ("finalize", "timeout", "final_timeout"),
            "recognition_timeout" => ("stream", "timeout", "recognition_timeout"),
            "authentication_failed" => ("connect", "authentication", "authentication_failed"),
            "invalid_credential" => ("connect", "authentication", "invalid_credential"),
            "closed_before_final" => ("stream", "network", "closed_before_final"),
            "event_queue_full" => ("stream", "capacity", "event_queue_full"),
            value if value.starts_with("connect_failed:") => ("connect", "network", "connect_failed"),
            value if value.starts_with("send_failed:") => ("stream", "network", "send_failed"),
            value if value.starts_with("receive_failed:") => ("stream", "network", "receive_failed"),
            value if value.starts_with("provider_error:") => ("stream", "provider", "provider_error"),
            _ => ("stream", "protocol", "invalid_provider_response"),
        };
        let provider_code = message.strip_prefix("provider_error: ").filter(|value| {
            !value.is_empty() && value.bytes().all(|byte| byte.is_ascii_digit()) && value.parse::<u64>().is_ok()
        });
        let code = match provider_code {
            Some(value) => value.to_string(),
            None => code.into(),
        };
        Self { stage: stage.into(), category: category.into(), code, request_id: None }
    }
}
impl Event {
    fn new(owner: String, recording_id: String, kind: &str, text: Option<String>, message: Option<String>) -> Self {
        let error = message.as_deref().map(Failure::sanitized);
        let message = error
            .as_ref()
            .map(|failure| if failure.category == "provider" { "provider_error".into() } else { failure.code.clone() });
        Self { owner, recording_id, kind: kind.into(), text, message, generation: 0, sequence: 0, error }
    }
}
struct State {
    owner: Option<(String, String)>,
    sessions: HashMap<String, Session>,
    events: VecDeque<Event>,
    completed: VecDeque<(String, String)>,
    closed: bool,
    generation: u32,
    versions: HashMap<String, (u32, u32)>,
}
pub struct Service {
    state: Mutex<State>,
    changed: Condvar,
    runtime: Mutex<Option<Runtime>>,
}
impl Service {
    pub fn new() -> Result<Arc<Self>, String> {
        Ok(Arc::new(Self {
            state: Mutex::new(State {
                owner: None,
                sessions: HashMap::new(),
                events: VecDeque::new(),
                completed: VecDeque::new(),
                closed: false,
                generation: 0,
                versions: HashMap::new(),
            }),
            changed: Condvar::new(),
            runtime: Mutex::new(Some(Runtime::new().map_err(|e| e.to_string())?)),
        }))
    }
    pub fn start(self: &Arc<Self>, mut start: Start) -> Result<(), String> {
        if start.key.is_empty() || !["vui", "doubao"].contains(&start.provider.as_str()) {
            return Err("invalid_profile".into());
        }
        if start.recording_id.len() > 80 || start.hotwords.len() > 100 || start.hotwords.iter().any(|w| w.len() > 512) {
            return Err("invalid_start_options".into());
        }
        start.request_id = uuid::Uuid::new_v4().to_string();
        let request_id = start.request_id.clone();
        let executor = self.runtime.lock().map_err(|_| "runtime_poisoned")?;
        let executor = executor.as_ref().ok_or("service_closed")?;
        let mut state = self.state.lock().map_err(|_| "service_poisoned")?;
        if state.events.len() >= 56 {
            return Err("event_queue_full".into());
        }
        if state.closed {
            return Err("service_closed".into());
        }
        if state.versions.contains_key(&start.recording_id) {
            return Err("duplicate_recording".into());
        }
        if let Some((owner, id)) = state.owner.clone() {
            Self::enqueue(&mut state, Event::new(owner, id, "revoke", None, None));
            self.changed.notify_all();
            let (next, wait) = self
                .changed
                .wait_timeout_while(state, Duration::from_secs(3), |s| s.owner.is_some() && !s.closed)
                .map_err(|_| "service_poisoned")?;
            state = next;
            if wait.timed_out() && state.owner.is_some() {
                return Err("capture_release_timeout".into());
            }
            if state.closed {
                return Err("service_closed".into());
            }
        }
        if state.sessions.len() >= 4 {
            return Err("session_limit".into());
        }
        let (tx, rx) = mpsc::channel(10);
        let cancel = CancellationToken::new();
        let owner = start.owner.clone();
        let id = start.recording_id.clone();
        state.generation = state.generation.checked_add(1).ok_or("generation_exhausted")?;
        let generation = state.generation;
        state.versions.insert(id.clone(), (generation, 0));
        state.owner = Some((owner.clone(), id.clone()));
        state.sessions.insert(
            id.clone(),
            Session {
                owner: owner.clone(),
                provider: start.provider.clone(),
                cancel: cancel.clone(),
                tx,
                sequence: 0,
                finishing: false,
            },
        );
        drop(state);
        let service = Arc::clone(self);
        executor.spawn(async move {
            let result=tokio::select!{biased; _=cancel.cancelled()=>Err("cancelled".into()), result=crate::provider::run(start,rx,|kind,text|service.emit(Event::new(owner.clone(),id.clone(),kind,text,None)))=>result};
            let (kind,text,message)=match result {Ok(text)=>("final",Some(text),None),Err(error) if error=="cancelled"=>("cancelled",None,None),Err(error)=>("failed",None,Some(error))};
            let mut state=service.state.lock().expect("service state");
            state.sessions.remove(&id);
            if state.completed.len()==64 && let Some((expired,_))=state.completed.pop_front(){ state.versions.remove(&expired); }
            state.completed.push_back((id.clone(),owner.clone()));
            // Capture ownership is released only by the host acknowledgment, not ASR termination.
            let mut event = Event::new(owner,id,kind,text,message);
            if let Some(error) = event.error.as_mut() { error.request_id = Some(request_id); }
            Self::enqueue(&mut state, event);
            service.changed.notify_all();
        });
        Ok(())
    }
    fn enqueue(state: &mut State, mut event: Event) {
        let (generation, sequence) = state.versions.get_mut(&event.recording_id).expect("registered recording");
        *sequence += 1;
        event.generation = *generation;
        event.sequence = *sequence;
        state.events.push_back(event);
    }
    fn emit(&self, event: Event) -> Result<(), String> {
        let mut state = self.state.lock().map_err(|_| "service_poisoned")?;
        if state.closed {
            return Err("service_closed".into());
        }
        if event.kind == "partial" {
            state.events.retain(|e| !(e.kind == "partial" && e.recording_id == event.recording_id));
        }
        if state.events.len() >= 64 {
            return Err("event_queue_full".into());
        }
        Self::enqueue(&mut state, event);
        self.changed.notify_all();
        Ok(())
    }
    pub fn push(&self, owner: &str, id: &str, sequence: u32, bytes: &[u8]) -> Result<(), String> {
        if bytes.is_empty() || bytes.len() > 6400 || !bytes.len().is_multiple_of(2) {
            return Err("invalid_pcm".into());
        }
        let mut state = self.state.lock().map_err(|_| "service_poisoned")?;
        let session = state.sessions.get_mut(id).ok_or("unknown_recording")?;
        if session.owner != owner {
            return Err("wrong_owner".into());
        }
        if session.finishing || session.sequence != sequence {
            return Err("invalid_audio_sequence".into());
        }
        session.tx.try_send(Audio::Pcm(bytes.to_vec())).map_err(|_| "audio_queue_full")?;
        session.sequence += 1;
        Ok(())
    }
    pub fn control(&self, owner: &str, id: &str, action: &str) -> Result<(), String> {
        let mut state = self.state.lock().map_err(|_| "service_poisoned")?;
        if action == "release" {
            if state.owner.as_ref() == Some(&(owner.into(), id.into())) {
                state.owner = None;
                self.changed.notify_all();
                return Ok(());
            }
            return Err("wrong_capture_owner".into());
        }
        if action == "cancel"
            && state
                .completed
                .iter()
                .any(|(completed_id, completed_owner)| completed_id == id && completed_owner == owner)
        {
            return Ok(());
        }
        let session = state.sessions.get_mut(id).ok_or("unknown_recording")?;
        if session.owner != owner {
            return Err("wrong_owner".into());
        }
        match action {
            "cancel" => {
                session.cancel.cancel();
                Ok(())
            }
            "finish" => {
                if session.finishing {
                    return Err("already_finishing".into());
                }
                session.tx.try_send(Audio::Finish).map_err(|_| "audio_queue_full")?;
                session.finishing = true;
                Ok(())
            }
            _ => Err("unknown_control".into()),
        }
    }
    pub fn cancel_provider(&self, provider: &str) -> Result<(), String> {
        if !["vui", "doubao"].contains(&provider) {
            return Err("invalid_profile".into());
        }
        let mut state = self.state.lock().map_err(|_| "service_poisoned")?;
        let mut revocations = Vec::new();
        for (id, session) in &state.sessions {
            if session.provider == provider && !session.cancel.is_cancelled() {
                session.cancel.cancel();
                if state.owner.as_ref() == Some(&(session.owner.clone(), id.clone())) {
                    revocations.push(Event::new(session.owner.clone(), id.clone(), "revoke", None, None));
                }
            }
        }
        for event in revocations {
            Self::enqueue(&mut state, event);
        }
        self.changed.notify_all();
        Ok(())
    }
    pub fn detach(&self, owner: &str) -> Result<(), String> {
        let mut state = self.state.lock().map_err(|_| "service_poisoned")?;
        for session in state.sessions.values() {
            if session.owner == owner {
                session.cancel.cancel();
            }
        }
        // This command is host-only: it asserts the webview has been destroyed.
        if state.owner.as_ref().is_some_and(|(current, _)| current == owner) {
            state.owner = None;
        }
        self.changed.notify_all();
        Ok(())
    }
    pub fn next(&self) -> Option<Event> {
        let mut state = self.state.lock().expect("service state");
        loop {
            if let Some(event) = state.events.pop_front() {
                return Some(event);
            }
            if state.closed {
                return None;
            }
            state = self.changed.wait(state).expect("event wait");
        }
    }
    pub fn shutdown(&self) {
        let mut state = self.state.lock().expect("service state");
        state.closed = true;
        for session in state.sessions.values() {
            session.cancel.cancel();
        }
        self.changed.notify_all();
        drop(state);
        // Dropping the executor joins its worker threads. A drained session map alone
        // does not prove that native futures have returned or released their Arc.
        let runtime = self.runtime.lock().expect("runtime state").take();
        drop(runtime);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn provider_codes_retain_only_strict_unsigned_numbers() {
        let event = Event::new("w".into(), "r".into(), "failed", None, Some("provider_error: 45000001".into()));
        assert_eq!(event.message.as_deref(), Some("provider_error"));
        assert_eq!(event.error.unwrap().code, "45000001");
        for unsafe_code in ["45000001 SECRET", "\"SECRET\"", "45000001\n", "+123", "18446744073709551616", ""] {
            let event =
                Event::new("w".into(), "r".into(), "failed", None, Some(format!("provider_error: {unsafe_code}")));
            assert_eq!(event.error.as_ref().unwrap().code, "provider_error");
            assert_eq!(event.message.as_deref(), Some("provider_error"));
            assert!(!serde_json::to_string(&event).unwrap().contains("SECRET"));
        }
    }
    #[test]
    fn event_metadata_survives_partial_coalescing_and_failure_is_sanitized() {
        let service = Service::new().unwrap();
        service.state.lock().unwrap().versions.insert("r".into(), (4, 0));
        service.emit(Event::new("w".into(), "r".into(), "partial", Some("old".into()), None)).unwrap();
        service.emit(Event::new("w".into(), "r".into(), "partial", Some("new".into()), None)).unwrap();
        service
            .emit(Event::new("w".into(), "r".into(), "failed", None, Some("connect_failed: SECRET_KEY body".into())))
            .unwrap();
        let partial = service.next().unwrap();
        assert_eq!((partial.generation, partial.sequence), (4, 2));
        let failure = service.next().unwrap();
        assert_eq!(failure.sequence, 3);
        let json = serde_json::to_string(&failure).unwrap();
        assert!(!json.contains("SECRET"));
        assert_eq!(failure.error.unwrap().code, "connect_failed");
        service.shutdown();
    }
    #[test]
    fn revocation_cancels_only_selected_provider_and_keeps_capture_until_ack() {
        let service = Service::new().unwrap();
        for (id, provider) in [("a", "vui"), ("b", "doubao")] {
            let (tx, _rx) = mpsc::channel(10);
            let mut state = service.state.lock().unwrap();
            state.versions.insert(id.into(), (1, 0));
            state.sessions.insert(
                id.into(),
                Session {
                    owner: "w".into(),
                    provider: provider.into(),
                    cancel: CancellationToken::new(),
                    tx,
                    sequence: 0,
                    finishing: false,
                },
            );
        }
        service.state.lock().unwrap().owner = Some(("w".into(), "a".into()));
        service.cancel_provider("vui").unwrap();
        {
            let state = service.state.lock().unwrap();
            assert!(state.sessions["a"].cancel.is_cancelled());
            assert!(!state.sessions["b"].cancel.is_cancelled());
            assert!(state.owner.is_some());
        }
        assert_eq!(service.next().unwrap().kind, "revoke");
        service.control("w", "a", "release").unwrap();
        service.shutdown();
    }
    #[test]
    fn shutdown_joins_tasks_and_wakes_event_reader() {
        let service = Service::new().unwrap();
        let worker = Arc::clone(&service);
        let (ready_tx, ready_rx) = std::sync::mpsc::channel();
        service.runtime.lock().unwrap().as_ref().unwrap().spawn(async move {
            let _held = worker;
            ready_tx.send(()).unwrap();
            std::future::pending::<()>().await;
        });
        ready_rx.recv().unwrap();
        let reader = Arc::clone(&service);
        let thread = std::thread::spawn(move || reader.next());
        service.shutdown();
        assert!(thread.join().unwrap().is_none());
        assert_eq!(Arc::strong_count(&service), 1);
    }
    #[test]
    fn release_requires_exact_owner_and_recording() {
        let service = Service::new().unwrap();
        service.state.lock().unwrap().owner = Some(("window-a".into(), "recording-a".into()));
        assert!(service.control("window-b", "recording-a", "release").is_err());
        assert!(service.control("window-a", "recording-b", "release").is_err());
        assert!(service.state.lock().unwrap().owner.is_some());
        service.control("window-a", "recording-a", "release").unwrap();
        assert!(service.state.lock().unwrap().owner.is_none());
        service.shutdown();
    }
    #[test]
    fn native_audio_budget_and_sequence_are_enforced() {
        let service = Service::new().unwrap();
        let (tx, _rx) = mpsc::channel(10);
        service.state.lock().unwrap().sessions.insert(
            "r".into(),
            Session {
                owner: "w".into(),
                provider: "vui".into(),
                cancel: CancellationToken::new(),
                tx,
                sequence: 0,
                finishing: false,
            },
        );
        assert!(service.push("wrong", "r", 0, &[0, 0]).is_err());
        assert!(service.push("w", "r", 1, &[0, 0]).is_err());
        for sequence in 0..10 {
            service.push("w", "r", sequence, &[0; 6400]).unwrap();
        }
        assert_eq!(service.push("w", "r", 10, &[0, 0]), Err("audio_queue_full".into()));
        service.control("w", "r", "cancel").unwrap();
        assert!(service.state.lock().unwrap().sessions["r"].cancel.is_cancelled());
        service.shutdown();
    }
}

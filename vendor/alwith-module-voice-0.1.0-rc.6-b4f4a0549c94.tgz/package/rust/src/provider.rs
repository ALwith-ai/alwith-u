use crate::{
    sauc,
    service::{Audio, Start},
};
use futures_util::{SinkExt, StreamExt};
use serde_json::{Value, json};
use tokio::{
    sync::mpsc,
    time::{Duration, Instant, sleep_until, timeout},
};
use tokio_tungstenite::{
    Connector, connect_async_tls_with_config,
    tungstenite::{Message, client::IntoClientRequest},
};

fn resource_header(resource_id: Option<&str>) -> Result<tokio_tungstenite::tungstenite::http::HeaderValue, String> {
    // Missing or blank configuration selects the default resource.
    let value = resource_id.filter(|value| !value.trim().is_empty()).unwrap_or("volc.seedasr.sauc.duration");
    if value.is_empty() || !value.bytes().all(|byte| byte.is_ascii_alphanumeric() || b"._-".contains(&byte)) {
        return Err("invalid_doubao_resource_id".into());
    }
    value.parse().map_err(|_| "invalid_doubao_resource_id".into())
}

pub async fn run(
    start: Start, audio: mpsc::Receiver<Audio>, emit: impl Fn(&str, Option<String>) -> Result<(), String>,
) -> Result<String, String> {
    let endpoint = match start.provider.as_str() {
        "doubao" => "wss://openspeech.bytedance.com/api/v3/sauc/bigmodel_async",
        "vui" => "wss://api.vuilabs.cn/v1/asr/stream",
        _ => return Err("unsupported_provider".into()),
    };
    run_at(start, audio, emit, endpoint).await
}
async fn run_at(
    start: Start, mut audio: mpsc::Receiver<Audio>, emit: impl Fn(&str, Option<String>) -> Result<(), String>,
    endpoint: &str,
) -> Result<String, String> {
    let doubao = start.provider == "doubao";
    let mut request = endpoint.into_client_request().map_err(|e| e.to_string())?;
    let key = start.key.parse().map_err(|_| "invalid_credential")?;
    request.headers_mut().insert("X-Api-Key", key);
    if doubao {
        request.headers_mut().insert("X-Api-Resource-Id", resource_header(start.resource_id.as_deref())?);
        for name in ["X-Api-Connect-Id", "X-Api-Request-Id"] {
            request.headers_mut().insert(name, start.request_id.parse().expect("uuid header"));
        }
    }
    let tls =
        rustls::ClientConfig::builder_with_provider(std::sync::Arc::new(rustls::crypto::aws_lc_rs::default_provider()))
            .with_safe_default_protocol_versions()
            .map_err(|e| e.to_string())?
            .with_root_certificates(rustls::RootCertStore::from_iter(webpki_roots::TLS_SERVER_ROOTS.iter().cloned()))
            .with_no_client_auth();
    let (mut ws, _) = timeout(
        Duration::from_secs(10),
        connect_async_tls_with_config(
            request,
            Some(
                tokio_tungstenite::tungstenite::protocol::WebSocketConfig::default()
                    .max_message_size(Some(1024 * 1024))
                    .max_frame_size(Some(1024 * 1024)),
            ),
            false,
            Some(Connector::Rustls(std::sync::Arc::new(tls))),
        ),
    )
    .await
    .map_err(|_| "connect_timeout")?
    .map_err(|e| match e {
        tokio_tungstenite::tungstenite::Error::Http(response) if matches!(response.status().as_u16(), 401 | 403) => {
            "authentication_failed".to_string()
        }
        _ => "connect_failed: transport".to_string(),
    })?;
    let first = if doubao {
        let mut request = json!({"model_name":"bigmodel","enable_itn":true,"enable_punc":true,"enable_ddc":start.smooth,"result_type":"full","end_window_size":800,"force_to_speech_time":1000});
        if !start.hotwords.is_empty() {
            request["corpus"] = json!({"context":json!({"hotwords":start.hotwords.iter().map(|word|json!({"word":word})).collect::<Vec<_>>()}).to_string()});
        }
        Message::Binary(sauc::build_full_client_request(&serde_json::to_vec(&json!({"user":{"uid":start.recording_id},"audio":{"format":"pcm","codec":"raw","rate":16000,"bits":16,"channel":1},"request":request})).map_err(|e|e.to_string())?).into())
    } else {
        if start.smooth {
            return Err("vui_does_not_support_smooth".into());
        }
        Message::Text(
            json!({"type":"start","audio_format":"pcm","recording_id":start.recording_id,"hotwords":start.hotwords})
                .to_string()
                .into(),
        )
    };
    timeout(Duration::from_secs(5), ws.send(first)).await.map_err(|_| "send_timeout")?.map_err(|e| e.to_string())?;
    let mut ready = false;
    let mut finishing = false;
    let mut deadline = Instant::now() + Duration::from_secs(10);
    loop {
        tokio::select! {
            _ = sleep_until(deadline) => return Err(if finishing {"final_timeout"} else {"recognition_timeout"}.into()),
            incoming = ws.next() => {
                let message = incoming.ok_or("closed_before_final")?.map_err(|e|format!("receive_failed: {e}"))?;
                let response = parse(doubao, message)?;
                match response {
                    Response::Ignore => {},
                    Response::Ready => {
                        if !ready { ready=true; emit("ready", None)?; deadline=Instant::now()+Duration::from_secs(300); }
                    },
                    Response::Text { text, last } => {
                        if !ready { ready=true; emit("ready", None)?; deadline=Instant::now()+Duration::from_secs(300); }
                        if last { return Ok(text); }
                        emit("partial", Some(text))?;
                    },
                }
            },
            frame = audio.recv(), if ready && !finishing => {
                let message = match frame.ok_or("audio_channel_closed")? {
                    Audio::Pcm(pcm) => if doubao {Message::Binary(sauc::build_audio_request(&pcm,false).into())} else {Message::Binary(pcm.into())},
                    Audio::Finish => {
                        finishing=true;
                        deadline=Instant::now()+Duration::from_secs(30);
                        if doubao {Message::Binary(sauc::build_audio_request(&[],true).into())} else {Message::Text(json!({"type":"stop"}).to_string().into())}
                    }
                };
                timeout(Duration::from_secs(5),ws.send(message)).await.map_err(|_|"send_timeout")?.map_err(|e|format!("send_failed: {e}"))?;
            }
        }
    }
}
#[derive(Debug, PartialEq)]
enum Response {
    Ignore,
    Ready,
    Text { text: String, last: bool },
}
fn parse(doubao: bool, message: Message) -> Result<Response, String> {
    if matches!(message, Message::Close(_)) {
        return Err("closed_before_final".into());
    }
    if matches!(message, Message::Ping(_) | Message::Pong(_)) {
        return Ok(Response::Ignore);
    }
    if doubao {
        let Message::Binary(bytes) = message else { return Err("expected_sauc_binary".into()) };
        match sauc::parse_server_frame(&bytes)? {
            sauc::ServerFrame::Ack => Ok(Response::Ready),
            sauc::ServerFrame::Error { code, .. } => Err(format!("provider_error: {code}")),
            sauc::ServerFrame::Response { is_last, payload } => {
                let value: Value = serde_json::from_slice(&payload).map_err(|e| e.to_string())?;
                if let Some(code) = value.get("code").and_then(Value::as_i64)
                    && code != 0
                    && code != 1000
                    && code != 20000000
                {
                    return Err(format!("provider_error: {code}"));
                }
                match value.pointer("/result/text") {
                    Some(Value::String(text)) => Ok(Response::Text { text: text.clone(), last: is_last }),
                    None if !is_last => Ok(Response::Ready),
                    _ => Err("invalid_result_text".into()),
                }
            }
        }
    } else {
        let Message::Text(text) = message else { return Err("expected_vui_json".into()) };
        let value: Value = serde_json::from_str(&text).map_err(|e| e.to_string())?;
        match value.get("type").and_then(Value::as_str) {
            Some("recording_started") => Ok(Response::Ready),
            Some("asr_partial" | "asr_final") => Ok(Response::Text {
                text: value["text"].as_str().ok_or("invalid_result_text")?.into(),
                last: value["type"] == "asr_final",
            }),
            Some("error") => Err(format!("provider_error: {}", value["code"])),
            _ => Err("unknown_vui_event".into()),
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    // Tungstenite requires its unboxed HTTP error response in this callback.
    #[allow(clippy::result_large_err)]
    #[test]
    fn resource_ids_default_and_reject_invalid_headers() {
        assert_eq!(resource_header(None).unwrap(), "volc.seedasr.sauc.duration");
        for value in ["", " "] {
            assert_eq!(resource_header(Some(value)).unwrap(), "volc.seedasr.sauc.duration");
        }
        assert_eq!(resource_header(Some("resource\r\nInjected: value")).unwrap_err(), "invalid_doubao_resource_id");
    }
    // The WebSocket handshake callback requires tungstenite's unboxed error response.
    #[allow(clippy::result_large_err)]
    #[tokio::test]
    async fn doubao_socket_validates_headers_request_pcm_and_terminal_frame() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let endpoint = format!("ws://{}", listener.local_addr().unwrap());
        let request_id = uuid::Uuid::new_v4().to_string();
        let expected_request_id = request_id.clone();
        let server = tokio::spawn(async move {
            let (socket, _) = listener.accept().await.unwrap();
            let mut ws = tokio_tungstenite::accept_hdr_async(
                socket,
                |request: &tokio_tungstenite::tungstenite::handshake::server::Request, response| {
                    assert_eq!(request.headers()["X-Api-Key"], "fake-local-test-key");
                    assert_eq!(request.headers()["X-Api-Resource-Id"], "volc.seedasr.sauc.concurrent");
                    assert_eq!(request.headers()["X-Api-Request-Id"], expected_request_id);
                    Ok(response)
                },
            )
            .await
            .unwrap();
            let Message::Binary(first) = ws.next().await.unwrap().unwrap() else { panic!("SAUC request") };
            assert_eq!(&first[..4], &[0x11, 0x10, 0x10, 0]);
            assert_eq!(u32::from_be_bytes(first[4..8].try_into().unwrap()) as usize, first.len() - 8);
            let request: Value = serde_json::from_slice(&first[8..]).unwrap();
            assert_eq!(request["audio"]["rate"], 16000);
            assert_eq!(request["request"]["enable_ddc"], true);
            let context: Value =
                serde_json::from_str(request["request"]["corpus"]["context"].as_str().unwrap()).unwrap();
            assert_eq!(context["hotwords"][0]["word"], "ALwith");
            ws.send(Message::Binary(vec![0x11, 0xb0, 0, 0].into())).await.unwrap();
            let Message::Binary(audio) = ws.next().await.unwrap().unwrap() else { panic!("SAUC audio") };
            assert_eq!(audio.as_ref(), &[0x11, 0x20, 0, 0, 0, 0, 0, 2, 1, 0]);
            let Message::Binary(last) = ws.next().await.unwrap().unwrap() else { panic!("SAUC last") };
            assert_eq!(last.as_ref(), &[0x11, 0x22, 0, 0, 0, 0, 0, 0]);
            let payload = br#"{"code":20000000,"result":{"text":"recognized"}}"#;
            let mut final_frame = vec![0x11, 0x92, 0x10, 0];
            final_frame.extend_from_slice(&(payload.len() as u32).to_be_bytes());
            final_frame.extend_from_slice(payload);
            ws.send(Message::Binary(final_frame.into())).await.unwrap();
        });
        let (tx, rx) = mpsc::channel(10);
        tx.send(Audio::Pcm(vec![1, 0])).await.unwrap();
        tx.send(Audio::Finish).await.unwrap();
        let start = Start {
            owner: "test".into(),
            recording_id: "test".into(),
            provider: "doubao".into(),
            key: "fake-local-test-key".into(),
            hotwords: vec!["ALwith".into()],
            smooth: true,
            resource_id: Some("volc.seedasr.sauc.concurrent".into()),
            request_id,
        };
        let result =
            timeout(Duration::from_secs(3), run_at(start, rx, |_, _| Ok(()), &endpoint)).await.unwrap().unwrap();
        assert_eq!(result, "recognized");
        server.await.unwrap();
    }
    #[tokio::test]
    async fn vui_socket_sends_audio_stop_and_waits_for_final() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let endpoint = format!("ws://{}", listener.local_addr().unwrap());
        let server = tokio::spawn(async move {
            let (socket, _) = listener.accept().await.unwrap();
            let mut ws = tokio_tungstenite::accept_async(socket).await.unwrap();
            let Message::Text(start) = ws.next().await.unwrap().unwrap() else { panic!("start JSON") };
            assert_eq!(serde_json::from_str::<Value>(&start).unwrap()["type"], "start");
            ws.send(Message::Text(r#"{"type":"recording_started"}"#.into())).await.unwrap();
            assert_eq!(ws.next().await.unwrap().unwrap(), Message::Binary(vec![1, 0].into()));
            let Message::Text(stop) = ws.next().await.unwrap().unwrap() else { panic!("stop JSON") };
            assert_eq!(serde_json::from_str::<Value>(&stop).unwrap()["type"], "stop");
            ws.send(Message::Text(r#"{"type":"asr_final","text":"recognized"}"#.into())).await.unwrap();
        });
        let (tx, rx) = mpsc::channel(10);
        tx.send(Audio::Pcm(vec![1, 0])).await.unwrap();
        tx.send(Audio::Finish).await.unwrap();
        let start = Start {
            owner: "test".into(),
            recording_id: "test".into(),
            provider: "vui".into(),
            key: "fake-local-test-key".into(),
            hotwords: vec![],
            smooth: false,
            resource_id: None,
            request_id: uuid::Uuid::new_v4().to_string(),
        };
        let result =
            timeout(Duration::from_secs(3), run_at(start, rx, |_, _| Ok(()), &endpoint)).await.unwrap().unwrap();
        assert_eq!(result, "recognized");
        server.await.unwrap();
    }
    #[test]
    fn close_never_becomes_final() {
        assert_eq!(parse(true, Message::Close(None)), Err("closed_before_final".into()));
    }
    #[test]
    fn vui_snapshots_allow_empty_and_final() {
        assert_eq!(
            parse(false, Message::Text(r#"{"type":"asr_partial","text":""}"#.into())).unwrap(),
            Response::Text { text: "".into(), last: false }
        );
        assert_eq!(
            parse(false, Message::Text(r#"{"type":"asr_final","text":"done"}"#.into())).unwrap(),
            Response::Text { text: "done".into(), last: true }
        );
    }
}

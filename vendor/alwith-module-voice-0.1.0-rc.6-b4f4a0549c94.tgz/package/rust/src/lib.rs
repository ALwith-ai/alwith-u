//! Shared voice service, compiled directly into the host application.
pub mod contract;
mod provider;
mod sauc;
mod service;
use serde_json::Value;
use service::Service;
use std::sync::Arc;

struct Inner(Arc<Service>);
impl Drop for Inner {
    fn drop(&mut self) {
        self.0.shutdown();
    }
}

/// Cloneable host handle. Call shutdown before joining the blocking event reader.
#[derive(Clone)]
pub struct Voice(Arc<Inner>);
impl Voice {
    pub fn new() -> Result<Self, String> {
        Ok(Self(Arc::new(Inner(Service::new()?))))
    }
    pub fn command(&self, value: Value) -> Result<(), String> {
        let service = &self.0.0;
        if value["action"] == "cancelProvider" {
            return service.cancel_provider(value["provider"].as_str().ok_or("missing_provider")?);
        }
        let owner = value["owner"].as_str().ok_or("missing_owner")?;
        match value["action"].as_str().ok_or("missing_action")? {
            "start" => service.start(serde_json::from_value(value["start"].clone()).map_err(|e| e.to_string())?),
            "detach" => service.detach(owner),
            action => service.control(owner, value["recordingId"].as_str().ok_or("missing_id")?, action),
        }
    }
    pub fn push(&self, owner: &str, id: &str, sequence: u32, pcm: &[u8]) -> Result<(), String> {
        self.0.0.push(owner, id, sequence, pcm)
    }
    /// Blocks until an event arrives or shutdown occurs. Run on a dedicated host thread.
    pub fn next(&self) -> Result<Option<Value>, String> {
        self.0.0.next().map(serde_json::to_value).transpose().map_err(|e| e.to_string())
    }
    /// Call from a synchronous host thread; joins the service runtime and wakes readers.
    pub fn shutdown(&self) {
        self.0.0.shutdown();
    }
}

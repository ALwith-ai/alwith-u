use serde::{Deserialize, Serialize};
#[derive(Clone, Deserialize, Serialize, specta::Type)]
#[serde(rename_all = "lowercase")]
pub enum Provider {
    Vui,
    Doubao,
}
#[derive(Clone, Deserialize, Serialize, specta::Type)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct StartOptions {
    pub recording_id: String,
    pub credential_profile_id: Provider,
    pub hotwords: Vec<String>,
    pub smooth: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub resource_id: Option<String>,
}
#[derive(Clone, Deserialize, Serialize, specta::Type)]
#[serde(rename_all = "camelCase")]
pub struct VoiceFailure {
    pub stage: String,
    pub category: String,
    pub code: String,
    pub request_id: Option<String>,
}
#[derive(Clone, Deserialize, Serialize, specta::Type)]
#[serde(tag = "type", rename_all = "camelCase", rename_all_fields = "camelCase")]
pub enum VoiceEvent {
    Ready {
        recording_id: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        generation: Option<u32>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        sequence: Option<u32>,
    },
    Partial {
        recording_id: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        generation: Option<u32>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        sequence: Option<u32>,
        text: String,
    },
    Final {
        recording_id: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        generation: Option<u32>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        sequence: Option<u32>,
        text: String,
    },
    Failed {
        recording_id: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        generation: Option<u32>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        sequence: Option<u32>,
        message: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        error: Option<VoiceFailure>,
    },
    Cancelled {
        recording_id: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        generation: Option<u32>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        sequence: Option<u32>,
    },
    Revoke {
        recording_id: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        generation: Option<u32>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        sequence: Option<u32>,
    },
}

//! 配置加载/校验/保存。映射用 Karabiner 结构:控件 → [`Mapping`](handler + event)。

use std::collections::HashMap;
use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::action::{Event, Mapping};
use crate::event::{Button, Direction};

#[derive(Debug, Clone, Serialize, Deserialize, specta::Type)]
pub struct Config {
    /// 摇杆死区(0.0–1.0)。
    #[serde(default = "default_deadzone")]
    pub deadzone: f32,
    /// 轮询间隔(毫秒)。
    #[serde(default = "default_poll_ms")]
    pub poll_interval_ms: u64,
    /// 光标移动速度倍率(方向键 / 摇杆映射成鼠标移动时每 tick 位移的缩放,1.0 = 原始步长)。
    #[serde(default = "default_move_scale")]
    pub mouse_move_scale: f32,
    /// 按钮映射。
    #[serde(default)]
    pub buttons: HashMap<Button, Mapping>,
    /// 左摇杆方向映射。
    #[serde(default)]
    pub left_stick: HashMap<Direction, Mapping>,
    /// 右摇杆方向映射。
    #[serde(default)]
    pub right_stick: HashMap<Direction, Mapping>,
    /// 条件覆盖(借 Karabiner 的 `conditions` 思路,收敛「按 App / 图层」为一套 `when`):
    /// 有序列表,按顺序把满足 `when` 的那些覆盖**层叠**到基础映射上(靠后的赢)。
    /// 上下文 = 当前前台 App(仅 macOS 检测)+ 已激活图层(由 `to_layer` 控件按住时激活)。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub overrides: Vec<Override>,
}

/// 一条条件覆盖:`when` 满足时,用它的映射覆盖对应控件(未列出的控件保持不变)。
#[derive(Debug, Clone, Default, Serialize, Deserialize, specta::Type)]
pub struct Override {
    #[serde(default)]
    pub when: When,
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub buttons: HashMap<Button, Mapping>,
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub left_stick: HashMap<Direction, Mapping>,
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub right_stick: HashMap<Direction, Mapping>,
}

/// 覆盖生效的条件。各字段 AND;字段内:`app` 任一 bundle id 相等即可(OR),
/// `layer` 需全部处于激活(AND)。空字段 = 不约束该维度。
#[derive(Debug, Clone, Default, Serialize, Deserialize, specta::Type)]
pub struct When {
    /// 前台 App 标识**精确列表**(任一相等即算 App 条件满足;mac=bundle id / win=exe 文件名小写)。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub app: Vec<String>,
    /// 需处于激活的图层名(全部需激活)。图层由某控件的 `to_layer` 按住时激活。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub layer: Vec<String>,
}

fn default_deadzone() -> f32 {
    0.2
}
fn default_poll_ms() -> u64 {
    8
}
fn default_move_scale() -> f32 {
    1.0
}

/// 构造 helper:一个 `to` handler,发一个 key_code(值用 W3C code)。
fn to_key(code: &str) -> Mapping {
    Mapping { to: vec![Event { key_code: Some(code.into()), ..Default::default() }], ..Default::default() }
}
/// 构造 helper:一个 `to` handler,发 key_code 并**按住连发**(方向键用)。
fn to_repeat(code: &str) -> Mapping {
    Mapping {
        to: vec![Event { key_code: Some(code.into()), repeat: true, ..Default::default() }],
        ..Default::default()
    }
}
/// 构造 helper:一个 `to` handler,发 key_code + 修饰键(组合键)。
fn to_combo(modifiers: &[&str], code: &str) -> Mapping {
    Mapping {
        to: vec![Event {
            key_code: Some(code.into()),
            modifiers: modifiers.iter().map(|s| s.to_string()).collect(),
            ..Default::default()
        }],
        ..Default::default()
    }
}

impl Default for Config {
    fn default() -> Self {
        // 键名一律 W3C code。修饰键平台差异:主 = ⌘/Ctrl,次 = Ctrl/⌘。
        let mac = cfg!(target_os = "macos");
        let primary = if mac { "MetaLeft" } else { "ControlLeft" };
        let secondary = if mac { "ControlLeft" } else { "MetaLeft" };

        let mut buttons = HashMap::new();
        // 面键:确认 / 返回 / 取消 / 切换应用。
        buttons.insert(Button::South, to_key("Enter"));
        buttons.insert(Button::East, to_key("Backspace"));
        buttons.insert(Button::West, to_key("Escape"));
        buttons.insert(Button::North, to_combo(if mac { &["MetaLeft"] } else { &["AltLeft"] }, "Tab"));
        // 肩键/扳机 = 四个修饰键(按住语义:`to` key_code 随控件按下/抬起)。
        buttons.insert(Button::L1, to_key("ShiftLeft"));
        buttons.insert(Button::R1, to_key(primary));
        buttons.insert(Button::L2, to_key("AltLeft"));
        buttons.insert(Button::R2, to_key(secondary));
        // 菜单键。
        buttons.insert(Button::Select, to_key("Tab")); // 配 L1=Shift → Shift+Tab 反向
        buttons.insert(
            Button::Start,
            if mac { to_combo(&["MetaLeft"], "Space") } else { to_key("MetaLeft") }, // Spotlight / 开始菜单
        );
        buttons.insert(
            Button::Mode,
            if mac { to_combo(&["ControlLeft"], "ArrowUp") } else { to_key("MetaLeft") }, // 调度中心
        );
        buttons.insert(
            Button::Capture,
            if mac {
                to_combo(&["MetaLeft", "ShiftLeft"], "Digit4") // 区域截图
            } else {
                to_combo(&["MetaLeft", "ShiftLeft"], "KeyS") // 截图工具
            },
        );
        buttons.insert(Button::L3, to_key("Space"));
        // 十字键 → 方向键(按住连发)。
        buttons.insert(Button::Up, to_repeat("ArrowUp"));
        buttons.insert(Button::Down, to_repeat("ArrowDown"));
        buttons.insert(Button::Left, to_repeat("ArrowLeft"));
        buttons.insert(Button::Right, to_repeat("ArrowRight"));

        // 左摇杆 → 方向键(按住连发)。
        let mut left_stick = HashMap::new();
        left_stick.insert(Direction::Up, to_repeat("ArrowUp"));
        left_stick.insert(Direction::Down, to_repeat("ArrowDown"));
        left_stick.insert(Direction::Left, to_repeat("ArrowLeft"));
        left_stick.insert(Direction::Right, to_repeat("ArrowRight"));

        // 右摇杆 → 翻页/行首尾(按住连发)。
        let mut right_stick = HashMap::new();
        right_stick.insert(Direction::Up, to_repeat("PageUp"));
        right_stick.insert(Direction::Down, to_repeat("PageDown"));
        right_stick.insert(Direction::Left, to_repeat("Home"));
        right_stick.insert(Direction::Right, to_repeat("End"));

        Config {
            deadzone: 0.2,
            poll_interval_ms: 8,
            mouse_move_scale: 1.0,
            buttons,
            left_stick,
            right_stick,
            overrides: Vec::new(),
        }
    }
}

impl Config {
    /// 从 JSON 文件加载。
    pub fn load(path: &Path) -> Result<Self, String> {
        let text = std::fs::read_to_string(path).map_err(|e| format!("读取配置失败 {}: {e}", path.display()))?;
        Self::from_json(&text)
    }

    pub fn from_json(text: &str) -> Result<Self, String> {
        let config: Self = serde_json::from_str(text).map_err(|e| format!("Invalid configuration JSON: {e}"))?;
        config.validate()?;
        Ok(config)
    }

    /// 保存为 JSON 文件。
    pub fn save(&self, path: &Path) -> Result<(), String> {
        let text = serde_json::to_string_pretty(self).map_err(|e| format!("序列化配置失败: {e}"))?;
        std::fs::write(path, text).map_err(|e| format!("写入配置失败 {}: {e}", path.display()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_config_has_core_bindings() {
        let c = Config::default();
        assert!((c.deadzone - 0.2).abs() < 1e-6);
        assert_eq!(c.poll_interval_ms, 8);
        assert_eq!(c.buttons.get(&Button::South), Some(&to_key("Enter")));
        assert_eq!(c.left_stick.get(&Direction::Up), Some(&to_repeat("ArrowUp"))); // 方向键连发
        assert_eq!(c.right_stick.get(&Direction::Up), Some(&to_repeat("PageUp")));
    }

    #[test]
    fn minimal_json_applies_defaults() {
        let c = Config::from_json(r#"{ "buttons": {} }"#).unwrap();
        assert!((c.deadzone - 0.2).abs() < 1e-6);
        assert_eq!(c.poll_interval_ms, 8);
        assert!(c.buttons.is_empty());
        assert!(c.left_stick.is_empty());
        assert!(c.right_stick.is_empty());
    }

    #[test]
    fn parses_karabiner_style_events() {
        let json = r#"{
            "buttons": {
                "south": { "to": [{ "key_code": "Enter" }] },
                "east": { "to_if_alone": [{ "key_code": "Escape" }], "to_if_held_down": [{ "key_code": "ControlLeft" }] },
                "north": { "to": [{ "key_code": "KeyS", "modifiers": ["MetaLeft"] }] },
                "rightshoulder": { "to": [{ "pointing_button": "button1" }] },
                "start": { "to": [{ "shell_command": "open -a X" }] }
            }
        }"#;
        let c = Config::from_json(json).unwrap();
        assert_eq!(c.buttons.len(), 5);
        assert_eq!(c.buttons.get(&Button::South), Some(&to_key("Enter")));
        // tap/hold 双行为:East 同时有 to_if_alone(轻点=Esc)与 to_if_held_down(长按=Ctrl)。
        let east = c.buttons.get(&Button::East).unwrap();
        assert_eq!(east.to_if_alone[0].key_code.as_deref(), Some("Escape"));
        assert_eq!(east.to_if_held_down[0].key_code.as_deref(), Some("ControlLeft"));
        // 鼠标左键。
        assert_eq!(c.buttons.get(&Button::R1).unwrap().to[0].pointing_button.as_deref(), Some("button1"));
    }

    #[test]
    fn roundtrip_serialize_then_parse() {
        let c = Config::default();
        let json = serde_json::to_string(&c).unwrap();
        let back = Config::from_json(&json).unwrap();
        assert_eq!(back.buttons.get(&Button::North), c.buttons.get(&Button::North));
        assert_eq!(back.left_stick.len(), c.left_stick.len());
        assert_eq!(back.right_stick.len(), c.right_stick.len());
    }

    #[test]
    fn invalid_json_returns_error() {
        assert!(Config::from_json("{ not json").is_err());
    }
}

use crate::{
    contract::*,
    engine::{Engine, EngineEvent, RumbleCmd, VirtualPadCmd},
    profiles::{ProfileRepository, ProfileStore},
};
use std::{
    collections::HashSet,
    fs::File,
    path::PathBuf,
    sync::{Arc, Mutex, mpsc},
};
type Reporter = Arc<dyn Fn(ServiceEvent) + Send + Sync>;
enum BootApply {
    Connected { generation: u32, id: u32, name: String },
    Disconnected { generation: u32, id: u32 },
    Shutdown,
}
struct Shared {
    snapshot: Mutex<Snapshot>,
    report: Reporter,
    boot_apply: mpsc::Sender<BootApply>,
}
impl Shared {
    fn change(&self, update: impl FnOnce(&mut Snapshot)) {
        let mut snapshot = self.snapshot.lock().unwrap();
        update(&mut snapshot);
        snapshot.sequence = snapshot.sequence.checked_add(1).expect("Gamepad sequence exhausted");
        let event = ServiceEvent::Snapshot { snapshot: snapshot.clone() };
        drop(snapshot);
        (self.report)(event);
    }
    fn event(&self, event: EngineEvent) {
        if matches!(&event, EngineEvent::GamepadConnected { .. } | EngineEvent::GamepadDisconnected { .. }) {
            (self.report)(ServiceEvent::Input { event: event.clone() });
        }
        match &event {
            EngineEvent::Input { .. } => (self.report)(ServiceEvent::Input { event }),
            EngineEvent::Ready => self.change(|s| s.state = EngineState::Running),
            EngineEvent::Stopped => self.change(|s| {
                if s.state != EngineState::Failed {
                    s.state = EngineState::Stopped;
                }
                s.devices.clear();
                s.active_device = None;
                s.applied_revision = None;
            }),
            EngineEvent::Error { message } => self.change(|s| {
                s.state = EngineState::Failed;
                s.error = Some(message.clone());
            }),
            EngineEvent::GamepadConnected { id, name, brand, model, battery, charging, connection } => {
                self.change(|s| {
                    s.devices.retain(|d| d.id != *id);
                    s.devices.push(crate::engine::DeviceSnapshot {
                        id: *id,
                        name: name.clone(),
                        brand: brand.clone(),
                        model: model.clone(),
                        battery: *battery,
                        charging: *charging,
                        connection: *connection,
                    });
                });
                let generation = self.snapshot.lock().unwrap().generation;
                if let Err(error) =
                    self.boot_apply.send(BootApply::Connected { generation, id: *id, name: name.clone() })
                {
                    log::error!("Cannot schedule Gamepad stored profile: {error}");
                }
            }
            EngineEvent::GamepadDisconnected { id } => {
                self.change(|snapshot| {
                    snapshot.devices.retain(|device| device.id != *id);
                    if snapshot.active_device == Some(*id) {
                        snapshot.active_device = None;
                    }
                });
                let generation = self.snapshot.lock().unwrap().generation;
                if let Err(error) = self.boot_apply.send(BootApply::Disconnected { generation, id: *id }) {
                    log::error!("Cannot schedule Gamepad selection cleanup: {error}");
                }
            }
            EngineEvent::GamepadBattery { id, battery, charging } => self.change(|s| {
                if let Some(device) = s.devices.iter_mut().find(|d| d.id == *id) {
                    device.battery = *battery;
                    device.charging = *charging;
                }
            }),
        }
    }
}
struct Operations {
    engine: Option<Engine>,
    active_device: Option<u32>,
    repository: Box<dyn ProfileStore>,
    suspensions: HashSet<String>,
    ownership: Option<File>,
}
pub struct GamepadService {
    shared: Arc<Shared>,
    operations: Arc<Mutex<Operations>>,
    boot_worker: Option<std::thread::JoinHandle<()>>,
    ownership_path: PathBuf,
}
impl GamepadService {
    pub fn new(
        profile_path: PathBuf, ownership_path: PathBuf, report: impl Fn(ServiceEvent) + Send + Sync + 'static,
    ) -> Result<Self, String> {
        Self::with_repository(Box::new(ProfileRepository::open(profile_path)?), ownership_path, report)
    }
    pub fn with_repository(
        repository: Box<dyn ProfileStore>, ownership_path: PathBuf,
        report: impl Fn(ServiceEvent) + Send + Sync + 'static,
    ) -> Result<Self, String> {
        let active = repository.active();
        let snapshot = Snapshot {
            version: 1,
            generation: 1,
            sequence: 0,
            state: EngineState::Stopped,
            devices: vec![],
            active_device: None,
            active_profile: active.as_ref().map(|p| p.id.clone()),
            saved_revision: active.map(|p| p.revision),
            applied_revision: None,
            error: None,
        };
        let (boot_apply, receiver) = mpsc::channel();
        let shared = Arc::new(Shared { snapshot: Mutex::new(snapshot), report: Arc::new(report), boot_apply });
        let operations = Arc::new(Mutex::new(Operations {
            engine: None,
            active_device: None,
            repository,
            suspensions: HashSet::new(),
            ownership: None,
        }));
        let weak_shared = Arc::downgrade(&shared);
        let weak_operations = Arc::downgrade(&operations);
        let boot_worker = std::thread::Builder::new()
            .name("gamepad-profiles".into())
            .spawn(move || {
                while let Ok(message) = receiver.recv() {
                    if matches!(message, BootApply::Shutdown) {
                        break;
                    }
                    let (Some(shared), Some(operations)) = (weak_shared.upgrade(), weak_operations.upgrade()) else {
                        break;
                    };
                    // Start holds this lock until the engine handle and Ready state are installed.
                    let mut op = operations.lock().unwrap();
                    let snapshot = shared.snapshot.lock().unwrap().clone();
                    if let BootApply::Disconnected { generation, id } = message {
                        if snapshot.generation == generation && op.active_device == Some(id) {
                            op.active_device = None;
                            if let Some(engine) = &op.engine {
                                engine.set_active(None);
                            }
                            shared.change(|snapshot| snapshot.active_device = None);
                        }
                        continue;
                    }
                    let BootApply::Connected { generation, id, name } = message else {
                        unreachable!();
                    };
                    let Some(profile) =
                        stored_profile_for_connection(&*op.repository, &snapshot, generation, id, &name)
                    else {
                        continue;
                    };
                    let result = (|| {
                        op.engine.as_ref().filter(|engine| engine.is_running()).ok_or("Gamepad engine is stopped")?;
                        op.repository.activate(&name)?;
                        shared.change(|snapshot| {
                            snapshot.active_profile = Some(name.clone());
                            snapshot.saved_revision = Some(profile.revision);
                            snapshot.applied_revision = None;
                        });
                        op.engine.as_ref().expect("running engine exists").set_config(profile.config.clone())?;
                        Ok::<(), String>(())
                    })();
                    match result {
                        Ok(()) => shared.change(|snapshot| {
                            commit_applied_selection(snapshot, generation, &profile, Some(id), |selected| {
                                op.active_device = selected;
                                op.engine.as_ref().expect("running engine exists").set_active(selected);
                            });
                        }),
                        Err(error) => shared.change(|snapshot| snapshot.error = Some(error)),
                    }
                }
            })
            .map_err(|error| error.to_string())?;
        Ok(Self { shared, operations, boot_worker: Some(boot_worker), ownership_path })
    }
    pub fn snapshot(&self) -> Snapshot {
        self.shared.snapshot.lock().unwrap().clone()
    }
    pub fn execute(&self, request: Request) -> Result<Response, String> {
        if matches!(request, Request::Snapshot) {
            return Ok(Response::Snapshot { snapshot: self.snapshot() });
        }
        let mut op = self.operations.lock().unwrap();
        match request {
            Request::Snapshot => unreachable!(),
            Request::LoadProfile { id } => {
                return Ok(Response::Profile { profile: op.repository.get(&id) });
            }
            Request::SaveProfile { id, expected_revision, config, color } => {
                let profile = op.repository.save(&id, expected_revision, *config, color)?;
                if self.snapshot().active_profile.as_deref() == Some(&id) {
                    self.shared.change(|s| s.saved_revision = Some(profile.revision));
                    self.apply(&mut op, &profile);
                }
                return Ok(Response::Saved { profile, snapshot: self.snapshot() });
            }
            Request::ActivateProfile { id } => {
                let profile = op.repository.activate(&id)?;
                self.shared.change(|s| {
                    s.active_profile = Some(id);
                    s.saved_revision = Some(profile.revision);
                    s.applied_revision = None;
                });
                self.apply(&mut op, &profile);
            }
            Request::Start => {
                if op.engine.as_ref().is_some_and(Engine::is_running) {
                    return Ok(Response::Snapshot { snapshot: self.snapshot() });
                }
                op.engine.take();
                op.active_device = None;
                op.ownership.take();
                let ownership = File::options()
                    .read(true)
                    .write(true)
                    .create(true)
                    .truncate(false)
                    .open(&self.ownership_path)
                    .map_err(|e| e.to_string())?;
                ownership.try_lock().map_err(|e| format!("Gamepad input is owned by another application: {e}"))?;
                let config = op
                    .repository
                    .active()
                    .map(|p| p.config)
                    .unwrap_or_else(|| crate::config::Config::from_json("{}").expect("empty configuration"));
                self.shared.change(|s| {
                    s.generation += 1;
                    s.state = EngineState::Starting;
                    s.active_device = None;
                    s.error = None;
                });
                let shared = self.shared.clone();
                match Engine::start_with_injection(config, op.suspensions.is_empty(), move |event| shared.event(event))
                {
                    Ok(engine) => {
                        engine.set_active(op.active_device);
                        op.engine = Some(engine);
                        op.ownership = Some(ownership);
                        let saved = self.snapshot().saved_revision;
                        self.shared.change(|s| s.applied_revision = saved);
                    }
                    Err(error) => {
                        self.shared.change(|s| {
                            s.state = EngineState::Failed;
                            s.error = Some(error.clone());
                        });
                        return Err(error);
                    }
                }
            }
            Request::Stop => {
                self.shared.change(|s| s.state = EngineState::Stopping);
                if let Some(mut engine) = op.engine.take() {
                    engine.stop();
                }
                op.ownership.take();
                op.active_device = None;
                self.shared.change(|s| {
                    s.active_device = None;
                    s.state = EngineState::Stopped;
                    s.devices.clear();
                    s.applied_revision = None;
                });
            }
            Request::SelectDevice { id } => {
                // Match Desktop: selection filters highlights; every controller still maps input.
                if op.engine.as_ref().is_some_and(Engine::is_running)
                    && id.is_some_and(|id| !self.snapshot().devices.iter().any(|device| device.id == id))
                {
                    return Err("Selected Gamepad device is not connected".into());
                }
                op.active_device = id;
                if op.engine.as_ref().is_some_and(Engine::is_running) {
                    self.shared.change(|snapshot| {
                        // A disconnect may arrive after validation but before this commit.
                        let actual = id.filter(|id| snapshot.devices.iter().any(|device| device.id == *id));
                        op.engine.as_ref().expect("running engine exists").set_active(actual);
                        op.active_device = actual;
                        snapshot.active_device = actual;
                    });
                }
            }
            Request::Suspend { token } => {
                op.suspensions.insert(token);
                if let Some(engine) = &op.engine {
                    engine.set_inject(false);
                }
            }
            Request::Resume { token } => {
                op.suspensions.remove(&token);
                if let Some(engine) = &op.engine {
                    engine.set_inject(op.suspensions.is_empty());
                }
            }
            other => {
                let engine = op.engine.as_ref().filter(|e| e.is_running()).ok_or("Gamepad engine is stopped")?;
                match other {
                    Request::Rumble { id } => {
                        let single = engine.devices().iter().any(|device| {
                            device.id == id && matches!(device.model.as_str(), "joycon-left" | "joycon-right")
                        });
                        for command in rumble_test_plan(id, single) {
                            engine.rumble(command);
                        }
                    }
                    Request::VirtualAttach { model } => engine.virtual_pad(VirtualPadCmd::Attach { model })?,
                    Request::VirtualDetach => engine.virtual_pad(VirtualPadCmd::Detach)?,
                    Request::VirtualButton { button, pressed } => {
                        engine.virtual_pad(VirtualPadCmd::Button { button, pressed })?
                    }
                    Request::VirtualAxis { axis, value } => engine.virtual_pad(VirtualPadCmd::Axis { axis, value })?,
                    _ => unreachable!(),
                }
            }
        }
        Ok(Response::Snapshot { snapshot: self.snapshot() })
    }
    fn apply(&self, op: &mut Operations, profile: &crate::profiles::Profile) {
        let generation = self.snapshot().generation;
        let result = op.engine.as_ref().map(|engine| engine.set_config(profile.config.clone()));
        match result {
            Some(Ok(())) => self.shared.change(|snapshot| {
                let selected = device_for_profile(snapshot, &profile.id);
                commit_applied_selection(snapshot, generation, profile, selected, |selected| {
                    op.active_device = selected;
                    op.engine.as_ref().expect("applied engine exists").set_active(selected);
                });
            }),
            Some(Err(error)) => self.shared.change(|snapshot| snapshot.error = Some(error)),
            None => {}
        }
    }
}

impl Drop for GamepadService {
    fn drop(&mut self) {
        if let Err(error) = self.shared.boot_apply.send(BootApply::Shutdown) {
            log::error!("Cannot signal Gamepad profile worker shutdown: {error}");
        }
        {
            let mut op = self.operations.lock().unwrap();
            if let Some(mut engine) = op.engine.take() {
                engine.stop();
            }
            op.ownership.take();
        }
        if let Some(worker) = self.boot_worker.take() {
            if worker.join().is_err() {
                log::error!("Gamepad profile worker panicked");
            }
        }
    }
}

fn boot_apply_is_current(snapshot: &Snapshot, generation: u32, id: u32, name: &str) -> bool {
    snapshot.generation == generation
        && snapshot.state == EngineState::Running
        && snapshot.devices.iter().any(|device| device.id == id && device.name == name)
}

/// Commit native selection under the snapshot lock, after configuration acknowledgement.
fn commit_applied_selection(
    snapshot: &mut Snapshot, generation: u32, profile: &crate::profiles::Profile, selected: Option<u32>,
    set_active: impl FnOnce(Option<u32>),
) {
    if snapshot.generation != generation {
        return;
    }
    let current = snapshot.state == EngineState::Running;
    let actual = selected
        .filter(|id| current && snapshot.devices.iter().any(|device| device.id == *id && device.name == profile.id));
    set_active(actual);
    snapshot.active_device = actual;
    if current {
        snapshot.active_profile = Some(profile.id.clone());
        snapshot.saved_revision = Some(profile.revision);
        snapshot.applied_revision = Some(profile.revision);
        snapshot.error = None;
    }
}

fn device_for_profile(snapshot: &Snapshot, name: &str) -> Option<u32> {
    snapshot
        .devices
        .iter()
        .find(|device| Some(device.id) == snapshot.active_device && device.name == name)
        .or_else(|| snapshot.devices.iter().find(|device| device.name == name))
        .map(|device| device.id)
}

fn stored_profile_for_connection(
    repository: &dyn ProfileStore, snapshot: &Snapshot, generation: u32, id: u32, name: &str,
) -> Option<crate::profiles::Profile> {
    if !boot_apply_is_current(snapshot, generation, id, name) {
        return None;
    }
    repository.get(name)
}

fn rumble_test_plan(id: u32, single: bool) -> Vec<RumbleCmd> {
    if single {
        vec![RumbleCmd { id: Some(id), low: u16::MAX, high: u16::MAX, duration_ms: 300, after_ms: 0 }]
    } else {
        vec![
            RumbleCmd { id: Some(id), low: 0, high: u16::MAX, duration_ms: 300, after_ms: 0 },
            RumbleCmd { id: Some(id), low: u16::MAX, high: 0, duration_ms: 300, after_ms: 400 },
        ]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[ignore = "Explicit native service smoke test; injection disabled"]
    fn native_boot_apply_tracks_reconnected_device_across_restart() {
        let directory = tempfile::tempdir().unwrap();
        let service =
            GamepadService::new(directory.path().join("profiles.json"), directory.path().join("lock"), |_| {}).unwrap();
        service
            .execute(Request::SaveProfile {
                id: "Test Gamepad".into(),
                expected_revision: 0,
                config: Box::new(crate::config::Config::from_json("{}").unwrap()),
                color: None,
            })
            .unwrap();
        service.execute(Request::Suspend { token: "native-test".into() }).unwrap();
        let mut previous_generation = 0;
        for _ in 0..2 {
            service.execute(Request::Start).unwrap();
            assert!(service.snapshot().generation > previous_generation);
            previous_generation = service.snapshot().generation;
            service.execute(Request::VirtualAttach { model: "generic".into() }).unwrap();
            let deadline = std::time::Instant::now() + std::time::Duration::from_secs(4);
            loop {
                let snapshot = service.snapshot();
                let selected = snapshot.active_device;
                if snapshot.active_profile.as_deref() == Some("Test Gamepad")
                    && snapshot.applied_revision == Some(1)
                    && snapshot
                        .devices
                        .iter()
                        .any(|device| device.name == "Test Gamepad" && selected == Some(device.id))
                {
                    break;
                }
                assert!(std::time::Instant::now() < deadline, "stored profile failed to apply: {snapshot:?}");
                std::thread::sleep(std::time::Duration::from_millis(10));
            }
            let id = service.snapshot().active_device.expect("stored profile selects connected device");
            service.execute(Request::SelectDevice { id: None }).unwrap();
            assert_eq!(service.snapshot().active_device, None);
            service.execute(Request::SelectDevice { id: Some(id) }).unwrap();
            assert_eq!(service.snapshot().active_device, Some(id));
            assert!(service.execute(Request::SelectDevice { id: Some(u32::MAX) }).is_err());
            service.execute(Request::VirtualDetach).unwrap();
            let deadline = std::time::Instant::now() + std::time::Duration::from_secs(4);
            while !service.snapshot().devices.is_empty() {
                assert!(std::time::Instant::now() < deadline, "device did not disconnect");
                std::thread::sleep(std::time::Duration::from_millis(10));
            }
            assert_eq!(service.snapshot().active_device, None);
            service.execute(Request::Stop).unwrap();
            assert_eq!(service.snapshot().state, EngineState::Stopped);
            assert!(service.snapshot().devices.is_empty());
            assert_eq!(service.snapshot().applied_revision, None);
            assert_eq!(service.snapshot().active_device, None);
        }
    }

    #[test]
    fn startup_connection_waits_until_start_installs_ready_state() {
        let directory = tempfile::tempdir().unwrap();
        let (sender, receiver) = mpsc::channel();
        let service =
            GamepadService::new(directory.path().join("profiles.json"), directory.path().join("lock"), move |event| {
                if let ServiceEvent::Snapshot { snapshot } = event {
                    if let Some(error) = snapshot.error {
                        sender.send(error).unwrap();
                    }
                }
            })
            .unwrap();
        service
            .execute(Request::SaveProfile {
                id: "Saved Pad".into(),
                expected_revision: 0,
                config: Box::new(crate::config::Config::from_json("{}").unwrap()),
                color: None,
            })
            .unwrap();
        // Reproduce Start's lock: a worker callback arrives before the engine is installed.
        let operations = service.operations.lock().unwrap();
        service.shared.change(|snapshot| snapshot.state = EngineState::Starting);
        service.shared.event(EngineEvent::GamepadConnected {
            id: 9,
            name: "Saved Pad".into(),
            brand: "generic".into(),
            model: "generic".into(),
            battery: None,
            charging: false,
            connection: crate::engine::Connection::Unknown,
        });
        assert!(receiver.try_recv().is_err());
        service.shared.event(EngineEvent::Ready);
        drop(operations);
        // No native engine is installed in this test. Reaching its boundary proves
        // the queued connection was not discarded while Start was still Starting.
        assert_eq!(receiver.recv_timeout(std::time::Duration::from_secs(2)).unwrap(), "Gamepad engine is stopped");
    }

    #[test]
    fn acknowledgement_cannot_restore_a_disconnected_or_stale_selection() {
        let directory = tempfile::tempdir().unwrap();
        let service =
            GamepadService::new(directory.path().join("profiles.json"), directory.path().join("lock"), |_| {}).unwrap();
        let profile = service
            .operations
            .lock()
            .unwrap()
            .repository
            .save("Saved Pad", 0, crate::config::Config::from_json("{}").unwrap(), None)
            .unwrap();
        let mut snapshot = service.snapshot();
        snapshot.state = EngineState::Running;
        snapshot.devices.push(crate::engine::DeviceSnapshot {
            id: 9,
            name: profile.id.clone(),
            brand: "generic".into(),
            model: "generic".into(),
            battery: None,
            charging: false,
            connection: crate::engine::Connection::Unknown,
        });
        let mut native_selection = None;
        commit_applied_selection(&mut snapshot, 1, &profile, Some(9), |id| native_selection = id);
        assert_eq!(native_selection, Some(9));
        assert_eq!(snapshot.active_device, Some(9));
        // Disconnect during the ACK wait has already removed the device from this lock's snapshot.
        snapshot.devices.clear();
        commit_applied_selection(&mut snapshot, 1, &profile, Some(9), |id| native_selection = id);
        assert_eq!(native_selection, None);
        assert_eq!(snapshot.active_device, None);
        snapshot.generation = 2;
        snapshot.applied_revision = None;
        snapshot.active_device = Some(10);
        native_selection = Some(10);
        commit_applied_selection(&mut snapshot, 1, &profile, Some(9), |id| native_selection = id);
        assert_eq!(snapshot.applied_revision, None);
        assert_eq!(snapshot.active_device, Some(10));
        assert_eq!(native_selection, Some(10));
        snapshot.state = EngineState::Stopped;
        commit_applied_selection(&mut snapshot, 2, &profile, Some(9), |id| native_selection = id);
        assert_eq!(native_selection, None);
        assert_eq!(snapshot.active_device, None);
        assert_eq!(snapshot.applied_revision, None);
    }

    #[test]
    fn rumble_tests_single_motor_and_both_motors_separately() {
        let single = rumble_test_plan(9, true);
        assert_eq!(single.len(), 1);
        assert_eq!(
            (single[0].id, single[0].low, single[0].high, single[0].duration_ms, single[0].after_ms),
            (Some(9), 65535, 65535, 300, 0)
        );
        let dual = rumble_test_plan(42, false);
        assert_eq!(dual.len(), 2);
        assert_eq!(
            (dual[0].id, dual[0].low, dual[0].high, dual[0].duration_ms, dual[0].after_ms),
            (Some(42), 0, 65535, 300, 0)
        );
        assert_eq!(
            (dual[1].id, dual[1].low, dual[1].high, dual[1].duration_ms, dual[1].after_ms),
            (Some(42), 65535, 0, 300, 400)
        );
    }

    #[test]
    fn stored_profile_selection_handles_scans_hotplug_missing_profiles_and_restarts() {
        let directory = tempfile::tempdir().unwrap();
        let mut repository = ProfileRepository::open(directory.path().join("profiles.json")).unwrap();
        repository.save("Saved Pad", 0, crate::config::Config::from_json("{}").unwrap(), None).unwrap();
        let service =
            GamepadService::new(directory.path().join("other.json"), directory.path().join("lock"), |_| {}).unwrap();
        let mut snapshot = service.snapshot();
        let device = crate::engine::DeviceSnapshot {
            id: 9,
            name: "Saved Pad".into(),
            brand: "generic".into(),
            model: "generic".into(),
            battery: None,
            charging: false,
            connection: crate::engine::Connection::Unknown,
        };
        snapshot.devices.push(device.clone());
        snapshot.state = EngineState::Starting;
        assert!(stored_profile_for_connection(&repository, &snapshot, 1, 9, "Saved Pad").is_none());
        snapshot.state = EngineState::Running;
        assert_eq!(stored_profile_for_connection(&repository, &snapshot, 1, 9, "Saved Pad").unwrap().id, "Saved Pad");
        let mut hotplug = device;
        hotplug.id = 10;
        snapshot.devices.push(hotplug);
        snapshot.active_device = Some(10);
        assert_eq!(device_for_profile(&snapshot, "Saved Pad"), Some(10));
        assert_eq!(device_for_profile(&snapshot, "No Pad"), None);
        snapshot.active_device = Some(99);
        assert_eq!(device_for_profile(&snapshot, "Saved Pad"), Some(9));
        assert!(stored_profile_for_connection(&repository, &snapshot, 1, 10, "Saved Pad").is_some());
        snapshot.devices[1].name = "New Pad".into();
        assert!(stored_profile_for_connection(&repository, &snapshot, 1, 10, "New Pad").is_none());
        snapshot.state = EngineState::Stopped;
        assert!(stored_profile_for_connection(&repository, &snapshot, 1, 9, "Saved Pad").is_none());
        snapshot.state = EngineState::Running;
        snapshot.generation = 2;
        assert!(stored_profile_for_connection(&repository, &snapshot, 1, 9, "Saved Pad").is_none());
        assert!(stored_profile_for_connection(&repository, &snapshot, 2, 9, "Saved Pad").is_some());
        snapshot.devices.clear();
        assert!(stored_profile_for_connection(&repository, &snapshot, 2, 9, "Saved Pad").is_none());
    }

    #[test]
    fn disconnect_reports_log_event_and_authoritative_snapshot() {
        let directory = tempfile::tempdir().unwrap();
        let events = Arc::new(Mutex::new(Vec::new()));
        let recorded = events.clone();
        let service = GamepadService::new(
            directory.path().join("profiles.json"),
            directory.path().join("injection.lock"),
            move |event| recorded.lock().unwrap().push(event),
        )
        .unwrap();
        service.shared.event(EngineEvent::GamepadDisconnected { id: 42 });
        let events = events.lock().unwrap();
        assert!(matches!(&events[0], ServiceEvent::Input { event: EngineEvent::GamepadDisconnected { id: 42 } }));
        assert!(matches!(&events[1], ServiceEvent::Snapshot { snapshot } if snapshot.sequence == 1));
    }

    #[test]
    fn device_selection_is_retained_before_engine_start() {
        let directory = tempfile::tempdir().unwrap();
        let service = GamepadService::new(
            directory.path().join("profiles.json"),
            directory.path().join("injection.lock"),
            |_| {},
        )
        .unwrap();
        let request: Request = serde_json::from_str(r#"{"type":"selectDevice","id":42}"#).unwrap();
        service.execute(request).unwrap();
        assert_eq!(service.operations.lock().unwrap().active_device, Some(42));
        assert_eq!(service.snapshot().state, EngineState::Stopped);
        assert_eq!(service.snapshot().active_device, None);
        service.execute(Request::SelectDevice { id: None }).unwrap();
        assert_eq!(service.operations.lock().unwrap().active_device, None);
        assert!(serde_json::from_str::<Request>(r#"{"type":"selectDevice","id":-1}"#).is_err());
    }
}

//! 可启停的映射引擎 —— 在后台线程跑 SDL3 事件泵,供 GUI(Tauri)复用。
//!
//! CLI 不用它(CLI 在主线程跑 `main.rs` 的循环)。GUI 里 webview 占着主线程,
//! 引擎只能在后台线程跑;`EnigoSink` 和 SDL 句柄都不是 `Send`,所以全部在本线程内创建。
//!
//! 设备发现用**定期重新枚举**(`gcs.gamepads()` 轮询 + diff),而不是依赖 SDL 的
//! `GamepadAdded/Removed` 热插拔事件 —— 后者在 macOS 后台线程上不可靠,
//! 会导致「插拔手柄界面不实时刷新」。输入事件(按钮/摇杆)仍走事件泵。

use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::thread::JoinHandle;
use std::time::{Duration, Instant};

use sdl3::GamepadSubsystem;
use sdl3::event::Event;
use sdl3::gamepad::Gamepad;
use sdl3::joystick::{ConnectionState, PowerLevel};

use crate::action::Output;
use crate::config::Config;
use crate::event::{Control, InputEvent};
use crate::gamepad::Translator;
use crate::mapper::Mapper;
use crate::output::EnigoSink;

/// 连接方式。用户侧只有 有线/2.4G接收器/蓝牙 三种(没有 WiFi);unknown = 暂未分清/读不出的
/// 单一兜底(前端不显示图标)。用 enum + specta 生成 TS 联合类型,避免前后端各维护一份字符串而漂移。
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, specta::Type)]
#[serde(rename_all = "snake_case")]
pub enum Connection {
    Wired,
    Dongle,
    Bluetooth,
    Unknown,
}

/// 引擎推给前端的事件(手柄监视器 / 状态显示)。直接 `Serialize` 给 Tauri emit。
#[derive(Debug, Clone, serde::Serialize, specta::Type)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum EngineEvent {
    /// 手柄连接:实例 id、名字、品牌、型号(ps4/ps5/xbox/switch/generic)、电量(`None` = 有线/未知)、
    /// 是否充电中、连接方式(见 `connection_of`)。
    GamepadConnected {
        id: u32,
        name: String,
        brand: String,
        model: String,
        battery: Option<u8>,
        charging: bool,
        connection: Connection,
    },
    /// 手柄断开。
    GamepadDisconnected {
        id: u32,
    },
    /// 电量 / 充电状态变化(连接期间定期上报)。
    GamepadBattery {
        id: u32,
        battery: Option<u8>,
        charging: bool,
    },
    /// 某控件按下/松开(供前端做按键高亮 / 校准)。
    Input {
        device_id: u32,
        control: Control,
        pressed: bool,
    },
    /// 引擎致命错误(如缺少辅助功能权限),线程已退出。
    Error {
        message: String,
    },
    Ready,
    Stopped,
}

/// 一次振动请求。`id = None` 表示对所有已连接手柄震;强弱为 0..=0xFFFF;时长毫秒。
/// `low` 驱动左/大马达(低频),`high` 驱动右/小马达(高频);`after_ms` 是入队后延迟多久才发
/// (用于「左脉冲→停→右脉冲」分开测两个马达)。在后台线程外构造(如 Tauri 命令),
/// 经队列交给引擎循环在持有 `Gamepad` 句柄的线程内按时发出。
#[derive(Debug, Clone, Copy)]
pub struct RumbleCmd {
    pub id: Option<u32>,
    pub low: u16,
    pub high: u16,
    pub duration_ms: u32,
    pub after_ms: u32,
}

/// 虚拟手柄命令(dev 测试台):不插真手柄,经 SDL virtual joystick 走与真设备**完全同一条**
/// 事件管线(型号识别 → 单只 Joy-Con 重映射 → 高亮 → 映射触发)。外部线程入队,
/// 循环在 SDL 线程内执行。注意:虚拟设备的 GamepadType 由声明的 VID/PID 推导,
/// 验证不了真机 HIDAPI 驱动行为(蓝牙/电量/震动)。
#[derive(Debug, Clone)]
pub enum VirtualPadCmd {
    /// 接入一只虚拟手柄(已有则先拆再换)。model 词表同 `model_of`。
    Attach { model: String },
    /// 拆掉当前虚拟手柄(幂等)。
    Detach,
    /// 按下/松开一个按钮。名字 = SDL_GamepadButton 语义(south/east/…/dpadup/misc1;
    /// 单只 Joy-Con 注入的是「SDL 上报层」的键,正好覆盖 core 的横持重映射)。
    Button { button: String, pressed: bool },
    /// 设置一根轴(-32768..=32767)。名字 = SDL_GamepadAxis 语义(leftx/…/righttrigger)。
    Axis { axis: String, value: i16 },
}

/// 当前已连接手柄快照。供前端**主动查询**(`list_devices` 命令)补种设备列表,
/// 不依赖 `GamepadConnected` 事件 —— 修复「启动时事件早于前端 listener 注册而丢失,
/// 导致按键有响应但列表里没有、要重启才出现」。
#[derive(Debug, Clone, serde::Serialize, specta::Type)]
pub struct DeviceSnapshot {
    pub id: u32,
    pub name: String,
    pub brand: String,
    pub model: String,
    pub battery: Option<u8>,
    /// 是否充电中(SDL 报告 Charging/Charged)。
    pub charging: bool,
    /// 连接方式(见 `connection_of`)。
    pub connection: Connection,
}

/// 后台映射引擎句柄。`stop()`(或 drop)会停线程并释放所有按住的键。
type PendingConfig = Arc<Mutex<Option<(Config, std::sync::mpsc::SyncSender<()>)>>>;
type VirtualCommands = Arc<Mutex<Vec<(VirtualPadCmd, std::sync::mpsc::SyncSender<Result<(), String>>)>>>;

pub struct Engine {
    running: Arc<AtomicBool>,
    /// 热更新配置:置入新配置后,循环会在下一拍重建 Mapper(无需重启 SDL)。
    pending: PendingConfig,
    /// 振动请求队列:外部线程入队,循环在持有 `Gamepad` 句柄的线程内取出执行。
    rumbles: Arc<Mutex<Vec<RumbleCmd>>>,
    /// 虚拟手柄命令队列(dev 测试台):同 rumbles 的入队/线程内执行模式。
    virtual_cmds: VirtualCommands,
    /// 已连接手柄快照:循环每次扫描后刷新,供 `devices()` 查询。
    devices: Arc<Mutex<Vec<DeviceSnapshot>>>,
    /// 活动手柄实例 id:仅它的输入被映射/上报;`None` = 不过滤(全部)。
    active: Arc<Mutex<Option<u32>>>,
    /// 是否注入按键。`false` 时只上报 Input(界面高亮)不发键 —— GUI 自己聚焦时暂停,
    /// 免得注入的键操作 GUI 自己的控件(焦点环/切换开关等)。
    inject: Arc<AtomicBool>,
    handle: Option<JoinHandle<()>>,
}

impl Engine {
    /// 在后台线程启动映射循环。`on_event` 把事件转发给前端(Tauri 里就是 `app.emit`)。
    pub fn start<F>(config: Config, on_event: F) -> Result<Self, String>
    where
        F: Fn(EngineEvent) + Send + 'static,
    {
        Self::start_with_injection(config, true, on_event)
    }

    pub fn start_with_injection<F>(config: Config, injecting: bool, on_event: F) -> Result<Self, String>
    where
        F: Fn(EngineEvent) + Send + 'static,
    {
        config.validate()?;
        let running = Arc::new(AtomicBool::new(true));
        let pending = Arc::new(Mutex::new(None));
        let rumbles = Arc::new(Mutex::new(Vec::new()));
        let virtual_cmds = Arc::new(Mutex::new(Vec::new()));
        let devices = Arc::new(Mutex::new(Vec::new()));
        let active = Arc::new(Mutex::new(None));
        let inject = Arc::new(AtomicBool::new(injecting));
        let r = running.clone();
        let p = pending.clone();
        let rb = rumbles.clone();
        let vc = virtual_cmds.clone();
        let dv = devices.clone();
        let ac = active.clone();
        let ij = inject.clone();
        let (ready_tx, ready_rx) = std::sync::mpsc::sync_channel(1);
        let handle = std::thread::spawn(move || {
            let pending_cleanup = p.clone();
            let virtual_cleanup = vc.clone();
            let report = |event: EngineEvent| {
                match &event {
                    EngineEvent::Ready => {
                        let _ = ready_tx.try_send(Ok(()));
                    }
                    EngineEvent::Error { message } => {
                        let _ = ready_tx.try_send(Err(message.clone()));
                    }
                    _ => {}
                }
                on_event(event);
            };
            let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                run_loop(config, r.clone(), p, rb, vc, dv, ac, ij, report);
            }));
            r.store(false, Ordering::SeqCst);
            pending_cleanup.lock().unwrap().take();
            virtual_cleanup.lock().unwrap().clear();
            if outcome.is_err() {
                report(EngineEvent::Error { message: "Gamepad worker panicked".into() });
            }
            report(EngineEvent::Stopped);
        });
        let mut engine =
            Engine { running, pending, rumbles, virtual_cmds, devices, active, inject, handle: Some(handle) };
        match ready_rx.recv_timeout(Duration::from_secs(10)) {
            Ok(Ok(())) => Ok(engine),
            Ok(Err(error)) => {
                engine.stop();
                Err(error)
            }
            Err(error) => {
                engine.stop();
                Err(format!("Gamepad initialization failed: {error}"))
            }
        }
    }

    /// 当前已连接手柄快照(供前端主动查询补种列表,绕开事件时序竞态)。
    pub fn devices(&self) -> Vec<DeviceSnapshot> {
        self.devices.lock().unwrap().clone()
    }

    /// Select the controller highlighted by input events. All controllers still map input.
    /// `None` reports highlights from every controller, matching Desktop behavior.
    pub fn set_active(&self, id: Option<u32>) {
        *self.active.lock().unwrap() = id;
    }

    /// 是否注入按键。`false`(如 GUI 自己聚焦时)只上报高亮、不发键,避免操作 GUI 自己的控件。
    pub fn set_inject(&self, on: bool) {
        self.inject.store(on, Ordering::SeqCst);
    }

    /// 热更新配置(切档案 / 保存映射时用),不重启 SDL,避免 EventPump 冲突与卡顿。
    pub fn set_config(&self, config: Config) -> Result<(), String> {
        config.validate()?;
        let (sender, receiver) = std::sync::mpsc::sync_channel(1);
        let mut pending = self.pending.lock().unwrap();
        if !self.is_running() {
            return Err("Gamepad engine is stopped".into());
        }
        if pending.is_some() {
            return Err("Another configuration is pending".into());
        }
        *pending = Some((config, sender));
        drop(pending);
        receiver.recv().map_err(|error| format!("Configuration was not applied: {error}"))
    }

    /// 入队一次振动请求(如 GUI「测试振动」)。引擎循环会在下一拍执行。
    pub fn rumble(&self, cmd: RumbleCmd) {
        self.rumbles.lock().unwrap().push(cmd);
    }

    /// 虚拟手柄命令入队(dev 测试台),循环下一拍在 SDL 线程内执行。
    pub fn virtual_pad(&self, cmd: VirtualPadCmd) -> Result<(), String> {
        let (sender, receiver) = std::sync::mpsc::sync_channel(1);
        let mut queue = self.virtual_cmds.lock().unwrap();
        if !self.is_running() {
            return Err("Gamepad engine is stopped".into());
        }
        queue.push((cmd, sender));
        drop(queue);
        receiver.recv().map_err(|error| format!("Virtual input was not applied: {error}"))?
    }

    /// 停止并等待线程退出(退出时会释放所有按住的键,防卡键)。
    pub fn stop(&mut self) {
        self.running.store(false, Ordering::SeqCst);
        if let Some(h) = self.handle.take() {
            let _ = h.join();
        }
    }

    pub fn is_running(&self) -> bool {
        self.running.load(Ordering::SeqCst)
    }
}

impl Drop for Engine {
    fn drop(&mut self) {
        self.stop();
    }
}

/// 根据 SDL 识别的手柄类型判断品牌。
fn brand_of(c: &Gamepad) -> &'static str {
    use sdl3::gamepad::GamepadType::*;
    match c.r#type() {
        Xbox360 | XboxOne => "Xbox",
        PS3 | PS4 | PS5 => "PlayStation",
        NintendoSwitchPro | NintendoSwitchJoyconLeft | NintendoSwitchJoyconRight | NintendoSwitchJoyconPair => {
            "Nintendo"
        }
        _ => "通用",
    }
}

/// 具体型号(决定前端显示哪张手柄图,命名沿用素材库 AL2009man)。
/// 区分 DS4 / DualSense / Switch Pro / Joy-Con(单只或合体都用合体图)。
fn model_of(c: &Gamepad) -> &'static str {
    use sdl3::gamepad::GamepadType::*;
    match c.r#type() {
        Xbox360 | XboxOne => "xbox",
        PS3 | PS4 => "dualshock-4",
        PS5 => "dualsense",
        NintendoSwitchPro => "switch-pro",
        NintendoSwitchJoyconLeft => "joycon-left",
        NintendoSwitchJoyconRight => "joycon-right",
        NintendoSwitchJoyconPair => "joycon-grip",
        _ => "generic",
    }
}

/// 单只 Joy-Con 的哪一侧(横持时方向/摇杆/按键都被 SDL 重排,左右各需特判)。
enum JoyconSide {
    Left,
    Right,
}

/// 来源手柄是不是单只 Joy-Con,是哪侧(成对/Pro 等返回 None,走通用映射)。
fn joycon_side(open: &HashMap<u32, Gamepad>, which: u32) -> Option<JoyconSide> {
    use sdl3::gamepad::GamepadType::*;
    match open.get(&which).map(|c| c.r#type()) {
        Some(NintendoSwitchJoyconLeft) => Some(JoyconSide::Left),
        Some(NintendoSwitchJoyconRight) => Some(JoyconSide::Right),
        _ => None,
    }
}

/// 单只 Joy-Con 横持时,用它那侧的完整按钮映射产出统一事件;其它手柄走通用 `Translator`(返回 None)。
/// `pressed`=true 为按下、false 为松开。
fn joycon_button_events(
    open: &HashMap<u32, Gamepad>, which: u32, b: sdl3::gamepad::Button, pressed: bool,
) -> Option<Vec<InputEvent>> {
    let btn = match joycon_side(open, which)? {
        JoyconSide::Left => crate::gamepad::joycon_left_button(b),
        JoyconSide::Right => crate::gamepad::joycon_right_button(b),
    };
    Some(
        btn.map(|btn| {
            let c = Control::Button(btn);
            vec![if pressed { InputEvent::Pressed(c) } else { InputEvent::Released(c) }]
        })
        .unwrap_or_default(),
    )
}

/// 单只 Joy-Con 摇杆轴 90° 旋转(左/右各自方向);其它手柄原样透传。
fn joycon_remap_axis(
    open: &HashMap<u32, Gamepad>, which: u32, axis: sdl3::gamepad::Axis, value: i16,
) -> (sdl3::gamepad::Axis, i16) {
    match joycon_side(open, which) {
        Some(JoyconSide::Left) => crate::gamepad::remap_joycon_left_axis(axis, value),
        Some(JoyconSide::Right) => crate::gamepad::remap_joycon_right_axis(axis, value),
        None => (axis, value),
    }
}

/// 读电量百分比 + 是否充电中。有线/无电池/未知电量 → `None`;否则 0..=100。
/// `charging` = SDL 报告 Charging/Charged(充电中或已充满在充电器上)。
/// macOS 上 SDL/HIDAPI 读不到 BLE 手柄(如 Xbox)的电量 —— 它在蓝牙 GATT 电池服务里,
/// 只有系统蓝牙栈读得到。此时回退到 `system_profiler` 暴露的蓝牙电量(见 `macos_bt`;无充电状态)。
fn battery_of(c: &Gamepad) -> (Option<u8>, bool) {
    let info = c.power_info();
    let charging = matches!(info.state, PowerLevel::Charging | PowerLevel::Charged);
    let sdl = match info.state {
        PowerLevel::OnBattery | PowerLevel::Charging | PowerLevel::Charged if info.percentage >= 0 => {
            Some(info.percentage.clamp(0, 100) as u8)
        }
        _ => None,
    };
    // macOS:SDL 读不到电量,且这只确属「已连接蓝牙手柄」时,才借蓝牙栈电量。
    // 加 is_bluetooth 闸:否则有线手柄(SDL 也常 None)会借到同品牌蓝牙手柄的电量。保留 charging。
    #[cfg(target_os = "macos")]
    if sdl.is_none() {
        let name = c.name().unwrap_or_default();
        if macos_bt::is_bluetooth(&name) {
            return (macos_bt::battery_for(&name), charging);
        }
    }
    (sdl, charging)
}

/// macOS:从蓝牙栈(`system_profiler SPBluetoothDataType -json`)读手柄电量,作为 SDL 读不到时的回退。
///
/// 为什么不用 GameController:实测 Xbox(含 Elite 2)的 `GCDeviceBattery` 即便走蓝牙也只返回
/// state=-1 / level=0 的无效占位 —— GameController 不读这只手柄的 BLE 电量。而蓝牙守护进程
/// (system_profiler 即其输出)有真实值(`device_batteryLevelMain` 如 "100%")。
///
/// system_profiler 调用较慢(~1–2s),故放到独立后台线程每 ~45s 刷一次缓存;`battery_for` 只读缓存,
/// 永不阻塞引擎线程。首次被调用(即出现 SDL 读不到电量的手柄)时才启动刷新线程。
#[cfg(target_os = "macos")]
mod macos_bt {
    use std::sync::Mutex;
    use std::sync::atomic::{AtomicBool, Ordering};
    use std::time::{Duration, Instant};

    // 已连接的蓝牙手柄:(蓝牙设备名, 电量% 或 None)。Vec 便于 const 初始化 static。
    static CACHE: Mutex<Vec<(String, Option<u8>)>> = Mutex::new(Vec::new());
    static LOADED: AtomicBool = AtomicBool::new(false); // 是否至少成功跑过一次 system_profiler
    static LAST: Mutex<Option<Instant>> = Mutex::new(None); // 上次刷新时间(按需节流,无常驻线程)

    /// 按需刷新:被调用(即有手柄需要查蓝牙/电量)且距上次 ≥45s 才在后台跑一次 system_profiler。
    /// 没手柄连接时无人调用 → 不刷新;引擎停了 → 不再调用 → 自然停。比常驻线程更省、随用随停。
    fn refresh_if_stale() {
        let mut last = match LAST.lock() {
            Ok(l) => l,
            Err(_) => return,
        };
        if last.is_some_and(|t| t.elapsed() < Duration::from_secs(45)) {
            return;
        }
        *last = Some(Instant::now()); // 先占位,避免并发重复 spawn
        drop(last);
        std::thread::spawn(|| {
            if let Some(v) = query() {
                if let Ok(mut c) = CACHE.lock() {
                    *c = v;
                }
                LOADED.store(true, Ordering::Relaxed);
            }
        });
    }

    /// system_profiler 是否已至少加载一次。用于判断「无线且非蓝牙 = 2.4G」是否可下结论
    /// (没加载完前不能断言不是蓝牙)。
    pub fn loaded() -> bool {
        refresh_if_stale();
        LOADED.load(Ordering::Relaxed)
    }

    /// 该 SDL 设备名是否对应一只「已连接的蓝牙手柄」。蓝牙守护进程权威,修 BLE 手柄(如 Xbox)
    /// 经 HID 枚举读不到总线类型、被误判成无线/WiFi 的问题。
    pub fn is_bluetooth(sdl_name: &str) -> bool {
        refresh_if_stale();
        let want = sdl_name.to_lowercase();
        CACHE.lock().map(|c| c.iter().any(|(n, _)| shared_token(&want, &n.to_lowercase()))).unwrap_or(false)
    }

    pub fn battery_for(sdl_name: &str) -> Option<u8> {
        refresh_if_stale();
        let want = sdl_name.to_lowercase();
        let cache = CACHE.lock().ok()?;
        // 名字按「共享品牌词」匹配:SDL 名("Xbox One Elite 2 Controller")与蓝牙名
        // ("Xbox Wireless Controller")整串对不上,但共享 "xbox" 这种品牌词即算同一只。
        // 不做「只有一只就用它」的兜底 —— 那会把某只手柄的电量错配给另一只(如 Joy-Con 拿到 Xbox 的)。
        cache.iter().find(|(n, b)| b.is_some() && shared_token(&want, &n.to_lowercase())).and_then(|(_, b)| *b)
    }

    /// 两个设备名是否共享一个有意义的词(长度 ≥3,排除 controller/wireless/gamepad 等泛词)。
    fn shared_token(a: &str, b: &str) -> bool {
        const STOP: [&str; 3] = ["controller", "wireless", "gamepad"];
        let toks = |s: &str| -> Vec<String> {
            s.split(|c: char| !c.is_alphanumeric())
                .filter(|t| t.len() >= 3 && !STOP.contains(t))
                .map(|t| t.to_string())
                .collect()
        };
        let (ta, tb) = (toks(a), toks(b));
        ta.iter().any(|t| tb.contains(t))
    }

    /// 跑 system_profiler 取「已连接、minorType=Gamepad」的蓝牙手柄 → (名字, 电量% 或 None)。
    fn query() -> Option<Vec<(String, Option<u8>)>> {
        let out = std::process::Command::new("system_profiler").args(["SPBluetoothDataType", "-json"]).output().ok()?;
        let v: serde_json::Value = serde_json::from_slice(&out.stdout).ok()?;
        let mut res = Vec::new();
        collect(&v, &mut res);
        Some(res)
    }

    /// 只在 `device_connected` 段里收手柄(minorType=Gamepad);电量(device_batteryLevel*)可有可无。
    /// 必须限「已连接」—— 否则配过对但没连的设备也会被当成蓝牙在用。
    fn collect(v: &serde_json::Value, out: &mut Vec<(String, Option<u8>)>) {
        match v {
            serde_json::Value::Object(map) => {
                for (k, val) in map {
                    if k == "device_connected" {
                        if let serde_json::Value::Array(list) = val {
                            for entry in list.iter().filter_map(|e| e.as_object()) {
                                for (name, props) in entry.iter() {
                                    let Some(p) = props.as_object() else { continue };
                                    let is_pad = p
                                        .get("device_minorType")
                                        .and_then(|m| m.as_str())
                                        .is_some_and(|m| m.contains("Gamepad"));
                                    if !is_pad {
                                        continue;
                                    }
                                    let batt = p
                                        .iter()
                                        .find(|(kk, _)| kk.starts_with("device_batteryLevel"))
                                        .and_then(|(_, vv)| vv.as_str())
                                        .and_then(|s| s.trim_end_matches('%').trim().parse::<u8>().ok())
                                        .map(|b| b.min(100));
                                    out.push((name.clone(), batt));
                                }
                            }
                        }
                    }
                    collect(val, out);
                }
            }
            serde_json::Value::Array(a) => a.iter().for_each(|it| collect(it, out)),
            _ => {}
        }
    }

    #[cfg(test)]
    mod tests {
        use super::{collect, shared_token};

        #[test]
        fn shared_token_matches_brand_word_ignoring_generic_terms() {
            // 契约:调用方(is_bluetooth / battery_for)已把两侧转小写,STOP 词表也是小写,故这里传小写。
            // SDL 名与蓝牙名整串对不上,但共享品牌词 "xbox" → 同一只。
            assert!(shared_token("xbox one elite 2 controller", "xbox wireless controller"));
            // 只共享泛词(controller / wireless / gamepad)不算 —— 否则不同品牌会互相误配。
            assert!(!shared_token("sony wireless controller", "xbox wireless controller"));
            // 无共享有意义词。
            assert!(!shared_token("dualsense", "xbox"));
            // 短词(<3)不算。
            assert!(!shared_token("a b", "a b"));
        }

        #[test]
        fn collect_extracts_connected_gamepads_with_optional_battery() {
            let v: serde_json::Value = serde_json::from_str(
                r#"{ "SPBluetoothDataType": [{ "device_connected": [
                    { "Xbox Wireless Controller": { "device_minorType": "Gamepad", "device_batteryLevelMain": "80%" } },
                    { "Some Keyboard": { "device_minorType": "Keyboard" } },
                    { "Joy-Con (L)": { "device_minorType": "Gamepad" } }
                ] }] }"#,
            )
            .unwrap();
            let mut out = vec![];
            collect(&v, &mut out);
            // 手柄才收;键盘跳过;有电量取值(≤100),无电量为 None。
            assert_eq!(
                out,
                vec![("Xbox Wireless Controller".to_string(), Some(80)), ("Joy-Con (L)".to_string(), None)]
            );
        }

        #[test]
        fn collect_ignores_devices_outside_connected_section() {
            // 只认 `device_connected` 段 —— 配过对但没连的不算「在用蓝牙」。
            let v: serde_json::Value = serde_json::from_str(
                r#"{ "SPBluetoothDataType": [{ "device_not_connected": [
                    { "Old Pad": { "device_minorType": "Gamepad", "device_batteryLevelMain": "50%" } }
                ] }] }"#,
            )
            .unwrap();
            let mut out = vec![];
            collect(&v, &mut out);
            assert!(out.is_empty());
        }
    }
}

/// 查某 VID 手柄的 HID 总线类型(USB / 蓝牙)。SDL 安全 API 不暴露总线类型,降到底层
/// `sdl3-sys` 的 `SDL_hid_enumerate`(SDL 会按需自动 init HIDAPI)。
///
/// 注意:**不能按 VID+PID 匹配** —— SDL 经 HIDAPI 上报的 gamepad PID 是归一化/虚拟值
/// (如 Joy-Con 合体 = 2008、Xbox 蓝牙 = 02e0),与底层 HID 设备的真实 PID(2006/2007、0b00)对不上;
/// gamepad 的 `path()` 在 macOS 上又是 None / 虚拟串,也匹配不了。所以按 **VID 通配(PID=0)** 枚举,
/// 只看真正的手柄 usage(generic desktop:gamepad 0x04 / joystick 0x05),收集这些设备的总线类型:
/// 全体一致 → 返回该总线;无 / 混合(同 VID 既有有线又有蓝牙)→ `None`,交由上层退回 connection_state。
fn hid_bus_for(vendor: Option<u16>) -> Option<sdl3::sys::hidapi::SDL_hid_bus_type> {
    use sdl3::sys::hidapi::{SDL_hid_enumerate, SDL_hid_free_enumeration};
    let v = vendor?;
    // SAFETY:enumerate 返回单链表,读完用 free_enumeration 释放;只在 SDL 线程调用(见 snapshot_devices)。
    unsafe {
        let head = SDL_hid_enumerate(v, 0);
        let mut cur = head;
        let mut found = None;
        let mut mixed = false;
        while !cur.is_null() {
            let is_pad = (*cur).usage_page == 0x01 && ((*cur).usage == 0x04 || (*cur).usage == 0x05);
            if is_pad {
                match found {
                    None => found = Some((*cur).bus_type),
                    Some(b) if b != (*cur).bus_type => mixed = true,
                    _ => {}
                }
            }
            cur = (*cur).next;
        }
        if !head.is_null() {
            SDL_hid_free_enumeration(head);
        }
        if mixed { None } else { found }
    }
}

/// 连接方式:有线 / 2.4G 接收器 / 蓝牙 / 无线(瞬态没分清)/ 未知。
/// 手柄连接只有 有线/蓝牙/2.4G 三种(没有 WiFi)。判定:
/// - macOS:先用蓝牙守护进程权威判蓝牙(HID 枚举对某些 BLE 手柄如 Xbox 读不到总线);
/// - HID 总线 = 蓝牙 → 蓝牙;= USB → 配合 SDL 状态分 有线(线)/ 2.4G(接收器是 USB、手柄无线);
/// - 都读不到:有线状态→有线;无线状态→2.4G(macOS 上既然非蓝牙就是 2.4G,但 bluetoothd 没加载完前先不下结论)。
fn connection_of(c: &Gamepad) -> Connection {
    use sdl3::sys::hidapi::SDL_hid_bus_type;
    let state = c.connection_state().unwrap_or(ConnectionState::Unknown);
    // HID 总线类型最准(按设备),优先用它;读不到(部分 BLE 手柄、或同 VID 多只总线混合返回 None)
    // 才退回蓝牙守护进程兜底。注意:**不能**让 is_bluetooth 抢在前面 —— 它按品牌词模糊匹配,
    // 会把同品牌的有线手柄也误判成蓝牙;HID 能给出确定总线时应当它说了算。
    match hid_bus_for(c.vendor_id()) {
        Some(SDL_hid_bus_type::BLUETOOTH) => Connection::Bluetooth,
        Some(SDL_hid_bus_type::USB) => match state {
            ConnectionState::Wireless => Connection::Dongle,
            _ => Connection::Wired,
        },
        _ => {
            #[cfg(target_os = "macos")]
            if macos_bt::is_bluetooth(&c.name().unwrap_or_default()) {
                return Connection::Bluetooth;
            }
            match state {
                ConnectionState::Wired => Connection::Wired,
                ConnectionState::Wireless => wireless_kind(),
                _ => Connection::Unknown,
            }
        }
    }
}

/// 「无线但 HID 没分清」时:macOS 上(此处已确定非蓝牙)即 2.4G 接收器,但 bluetoothd 没加载完前
/// 先归 unknown(前端不显示图标),避免把刚连上的蓝牙手柄误标成 2.4G。其它平台无从细分,也归 unknown。
fn wireless_kind() -> Connection {
    #[cfg(target_os = "macos")]
    if macos_bt::loaded() {
        return Connection::Dongle;
    }
    Connection::Unknown
}

/// 前台 App 检测。macOS 经 `lsappinfo` 取 bundle id;Windows 经 GetForegroundWindow → 进程 exe
/// 文件名(小写);其它平台不编译本模块,`when.app` 覆盖不生效(基础映射照常)。两端标识口径与
/// installed_apps 的 list_applications(mac=bundle id / win=exe 文件名)一致,才能命中 when.app。
#[cfg(any(target_os = "macos", target_os = "windows"))]
mod frontmost {
    /// 取前台 App 的 bundle id;读不到 → `None`。
    /// 用 `lsappinfo`(系统自带、无需授权):先取前台 ASN,再查其 bundleID。
    #[cfg(target_os = "macos")]
    pub fn detect() -> Option<String> {
        use std::process::Command;
        let front = Command::new("lsappinfo").arg("front").output().ok()?;
        let asn = String::from_utf8_lossy(&front.stdout);
        let asn = asn.trim();
        if asn.is_empty() {
            return None;
        }
        let info = Command::new("lsappinfo").args(["info", "-only", "bundleID", asn]).output().ok()?;
        parse_bundle_id(&String::from_utf8_lossy(&info.stdout))
    }

    /// GetForegroundWindow → 进程 exe 文件名(小写)。exe 名语言无关且稳定;读不到 → `None`。
    #[cfg(target_os = "windows")]
    pub fn detect() -> Option<String> {
        use std::ffi::OsString;
        use std::os::windows::ffi::OsStringExt;
        use windows_sys::Win32::Foundation::CloseHandle;
        use windows_sys::Win32::System::Threading::{
            OpenProcess, PROCESS_NAME_WIN32, PROCESS_QUERY_LIMITED_INFORMATION, QueryFullProcessImageNameW,
        };
        use windows_sys::Win32::UI::WindowsAndMessaging::{GetForegroundWindow, GetWindowThreadProcessId};

        unsafe {
            let hwnd = GetForegroundWindow();
            if hwnd.is_null() {
                return None;
            }
            let mut pid: u32 = 0;
            GetWindowThreadProcessId(hwnd, &mut pid);
            if pid == 0 {
                return None;
            }
            let handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
            if handle.is_null() {
                return None;
            }
            let mut buf = [0u16; 1024];
            let mut len = buf.len() as u32;
            let ok = QueryFullProcessImageNameW(handle, PROCESS_NAME_WIN32, buf.as_mut_ptr(), &mut len);
            CloseHandle(handle);
            if ok == 0 {
                return None;
            }
            let full = OsString::from_wide(&buf[..len as usize]);
            full.to_string_lossy().rsplit(['\\', '/']).next().map(|f| f.to_ascii_lowercase())
        }
    }

    /// 从 lsappinfo 的 `"CFBundleIdentifier"="com.x.y"` 行抽出 bundle id。纯函数,可单测。
    /// 无 `=`(读取出错)、空值、`<null>`(无 bundle id 的进程)→ `None`。
    #[cfg(target_os = "macos")]
    pub(crate) fn parse_bundle_id(s: &str) -> Option<String> {
        let (_, val) = s.rsplit_once('=')?;
        let val = val.trim().trim_matches('"').trim();
        (!val.is_empty() && val != "<null>").then(|| val.to_string())
    }

    #[cfg(all(test, target_os = "macos"))]
    mod tests {
        use super::parse_bundle_id;

        #[test]
        fn parses_cfbundleidentifier_line() {
            assert_eq!(
                parse_bundle_id("\"CFBundleIdentifier\"=\"com.cmuxterm.app\"\n").as_deref(),
                Some("com.cmuxterm.app")
            );
            assert_eq!(parse_bundle_id("\"CFBundleIdentifier\"=\"<null>\""), None);
            assert_eq!(parse_bundle_id(""), None); // 无 '='
            assert_eq!(parse_bundle_id("garbage no equals"), None);
        }
    }
}

/// 后台线程主体:初始化 SDL3 + enigo,跑事件泵 + 定期枚举设备直到 `r` 被清零。
fn run_loop<F: Fn(EngineEvent)>(
    config: Config, r: Arc<AtomicBool>, pending: PendingConfig, rumbles: Arc<Mutex<Vec<RumbleCmd>>>,
    virtual_cmds: VirtualCommands, devices: Arc<Mutex<Vec<DeviceSnapshot>>>, active: Arc<Mutex<Option<u32>>>,
    inject: Arc<AtomicBool>, on_event: F,
) {
    macro_rules! fail {
        ($e:expr) => {{
            on_event(EngineEvent::Error { message: $e.to_string() });
            return;
        }};
    }

    // 须在 init 前设。
    sdl3::hint::set("SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", "1");
    sdl3::hint::set("SDL_JOYSTICK_HIDAPI", "1");

    let mut config = config;
    // 当前前台 App 标识(mac=bundle id / win=exe 文件名);注入 mapper 影响 when.app 覆盖命中(见 Mapper::set_app)。
    let mut current_app: Option<String> = None;
    let mut runtimes: HashMap<u32, DeviceRuntime> = HashMap::new();
    let mut sink = match EnigoSink::new() {
        Ok(s) => s,
        Err(e) => fail!(e),
    };
    let sdl = match sdl3::init() {
        Ok(s) => s,
        Err(e) => fail!(e),
    };
    let gcs = match sdl.gamepad() {
        Ok(s) => s,
        Err(e) => fail!(e),
    };
    let _events = match sdl.event() {
        Ok(events) => events,
        Err(error) => fail!(error),
    };
    on_event(EngineEvent::Ready);

    let mut poll_ms = config.poll_interval_ms.max(1);
    let mut poll = Duration::from_millis(poll_ms);
    // 每 ~500ms 重新枚举一次设备(并刷新电量)。
    let mut scan_every = (500 / poll_ms).max(1);

    let mut open: HashMap<u32, Gamepad> = HashMap::new();
    let mut batt: HashMap<u32, (Option<u8>, bool)> = HashMap::new(); // id → (电量, 充电中)
    // 当前虚拟手柄(dev 测试台;裸指针仅本线程使用,循环退出时统一拆掉)。
    let mut virtual_pad: Option<VirtualPad> = None;
    // 已排期但还没到点的振动请求:(应发出的 tick, 请求)。
    let mut pending_rumbles: Vec<(u64, RumbleCmd)> = Vec::new();
    let mut tick: u64 = 0;
    let mut was_injecting = true;
    let start = Instant::now(); // 单调计时基准,供 mapper 的 tap/hold 阈值与 mouse_key tick

    while r.load(Ordering::SeqCst) {
        let now_ms = start.elapsed().as_millis() as u64;
        // -1) 注入开关:GUI 自己聚焦时暂停发键(只保留高亮)。转为暂停的那一拍,
        //     释放所有物理按住的键 + 停连发,防卡键。
        let injecting = inject.load(Ordering::SeqCst);
        if was_injecting && !injecting {
            for runtime in runtimes.values_mut() {
                runtime.release(&mut sink, poll_ms);
            }
        }
        was_injecting = injecting;

        // 0) 热更新配置:切档案/保存映射时不重启 SDL,只重建 Mapper(防 EventPump 冲突 + 卡顿)。
        let next = pending.lock().unwrap().take();
        if let Some((cfg, applied)) = next {
            // 先释放旧映射按住的键 + 停连发,防卡键。
            for runtime in runtimes.values_mut() {
                runtime.release(&mut sink, poll_ms);
            }
            runtimes.clear();
            config = cfg;
            poll_ms = config.poll_interval_ms.max(1);
            poll = Duration::from_millis(poll_ms);
            scan_every = (500 / poll_ms).max(1);

            // 重建后重新注入当前前台 App,使 when.app 覆盖立即按当前上下文生效。

            let _ = applied.send(());
        }

        // 0.5) 振动请求(GUI「测试振动」等):入队的请求按 after_ms 排期,到点才发
        //      —— 这样「左脉冲→停→右脉冲」能分开,确认两个马达各自工作。
        for cmd in std::mem::take(&mut *rumbles.lock().unwrap()) {
            let fire_at = tick + (cmd.after_ms as u64 / poll_ms);
            pending_rumbles.push((fire_at, cmd));
        }
        for cmd in drain_due_rumbles(&mut pending_rumbles, tick) {
            let open_ids: Vec<u32> = open.keys().copied().collect();
            for id in rumble_targets(cmd.id, &open_ids) {
                if let Some(c) = open.get_mut(&id) {
                    let _ = c.set_rumble(cmd.low, cmd.high, cmd.duration_ms);
                }
            }
        }

        // 0.5) 虚拟手柄命令(dev 测试台):attach/detach/注入都必须在本(SDL)线程执行。
        // Process one acknowledged command per poll. A down/up pair must survive separate SDL updates.
        let command = {
            let mut queue = virtual_cmds.lock().unwrap();
            if queue.is_empty() { None } else { Some(queue.remove(0)) }
        };
        let completion = command.map(|(cmd, sender)| {
            let result = apply_virtual_command(cmd, &mut virtual_pad);
            (sender, result)
        });

        // 1) 输入事件(按钮 / 摇杆)走事件泵 —— 后台线程上 PumpEvents 仍能产出。
        // **所有手柄都映射出键**(可一起响应);但 Input 事件(界面高亮)只为活动手柄上报
        // —— 选中手柄二时,图上只高亮手柄二。`which` = 来源手柄实例 id,active=None 时全部高亮。
        let active_id = *active.lock().unwrap();
        gcs.update();
        let events = match take_gamepad_events() {
            Ok(events) => events,
            Err(error) => {
                on_event(EngineEvent::Error { message: error });
                break;
            }
        };
        for ev in events {
            match ev {
                Event::Quit { .. } => r.store(false, Ordering::SeqCst),
                Event::GamepadButtonDown { which, button, .. } => {
                    let which = which.raw();
                    let runtime =
                        runtimes.entry(which).or_insert_with(|| DeviceRuntime::new(&config, current_app.clone()));
                    let DeviceRuntime { mapper, translator, repeats } = runtime;
                    let events = joycon_button_events(&open, which, button, true)
                        .unwrap_or_else(|| translator.on_button_down(button));
                    // 诊断:没翻译出任何事件 = 该 SDL 按钮当前未映射(如背键 Paddle1-4)。
                    // 打到日志,便于确认手柄背键到底上报成什么(或根本没上报)。
                    if events.is_empty() {
                        log::info!("未映射的手柄按钮(SDL {button:?},实例 {which})");
                    }
                    let hl = active_id.is_none_or(|a| a == which);
                    dispatch(events, mapper, &mut sink, &on_event, repeats, poll_ms, now_ms, which, hl, injecting);
                }
                Event::GamepadButtonUp { which, button, .. } => {
                    let which = which.raw();
                    let runtime =
                        runtimes.entry(which).or_insert_with(|| DeviceRuntime::new(&config, current_app.clone()));
                    let DeviceRuntime { mapper, translator, repeats } = runtime;
                    let events = joycon_button_events(&open, which, button, false)
                        .unwrap_or_else(|| translator.on_button_up(button));
                    let hl = active_id.is_none_or(|a| a == which);
                    dispatch(events, mapper, &mut sink, &on_event, repeats, poll_ms, now_ms, which, hl, injecting);
                }
                Event::GamepadAxisMotion { which, axis, value, .. } => {
                    let which = which.raw();
                    let runtime =
                        runtimes.entry(which).or_insert_with(|| DeviceRuntime::new(&config, current_app.clone()));
                    let DeviceRuntime { mapper, translator, repeats } = runtime;
                    let (axis, value) = joycon_remap_axis(&open, which, axis, value);
                    let hl = active_id.is_none_or(|a| a == which);
                    dispatch(
                        translator.on_axis(axis, value),
                        mapper,
                        &mut sink,
                        &on_event,
                        repeats,
                        poll_ms,
                        now_ms,
                        which,
                        hl,
                        injecting,
                    );
                    // 摇杆当前模拟量推给 mapper:tick 里摇杆→鼠标按此缩放移动量(斜向 + 推程调速)。
                    mapper.set_stick_mags(&translator.stick_mags());
                }
                _ => {}
            }
        }

        // 2) 计时驱动:连发到点重发 + mapper 的 tap/hold 长按到点 + mouse_key 每 tick 移动。暂停注入时不发。
        if injecting {
            for runtime in runtimes.values_mut() {
                tick_repeats(&mut sink, &mut runtime.repeats);
                for output in runtime.mapper.tick(now_ms) {
                    execute(output, &mut sink, &mut runtime.repeats, poll_ms);
                }
            }
        }

        // 3) 定期重新枚举设备(可靠的实时插拔检测)+ 刷新电量 + 刷新设备快照。
        if completion.is_some() || tick.is_multiple_of(scan_every) {
            scan_devices(&gcs, &mut open, &mut batt, &mut runtimes, &mut sink, &on_event, poll_ms);
            *devices.lock().unwrap() = snapshot_devices(&open, &batt);
            // 按前台 App 切档(mac/win):变化时注入新 App 标识;when.app 覆盖下一次按键动态命中。
            // 无需重建 Mapper / 放键 —— 已按住的键按「按下当刻映射」结算(见 pressed_map),不卡键。
            // ~500ms 一次(随设备扫描),mac 走 lsappinfo、win 走 GetForegroundWindow,均无需权限。
            #[cfg(any(target_os = "macos", target_os = "windows"))]
            {
                let app = frontmost::detect();
                if app != current_app {
                    current_app = app;
                    for runtime in runtimes.values_mut() {
                        runtime.mapper.set_app(current_app.clone());
                    }
                }
            }
        }
        if let Some((sender, result)) = completion {
            let _ = sender.send(result);
        }
        tick = tick.wrapping_add(1);
        std::thread::sleep(poll);
    }

    // 退出清理:释放所有按住的键 + 停连发;虚拟手柄一并拆掉。
    for runtime in runtimes.values_mut() {
        runtime.release(&mut sink, poll_ms);
    }
    sink.release_all();
    if let Some(vp) = virtual_pad.take() {
        detach_virtual(vp);
    }
}

// ───────────────────────── 虚拟手柄(dev 测试台) ─────────────────────────

/// 引擎线程内持有的虚拟手柄。`joy` 裸指针仅本线程使用;`_name` 保住 desc.name 指向的内存。
struct VirtualPad {
    id: sdl3::sys::joystick::SDL_JoystickID,
    joy: *mut sdl3::sys::joystick::SDL_Joystick,
    _name: std::ffi::CString,
}

/// 各型号的官方 VID/PID(SDL 按它推导 GamepadType;词表同 `model_of`)。
fn virtual_vid_pid(model: &str) -> Option<(u16, u16)> {
    Some(match model {
        "joycon-left" => (0x057e, 0x2006),
        "joycon-right" => (0x057e, 0x2007),
        "joycon-grip" => (0x057e, 0x2008),
        "switch-pro" => (0x057e, 0x2009),
        "xbox" => (0x045e, 0x02dd),
        "dualsense" => (0x054c, 0x0ce6),
        "dualshock-4" => (0x054c, 0x05c4),
        "generic" => (0, 0),
        _ => return None,
    })
}

/// 虚拟手柄的设备名恒定(不随型号变):前端「测试手柄」按名字选中/识别,
/// 切型号 = 重新 attach 换 VID/PID,名字不变选中不丢。
pub const VIRTUAL_PAD_NAME: &str = "Test Gamepad";

/// 接入虚拟手柄:声明成 GAMEPAD 类型(SDL 对 virtual gamepad 用「joystick 键位 i = gamepad 键 i」
/// 的默认映射,注入按 SDL_GamepadButton/Axis 序号即可),VID/PID 决定 GamepadType 识别。
fn attach_virtual(model: &str) -> Result<VirtualPad, String> {
    use sdl3::sys::joystick::*;
    let (vid, pid) = virtual_vid_pid(model).ok_or_else(|| format!("未知型号 {model}"))?;
    let cname = std::ffi::CString::new(VIRTUAL_PAD_NAME).expect("static name");
    let mut desc = SDL_VirtualJoystickDesc::new();
    desc.r#type = SDL_JoystickType::GAMEPAD.0 as u16;
    desc.vendor_id = vid;
    desc.product_id = pid;
    desc.naxes = 6; // SDL_GamepadAxis 全集
    desc.nbuttons = 26; // SDL_GamepadButton 全集
    desc.name = cname.as_ptr();
    let id = unsafe { SDL_AttachVirtualJoystick(&desc) };
    if id.0 == 0 {
        return Err(sdl3::get_error().to_string());
    }
    let joy = unsafe { SDL_OpenJoystick(id) };
    if joy.is_null() {
        unsafe { SDL_DetachVirtualJoystick(id) };
        return Err(sdl3::get_error().to_string());
    }
    Ok(VirtualPad { id, joy, _name: cname })
}

fn detach_virtual(vp: VirtualPad) {
    unsafe {
        sdl3::sys::joystick::SDL_CloseJoystick(vp.joy);
        sdl3::sys::joystick::SDL_DetachVirtualJoystick(vp.id);
    }
}

fn apply_virtual_command(cmd: VirtualPadCmd, pad: &mut Option<VirtualPad>) -> Result<(), String> {
    match cmd {
        VirtualPadCmd::Attach { model } => {
            if virtual_vid_pid(&model).is_none() {
                return Err(format!("Unknown controller model: {model}"));
            }
            if let Some(old) = pad.take() {
                detach_virtual(old);
            }
            *pad = Some(attach_virtual(&model)?);
        }
        VirtualPadCmd::Detach => {
            if let Some(old) = pad.take() {
                detach_virtual(old);
            }
        }
        VirtualPadCmd::Button { button, pressed } => {
            let pad = pad.as_ref().ok_or("Virtual controller is not attached")?;
            let index = virtual_button_index(&button).ok_or_else(|| format!("Unknown controller button: {button}"))?;
            if !unsafe { sdl3::sys::joystick::SDL_SetJoystickVirtualButton(pad.joy, index, pressed) } {
                return Err(sdl3::get_error().to_string());
            }
        }
        VirtualPadCmd::Axis { axis, value } => {
            let pad = pad.as_ref().ok_or("Virtual controller is not attached")?;
            let index = virtual_axis_index(&axis).ok_or_else(|| format!("Unknown controller axis: {axis}"))?;
            if !unsafe { sdl3::sys::joystick::SDL_SetJoystickVirtualAxis(pad.joy, index, value) } {
                return Err(sdl3::get_error().to_string());
            }
        }
    }
    Ok(())
}

/// 按钮名(SDL_GamepadButton 语义)→ virtual joystick 键位序号。
fn virtual_button_index(name: &str) -> Option<i32> {
    use sdl3::gamepad::Button;
    let b = match name {
        "south" => Button::South,
        "east" => Button::East,
        "west" => Button::West,
        "north" => Button::North,
        "back" => Button::Back,
        "guide" => Button::Guide,
        "start" => Button::Start,
        "leftstick" => Button::LeftStick,
        "rightstick" => Button::RightStick,
        "leftshoulder" => Button::LeftShoulder,
        "rightshoulder" => Button::RightShoulder,
        "dpadup" => Button::DPadUp,
        "dpaddown" => Button::DPadDown,
        "dpadleft" => Button::DPadLeft,
        "dpadright" => Button::DPadRight,
        "misc1" => Button::Misc1,
        "leftpaddle1" => Button::LeftPaddle1,
        "leftpaddle2" => Button::LeftPaddle2,
        "rightpaddle1" => Button::RightPaddle1,
        "rightpaddle2" => Button::RightPaddle2,
        "touchpad" => Button::Touchpad,
        _ => return None,
    };
    Some(b as i32)
}

/// 轴名(SDL_GamepadAxis 语义)→ virtual joystick 轴序号。
fn virtual_axis_index(name: &str) -> Option<i32> {
    use sdl3::gamepad::Axis;
    let a = match name {
        "leftx" => Axis::LeftX,
        "lefty" => Axis::LeftY,
        "rightx" => Axis::RightX,
        "righty" => Axis::RightY,
        "lefttrigger" => Axis::TriggerLeft,
        "righttrigger" => Axis::TriggerRight,
        _ => return None,
    };
    Some(a as i32)
}

/// 设备增减 diff(纯逻辑,可单测):给定当前在线实例 id 列表与已打开 id 列表,
/// 返回 `(新接入待打开, 已消失待移除)`。移除一律以【已打开集合里存好的 id】跟在线列表
/// 对账,而不是读失效句柄——这是「重连出现多个 / 残留删不掉」一类 bug 的根因与修复点。
fn diff_devices(listed: &[u32], open: &[u32]) -> (Vec<u32>, Vec<u32>) {
    let live: std::collections::HashSet<u32> = listed.iter().copied().collect();
    let opened: std::collections::HashSet<u32> = open.iter().copied().collect();
    let added: Vec<u32> = listed.iter().copied().filter(|id| !opened.contains(id)).collect();
    let removed: Vec<u32> = open.iter().copied().filter(|id| !live.contains(id)).collect();
    (added, removed)
}

/// 取出排期表里「应发出 tick ≤ now」的振动请求并从表中移除(纯逻辑,可单测)。
fn drain_due_rumbles(pending: &mut Vec<(u64, RumbleCmd)>, now: u64) -> Vec<RumbleCmd> {
    let mut due = vec![];
    pending.retain(|(fire_at, cmd)| {
        if *fire_at <= now {
            due.push(*cmd);
            false
        } else {
            true
        }
    });
    due
}

/// 振动目标选择(纯逻辑,可单测):`Some(id)` 仅当该 id 在线时震它;`None` 震全部已连接。
/// 离线的指定 id 直接忽略(不报错)。
fn rumble_targets(id: Option<u32>, open_ids: &[u32]) -> Vec<u32> {
    match id {
        Some(id) if open_ids.contains(&id) => vec![id],
        Some(_) => vec![],
        None => open_ids.to_vec(),
    }
}

/// 从当前打开的手柄集合构建快照(名字/品牌/电量)。供前端主动查询补种列表。
fn snapshot_devices(open: &HashMap<u32, Gamepad>, batt: &HashMap<u32, (Option<u8>, bool)>) -> Vec<DeviceSnapshot> {
    open.iter()
        .map(|(id, c)| {
            let (battery, charging) = *batt.get(id).unwrap_or(&(None, false));
            DeviceSnapshot {
                id: *id,
                name: c.name().unwrap_or_else(|| "未知手柄".into()),
                brand: brand_of(c).to_string(),
                model: model_of(c).to_string(),
                battery,
                charging,
                // 每次快照实时算(不缓存)——连接方式会随插拔/蓝牙↔有线切换变化,缓存会留旧值。
                connection: connection_of(c),
            }
        })
        .collect()
}

/// 枚举当前设备,与已打开集合做 diff:新设备 open + 上报连接;消失的上报断开;
/// 在线设备电量变化则上报。必须打开手柄(并保持存活)才会收到其输入事件。
fn scan_devices<F: Fn(EngineEvent)>(
    gcs: &GamepadSubsystem, open: &mut HashMap<u32, Gamepad>, batt: &mut HashMap<u32, (Option<u8>, bool)>,
    runtimes: &mut HashMap<u32, DeviceRuntime>, sink: &mut EnigoSink, on_event: &F, poll_ms: u64,
) {
    let listed = gcs.gamepads().unwrap_or_default();
    let listed_ids: Vec<u32> = listed.iter().map(|j| j.raw()).collect();
    let open_ids: Vec<u32> = open.keys().copied().collect();
    let (added, removed) = diff_devices(&listed_ids, &open_ids);
    let added: std::collections::HashSet<u32> = added.into_iter().collect();

    // 新接入 → 打开 + 上报。以打开时的实例 id 为 key,后续不再读 c.id()。
    for jid in &listed {
        let id = jid.raw();
        if !added.contains(&id) || !gcs.is_gamepad(*jid) {
            continue;
        }
        if let Ok(c) = gcs.open(*jid) {
            let (battery, charging) = battery_of(&c);
            batt.insert(id, (battery, charging));
            on_event(EngineEvent::GamepadConnected {
                id,
                name: c.name().unwrap_or_else(|| "未知手柄".into()),
                brand: brand_of(&c).to_string(),
                model: model_of(&c).to_string(),
                battery,
                charging,
                connection: connection_of(&c),
            });
            open.insert(id, c);
        }
    }

    // 消失 → 上报断开 + 移除(removed 由 diff_devices 用存好的 id 算出,见其文档)。
    for id in &removed {
        open.remove(id);
        batt.remove(id);
        on_event(EngineEvent::GamepadDisconnected { id: *id });
    }
    for id in removed {
        if let Some(mut runtime) = runtimes.remove(&id) {
            runtime.release(sink, poll_ms);
        }
    }

    // 在线设备电量 / 充电状态变化 → 上报。
    for (id, c) in open.iter() {
        let bc = battery_of(c);
        if batt.get(id) != Some(&bc) {
            batt.insert(*id, bc);
            on_event(EngineEvent::GamepadBattery { id: *id, battery: bc.0, charging: bc.1 });
        }
    }
}

/// 连发表:键名 → (间隔 tick 数, 倒计时 tick)。倒计时归零就 tap 一次再重置。
struct DeviceRuntime {
    mapper: Mapper,
    translator: Translator,
    repeats: Repeats,
}
impl DeviceRuntime {
    fn new(config: &Config, app: Option<String>) -> Self {
        let mut mapper = Mapper::new(config);
        mapper.set_app(app);
        Self { mapper, translator: Translator::new(config.deadzone), repeats: Repeats::new() }
    }
    fn release(&mut self, sink: &mut EnigoSink, poll_ms: u64) {
        for output in self.mapper.release_all() {
            execute(output, sink, &mut self.repeats, poll_ms);
        }
        self.repeats.clear();
    }
}

type Repeats = std::collections::HashMap<String, (u64, u64)>;

/// 连发间隔(毫秒)→ tick 数。至少 1,防止间隔 ≤ 轮询间隔时算出 0 拍 → 永不/疯狂触发。
/// 纯函数,与时序/键盘解耦,可单测。
fn repeat_ticks(interval_ms: u64, poll_ms: u64) -> u64 {
    (interval_ms / poll_ms).max(1)
}

/// 推进所有连发倒计时一拍,返回本拍到点要重发的键(到点后倒计时重置为间隔)。
/// 纯逻辑(不碰键盘),可单测;实际 tap 由 [`tick_repeats`] 完成。
fn due_repeats(repeats: &mut Repeats) -> Vec<String> {
    let mut due = vec![];
    for (key, (interval, countdown)) in repeats.iter_mut() {
        *countdown = countdown.saturating_sub(1);
        if *countdown == 0 {
            due.push(key.clone());
            *countdown = *interval;
        }
    }
    due
}

fn execute(output: Output, sink: &mut EnigoSink, repeats: &mut Repeats, poll_ms: u64) {
    match output {
        // 连发按 tick 计时(轮询固定间隔);其余键鼠/exec 复用共享的 apply_output(与 main.rs 同一份)。
        Output::RepeatStart(k, ms) => {
            sink.tap(&k); // 立即触发一次,后续由 tick_repeats 按间隔重发
            let ticks = repeat_ticks(ms, poll_ms);
            repeats.insert(k, (ticks, ticks));
        }
        Output::RepeatStop(k) => {
            repeats.remove(&k);
        }
        other => crate::output::apply_output(&other, sink),
    }
}

/// 每个 poll tick 调一次:递减各连发倒计时,到点就再 tap 一次。
fn tick_repeats(sink: &mut EnigoSink, repeats: &mut Repeats) {
    for key in due_repeats(repeats) {
        sink.tap(&key);
    }
}

/// 把一批统一事件喂给映射引擎并执行;`emit_input` 为真才上报高亮(只有活动手柄上报)。
/// `inject` 为假(GUI 自己聚焦时)只上报高亮、**不发键也不动映射状态** —— 免得注入的键
/// 操作 GUI 自己的控件。注:暂停时跳过 `mapper.handle`,转回注入时是干净状态。
fn dispatch<F: Fn(EngineEvent)>(
    events: Vec<InputEvent>, mapper: &mut Mapper, sink: &mut EnigoSink, on_event: &F, repeats: &mut Repeats,
    poll_ms: u64, now_ms: u64, device_id: u32, emit_input: bool, inject: bool,
) {
    for ie in events {
        if emit_input {
            let (control, pressed) = match ie {
                InputEvent::Pressed(c) => (c, true),
                InputEvent::Released(c) => (c, false),
            };
            on_event(EngineEvent::Input { device_id, control, pressed });
        }
        if inject {
            for o in mapper.handle(ie, now_ms) {
                execute(o, sink, repeats, poll_ms);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn controllers_keep_layers_and_axis_edges_independent() {
        use crate::event::{Button, Control, InputEvent};
        use crate::{action::Output, config::Config, engine::DeviceRuntime};
        let config = Config::from_json(
            r#"{
          "buttons": {"leftshoulder": {"to_layer": "shift"}, "south": {"to":[{"key_code":"KeyA"}]}},
          "overrides": [{"when":{"layer":["shift"]},"buttons":{"south":{"to":[{"key_code":"KeyB"}]}}}]
        }"#,
        )
        .unwrap();
        let mut first = DeviceRuntime::new(&config, None);
        let mut second = DeviceRuntime::new(&config, None);
        first.mapper.handle(InputEvent::Pressed(Control::Button(Button::L1)), 0);
        assert_eq!(
            first.mapper.handle(InputEvent::Pressed(Control::Button(Button::South)), 1),
            vec![Output::Press("KeyB".into())]
        );
        assert_eq!(
            second.mapper.handle(InputEvent::Pressed(Control::Button(Button::South)), 1),
            vec![Output::Press("KeyA".into())]
        );
        first.mapper.release_all();
        assert_eq!(
            second.mapper.handle(InputEvent::Released(Control::Button(Button::South)), 2),
            vec![Output::Release("KeyA".into())]
        );
        let first_edge = first.translator.on_axis(sdl3::gamepad::Axis::LeftX, 30000);
        let second_edge = second.translator.on_axis(sdl3::gamepad::Axis::LeftX, 30000);
        assert!(!first_edge.is_empty());
        assert_eq!(first_edge, second_edge);
    }

    #[test]
    fn repeat_ticks_divides_interval_by_poll() {
        // 60ms 间隔 / 8ms 轮询 = 每 7 拍触发一次。
        assert_eq!(repeat_ticks(60, 8), 7);
        assert_eq!(repeat_ticks(80, 8), 10);
    }

    #[test]
    fn repeat_ticks_is_at_least_one() {
        // 间隔 ≤ 轮询间隔时,至少每拍触发一次(防 0 间隔死循环)。
        assert_eq!(repeat_ticks(5, 8), 1);
        assert_eq!(repeat_ticks(0, 8), 1);
    }

    #[test]
    fn due_repeats_fires_only_after_countdown_reaches_zero() {
        let mut r: Repeats = Repeats::new();
        r.insert("x".into(), (3, 3)); // 间隔 3 拍
        assert_eq!(due_repeats(&mut r), Vec::<String>::new()); // 拍 1
        assert_eq!(due_repeats(&mut r), Vec::<String>::new()); // 拍 2
        assert_eq!(due_repeats(&mut r), vec!["x".to_string()]); // 拍 3 → 触发
    }

    #[test]
    fn due_repeats_reloads_interval_and_keeps_firing() {
        let mut r: Repeats = Repeats::new();
        r.insert("x".into(), (2, 2));
        assert_eq!(due_repeats(&mut r), Vec::<String>::new()); // 拍 1
        assert_eq!(due_repeats(&mut r), vec!["x".to_string()]); // 拍 2 → 触发,重置回 2
        assert_eq!(due_repeats(&mut r), Vec::<String>::new()); // 拍 1
        assert_eq!(due_repeats(&mut r), vec!["x".to_string()]); // 拍 2 → 再次触发
    }

    #[test]
    fn due_repeats_runs_each_key_at_its_own_cadence() {
        let mut r: Repeats = Repeats::new();
        r.insert("fast".into(), (1, 1)); // 每拍
        r.insert("slow".into(), (3, 3)); // 每 3 拍
        // 拍 1:只有 fast 到点。
        assert_eq!(due_repeats(&mut r), vec!["fast".to_string()]);
        // 拍 2:只有 fast。
        assert_eq!(due_repeats(&mut r), vec!["fast".to_string()]);
        // 拍 3:两者都到点(HashMap 序不定,排序后比较)。
        let mut both = due_repeats(&mut r);
        both.sort();
        assert_eq!(both, vec!["fast".to_string(), "slow".to_string()]);
    }

    #[test]
    fn due_repeats_empty_table_fires_nothing() {
        let mut r: Repeats = Repeats::new();
        assert_eq!(due_repeats(&mut r), Vec::<String>::new());
    }

    fn sorted(mut v: Vec<u32>) -> Vec<u32> {
        v.sort_unstable();
        v
    }

    #[test]
    fn diff_devices_reports_new_devices_as_added() {
        let (added, removed) = diff_devices(&[1, 2], &[1]);
        assert_eq!(added, vec![2]);
        assert_eq!(removed, Vec::<u32>::new());
    }

    #[test]
    fn diff_devices_reports_vanished_devices_as_removed() {
        // 1 还在,2 已从在线列表消失 → 移除 2(以已打开的 id 对账,不依赖句柄)。
        let (added, removed) = diff_devices(&[1], &[1, 2]);
        assert_eq!(added, Vec::<u32>::new());
        assert_eq!(removed, vec![2]);
    }

    #[test]
    fn diff_devices_already_open_device_is_not_re_added() {
        // 已打开的设备再次出现在列表里不应重复 added —— 防「重复条目」。
        let (added, _) = diff_devices(&[1, 1], &[1]);
        assert_eq!(added, Vec::<u32>::new());
    }

    #[test]
    fn diff_devices_reconnect_same_id_adds_once_no_duplicate() {
        // 断开(从 open 移除)后以同一 id 重连:应正好 added 一次,removed 为空。
        let (added, removed) = diff_devices(&[7], &[]);
        assert_eq!(added, vec![7]);
        assert_eq!(removed, Vec::<u32>::new());
    }

    #[test]
    fn diff_devices_handles_simultaneous_add_and_remove() {
        // 同一拍里 2 走、3 来:各报一次,互不影响。
        let (added, removed) = diff_devices(&[1, 3], &[1, 2]);
        assert_eq!(sorted(added), vec![3]);
        assert_eq!(sorted(removed), vec![2]);
    }

    #[test]
    fn diff_devices_empty_lists_yield_nothing() {
        let (added, removed) = diff_devices(&[], &[]);
        assert_eq!(added, Vec::<u32>::new());
        assert_eq!(removed, Vec::<u32>::new());
    }

    #[test]
    fn rumble_targets_none_means_all_connected() {
        assert_eq!(sorted(rumble_targets(None, &[1, 2, 3])), vec![1, 2, 3]);
        assert_eq!(rumble_targets(None, &[]), Vec::<u32>::new());
    }

    #[test]
    fn rumble_targets_specific_id_only_when_online() {
        assert_eq!(rumble_targets(Some(2), &[1, 2, 3]), vec![2]);
        // 指定的 id 已离线 → 忽略,不震别的。
        assert_eq!(rumble_targets(Some(9), &[1, 2, 3]), Vec::<u32>::new());
    }

    fn rc(after_ms: u32) -> RumbleCmd {
        RumbleCmd { id: None, low: 0xFFFF, high: 0, duration_ms: 200, after_ms }
    }

    #[test]
    fn drain_due_rumbles_fires_only_elapsed_and_keeps_the_rest() {
        // 排期:左在 tick 5 发,右在 tick 50 发。
        let mut pending = vec![(5u64, rc(0)), (50u64, rc(350))];
        assert_eq!(drain_due_rumbles(&mut pending, 4).len(), 0); // 都没到点
        assert_eq!(pending.len(), 2);

        let due = drain_due_rumbles(&mut pending, 5); // 左到点
        assert_eq!(due.len(), 1);
        assert_eq!(pending.len(), 1); // 右还留着

        let due2 = drain_due_rumbles(&mut pending, 50); // 右到点
        assert_eq!(due2.len(), 1);
        assert!(pending.is_empty());
    }
}

/// Updates are pumped with SDL_UpdateGamepads, which SDL allows on any thread.
/// Read only gamepad events so other SDL users retain their event queues.
fn take_gamepad_events() -> Result<Vec<Event>, String> {
    use sdl3::sys::events::{
        SDL_EVENT_GAMEPAD_AXIS_MOTION, SDL_EVENT_GAMEPAD_STEAM_HANDLE_UPDATED, SDL_Event, SDL_GETEVENT, SDL_PeepEvents,
    };
    let mut events = Vec::new();
    loop {
        let mut raw = std::mem::MaybeUninit::<SDL_Event>::uninit();
        let count = unsafe {
            SDL_PeepEvents(
                raw.as_mut_ptr(),
                1,
                SDL_GETEVENT,
                SDL_EVENT_GAMEPAD_AXIS_MOTION.into(),
                SDL_EVENT_GAMEPAD_STEAM_HANDLE_UPDATED.into(),
            )
        };
        if count < 0 {
            return Err(sdl3::get_error().to_string());
        }
        if count == 0 {
            break;
        }
        events.push(Event::from_ll(unsafe { raw.assume_init() }));
    }
    Ok(events)
}

#[cfg(test)]
mod native_tests {
    use super::*;
    #[test]
    #[ignore = "Explicit native SDL virtual-device smoke test; no system output"]
    fn virtual_input_without_main_thread_event_pump() {
        let sdl = sdl3::init().unwrap();
        let gamepads = sdl.gamepad().unwrap();
        let _events = sdl.event().unwrap();
        let pad = attach_virtual("xbox").unwrap();
        let opened = gamepads.open(pad.id.into()).unwrap();
        gamepads.update();
        take_gamepad_events().unwrap();
        assert!(unsafe { sdl3::sys::joystick::SDL_SetJoystickVirtualButton(pad.joy, 0, true) });
        gamepads.update();
        let events = take_gamepad_events().unwrap();
        assert!(events.iter().any(|event| matches!(event, Event::GamepadButtonDown { which, button: sdl3::gamepad::Button::South, .. } if which.raw() == pad.id.0)), "Missing virtual press: {events:?}");
        assert!(unsafe { sdl3::sys::joystick::SDL_SetJoystickVirtualButton(pad.joy, 0, false) });
        gamepads.update();
        let events = take_gamepad_events().unwrap();
        assert!(
            events.iter().any(|event| matches!(event, Event::GamepadButtonUp { .. })),
            "Missing virtual release: {events:?}"
        );
        drop(opened);
        detach_virtual(pad);
    }
}

#[cfg(test)]
mod worker_smoke_tests {
    use super::*;
    #[test]
    #[ignore = "Explicit native worker smoke test; empty mappings and injection disabled"]
    fn native_worker_acknowledges_virtual_edges_and_stops() {
        let (sender, receiver) = std::sync::mpsc::channel();
        let mut engine = Engine::start_with_injection(Config::from_json("{}").unwrap(), false, move |event| {
            sender.send(event).unwrap();
        })
        .unwrap();
        engine.virtual_pad(VirtualPadCmd::Attach { model: "xbox".into() }).unwrap();
        engine.virtual_pad(VirtualPadCmd::Button { button: "south".into(), pressed: true }).unwrap();
        engine.virtual_pad(VirtualPadCmd::Button { button: "south".into(), pressed: false }).unwrap();
        engine.virtual_pad(VirtualPadCmd::Detach).unwrap();
        engine.stop();
        assert!(!engine.is_running());
        let events: Vec<_> = receiver.try_iter().collect();
        assert!(
            events
                .iter()
                .any(|event| matches!(event, EngineEvent::GamepadConnected { name, .. } if name == VIRTUAL_PAD_NAME))
        );
        assert!(events.iter().any(|event| matches!(event, EngineEvent::Input { pressed: true, .. })));
        assert!(events.iter().any(|event| matches!(event, EngineEvent::Input { pressed: false, .. })));
        assert!(events.iter().any(|event| matches!(event, EngineEvent::GamepadDisconnected { .. })));
        assert!(matches!(events.last(), Some(EngineEvent::Stopped)));
    }
}

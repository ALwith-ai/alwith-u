//! 键盘模拟执行层。把键名字符串解析成按键并注入系统。
//! 跟踪已按下的键,支持退出/断开时统一释放,防卡键。
//!
//! 底层注入抽象成 [`KeyBackend`] trait —— enigo 是生产实现,测试用录制后端,
//! 这样 tap/combo 处理"已按住修饰键"的逻辑可纯单测。

use std::collections::HashMap;
use std::thread::sleep;
use std::time::Duration;

use enigo::{Axis, Button as EnButton, Coordinate, Direction as Dir, Enigo, Key, Keyboard, Mouse, Settings};

use crate::action::{MouseBtn, Output};

/// 组合键里每次按下之间的间隔。**经验值**:合成太快会被系统/应用丢弃(尤其 Cmd+Tab /
/// Cmd+Space 这类需修饰键稳定按住的系统快捷键)。跨系统偏保守,宁慢勿丢。
const COMBO_KEY_DELAY_MS: u64 = 12;
/// 组合键全部按下后、逆序松开前的保持时长(同为经验值,原因同上)。
const COMBO_HOLD_MS: u64 = 30;

/// 底层键鼠注入(按下/松开/点击 + 鼠标)。抽象出来便于测试。
pub trait KeyBackend {
    fn key(&mut self, key: Key, dir: Dir);
    fn mouse_button(&mut self, btn: MouseBtn, dir: Dir);
    /// 相对移动光标。
    fn mouse_move(&mut self, x: i32, y: i32);
    /// 滚轮(x=水平,y=垂直;非零才发)。
    fn scroll(&mut self, x: i32, y: i32);
}

/// 生产后端:调 enigo 真正注入,失败记日志(不向上传播)。
pub struct EnigoBackend {
    enigo: Enigo,
}

fn en_btn(b: MouseBtn) -> EnButton {
    match b {
        MouseBtn::Left => EnButton::Left,
        MouseBtn::Middle => EnButton::Middle,
        MouseBtn::Right => EnButton::Right,
    }
}

impl KeyBackend for EnigoBackend {
    fn key(&mut self, key: Key, dir: Dir) {
        if let Err(e) = self.enigo.key(key, dir) {
            log::warn!("注入按键失败 {key:?} {dir:?}: {e}");
        }
    }
    fn mouse_button(&mut self, btn: MouseBtn, dir: Dir) {
        if let Err(e) = self.enigo.button(en_btn(btn), dir) {
            log::warn!("注入鼠标键失败 {btn:?} {dir:?}: {e}");
        }
    }
    fn mouse_move(&mut self, x: i32, y: i32) {
        if let Err(e) = self.enigo.move_mouse(x, y, Coordinate::Rel) {
            log::warn!("鼠标移动失败 ({x},{y}): {e}");
        }
    }
    fn scroll(&mut self, x: i32, y: i32) {
        if x != 0 {
            if let Err(e) = self.enigo.scroll(x, Axis::Horizontal) {
                log::warn!("横向滚动失败 {x}: {e}");
            }
        }
        if y != 0 {
            if let Err(e) = self.enigo.scroll(y, Axis::Vertical) {
                log::warn!("纵向滚动失败 {y}: {e}");
            }
        }
    }
}

/// 键盘输出:维护"已按下"集合 + 一个后端。映射逻辑与具体注入方式解耦。
pub struct Sink<B: KeyBackend> {
    backend: B,
    held: HashMap<String, usize>,
    held_mouse: HashMap<MouseBtn, usize>,
    /// 组合键里每次按下之间的间隔。合成组合键太快会被系统/应用丢弃
    /// (尤其 Cmd+Tab / Cmd+Space 这类需要修饰键稳定按住的系统快捷键)。
    key_delay: Duration,
    /// 组合键全部按下后、逆序松开前的保持时长。
    combo_hold: Duration,
}

impl<B: KeyBackend> Sink<B> {
    fn new_with(backend: B) -> Self {
        // 默认零延时(单测用);真实 enigo 后端在 EnigoSink::new 里设非零值。
        Sink {
            backend,
            held: HashMap::new(),
            held_mouse: HashMap::new(),
            key_delay: Duration::ZERO,
            combo_hold: Duration::ZERO,
        }
    }

    pub fn press(&mut self, key: &str) {
        let Some(k) = resolve(key) else {
            log::warn!("未知按键: {key}");
            return;
        };
        let owners = self.held.entry(key.to_string()).or_default();
        if *owners == 0 {
            self.backend.key(k, Dir::Press);
        }
        *owners += 1;
    }

    pub fn release(&mut self, key: &str) {
        let Some(owners) = self.held.get_mut(key) else {
            return;
        };
        *owners -= 1;
        if *owners == 0 {
            self.held.remove(key);
            if let Some(k) = resolve(key) {
                self.backend.key(k, Dir::Release);
            }
        }
    }

    pub fn tap(&mut self, key: &str) {
        let Some(k) = resolve(key) else {
            log::warn!("未知按键: {key}");
            return;
        };
        // 若该键当前正被按住(Hold),先临时松开再点击,完事恢复,避免冲突/卡键。
        let was_held = self.held.contains_key(key);
        if was_held {
            self.backend.key(k, Dir::Release);
        }
        self.backend.key(k, Dir::Click);
        if was_held {
            self.backend.key(k, Dir::Press);
        }
    }

    pub fn combo(&mut self, keys: &[String]) {
        // 与 press/tap 一致:未知键告警而非静默丢弃(combo 里某个键打错了能看见)。
        let resolved: Vec<(&String, Key)> = keys
            .iter()
            .filter_map(|k| match resolve(k) {
                Some(rk) => Some((k, rk)),
                None => {
                    log::warn!("未知按键: {k}");
                    None
                }
            })
            .collect();
        // 临时松开 combo 里那些当前正按住的键(如 Hold 的修饰键),避免与组合键冲突。
        let restore: Vec<Key> =
            resolved.iter().filter(|(name, _)| self.held.contains_key(name.as_str())).map(|(_, k)| *k).collect();
        for k in &restore {
            self.backend.key(*k, Dir::Release);
        }
        // 依次按下,每次之间留间隔让系统稳定识别修饰键;全部按下后保持片刻再松开。
        for (_, k) in &resolved {
            self.backend.key(*k, Dir::Press);
            sleep(self.key_delay);
        }
        sleep(self.combo_hold);
        // 逆序松开。
        for (_, k) in resolved.iter().rev() {
            self.backend.key(*k, Dir::Release);
        }
        // 恢复之前按住的键。
        for k in &restore {
            self.backend.key(*k, Dir::Press);
        }
    }

    pub fn mouse_down(&mut self, btn: MouseBtn) {
        let owners = self.held_mouse.entry(btn).or_default();
        if *owners == 0 {
            self.backend.mouse_button(btn, Dir::Press);
        }
        *owners += 1;
    }
    pub fn mouse_up(&mut self, btn: MouseBtn) {
        let Some(owners) = self.held_mouse.get_mut(&btn) else {
            return;
        };
        *owners -= 1;
        if *owners == 0 {
            self.held_mouse.remove(&btn);
            self.backend.mouse_button(btn, Dir::Release);
        }
    }
    pub fn mouse_click(&mut self, btn: MouseBtn) {
        let held = self.held_mouse.contains_key(&btn);
        if held {
            self.backend.mouse_button(btn, Dir::Release);
        }
        self.backend.mouse_button(btn, Dir::Click);
        if held {
            self.backend.mouse_button(btn, Dir::Press);
        }
    }
    pub fn mouse_move(&mut self, x: i32, y: i32) {
        self.backend.mouse_move(x, y);
    }
    pub fn scroll(&mut self, x: i32, y: i32) {
        self.backend.scroll(x, y);
    }

    /// 释放所有当前按住的键。
    pub fn release_all(&mut self) {
        let keys: Vec<String> = self.held.drain().map(|(key, _)| key).collect();
        for (button, _) in self.held_mouse.drain() {
            self.backend.mouse_button(button, Dir::Release);
        }
        for key in keys {
            if let Some(k) = resolve(&key) {
                self.backend.key(k, Dir::Release);
            }
        }
    }
}

impl<B: KeyBackend> Drop for Sink<B> {
    fn drop(&mut self) {
        self.release_all();
    }
}

/// Production keyboard and mouse output.
pub type EnigoSink = Sink<EnigoBackend>;

fn enigo_settings() -> Settings {
    Settings { open_prompt_to_get_permissions: false, ..Settings::default() }
}

impl Sink<EnigoBackend> {
    pub fn new() -> Result<Self, String> {
        let settings = enigo_settings();
        let enigo =
            Enigo::new(&settings).map_err(|e| format!("初始化 enigo 失败(macOS 需要辅助功能+输入监控权限): {e}"))?;
        let mut sink = Sink::new_with(EnigoBackend { enigo });
        sink.key_delay = Duration::from_millis(COMBO_KEY_DELAY_MS);
        sink.combo_hold = Duration::from_millis(COMBO_HOLD_MS);
        Ok(sink)
    }
}

/// 执行与「连发计时模型」无关的输出(键 / 鼠标 / exec)。CLI(按时间)与引擎(按 tick)
/// 各自的 `execute` 复用它,只自行处理 `RepeatStart`/`RepeatStop` —— 那两支计时模型不同、
/// 不走这里(传进来也为空操作)。抽出来避免两处 execute 的这段分支复制粘贴、加新 Output 漏改。
pub fn apply_output(output: &Output, sink: &mut EnigoSink) {
    match output {
        Output::Press(k) => sink.press(k),
        Output::Release(k) => sink.release(k),
        Output::Tap(k) => sink.tap(k),
        Output::Combo(ks) => sink.combo(ks),
        Output::Exec(cmd) => crate::exec::run(cmd),
        // 用系统默认方式打开路径/URL(跨平台启动 app:mac→`open`、Windows→ShellExecute)。
        Output::Open(path) => {
            if let Err(e) = open::that(path) {
                log::warn!("open 失败 {path:?}: {e}");
            }
        }
        Output::MouseDown(b) => sink.mouse_down(*b),
        Output::MouseUp(b) => sink.mouse_up(*b),
        Output::MouseClick(b) => sink.mouse_click(*b),
        Output::MouseMove { x, y } => sink.mouse_move(*x, *y),
        Output::Scroll { x, y } => sink.scroll(*x, *y),
        // 连发由各调用方按自己的计时模型处理,不在此发生。
        Output::RepeatStart(..) | Output::RepeatStop(..) => {}
    }
}

/// 键名字符串 → enigo 按键。
/// canonical:W3C `KeyboardEvent.code`(如 `KeyA` / `Digit1` / `Numpad1` / `MetaLeft` / `ArrowUp` / `F5`),
/// 与在线键盘检测站一致、跨平台、天然区分主键盘/小键盘与左右修饰键。
/// 兼容:也认旧短名(`enter`/`cmd`/`up`…,大小写不敏感),避免老配置失效。
fn resolve(name: &str) -> Option<Key> {
    let n = name.trim();
    // macOS/Windows:字符键(字母/主排数字/标点)优先走物理虚拟键码表,见 char_key_vk
    #[cfg(any(target_os = "macos", target_os = "windows"))]
    if let Some(k) = char_key_vk(n) {
        return Some(k);
    }
    // 字母:KeyA..KeyZ → 小写 Unicode
    if let Some(rest) = n.strip_prefix("Key") {
        if let Some(ch) = single_ascii_alpha(rest) {
            return Some(Key::Unicode(ch.to_ascii_lowercase()));
        }
    }
    // 主键盘数字:Digit0..Digit9 → Unicode
    if let Some(rest) = n.strip_prefix("Digit") {
        if let Some(d) = single_digit(rest) {
            return Some(Key::Unicode((b'0' + d) as char));
        }
    }
    // 小键盘:Numpad0..Numpad9 + 运算符(与主键盘 Digit* 是不同物理键)
    if let Some(rest) = n.strip_prefix("Numpad") {
        if let Some(d) = single_digit(rest) {
            return Some(numpad_digit_key(d));
        }
        return match rest {
            "Add" => Some(Key::Add),
            "Subtract" => Some(Key::Subtract),
            "Multiply" => Some(Key::Multiply),
            "Divide" => Some(Key::Divide),
            "Decimal" => Some(Key::Decimal),
            "Enter" => Some(Key::Return),
            _ => None,
        };
    }
    // 功能键:F1..F24
    if let Some(rest) = n.strip_prefix('F') {
        if let Ok(num) = rest.parse::<u8>() {
            return fkey(num);
        }
    }
    // code 具名键
    let key = match n {
        "Enter" => Key::Return,
        "Escape" => Key::Escape,
        "Backspace" => Key::Backspace,
        "Tab" => Key::Tab,
        "Space" => Key::Space,
        "Delete" => Key::Delete,
        "CapsLock" => Key::CapsLock,
        "ArrowUp" => Key::UpArrow,
        "ArrowDown" => Key::DownArrow,
        "ArrowLeft" => Key::LeftArrow,
        "ArrowRight" => Key::RightArrow,
        "Home" => Key::Home,
        "End" => Key::End,
        "PageUp" => Key::PageUp,
        "PageDown" => Key::PageDown,
        // 媒体 / 消费键(consumer_key_code)。值用 W3C UI Events `key` 名(如 `MediaPlayPause`),
        // 与「key_code 用 W3C code」同源。enigo 跨平台注入(macOS 走 NX aux 事件)。
        "AudioVolumeUp" => Key::VolumeUp,
        "AudioVolumeDown" => Key::VolumeDown,
        "AudioVolumeMute" => Key::VolumeMute,
        "MediaPlayPause" => Key::MediaPlayPause,
        "MediaTrackNext" => Key::MediaNextTrack,
        "MediaTrackPrevious" => Key::MediaPrevTrack,
        // MediaStop:enigo 仅 Windows/Linux 有(macOS 无此变体)。
        #[cfg(any(target_os = "windows", all(unix, not(target_os = "macos"))))]
        "MediaStop" => Key::MediaStop,
        // 修饰键(左右分明):macOS 上 Meta=左⌘、RCommand=右⌘、ROption=右⌥
        // Fn:macOS 独有(enigo Key::Function);Windows 的 Fn 是键盘固件键,系统层无法合成。
        #[cfg(target_os = "macos")]
        "Fn" => Key::Function,
        "MetaLeft" => Key::Meta,
        "ControlLeft" => Key::Control,
        "AltLeft" => Key::Alt,
        "ShiftLeft" => Key::Shift,
        "ShiftRight" => Key::RShift,
        "ControlRight" => Key::RControl,
        #[cfg(target_os = "macos")]
        "MetaRight" => Key::RCommand,
        #[cfg(not(target_os = "macos"))]
        "MetaRight" => Key::RWin,
        #[cfg(target_os = "macos")]
        "AltRight" => Key::ROption,
        #[cfg(not(target_os = "macos"))]
        "AltRight" => Key::RMenu,
        // 以下键 enigo 在 macOS 无对应变体(被 cfg 门控掉),仅 Windows/Linux 支持。
        #[cfg(not(target_os = "macos"))]
        "Insert" => Key::Insert,
        #[cfg(not(target_os = "macos"))]
        "PrintScreen" => Key::PrintScr,
        // ScrollLock:enigo 变体名分平台(Windows=Scroll、Linux=ScrollLock)。
        #[cfg(target_os = "windows")]
        "ScrollLock" => Key::Scroll,
        #[cfg(all(unix, not(target_os = "macos")))]
        "ScrollLock" => Key::ScrollLock,
        #[cfg(not(target_os = "macos"))]
        "Pause" => Key::Pause,
        // ContextMenu:Windows=Apps、Linux=LMenu(Keysym::Menu),enigo 无跨平台统一变体。
        #[cfg(target_os = "windows")]
        "ContextMenu" => Key::Apps,
        #[cfg(all(unix, not(target_os = "macos")))]
        "ContextMenu" => Key::LMenu,
        // 标点(code 名 → US 布局字符)
        "Minus" => Key::Unicode('-'),
        "Equal" => Key::Unicode('='),
        "BracketLeft" => Key::Unicode('['),
        "BracketRight" => Key::Unicode(']'),
        "Backslash" => Key::Unicode('\\'),
        "Semicolon" => Key::Unicode(';'),
        "Quote" => Key::Unicode('\''),
        "Backquote" => Key::Unicode('`'),
        "Comma" => Key::Unicode(','),
        "Period" => Key::Unicode('.'),
        "Slash" => Key::Unicode('/'),
        _ => return None,
    };
    Some(key)
}

/// 字符键(字母/主排数字/标点)→ **物理虚拟键码**(`Key::Other`),macOS/Windows 专用。
///
/// 为什么不能用 `Key::Unicode`:
/// - macOS:enigo 对 Unicode 键要查键盘布局(`TSMGetInputSourceProperty`),macOS 26 起
///   HIToolbox 给 TIS API 加了主队列断言(`dispatch_assert_queue`),引擎线程调用直接
///   SIGTRAP 杀整个进程(2026-07-10 崩溃报告:islGetInputSourceListWithAdditions →
///   dispatch_assert_queue_fail,Thread 16 = 引擎线程 combo 注入)。kVK_ANSI_* 物理码
///   走 CGEventCreateKeyboardEvent,不触 TIS。
/// - Windows:enigo 对 Unicode 键走 KEYEVENTF_UNICODE 字符注入,修饰键组合(Ctrl+C 等)
///   对多数应用不成立;VK_* 物理码才有正确的组合键语义。
/// - 其余平台(Linux)保持 Unicode 注入,不在此表。
///
/// W3C `code` 本就是物理键语义,发物理码同时更贴协议(布局无关)。
#[cfg(any(target_os = "macos", target_os = "windows"))]
fn char_key_vk(n: &str) -> Option<Key> {
    #[cfg(target_os = "macos")]
    let vk: u32 = match n {
        // kVK_ANSI_*(Carbon Events.h)
        "KeyA" => 0x00,
        "KeyS" => 0x01,
        "KeyD" => 0x02,
        "KeyF" => 0x03,
        "KeyH" => 0x04,
        "KeyG" => 0x05,
        "KeyZ" => 0x06,
        "KeyX" => 0x07,
        "KeyC" => 0x08,
        "KeyV" => 0x09,
        "KeyB" => 0x0B,
        "KeyQ" => 0x0C,
        "KeyW" => 0x0D,
        "KeyE" => 0x0E,
        "KeyR" => 0x0F,
        "KeyY" => 0x10,
        "KeyT" => 0x11,
        "KeyO" => 0x1F,
        "KeyU" => 0x20,
        "KeyI" => 0x22,
        "KeyP" => 0x23,
        "KeyL" => 0x25,
        "KeyJ" => 0x26,
        "KeyK" => 0x28,
        "KeyN" => 0x2D,
        "KeyM" => 0x2E,
        "Digit1" => 0x12,
        "Digit2" => 0x13,
        "Digit3" => 0x14,
        "Digit4" => 0x15,
        "Digit5" => 0x17,
        "Digit6" => 0x16,
        "Digit7" => 0x1A,
        "Digit8" => 0x1C,
        "Digit9" => 0x19,
        "Digit0" => 0x1D,
        "Minus" => 0x1B,
        "Equal" => 0x18,
        "BracketLeft" => 0x21,
        "BracketRight" => 0x1E,
        "Backslash" => 0x2A,
        "Semicolon" => 0x29,
        "Quote" => 0x27,
        "Backquote" => 0x32,
        "Comma" => 0x2B,
        "Period" => 0x2F,
        "Slash" => 0x2C,
        _ => return None,
    };
    #[cfg(target_os = "windows")]
    let vk: u32 = match n {
        // 字母/数字 VK 就是 ASCII 大写字母与数字本身
        _ if n.len() == 4 && n.starts_with("Key") && n.as_bytes()[3].is_ascii_uppercase() => u32::from(n.as_bytes()[3]),
        _ if n.len() == 6 && n.starts_with("Digit") && n.as_bytes()[5].is_ascii_digit() => u32::from(n.as_bytes()[5]),
        // VK_OEM_*(US 布局位置)
        "Minus" => 0xBD,
        "Equal" => 0xBB,
        "BracketLeft" => 0xDB,
        "BracketRight" => 0xDD,
        "Backslash" => 0xDC,
        "Semicolon" => 0xBA,
        "Quote" => 0xDE,
        "Backquote" => 0xC0,
        "Comma" => 0xBC,
        "Period" => 0xBE,
        "Slash" => 0xBF,
        _ => return None,
    };
    Some(Key::Other(vk))
}

fn single_ascii_alpha(s: &str) -> Option<char> {
    let mut it = s.chars();
    match (it.next(), it.next()) {
        (Some(c), None) if c.is_ascii_alphabetic() => Some(c),
        _ => None,
    }
}
fn single_digit(s: &str) -> Option<u8> {
    let mut it = s.chars();
    match (it.next(), it.next()) {
        (Some(c), None) => c.to_digit(10).map(|d| d as u8),
        _ => None,
    }
}
fn numpad_digit_key(d: u8) -> Key {
    match d {
        0 => Key::Numpad0,
        1 => Key::Numpad1,
        2 => Key::Numpad2,
        3 => Key::Numpad3,
        4 => Key::Numpad4,
        5 => Key::Numpad5,
        6 => Key::Numpad6,
        7 => Key::Numpad7,
        8 => Key::Numpad8,
        _ => Key::Numpad9,
    }
}
fn fkey(num: u8) -> Option<Key> {
    Some(match num {
        1 => Key::F1,
        2 => Key::F2,
        3 => Key::F3,
        4 => Key::F4,
        5 => Key::F5,
        6 => Key::F6,
        7 => Key::F7,
        8 => Key::F8,
        9 => Key::F9,
        10 => Key::F10,
        11 => Key::F11,
        12 => Key::F12,
        13 => Key::F13,
        14 => Key::F14,
        15 => Key::F15,
        16 => Key::F16,
        17 => Key::F17,
        18 => Key::F18,
        19 => Key::F19,
        20 => Key::F20,
        // F21-F24:enigo 仅 Windows/Linux 有,macOS 无 → 一律上限 F20,保持跨平台一致。
        _ => return None,
    })
}

/// 键名是否可被识别(W3C code)。用于启动期校验配置。
pub fn is_valid_key(name: &str) -> bool {
    resolve(name).is_some()
}

pub fn is_supported_key(name: &str) -> bool {
    resolve(name).is_some()
}

#[cfg(test)]
mod tests {
    use super::*;

    // 用 Debug 字符串比较,避免依赖 enigo::Key 的 PartialEq。
    fn dbg(name: &str) -> Option<String> {
        resolve(name).map(|k| format!("{k:?}"))
    }

    #[test]
    fn shared_key_stays_pressed_until_last_owner_releases() {
        let mut sink = Sink::new_with(Recorder::default());
        sink.press("KeyA");
        sink.press("KeyA");
        sink.release("KeyA");
        assert_eq!(sink.backend.events, vec![ev("KeyA", "Press")]);
        sink.release("KeyA");
        assert_eq!(sink.backend.events, vec![ev("KeyA", "Press"), ev("KeyA", "Release")]);
    }

    #[test]
    fn resolves_w3c_code_names() {
        assert_eq!(dbg("Enter"), Some("Return".to_string()));
        assert_eq!(dbg("Escape"), Some("Escape".to_string()));
        assert_eq!(dbg("ArrowUp"), Some("UpArrow".to_string()));
        assert_eq!(dbg("MetaLeft"), Some("Meta".to_string()));
        // 字符键分平台:macOS/Windows 发物理虚拟键码(见 char_key_vk),Linux 用字符注入
        #[cfg(target_os = "macos")]
        assert_eq!(dbg("KeyA"), Some("Other(0)".to_string()));
        #[cfg(target_os = "windows")]
        assert_eq!(dbg("KeyA"), Some("Other(65)".to_string()));
        #[cfg(all(unix, not(target_os = "macos")))]
        assert_eq!(dbg("KeyA"), Some("Unicode('a')".to_string()));
        #[cfg(target_os = "macos")]
        assert_eq!(dbg("Digit1"), Some("Other(18)".to_string()));
        #[cfg(target_os = "windows")]
        assert_eq!(dbg("Digit1"), Some("Other(49)".to_string()));
        #[cfg(all(unix, not(target_os = "macos")))]
        assert_eq!(dbg("Digit1"), Some("Unicode('1')".to_string()));
        assert_eq!(dbg("Numpad1"), Some("Numpad1".to_string())); // 小键盘用真·小键盘键
        assert_ne!(dbg("Digit1"), dbg("Numpad1")); // 主键盘 ≠ 小键盘
        assert_eq!(dbg("F5"), Some("F5".to_string()));
    }

    /// 关键契约:字符键在 macOS/Windows 上不得出现 Unicode 注入——macOS 26 上 Unicode
    /// 会触 TIS 布局解析,引擎线程直接 SIGTRAP 杀进程;Windows 上组合键语义不成立。
    #[test]
    #[cfg(any(target_os = "macos", target_os = "windows"))]
    fn char_keys_never_resolve_to_unicode() {
        let mut names: Vec<String> = (b'A'..=b'Z').map(|c| format!("Key{}", c as char)).collect();
        names.extend((0..=9).map(|d| format!("Digit{d}")));
        for p in [
            "Minus",
            "Equal",
            "BracketLeft",
            "BracketRight",
            "Backslash",
            "Semicolon",
            "Quote",
            "Backquote",
            "Comma",
            "Period",
            "Slash",
        ] {
            names.push(p.to_string());
        }
        for name in names {
            let d = dbg(&name).unwrap_or_else(|| panic!("{name} 未解析"));
            assert!(d.starts_with("Other("), "{name} 解析成了 {d},应为物理虚拟键码");
        }
    }

    #[test]
    fn resolves_consumer_media_keys() {
        // consumer_key_code:W3C UI Events key 名 → enigo 媒体键(跨平台)。
        assert_eq!(dbg("AudioVolumeUp"), Some("VolumeUp".to_string()));
        assert_eq!(dbg("AudioVolumeDown"), Some("VolumeDown".to_string()));
        assert_eq!(dbg("AudioVolumeMute"), Some("VolumeMute".to_string()));
        assert_eq!(dbg("MediaPlayPause"), Some("MediaPlayPause".to_string()));
        assert_eq!(dbg("MediaTrackNext"), Some("MediaNextTrack".to_string()));
        assert_eq!(dbg("MediaTrackPrevious"), Some("MediaPrevTrack".to_string()));
        assert!(is_valid_key("MediaPlayPause"));
    }

    #[test]
    fn distinguishes_left_right_modifiers() {
        assert_ne!(dbg("ShiftRight"), dbg("ShiftLeft"));
        assert_ne!(dbg("ControlRight"), dbg("ControlLeft"));
        assert!(dbg("ShiftRight").is_some());
    }

    #[test]
    fn unknown_and_legacy_names_return_none() {
        assert_eq!(resolve("notakey"), None);
        assert_eq!(resolve(""), None);
        // 旧短名不再兼容(清爽断裂,无兼容层)。
        assert_eq!(resolve("enter"), None);
        assert_eq!(resolve("cmd"), None);
        assert_eq!(resolve("a"), None);
    }

    // ---- 录制后端:把每次键鼠操作记成 (对象Debug, 方向/动作),供断言序列 ----
    #[derive(Default)]
    struct Recorder {
        events: Vec<(String, String)>,
    }
    impl KeyBackend for Recorder {
        fn key(&mut self, key: Key, dir: Dir) {
            self.events.push((format!("{key:?}"), format!("{dir:?}")));
        }
        fn mouse_button(&mut self, btn: MouseBtn, dir: Dir) {
            self.events.push((format!("{btn:?}"), format!("{dir:?}")));
        }
        fn mouse_move(&mut self, x: i32, y: i32) {
            self.events.push((format!("move {x},{y}"), "Move".into()));
        }
        fn scroll(&mut self, x: i32, y: i32) {
            self.events.push((format!("scroll {x},{y}"), "Scroll".into()));
        }
    }
    fn ev(name: &str, dir: &str) -> (String, String) {
        (format!("{:?}", resolve(name).unwrap()), dir.to_string())
    }

    #[test]
    fn tap_when_not_held_is_a_single_click() {
        let mut s = Sink::new_with(Recorder::default());
        s.tap("Enter");
        assert_eq!(s.backend.events, vec![ev("Enter", "Click")]);
    }

    #[test]
    fn tap_releases_then_restores_a_held_key() {
        let mut s = Sink::new_with(Recorder::default());
        s.press("KeyA"); // 按住 a
        s.backend.events.clear();
        s.tap("KeyA");
        // 临时松开 → 点击 → 恢复按住
        assert_eq!(s.backend.events, vec![ev("KeyA", "Release"), ev("KeyA", "Click"), ev("KeyA", "Press")]);
    }

    #[test]
    fn combo_without_held_keys_is_plain_press_release() {
        let mut s = Sink::new_with(Recorder::default());
        s.combo(&["MetaLeft".into(), "KeyS".into()]);
        assert_eq!(
            s.backend.events,
            vec![ev("MetaLeft", "Press"), ev("KeyS", "Press"), ev("KeyS", "Release"), ev("MetaLeft", "Release")]
        );
    }

    #[test]
    fn combo_skips_unknown_keys_and_runs_the_rest() {
        let mut s = Sink::new_with(Recorder::default());
        s.combo(&["MetaLeft".into(), "notakey".into(), "KeyS".into()]); // 中间是打错的键
        assert_eq!(
            s.backend.events,
            vec![ev("MetaLeft", "Press"), ev("KeyS", "Press"), ev("KeyS", "Release"), ev("MetaLeft", "Release")]
        );
    }

    #[test]
    fn combo_temporarily_releases_and_restores_held_modifier() {
        let mut s = Sink::new_with(Recorder::default());
        s.press("MetaLeft"); // 按住 ⌘(如 R1=to MetaLeft)
        s.backend.events.clear();
        s.combo(&["MetaLeft".into(), "KeyS".into()]); // 触发 ⌘S
        assert_eq!(
            s.backend.events,
            vec![
                ev("MetaLeft", "Release"), // restore-release
                ev("MetaLeft", "Press"),   // combo
                ev("KeyS", "Press"),
                ev("KeyS", "Release"),
                ev("MetaLeft", "Release"),
                ev("MetaLeft", "Press"), // restore-press
            ]
        );
    }

    #[test]
    fn release_all_releases_every_held_key() {
        let mut s = Sink::new_with(Recorder::default());
        s.press("MetaLeft");
        s.press("ShiftLeft");
        s.backend.events.clear();
        s.release_all();
        let mut dirs: Vec<&str> = s.backend.events.iter().map(|(_, d)| d.as_str()).collect();
        dirs.sort_unstable();
        assert_eq!(dirs, vec!["Release", "Release"]);
        assert_eq!(s.backend.events.len(), 2);
    }

    #[test]
    fn mouse_button_move_and_scroll() {
        let mut s = Sink::new_with(Recorder::default());
        s.mouse_down(MouseBtn::Left);
        s.mouse_up(MouseBtn::Left);
        s.mouse_move(3, -5);
        s.scroll(0, -2);
        assert_eq!(
            s.backend.events,
            vec![
                ("Left".into(), "Press".into()),
                ("Left".into(), "Release".into()),
                ("move 3,-5".into(), "Move".into()),
                ("scroll 0,-2".into(), "Scroll".into()),
            ]
        );
    }

    #[test]
    fn enigo_never_prompts_for_system_permissions() {
        assert!(!enigo_settings().open_prompt_to_get_permissions);
    }
}

//! 核心映射引擎 —— 纯逻辑状态机:统一输入事件 → 底层输出意图。
//!
//! 对齐 Karabiner:控件 → [`Mapping`](handler)。时间由外部注入(`now_ms`),因此仍可纯单测:
//! - `to`:按下即发(key_code 走按住语义;combo/exec 一次性;mouse_key 按住每 tick 移动)。
//! - `to_if_alone`:单独轻点(按下后在阈值内、且没被其他键打断就松开)→ 松开时发。
//! - `to_if_held_down`:按住超过阈值 → tick 时发(按住语义,松开释放)。
//! - `to_after_key_up`:松开后一次性发。

use std::collections::HashMap;

use crate::action::{Event, Mapping, MouseBtn, MouseKey, Output};
use crate::config::Config;
use crate::event::{Button, Control, Direction, InputEvent, StickSide};

/// `repeat: true` 的连发间隔(Karabiner 用系统键盘设置,这里用固定默认)。
const REPEAT_INTERVAL_MS: u64 = 60;
/// 长按阈值:按住超过这么久算「长按」(Karabiner 默认 500ms;手柄取更跟手的 200ms)。
const HELD_THRESHOLD_MS: u64 = 200;

pub struct Mapper {
    /// 基础映射表:按钮与摇杆方向一视同仁。
    map: HashMap<Control, Mapping>,
    /// 条件覆盖(有序):`when` 满足则层叠到基础上(靠后的赢)。收敛「按 App / 图层」为一套。
    overrides: Vec<CompiledOverride>,
    /// 当前前台 App 标识(由引擎注入;mac=bundle id / win=exe 文件名)。用于 `when.app` 判定。
    current_app: Option<String>,
    /// 当前激活的图层集合(由 `to_layer` 控件按住时激活)。用于 `when.layer` 判定。
    active_layers: Vec<String>,
    /// 某控件按下时激活了哪个图层(松开时据此撤下该层)。
    held_layer: HashMap<Control, String>,
    /// 每个按下的控件按下**当刻**解析出的有效映射 —— 松开/长按结算用它,
    /// 使图层切换后仍按「按下时所处的层」结算(避免按下在层内、松开在层外时用错映射)。
    pressed_map: HashMap<Control, Mapping>,
    /// 每个按住的控件在松开时要撤销的项(逆序执行)。
    held: HashMap<Control, Vec<Undo>>,
    /// tap/hold 计时态(有 to_if_alone / to_if_held_down 的控件)。
    pending: HashMap<Control, Pending>,
    /// 活动的 mouse_key(按住期间每 tick 应用移动/滚动)。
    mouse_keys: HashMap<Control, MouseKey>,
    /// 光标移动速度倍率(config.mouse_move_scale),tick 时缩放 mouse_key 位移。
    move_scale: f32,
    /// 摇杆各方向当前模拟量幅度(0..1),由引擎每次轴变化推入。tick 时摇杆→鼠标的移动量
    /// 额外乘此幅度(推得越满越快、斜向按分量);非摇杆控件无条目 → 幅度 1.0(固定步长)。
    stick_mag: HashMap<Control, f32>,
}

/// 按速度倍率缩放单轴位移:非零位移缩放后至少保留 1px(带原方向),避免小倍率把移动抹成 0 卡住。
fn scale_move(v: i32, scale: f32) -> i32 {
    if v == 0 {
        return 0;
    }
    let scaled = (v as f32 * scale).round() as i32;
    if scaled == 0 { v.signum() } else { scaled }
}

/// 从(按钮 / 左摇杆 / 右摇杆)三张表构建统一的「控件 → 映射」表。基础层与各图层共用。
fn build_control_map(
    buttons: &HashMap<Button, Mapping>, left: &HashMap<Direction, Mapping>, right: &HashMap<Direction, Mapping>,
) -> HashMap<Control, Mapping> {
    let mut map = HashMap::new();
    for (btn, m) in buttons {
        map.insert(Control::Button(*btn), m.clone());
    }
    for (dir, m) in left {
        map.insert(Control::Stick { side: StickSide::Left, dir: *dir }, m.clone());
    }
    for (dir, m) in right {
        map.insert(Control::Stick { side: StickSide::Right, dir: *dir }, m.clone());
    }
    map
}

/// 编译好的条件覆盖。
struct CompiledOverride {
    /// `when.app`:前台 App 的 **bundle id 精确列表**(任一相等即算 App 满足)。
    app: Vec<String>,
    /// 原配置里是否指定了 `app`(区分「不约束 App」与「约束了但当前无前台 App」)。
    app_constrained: bool,
    /// `when.layer`:需全部处于激活。
    layer: Vec<String>,
    /// 该覆盖的映射表(仅列出要改的控件)。
    map: HashMap<Control, Mapping>,
}

/// 松开控件时要撤销的一项。
enum Undo {
    Key(String),
    Mouse(MouseBtn),
    Repeat(String),
}

/// tap/hold 计时态。
struct Pending {
    press_ms: u64,
    /// 还算「单独按」(按下后没有别的控件插进来)。
    alone: bool,
    /// to_if_held_down 是否已触发(触发后其键进 held,松开时释放)。
    held_fired: bool,
}

impl Mapper {
    pub fn new(config: &Config) -> Self {
        let map = build_control_map(&config.buttons, &config.left_stick, &config.right_stick);
        let overrides = config
            .overrides
            .iter()
            .map(|ov| CompiledOverride {
                app: ov.when.app.clone(),
                app_constrained: !ov.when.app.is_empty(),
                layer: ov.when.layer.clone(),
                map: build_control_map(&ov.buttons, &ov.left_stick, &ov.right_stick),
            })
            .collect();
        Mapper {
            map,
            overrides,
            current_app: None,
            active_layers: Vec::new(),
            held_layer: HashMap::new(),
            pressed_map: HashMap::new(),
            held: HashMap::new(),
            pending: HashMap::new(),
            mouse_keys: HashMap::new(),
            move_scale: config.mouse_move_scale,
            stick_mag: HashMap::new(),
        }
    }

    /// 更新摇杆各方向的当前模拟量幅度(引擎每次轴变化后调用)。
    pub fn set_stick_mags(&mut self, mags: &[(Control, f32)]) {
        for (ctrl, mag) in mags {
            self.stick_mag.insert(*ctrl, *mag);
        }
    }

    /// 处理一个输入事件(带当前时间毫秒)。
    pub fn handle(&mut self, event: InputEvent, now_ms: u64) -> Vec<Output> {
        match event {
            InputEvent::Pressed(ctrl) => self.on_press(ctrl, now_ms),
            InputEvent::Released(ctrl) => self.on_release(ctrl),
        }
    }

    /// 引擎注入当前前台 App 标识。影响 `when.app` 覆盖的命中(mac/win 检测得到,其它平台恒 None)。
    pub fn set_app(&mut self, app: Option<String>) {
        self.current_app = app;
    }

    /// 覆盖的 `when` 是否满足当前上下文(App + 已激活图层)。
    fn when_matches(&self, ov: &CompiledOverride) -> bool {
        let app_ok =
            !ov.app_constrained || self.current_app.as_deref().is_some_and(|id| ov.app.iter().any(|a| a == id));
        let layer_ok = ov.layer.iter().all(|l| self.active_layers.contains(l));
        app_ok && layer_ok
    }

    /// 解析控件的有效映射:基础映射起底,按顺序把满足 `when` 的覆盖层叠上去(靠后的赢)。
    fn resolve(&self, ctrl: &Control) -> Option<Mapping> {
        let mut result = self.map.get(ctrl).cloned();
        for ov in &self.overrides {
            if self.when_matches(ov) {
                if let Some(m) = ov.map.get(ctrl) {
                    result = Some(m.clone());
                }
            }
        }
        result
    }

    fn on_press(&mut self, ctrl: Control, now_ms: u64) -> Vec<Output> {
        let Some(mapping) = self.resolve(&ctrl) else {
            return vec![];
        };
        // 记住按下当刻的有效映射,供松开/长按结算(切层后仍按按下时所处的层结算)。
        self.pressed_map.insert(ctrl, mapping.clone());
        // 层修饰键:按住即激活该层,本身不发键(纯修饰)。
        if let Some(layer) = &mapping.to_layer {
            self.active_layers.push(layer.clone());
            self.held_layer.insert(ctrl, layer.clone());
            return vec![];
        }
        // 有别的控件在计时中 → 它们不再算「单独按」(轻点判定被打断)。
        for p in self.pending.values_mut() {
            p.alone = false;
        }
        let mut out = Vec::new();
        // `to`:立即发。
        self.press_events(ctrl, &mapping.to, &mut out);
        // 有 tap/hold handler → 起一个计时态。
        if !mapping.to_if_alone.is_empty() || !mapping.to_if_held_down.is_empty() {
            self.pending.insert(ctrl, Pending { press_ms: now_ms, alone: true, held_fired: false });
        }
        out
    }

    fn on_release(&mut self, ctrl: Control) -> Vec<Output> {
        let mut out = Vec::new();
        // 层修饰键松开:撤下它激活的那一层(移除栈里最后一个匹配项)。
        if let Some(layer) = self.held_layer.remove(&ctrl) {
            if let Some(pos) = self.active_layers.iter().rposition(|l| *l == layer) {
                self.active_layers.remove(pos);
            }
        }
        // 撤销按住的键/鼠标/连发(含已触发的 to_if_held_down 的键)。
        if let Some(undo) = self.held.remove(&ctrl) {
            undo_all(undo, &mut out);
        }
        self.mouse_keys.remove(&ctrl);
        // 用按下当刻的映射结算(而非当前层)。
        let mapping = self.pressed_map.remove(&ctrl);
        // tap/hold 计时结算。
        if let Some(p) = self.pending.remove(&ctrl) {
            if !p.held_fired && p.alone {
                if let Some(m) = &mapping {
                    for ev in &m.to_if_alone {
                        momentary_event(ev, &mut out);
                    }
                }
            }
        }
        // to_after_key_up:松开后一次性发。
        if let Some(m) = &mapping {
            for ev in &m.to_after_key_up {
                momentary_event(ev, &mut out);
            }
        }
        out
    }

    /// 每个 poll tick 调一次(带当前时间):长按到点触发 + 活动 mouse_key 移动。
    pub fn tick(&mut self, now_ms: u64) -> Vec<Output> {
        let mut out = Vec::new();
        // 长按到点:仍在计时、未触发、超过阈值 → 触发 to_if_held_down。
        let due: Vec<Control> = self
            .pending
            .iter()
            .filter(|(_, p)| !p.held_fired && now_ms.saturating_sub(p.press_ms) >= HELD_THRESHOLD_MS)
            .map(|(c, _)| *c)
            .collect();
        for ctrl in due {
            if let Some(mapping) = self.pressed_map.get(&ctrl).cloned() {
                self.press_events(ctrl, &mapping.to_if_held_down, &mut out);
            }
            if let Some(p) = self.pending.get_mut(&ctrl) {
                p.held_fired = true;
                p.alone = false;
            }
        }
        // 活动 mouse_key:每 tick 应用一次相对移动 / 滚动。移动量 = 全局速度倍率 × 摇杆模拟量幅度
        //(非摇杆控件幅度 1.0);滚轮不缩放(档位感,缩放会变成非整行)。scale 后至少保留 1px 方向。
        for (ctrl, mk) in &self.mouse_keys {
            let mag = self.stick_mag.get(ctrl).copied().unwrap_or(1.0);
            let scale = self.move_scale * mag;
            if mk.x != 0 || mk.y != 0 {
                out.push(Output::MouseMove { x: scale_move(mk.x, scale), y: scale_move(mk.y, scale) });
            }
            if mk.horizontal_wheel != 0 || mk.vertical_wheel != 0 {
                out.push(Output::Scroll { x: mk.horizontal_wheel, y: mk.vertical_wheel });
            }
        }
        out
    }

    /// 释放所有按住的键/鼠标 + 停所有连发 + 清计时/移动态。用于断开或退出时防卡键。
    pub fn release_all(&mut self) -> Vec<Output> {
        let mut out = Vec::new();
        for (_, undo) in self.held.drain() {
            undo_all(undo, &mut out);
        }
        self.pending.clear();
        self.mouse_keys.clear();
        self.active_layers.clear();
        self.held_layer.clear();
        self.pressed_map.clear();
        out
    }

    /// 发一组 event(用于 `to` 与到点的 `to_if_held_down`):记录松开时要撤销的项;
    /// mouse_key 进 mouse_keys 表(由 tick 持续移动)。
    fn press_events(&mut self, ctrl: Control, events: &[Event], out: &mut Vec<Output>) {
        let mut undo = self.held.remove(&ctrl).unwrap_or_default();
        for ev in events {
            if let Some(code) = &ev.key_code {
                if !ev.modifiers.is_empty() {
                    let mut keys = ev.modifiers.clone();
                    keys.push(code.clone());
                    out.push(Output::Combo(keys));
                } else if ev.repeat {
                    out.push(Output::RepeatStart(code.clone(), REPEAT_INTERVAL_MS));
                    undo.push(Undo::Repeat(code.clone()));
                } else {
                    out.push(Output::Press(code.clone()));
                    undo.push(Undo::Key(code.clone()));
                }
            } else if let Some(code) = &ev.consumer_key_code {
                out.push(Output::Press(code.clone()));
                undo.push(Undo::Key(code.clone()));
            } else if let Some(name) = &ev.pointing_button {
                if let Some(btn) = MouseBtn::parse(name) {
                    out.push(Output::MouseDown(btn));
                    undo.push(Undo::Mouse(btn));
                }
            } else if let Some(mk) = &ev.mouse_key {
                self.mouse_keys.insert(ctrl, mk.clone());
            } else if let Some(cmd) = &ev.shell_command {
                out.push(Output::Exec(vec!["sh".into(), "-c".into(), cmd.clone()]));
            } else if let Some(path) = &ev.open {
                out.push(Output::Open(path.clone()));
            }
        }
        if !undo.is_empty() {
            self.held.insert(ctrl, undo);
        }
    }
}

/// 一次性发一个 event(to_if_alone / to_after_key_up:tap / click / 单次移动 / exec)。
fn momentary_event(ev: &Event, out: &mut Vec<Output>) {
    if let Some(code) = &ev.key_code {
        if !ev.modifiers.is_empty() {
            let mut keys = ev.modifiers.clone();
            keys.push(code.clone());
            out.push(Output::Combo(keys));
        } else {
            out.push(Output::Tap(code.clone()));
        }
    } else if let Some(code) = &ev.consumer_key_code {
        out.push(Output::Tap(code.clone()));
    } else if let Some(name) = &ev.pointing_button {
        if let Some(btn) = MouseBtn::parse(name) {
            out.push(Output::MouseClick(btn));
        }
    } else if let Some(mk) = &ev.mouse_key {
        if mk.x != 0 || mk.y != 0 {
            out.push(Output::MouseMove { x: mk.x, y: mk.y });
        }
        if mk.horizontal_wheel != 0 || mk.vertical_wheel != 0 {
            out.push(Output::Scroll { x: mk.horizontal_wheel, y: mk.vertical_wheel });
        }
    } else if let Some(cmd) = &ev.shell_command {
        out.push(Output::Exec(vec!["sh".into(), "-c".into(), cmd.clone()]));
    } else if let Some(path) = &ev.open {
        out.push(Output::Open(path.clone()));
    }
}

/// 逆序撤销一组按住项。
fn undo_all(undo: Vec<Undo>, out: &mut Vec<Output>) {
    for u in undo.into_iter().rev() {
        match u {
            Undo::Key(k) => out.push(Output::Release(k)),
            Undo::Mouse(b) => out.push(Output::MouseUp(b)),
            Undo::Repeat(k) => out.push(Output::RepeatStop(k)),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::event::{Button, Control, Direction, StickSide};

    fn cfg_json(buttons: &str) -> Config {
        let text = format!(r#"{{ "buttons": {buttons} }}"#);
        Config::from_json(&text).unwrap()
    }
    fn press(m: &mut Mapper, b: Button, now: u64) -> Vec<Output> {
        m.handle(InputEvent::Pressed(Control::Button(b)), now)
    }
    fn release(m: &mut Mapper, b: Button, now: u64) -> Vec<Output> {
        m.handle(InputEvent::Released(Control::Button(b)), now)
    }

    #[test]
    fn to_key_code_presses_on_down_releases_on_up() {
        let cfg = cfg_json(r#"{ "rightshoulder": { "to": [{ "key_code": "MetaLeft" }] } }"#);
        let mut m = Mapper::new(&cfg);
        assert_eq!(press(&mut m, Button::R1, 0), vec![Output::Press("MetaLeft".into())]);
        assert_eq!(release(&mut m, Button::R1, 5), vec![Output::Release("MetaLeft".into())]);
    }

    #[test]
    fn to_key_code_with_modifiers_is_momentary_combo() {
        let cfg = cfg_json(r#"{ "north": { "to": [{ "key_code": "Tab", "modifiers": ["MetaLeft"] }] } }"#);
        let mut m = Mapper::new(&cfg);
        assert_eq!(press(&mut m, Button::North, 0), vec![Output::Combo(vec!["MetaLeft".into(), "Tab".into()])]);
        assert_eq!(release(&mut m, Button::North, 1), vec![]);
    }

    #[test]
    fn repeat_true_emits_repeat_start_stop() {
        let cfg = cfg_json(r#"{ "dpaddown": { "to": [{ "key_code": "ArrowDown", "repeat": true }] } }"#);
        let mut m = Mapper::new(&cfg);
        assert_eq!(press(&mut m, Button::Down, 0), vec![Output::RepeatStart("ArrowDown".into(), REPEAT_INTERVAL_MS)]);
        assert_eq!(release(&mut m, Button::Down, 1), vec![Output::RepeatStop("ArrowDown".into())]);
    }

    #[test]
    fn pointing_button_presses_and_releases_mouse() {
        let cfg = cfg_json(r#"{ "rightshoulder": { "to": [{ "pointing_button": "button1" }] } }"#);
        let mut m = Mapper::new(&cfg);
        assert_eq!(press(&mut m, Button::R1, 0), vec![Output::MouseDown(MouseBtn::Left)]);
        assert_eq!(release(&mut m, Button::R1, 1), vec![Output::MouseUp(MouseBtn::Left)]);
    }

    #[test]
    fn shell_command_runs_via_sh() {
        let cfg = cfg_json(r#"{ "start": { "to": [{ "shell_command": "open -a X" }] } }"#);
        let mut m = Mapper::new(&cfg);
        assert_eq!(
            press(&mut m, Button::Start, 0),
            vec![Output::Exec(vec!["sh".into(), "-c".into(), "open -a X".into()])]
        );
    }

    // ── tap/hold 双行为 ──

    #[test]
    fn tap_hold_quick_release_fires_to_if_alone() {
        let cfg = cfg_json(
            r#"{ "east": { "to_if_alone": [{ "key_code": "Escape" }], "to_if_held_down": [{ "key_code": "ControlLeft" }] } }"#,
        );
        let mut m = Mapper::new(&cfg);
        assert_eq!(press(&mut m, Button::East, 0), vec![]); // 按下不发
        assert_eq!(m.tick(50), vec![]); // 没到阈值
        // 阈值内松开 → 轻点 Escape。
        assert_eq!(release(&mut m, Button::East, 100), vec![Output::Tap("Escape".into())]);
    }

    #[test]
    fn tap_hold_past_threshold_fires_to_if_held_down() {
        let cfg = cfg_json(
            r#"{ "east": { "to_if_alone": [{ "key_code": "Escape" }], "to_if_held_down": [{ "key_code": "ControlLeft" }] } }"#,
        );
        let mut m = Mapper::new(&cfg);
        press(&mut m, Button::East, 0);
        assert_eq!(m.tick(100), vec![]); // 未到 200ms
        assert_eq!(m.tick(200), vec![Output::Press("ControlLeft".into())]); // 到点长按
        assert_eq!(m.tick(260), vec![]); // 已触发,不重复
        // 松开释放长按键,且不再发轻点。
        assert_eq!(release(&mut m, Button::East, 300), vec![Output::Release("ControlLeft".into())]);
    }

    #[test]
    fn tap_hold_interrupted_by_other_key_is_not_alone() {
        let cfg = cfg_json(
            r#"{
                "east": { "to_if_alone": [{ "key_code": "Escape" }] },
                "south": { "to": [{ "key_code": "Enter" }] }
            }"#,
        );
        let mut m = Mapper::new(&cfg);
        press(&mut m, Button::East, 0);
        press(&mut m, Button::South, 20); // 插入别的键 → East 不再「单独按」
        // East 松开:被打断,不发轻点。
        assert_eq!(release(&mut m, Button::East, 40), vec![]);
    }

    #[test]
    fn mouse_key_glides_each_tick_while_held() {
        let text = r#"{
            "buttons": {},
            "right_stick": { "up": { "to": [{ "mouse_key": { "y": -10 } }] } }
        }"#;
        let cfg = Config::from_json(text).unwrap();
        let mut m = Mapper::new(&cfg);
        let up = Control::Stick { side: StickSide::Right, dir: Direction::Up };
        assert_eq!(m.handle(InputEvent::Pressed(up), 0), vec![]); // 按下不直接动
        assert_eq!(m.tick(8), vec![Output::MouseMove { x: 0, y: -10 }]); // 每 tick 移动
        assert_eq!(m.tick(16), vec![Output::MouseMove { x: 0, y: -10 }]);
        assert_eq!(m.handle(InputEvent::Released(up), 24), vec![]); // 松开停止
        assert_eq!(m.tick(32), vec![]); // 不再移动
    }

    #[test]
    fn stick_mouse_move_scales_by_analog_magnitude() {
        let text = r#"{
            "buttons": {},
            "right_stick": {
                "up": { "to": [{ "mouse_key": { "y": -10 } }] },
                "right": { "to": [{ "mouse_key": { "x": 10 } }] }
            }
        }"#;
        let cfg = Config::from_json(text).unwrap();
        let mut m = Mapper::new(&cfg);
        let up = Control::Stick { side: StickSide::Right, dir: Direction::Up };
        let right = Control::Stick { side: StickSide::Right, dir: Direction::Right };
        // 斜推:上下轴半满、水平轴满 → 两方向同时按下(斜向),各按自身分量缩放。
        m.handle(InputEvent::Pressed(up), 0);
        m.handle(InputEvent::Pressed(right), 0);
        m.set_stick_mags(&[(up, 0.5), (right, 1.0)]);
        let out = m.tick(8);
        assert!(out.contains(&Output::MouseMove { x: 0, y: -5 })); // 半满 → 10×0.5=5
        assert!(out.contains(&Output::MouseMove { x: 10, y: 0 })); // 满 → 10×1.0=10
    }

    #[test]
    fn release_all_reverses_held_and_clears_state() {
        let cfg = cfg_json(
            r#"{
                "rightshoulder": { "to": [{ "key_code": "MetaLeft" }] },
                "east": { "to_if_held_down": [{ "key_code": "ControlLeft" }] }
            }"#,
        );
        let mut m = Mapper::new(&cfg);
        press(&mut m, Button::R1, 0);
        press(&mut m, Button::East, 0);
        m.tick(200); // East 长按触发 ControlLeft
        let mut out = m.release_all();
        out.sort_by(|a, b| format!("{a:?}").cmp(&format!("{b:?}")));
        assert_eq!(out, vec![Output::Release("ControlLeft".into()), Output::Release("MetaLeft".into())]);
        assert_eq!(m.release_all(), vec![]);
    }

    // ── 条件覆盖(when:图层 / 前台 App,可组合)──

    fn layered() -> Config {
        Config::from_json(
            r#"{
                "buttons": {
                    "leftshoulder": { "to_layer": "fn" },
                    "south": { "to": [{ "key_code": "Enter" }] },
                    "east": { "to": [{ "key_code": "Backspace" }] }
                },
                "overrides": [
                    { "when": { "layer": ["fn"] }, "buttons": { "south": { "to": [{ "key_code": "F1" }] } } }
                ]
            }"#,
        )
        .unwrap()
    }

    #[test]
    fn held_layer_key_switches_mapping_and_reverts() {
        let cfg = layered();
        let mut m = Mapper::new(&cfg);
        // 未按层键:south = Enter。
        assert_eq!(press(&mut m, Button::South, 0), vec![Output::Press("Enter".into())]);
        assert_eq!(release(&mut m, Button::South, 1), vec![Output::Release("Enter".into())]);
        // 按住层键本身不发键。
        assert_eq!(press(&mut m, Button::L1, 2), vec![]);
        // 层内:south = F1;east 层内未定义 → 回落基础 Backspace。
        assert_eq!(press(&mut m, Button::South, 3), vec![Output::Press("F1".into())]);
        assert_eq!(release(&mut m, Button::South, 4), vec![Output::Release("F1".into())]);
        assert_eq!(press(&mut m, Button::East, 5), vec![Output::Press("Backspace".into())]);
        assert_eq!(release(&mut m, Button::East, 6), vec![Output::Release("Backspace".into())]);
        // 层键松开后:south 回到 Enter。
        assert_eq!(release(&mut m, Button::L1, 7), vec![]);
        assert_eq!(press(&mut m, Button::South, 8), vec![Output::Press("Enter".into())]);
    }

    #[test]
    fn press_in_layer_then_release_after_layer_off_still_releases() {
        // 防卡键:按下在层内(F1),松层键后再松 south —— 仍按「按下当刻的映射」释放 F1。
        let cfg = layered();
        let mut m = Mapper::new(&cfg);
        press(&mut m, Button::L1, 0);
        assert_eq!(press(&mut m, Button::South, 1), vec![Output::Press("F1".into())]);
        release(&mut m, Button::L1, 2); // 先松层键(south 还按着)
        assert_eq!(release(&mut m, Button::South, 3), vec![Output::Release("F1".into())]);
    }

    #[test]
    fn release_all_clears_active_layers() {
        let cfg = layered();
        let mut m = Mapper::new(&cfg);
        press(&mut m, Button::L1, 0); // 激活 fn 层
        m.release_all();
        // 层已清:south 回到基础 Enter。
        assert_eq!(press(&mut m, Button::South, 1), vec![Output::Press("Enter".into())]);
    }

    #[test]
    fn app_override_applies_only_for_matching_frontmost_app() {
        // when.app 是 bundle id **精确列表**(从 App 列表挑选,无需正则)。
        let cfg = Config::from_json(
            r#"{
                "buttons": { "south": { "to": [{ "key_code": "Enter" }] } },
                "overrides": [
                    { "when": { "app": ["com.apple.Terminal"] }, "buttons": { "south": { "to": [{ "key_code": "F5" }] } } }
                ]
            }"#,
        )
        .unwrap();
        let mut m = Mapper::new(&cfg);
        // 无前台 App → 基础 Enter。
        assert_eq!(press(&mut m, Button::South, 0), vec![Output::Press("Enter".into())]);
        release(&mut m, Button::South, 1);
        // 不匹配 → 基础。
        m.set_app(Some("com.other".into()));
        assert_eq!(press(&mut m, Button::South, 2), vec![Output::Press("Enter".into())]);
        release(&mut m, Button::South, 3);
        // 精确匹配 Terminal → F5。
        m.set_app(Some("com.apple.Terminal".into()));
        assert_eq!(press(&mut m, Button::South, 4), vec![Output::Press("F5".into())]);
        assert_eq!(release(&mut m, Button::South, 5), vec![Output::Release("F5".into())]);
    }

    #[test]
    fn when_composes_app_and_layer() {
        // 只有「前台是 Terminal」且「按住 fn 层」两者都满足时,south 才 = F3。
        let cfg = Config::from_json(
            r#"{
                "buttons": {
                    "leftshoulder": { "to_layer": "fn" },
                    "south": { "to": [{ "key_code": "Enter" }] }
                },
                "overrides": [
                    { "when": { "app": ["com.apple.Terminal"], "layer": ["fn"] }, "buttons": { "south": { "to": [{ "key_code": "F3" }] } } }
                ]
            }"#,
        )
        .unwrap();
        let mut m = Mapper::new(&cfg);
        // 在 Terminal 但没按层 → 基础。
        m.set_app(Some("com.apple.Terminal".into()));
        assert_eq!(press(&mut m, Button::South, 0), vec![Output::Press("Enter".into())]);
        release(&mut m, Button::South, 1);
        // 按住层但不在 Terminal → 基础。
        m.set_app(Some("com.other".into()));
        press(&mut m, Button::L1, 2);
        assert_eq!(press(&mut m, Button::South, 3), vec![Output::Press("Enter".into())]);
        release(&mut m, Button::South, 4);
        release(&mut m, Button::L1, 5);
        // 两者都满足 → F3。
        m.set_app(Some("com.apple.Terminal".into()));
        press(&mut m, Button::L1, 6);
        assert_eq!(press(&mut m, Button::South, 7), vec![Output::Press("F3".into())]);
    }
}

//! 执行 shell 命令(exec 动作)。

use std::process::Command;

/// 启动一个命令(不阻塞,不等待退出)。命令首项是程序,其余是参数。
pub fn run(command: &[String]) {
    let Some((program, args)) = command.split_first() else {
        log::warn!("exec: 空命令");
        return;
    };
    match Command::new(program).args(args).spawn() {
        Ok(_) => log::info!("exec: {command:?}"),
        Err(e) => log::warn!("exec 失败 {command:?}: {e}"),
    }
}

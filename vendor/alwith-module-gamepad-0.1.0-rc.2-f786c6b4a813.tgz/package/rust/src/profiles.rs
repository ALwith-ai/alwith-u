use crate::config::Config;
use serde::{Deserialize, Serialize};
use specta::Type;
use std::{collections::BTreeMap, io::Write, path::PathBuf};

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct GripColor {
    pub left: String,
    pub right: String,
}
#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct Profile {
    pub id: String,
    pub revision: u32,
    pub config: Config,
    pub color: Option<GripColor>,
}
#[derive(Clone, Serialize, Deserialize)]
struct FileData {
    version: u32,
    profiles: BTreeMap<String, Profile>,
    active: Option<String>,
}
pub struct ProfileRepository {
    path: PathBuf,
    data: FileData,
}
impl ProfileRepository {
    pub fn open(path: PathBuf) -> Result<Self, String> {
        let data = match std::fs::read(&path) {
            Ok(bytes) => {
                serde_json::from_slice::<FileData>(&bytes).map_err(|e| format!("Invalid profile store: {e}"))?
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
                FileData { version: 1, profiles: BTreeMap::new(), active: None }
            }
            Err(e) => return Err(e.to_string()),
        };
        if data.version != 1 {
            return Err("Unsupported profile store version".into());
        }
        for (id, profile) in &data.profiles {
            if id != &profile.id {
                return Err("Profile identity does not match its key".into());
            }
            profile.config.validate()?;
        }
        if data.active.as_ref().is_some_and(|id| !data.profiles.contains_key(id)) {
            return Err("Active profile is missing".into());
        }
        Ok(Self { path, data })
    }
    pub fn get(&self, id: &str) -> Option<Profile> {
        self.data.profiles.get(id).cloned()
    }
    pub fn active(&self) -> Option<Profile> {
        self.data.active.as_ref().and_then(|id| self.get(id))
    }
    fn write(&self, data: &FileData) -> Result<(), String> {
        let parent = self.path.parent().ok_or("Profile path must have a parent")?;
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        let mut file = tempfile::NamedTempFile::new_in(parent).map_err(|e| e.to_string())?;
        file.write_all(&serde_json::to_vec_pretty(data).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
        file.as_file().sync_all().map_err(|e| e.to_string())?;
        file.persist(&self.path).map_err(|e| e.to_string())?;
        Ok(())
    }
    pub fn save(
        &mut self, id: &str, expected: u32, config: Config, color: Option<GripColor>,
    ) -> Result<Profile, String> {
        if id.trim().is_empty() {
            return Err("Profile ID must not be empty".into());
        }
        config.validate()?;
        let revision = self.get(id).map_or(0, |profile| profile.revision);
        if revision != expected {
            return Err(format!("Profile changed: expected {expected}, current {revision}"));
        }
        let profile = Profile {
            id: id.into(),
            revision: revision.checked_add(1).ok_or("Profile revision exhausted")?,
            config,
            color,
        };
        let mut next = self.data.clone();
        next.profiles.insert(id.into(), profile.clone());
        self.write(&next)?;
        self.data = next;
        Ok(profile)
    }
    pub fn activate(&mut self, id: &str) -> Result<Profile, String> {
        let profile = self.get(id).ok_or("Profile does not exist")?;
        let mut next = self.data.clone();
        next.active = Some(id.into());
        self.write(&next)?;
        self.data = next;
        Ok(profile)
    }
}

/// Native persistence port. The service is the only writer for a repository.
pub trait ProfileStore: Send {
    fn get(&self, id: &str) -> Option<Profile>;
    fn active(&self) -> Option<Profile>;
    fn save(&mut self, id: &str, expected: u32, config: Config, color: Option<GripColor>) -> Result<Profile, String>;
    fn activate(&mut self, id: &str) -> Result<Profile, String>;
}
impl ProfileStore for ProfileRepository {
    fn get(&self, id: &str) -> Option<Profile> {
        self.get(id)
    }
    fn active(&self) -> Option<Profile> {
        self.active()
    }
    fn save(&mut self, id: &str, expected: u32, config: Config, color: Option<GripColor>) -> Result<Profile, String> {
        self.save(id, expected, config, color)
    }
    fn activate(&mut self, id: &str) -> Result<Profile, String> {
        self.activate(id)
    }
}

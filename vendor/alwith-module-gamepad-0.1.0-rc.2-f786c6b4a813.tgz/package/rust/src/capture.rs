use std::sync::{Arc, Mutex};
#[derive(Clone, serde::Serialize)]
pub struct CaptureEvent {
    pub codes: String,
    pub pending: bool,
}
pub type CaptureReporter = Arc<dyn Fn(CaptureEvent) + Send + Sync>;
static OWNER: Mutex<bool> = Mutex::new(false);
static THREAD: Mutex<Option<std::thread::JoinHandle<()>>> = Mutex::new(None);
pub struct CaptureSession;
impl CaptureSession {
    pub fn start(report: CaptureReporter) -> Result<Self, String> {
        let mut owner = OWNER.lock().unwrap();
        if *owner {
            return Err("Another key capture session is active".into());
        }
        if let Err(error) = start_native(report) {
            if let Some(handle) = THREAD.lock().unwrap().take() {
                let _ = handle.join();
            }
            return Err(error);
        }
        *owner = true;
        Ok(Self)
    }
}
impl Drop for CaptureSession {
    fn drop(&mut self) {
        let mut owner = OWNER.lock().unwrap();
        stop_native();
        if let Some(handle) = THREAD.lock().unwrap().take() {
            if handle.join().is_err() {
                log::error!("Key capture thread panicked");
            }
        }
        *owner = false;
    }
}

#[cfg(target_os = "macos")]
mod imp {
    use super::CaptureReporter;
    use std::ffi::c_void;
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

    // ── CoreGraphics / CoreFoundation 裸 FFI(与 gamepad_system.rs 同款,不引新依赖) ──
    type CGEventRef = *mut c_void;
    type CFMachPortRef = *mut c_void;
    type CFRunLoopSourceRef = *mut c_void;
    type CFRunLoopRef = *mut c_void;

    const KCG_HID_EVENT_TAP: u32 = 0; // kCGHIDEventTap:最上游,系统热键处理之前
    const KCG_HEAD_INSERT_EVENT_TAP: u32 = 0;
    const KCG_EVENT_TAP_OPTION_DEFAULT: u32 = 0; // 可吞事件(listen-only 是 1)
    const KCG_EVENT_KEY_DOWN: u32 = 10;
    const KCG_EVENT_FLAGS_CHANGED: u32 = 12;
    const KCG_EVENT_TAP_DISABLED_BY_TIMEOUT: u32 = 0xFFFF_FFFE;
    const KCG_EVENT_TAP_DISABLED_BY_USER_INPUT: u32 = 0xFFFF_FFFF;
    const KCG_KEYBOARD_EVENT_KEYCODE: u32 = 9; // kCGKeyboardEventKeycode

    // CGEventFlags 的左右分明设备位(IOKit NX_DEVICE*KEYMASK)
    const DEV_LCTL: u64 = 0x0000_0001;
    const DEV_LSHIFT: u64 = 0x0000_0002;
    const DEV_RSHIFT: u64 = 0x0000_0004;
    const DEV_LCMD: u64 = 0x0000_0008;
    const DEV_RCMD: u64 = 0x0000_0010;
    const DEV_LALT: u64 = 0x0000_0020;
    const DEV_RALT: u64 = 0x0000_0040;
    const DEV_RCTL: u64 = 0x0000_2000;
    // 通用修饰位(设备位缺失时兜别名到左键)
    const MASK_SHIFT: u64 = 1 << 17;
    const MASK_CTRL: u64 = 1 << 18;
    const MASK_ALT: u64 = 1 << 19;
    const MASK_CMD: u64 = 1 << 20;
    const MASK_FN: u64 = 1 << 23; // kCGEventFlagMaskSecondaryFn(Fn 无左右之分)

    #[link(name = "CoreGraphics", kind = "framework")]
    unsafe extern "C" {
        fn CGEventTapCreate(
            tap: u32, place: u32, options: u32, events_of_interest: u64,
            callback: extern "C" fn(*const c_void, u32, CGEventRef, *mut c_void) -> CGEventRef, user_info: *mut c_void,
        ) -> CFMachPortRef;
        fn CGEventTapEnable(tap: CFMachPortRef, enable: bool);
        fn CGEventGetIntegerValueField(event: CGEventRef, field: u32) -> i64;
        fn CGEventGetFlags(event: CGEventRef) -> u64;
    }
    #[link(name = "CoreFoundation", kind = "framework")]
    unsafe extern "C" {
        fn CFMachPortCreateRunLoopSource(
            allocator: *const c_void, port: CFMachPortRef, order: i64,
        ) -> CFRunLoopSourceRef;
        fn CFRunLoopGetCurrent() -> CFRunLoopRef;
        fn CFRunLoopAddSource(rl: CFRunLoopRef, source: CFRunLoopSourceRef, mode: *const c_void);
        fn CFRunLoopRunInMode(mode: *const c_void, seconds: f64, return_after_source: bool) -> i32;
        fn CFRelease(cf: *const c_void);
        static kCFRunLoopDefaultMode: *const c_void;
        static kCFRunLoopCommonModes: *const c_void;
    }

    /// 捕获会话单例:runloop / machport 裸指针存 usize(仅捕获线程解引用,Stop 跨线程安全)。
    static ACTIVE: AtomicBool = AtomicBool::new(false);
    static TAP_PORT: AtomicUsize = AtomicUsize::new(0);

    /// macOS 虚拟键码(kVK_*)→ W3C KeyboardEvent.code 名,与前端 keymap.ts 同一词表。
    fn vk_to_code(vk: i64) -> Option<&'static str> {
        Some(match vk {
            0 => "KeyA",
            1 => "KeyS",
            2 => "KeyD",
            3 => "KeyF",
            4 => "KeyH",
            5 => "KeyG",
            6 => "KeyZ",
            7 => "KeyX",
            8 => "KeyC",
            9 => "KeyV",
            11 => "KeyB",
            12 => "KeyQ",
            13 => "KeyW",
            14 => "KeyE",
            15 => "KeyR",
            16 => "KeyY",
            17 => "KeyT",
            18 => "Digit1",
            19 => "Digit2",
            20 => "Digit3",
            21 => "Digit4",
            22 => "Digit6",
            23 => "Digit5",
            24 => "Equal",
            25 => "Digit9",
            26 => "Digit7",
            27 => "Minus",
            28 => "Digit8",
            29 => "Digit0",
            30 => "BracketRight",
            31 => "KeyO",
            32 => "KeyU",
            33 => "BracketLeft",
            34 => "KeyI",
            35 => "KeyP",
            36 => "Enter",
            37 => "KeyL",
            38 => "KeyJ",
            39 => "Quote",
            40 => "KeyK",
            41 => "Semicolon",
            42 => "Backslash",
            43 => "Comma",
            44 => "Slash",
            45 => "KeyN",
            46 => "KeyM",
            47 => "Period",
            48 => "Tab",
            49 => "Space",
            50 => "Backquote",
            51 => "Backspace",
            53 => "Escape",
            65 => "NumpadDecimal",
            67 => "NumpadMultiply",
            69 => "NumpadAdd",
            75 => "NumpadDivide",
            76 => "NumpadEnter",
            78 => "NumpadSubtract",
            82 => "Numpad0",
            83 => "Numpad1",
            84 => "Numpad2",
            85 => "Numpad3",
            86 => "Numpad4",
            87 => "Numpad5",
            88 => "Numpad6",
            89 => "Numpad7",
            91 => "Numpad8",
            92 => "Numpad9",
            96 => "F5",
            97 => "F6",
            98 => "F7",
            99 => "F3",
            100 => "F8",
            101 => "F9",
            103 => "F11",
            109 => "F10",
            111 => "F12",
            118 => "F4",
            120 => "F2",
            122 => "F1",
            115 => "Home",
            116 => "PageUp",
            117 => "Delete",
            119 => "End",
            121 => "PageDown",
            123 => "ArrowLeft",
            124 => "ArrowRight",
            125 => "ArrowDown",
            126 => "ArrowUp",
            _ => return None,
        })
    }

    /// 按住的修饰键 code 名,顺序:Fn, Meta, Control, Alt, Shift(Fn 之后与前端 fillFromEvent 一致;
    /// Fn 只有 tap 能感知,DOM KeyboardEvent 无 fn 标志)。
    fn held_modifiers(flags: u64) -> Vec<&'static str> {
        let mut out = Vec::new();
        if flags & MASK_FN != 0 {
            out.push("Fn");
        }
        if flags & MASK_CMD != 0 {
            out.push(if flags & DEV_RCMD != 0 && flags & DEV_LCMD == 0 { "MetaRight" } else { "MetaLeft" });
        }
        if flags & MASK_CTRL != 0 {
            out.push(if flags & DEV_RCTL != 0 && flags & DEV_LCTL == 0 { "ControlRight" } else { "ControlLeft" });
        }
        if flags & MASK_ALT != 0 {
            out.push(if flags & DEV_RALT != 0 && flags & DEV_LALT == 0 { "AltRight" } else { "AltLeft" });
        }
        if flags & MASK_SHIFT != 0 {
            out.push(if flags & DEV_RSHIFT != 0 && flags & DEV_LSHIFT == 0 { "ShiftRight" } else { "ShiftLeft" });
        }
        out
    }

    /// 这些键按下时 macOS 自动置 SecondaryFn 标志(内置键盘的方向/翻页/前删/F 区),不代表按住 fn。
    fn auto_fn_key(code: &str) -> bool {
        matches!(
            code,
            "ArrowUp"
                | "ArrowDown"
                | "ArrowLeft"
                | "ArrowRight"
                | "Home"
                | "End"
                | "PageUp"
                | "PageDown"
                | "Delete"
                | "F1"
                | "F2"
                | "F3"
                | "F4"
                | "F5"
                | "F6"
                | "F7"
                | "F8"
                | "F9"
                | "F10"
                | "F11"
                | "F12"
        )
    }

    fn emit(app: &CaptureReporter, codes: String, pending: bool) {
        app(super::CaptureEvent { codes, pending });
    }

    extern "C" fn tap_callback(
        _proxy: *const c_void, ev_type: u32, event: CGEventRef, user_info: *mut c_void,
    ) -> CGEventRef {
        // 超时/用户输入过密导致 tap 被系统禁用 → 重新启用,事件放行
        if ev_type == KCG_EVENT_TAP_DISABLED_BY_TIMEOUT || ev_type == KCG_EVENT_TAP_DISABLED_BY_USER_INPUT {
            let port = TAP_PORT.load(Ordering::SeqCst);
            if port != 0 {
                unsafe { CGEventTapEnable(port as CFMachPortRef, true) };
            }
            return event;
        }
        let app = unsafe { &*(user_info as *const CaptureReporter) };
        let flags = unsafe { CGEventGetFlags(event) };
        match ev_type {
            KCG_EVENT_FLAGS_CHANGED => {
                // 修饰键按住的实时预览;透传不吞(吞 flagsChanged 会让系统修饰键状态失同步)
                emit(app, held_modifiers(flags).join(","), true);
                event
            }
            KCG_EVENT_KEY_DOWN => {
                let vk = unsafe { CGEventGetIntegerValueField(event, KCG_KEYBOARD_EVENT_KEYCODE) };
                let Some(code) = vk_to_code(vk) else {
                    return event;
                };
                let mut parts = held_modifiers(flags);
                // 方向键/翻页/F 区等按下时 macOS 会自动带 SecondaryFn 标志(并非用户按住 fn),
                // 拼组合时剔除,免得录出 Fn,ArrowUp 这种假组合;flagsChanged(纯修饰预览)不受影响。
                if auto_fn_key(code) {
                    parts.retain(|m| *m != "Fn");
                }
                parts.push(code);
                emit(app, parts.join(","), false);
                std::ptr::null_mut() // 吞掉:录制期间系统保留组合(Ctrl+← 等)不真的触发
            }
            _ => event,
        }
    }

    pub fn start(app: CaptureReporter) -> Result<(), String> {
        if ACTIVE.swap(true, Ordering::SeqCst) {
            return Ok(());
        }
        let (ready_tx, ready_rx) = std::sync::mpsc::sync_channel(1);
        let handle = std::thread::Builder::new()
            .name("gamepad-key-capture".into())
            .spawn(move || {
                let user_info = Box::into_raw(Box::new(app)) as *mut c_void;
                let mask = (1u64 << KCG_EVENT_KEY_DOWN) | (1u64 << KCG_EVENT_FLAGS_CHANGED);
                let port = unsafe {
                    CGEventTapCreate(
                        KCG_HID_EVENT_TAP,
                        KCG_HEAD_INSERT_EVENT_TAP,
                        KCG_EVENT_TAP_OPTION_DEFAULT,
                        mask,
                        tap_callback,
                        user_info,
                    )
                };
                if port.is_null() {
                    // 无辅助功能授权时 create 返回 null;前端已有 accessibility 引导流程,DOM 捕获兜底
                    log::warn!("[gamepad-capture] CGEventTapCreate 失败(多为未授权辅助功能)");
                    drop(unsafe { Box::from_raw(user_info as *mut CaptureReporter) });
                    ACTIVE.store(false, Ordering::SeqCst);
                    let _ = ready_tx.send(Err("Cannot initialize global key capture".to_string()));
                    return;
                }
                TAP_PORT.store(port as usize, Ordering::SeqCst);
                unsafe {
                    let source = CFMachPortCreateRunLoopSource(std::ptr::null(), port, 0);
                    if source.is_null() {
                        TAP_PORT.store(0, Ordering::SeqCst);
                        CFRelease(port as *const c_void);
                        drop(Box::from_raw(user_info as *mut CaptureReporter));
                        ACTIVE.store(false, Ordering::SeqCst);
                        let _ = ready_tx.send(Err("Cannot create key capture run loop source".into()));
                        return;
                    }
                    let rl = CFRunLoopGetCurrent();
                    CFRunLoopAddSource(rl, source, kCFRunLoopCommonModes);
                    CGEventTapEnable(port, true);
                    // 可见日志:录制时系统组合(截屏等)是否真被吞,先看这行有没有出现
                    log::info!("[gamepad-capture] CGEventTap active(键按下将被吞掉,系统组合不触发)");
                    let _ = ready_tx.send(Ok(()));
                    while ACTIVE.load(Ordering::SeqCst) {
                        CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.05, true);
                    } // Bounded polling keeps shutdown independent of a cross-thread CF pointer.
                    CGEventTapEnable(port, false);
                    CFRelease(source as *const c_void);
                    CFRelease(port as *const c_void);
                }
                drop(unsafe { Box::from_raw(user_info as *mut CaptureReporter) });
                TAP_PORT.store(0, Ordering::SeqCst);
                ACTIVE.store(false, Ordering::SeqCst);
            })
            .map_err(|e| {
                ACTIVE.store(false, Ordering::SeqCst);
                e.to_string()
            })?;
        *super::THREAD.lock().unwrap() = Some(handle);
        let result = ready_rx.recv().map_err(|e| e.to_string())?;
        if result.is_err() {
            stop();
        }
        result
    }

    pub fn stop() {
        ACTIVE.store(false, Ordering::SeqCst);
    }
}

/// Windows:WH_KEYBOARD_LL 低级键盘钩子,角色同 mac 的 CGEventTap。
/// 录制期间**全键吞掉**(修饰键也吞):不吞的话松开 Win 会弹开始菜单、Win+D 等系统组合会真触发;
/// 录制是模态场景(捕获框聚焦),吞掉无副作用,停止录制即恢复。LL 钩子给的是逐键事件不带
/// 修饰状态,自己维护按住位。引擎自己合成的键带 LLKHF_INJECTED,放行不吞(免得截断触发链)。
/// Win+L 等少数系统受保护组合在钩子之前处理,吞不到(平台限制)。
#[cfg(target_os = "windows")]
mod imp {
    use super::CaptureReporter;
    use std::sync::Mutex;
    use std::sync::atomic::{AtomicBool, AtomicU32, AtomicUsize, Ordering};
    use windows_sys::Win32::Foundation::{LPARAM, LRESULT, WPARAM};
    use windows_sys::Win32::System::Threading::GetCurrentThreadId;
    use windows_sys::Win32::UI::WindowsAndMessaging::{
        CallNextHookEx, GetMessageW, KBDLLHOOKSTRUCT, LLKHF_INJECTED, MSG, PostThreadMessageW, SetWindowsHookExW,
        UnhookWindowsHookEx, WH_KEYBOARD_LL, WM_KEYDOWN, WM_QUIT, WM_SYSKEYDOWN,
    };

    static ACTIVE: AtomicBool = AtomicBool::new(false);
    static HOOK: AtomicUsize = AtomicUsize::new(0); // HHOOK(仅钩子线程解引用)
    static THREAD_ID: AtomicU32 = AtomicU32::new(0);
    /// 修饰键按住位(LL 钩子无 flags,按 down/up 自己记账;stop 时清零)。
    static MODS: AtomicU32 = AtomicU32::new(0);
    static APP: Mutex<Option<CaptureReporter>> = Mutex::new(None);

    const B_LWIN: u32 = 1 << 0;
    const B_RWIN: u32 = 1 << 1;
    const B_LCTRL: u32 = 1 << 2;
    const B_RCTRL: u32 = 1 << 3;
    const B_LALT: u32 = 1 << 4;
    const B_RALT: u32 = 1 << 5;
    const B_LSHIFT: u32 = 1 << 6;
    const B_RSHIFT: u32 = 1 << 7;

    /// 修饰键 VK → 按住位。LL 钩子上报的是左右分明的 VK(VK_LWIN/VK_RCONTROL 等)。
    fn mod_bit(vk: u32) -> Option<u32> {
        use windows_sys::Win32::UI::Input::KeyboardAndMouse::{
            VK_LCONTROL, VK_LMENU, VK_LSHIFT, VK_LWIN, VK_RCONTROL, VK_RMENU, VK_RSHIFT, VK_RWIN,
        };
        Some(match vk as u16 {
            v if v == VK_LWIN => B_LWIN,
            v if v == VK_RWIN => B_RWIN,
            v if v == VK_LCONTROL => B_LCTRL,
            v if v == VK_RCONTROL => B_RCTRL,
            v if v == VK_LMENU => B_LALT,
            v if v == VK_RMENU => B_RALT,
            v if v == VK_LSHIFT => B_LSHIFT,
            v if v == VK_RSHIFT => B_RSHIFT,
            _ => return None,
        })
    }

    /// 按住的修饰键 code 名,顺序与 mac 版/前端一致:Meta(Win), Control, Alt, Shift;
    /// 左右分明,仅右侧按住时才标 Right(与 mac held_modifiers 同规则)。
    fn held_modifiers(mods: u32) -> Vec<&'static str> {
        let mut out = Vec::new();
        if mods & (B_LWIN | B_RWIN) != 0 {
            out.push(if mods & B_RWIN != 0 && mods & B_LWIN == 0 { "MetaRight" } else { "MetaLeft" });
        }
        if mods & (B_LCTRL | B_RCTRL) != 0 {
            out.push(if mods & B_RCTRL != 0 && mods & B_LCTRL == 0 { "ControlRight" } else { "ControlLeft" });
        }
        if mods & (B_LALT | B_RALT) != 0 {
            out.push(if mods & B_RALT != 0 && mods & B_LALT == 0 { "AltRight" } else { "AltLeft" });
        }
        if mods & (B_LSHIFT | B_RSHIFT) != 0 {
            out.push(if mods & B_RSHIFT != 0 && mods & B_LSHIFT == 0 { "ShiftRight" } else { "ShiftLeft" });
        }
        out
    }

    /// Windows 虚拟键码(VK_*)→ W3C KeyboardEvent.code 名,与前端 keymap.ts 同一词表。
    fn vk_to_code(vk: u32) -> Option<&'static str> {
        Some(match vk {
            0x41 => "KeyA",
            0x42 => "KeyB",
            0x43 => "KeyC",
            0x44 => "KeyD",
            0x45 => "KeyE",
            0x46 => "KeyF",
            0x47 => "KeyG",
            0x48 => "KeyH",
            0x49 => "KeyI",
            0x4A => "KeyJ",
            0x4B => "KeyK",
            0x4C => "KeyL",
            0x4D => "KeyM",
            0x4E => "KeyN",
            0x4F => "KeyO",
            0x50 => "KeyP",
            0x51 => "KeyQ",
            0x52 => "KeyR",
            0x53 => "KeyS",
            0x54 => "KeyT",
            0x55 => "KeyU",
            0x56 => "KeyV",
            0x57 => "KeyW",
            0x58 => "KeyX",
            0x59 => "KeyY",
            0x5A => "KeyZ",
            0x30 => "Digit0",
            0x31 => "Digit1",
            0x32 => "Digit2",
            0x33 => "Digit3",
            0x34 => "Digit4",
            0x35 => "Digit5",
            0x36 => "Digit6",
            0x37 => "Digit7",
            0x38 => "Digit8",
            0x39 => "Digit9",
            0x60 => "Numpad0",
            0x61 => "Numpad1",
            0x62 => "Numpad2",
            0x63 => "Numpad3",
            0x64 => "Numpad4",
            0x65 => "Numpad5",
            0x66 => "Numpad6",
            0x67 => "Numpad7",
            0x68 => "Numpad8",
            0x69 => "Numpad9",
            0x6A => "NumpadMultiply",
            0x6B => "NumpadAdd",
            0x6D => "NumpadSubtract",
            0x6E => "NumpadDecimal",
            0x6F => "NumpadDivide",
            0x70 => "F1",
            0x71 => "F2",
            0x72 => "F3",
            0x73 => "F4",
            0x74 => "F5",
            0x75 => "F6",
            0x76 => "F7",
            0x77 => "F8",
            0x78 => "F9",
            0x79 => "F10",
            0x7A => "F11",
            0x7B => "F12",
            0x25 => "ArrowLeft",
            0x26 => "ArrowUp",
            0x27 => "ArrowRight",
            0x28 => "ArrowDown",
            0x0D => "Enter",
            0x1B => "Escape",
            0x08 => "Backspace",
            0x09 => "Tab",
            0x20 => "Space",
            0x14 => "CapsLock",
            0x2D => "Insert",
            0x2E => "Delete",
            0x24 => "Home",
            0x23 => "End",
            0x21 => "PageUp",
            0x22 => "PageDown",
            0x2C => "PrintScreen",
            0x91 => "ScrollLock",
            0xBA => "Semicolon",
            0xBB => "Equal",
            0xBC => "Comma",
            0xBD => "Minus",
            0xBE => "Period",
            0xBF => "Slash",
            0xC0 => "Backquote",
            0xDB => "BracketLeft",
            0xDC => "Backslash",
            0xDD => "BracketRight",
            0xDE => "Quote",
            _ => return None,
        })
    }

    fn emit(codes: String, pending: bool) {
        if let Some(app) = APP.lock().unwrap().as_ref() {
            app(super::CaptureEvent { codes, pending });
        }
    }

    unsafe extern "system" fn hook_proc(code: i32, wparam: WPARAM, lparam: LPARAM) -> LRESULT {
        if code < 0 {
            return unsafe { CallNextHookEx(std::ptr::null_mut(), code, wparam, lparam) };
        }
        let kb = unsafe { &*(lparam as *const KBDLLHOOKSTRUCT) };
        // 引擎合成的键(enigo 注入)放行:录制期间手柄仍可能在触发映射,吞了会截断触发链
        if kb.flags & LLKHF_INJECTED != 0 {
            return unsafe { CallNextHookEx(std::ptr::null_mut(), code, wparam, lparam) };
        }
        let down = matches!(wparam as u32, WM_KEYDOWN | WM_SYSKEYDOWN);
        if let Some(bit) = mod_bit(kb.vkCode) {
            let prev = if down { MODS.fetch_or(bit, Ordering::SeqCst) } else { MODS.fetch_and(!bit, Ordering::SeqCst) };
            let now = if down { prev | bit } else { prev & !bit };
            if down {
                emit(held_modifiers(now).join(","), true);
            }
            return 1; // 修饰键也吞:防松开 Win 弹开始菜单
        }
        if down {
            if let Some(key) = vk_to_code(kb.vkCode) {
                let mut parts = held_modifiers(MODS.load(Ordering::SeqCst));
                parts.push(key);
                emit(parts.join(","), false);
            }
        }
        1 // 非修饰键 down/up 一律吞:录制期间系统组合(Win+D 等)不真的触发
    }

    pub fn start(app: CaptureReporter) -> Result<(), String> {
        if ACTIVE.swap(true, Ordering::SeqCst) {
            return Ok(());
        }
        *APP.lock().unwrap() = Some(app);
        MODS.store(0, Ordering::SeqCst);
        let (ready_tx, ready_rx) = std::sync::mpsc::sync_channel(1);
        let handle = std::thread::Builder::new()
            .name("gamepad-key-capture".into())
            .spawn(move || {
                let hook = unsafe { SetWindowsHookExW(WH_KEYBOARD_LL, Some(hook_proc), std::ptr::null_mut(), 0) };
                if hook.is_null() {
                    log::warn!("[gamepad-capture] SetWindowsHookExW 失败,DOM 捕获兜底");
                    ACTIVE.store(false, Ordering::SeqCst);
                    let _ = ready_tx.send(Err("Cannot initialize global key capture".to_string()));
                    return;
                }
                HOOK.store(hook as usize, Ordering::SeqCst);
                THREAD_ID.store(unsafe { GetCurrentThreadId() }, Ordering::SeqCst);
                unsafe {
                    let mut message = std::mem::zeroed();
                    windows_sys::Win32::UI::WindowsAndMessaging::PeekMessageW(
                        &mut message,
                        std::ptr::null_mut(),
                        0,
                        0,
                        0,
                    );
                }
                let _ = ready_tx.send(Ok(()));
                // LL 钩子回调由本线程的消息泵驱动;GetMessageW 收到 WM_QUIT(stop 投递)返回 0 退出
                let mut msg: MSG = unsafe { std::mem::zeroed() };
                while unsafe { GetMessageW(&mut msg, std::ptr::null_mut(), 0, 0) } > 0 {}
                unsafe { UnhookWindowsHookEx(hook) };
                HOOK.store(0, Ordering::SeqCst);
                THREAD_ID.store(0, Ordering::SeqCst);
                MODS.store(0, Ordering::SeqCst);
                ACTIVE.store(false, Ordering::SeqCst);
            })
            .map_err(|e| {
                ACTIVE.store(false, Ordering::SeqCst);
                e.to_string()
            })?;
        *super::THREAD.lock().unwrap() = Some(handle);
        let result = ready_rx.recv().map_err(|e| e.to_string())?;
        if result.is_err() {
            stop();
        }
        result
    }

    pub fn stop() {
        ACTIVE.store(false, Ordering::SeqCst);
        let tid = THREAD_ID.load(Ordering::SeqCst);
        if tid != 0 {
            unsafe { PostThreadMessageW(tid, WM_QUIT, 0, 0) };
        }
    }
}

/// 开始捕获:mac 挂 CGEventTap、Windows 挂 WH_KEYBOARD_LL,按键经 `gamepad:capture-key`
/// 事件上报(pending=修饰键预览)。幂等;建不起来(mac 未授权辅助功能等)时前端 DOM keydown
/// 兜底(系统保留组合录不到而已)。
fn start_native(app: CaptureReporter) -> Result<(), String> {
    #[cfg(any(target_os = "macos", target_os = "windows"))]
    return imp::start(app);
    #[cfg(not(any(target_os = "macos", target_os = "windows")))]
    {
        let _ = app;
        Ok(())
    }
}

/// 结束捕获,拆钩子。幂等。
fn stop_native() {
    #[cfg(any(target_os = "macos", target_os = "windows"))]
    imp::stop();
}

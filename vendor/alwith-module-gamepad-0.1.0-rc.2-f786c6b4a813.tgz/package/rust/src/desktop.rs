//! Native desktop catalogs shared by hosts without a Tauri dependency.
pub use alwith_installed_apps as applications;
use cpal::traits::{DeviceTrait, HostTrait};
use serde::Serialize;

#[derive(Debug, Serialize)]
pub struct Microphone {
    pub name: String,
    pub default: bool,
}

/// Enumerate audio inputs without opening a recording stream.
pub fn microphones() -> Result<Vec<Microphone>, String> {
    let host = cpal::default_host();
    let default_name = host
        .default_input_device()
        .map(|device| device.description().map(|description| description.name().to_string()))
        .transpose()
        .map_err(|error| error.to_string())?;
    host.input_devices()
        .map_err(|error| error.to_string())?
        .map(|device| {
            let description = device.description().map_err(|error| error.to_string())?;
            let name = description.name().to_string();
            let default = default_name.as_deref() == Some(name.as_str());
            Ok(Microphone { name, default })
        })
        .collect()
}

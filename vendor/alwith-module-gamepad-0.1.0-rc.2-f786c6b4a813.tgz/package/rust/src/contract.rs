use crate::{
    config::Config,
    engine::{DeviceSnapshot, EngineEvent},
    profiles::{GripColor, Profile},
};
use serde::{Deserialize, Serialize};
use specta::Type;
#[derive(Debug, Clone, Serialize, Type)]
#[serde(rename_all = "camelCase")]
pub struct Snapshot {
    pub version: u32,
    pub generation: u32,
    pub sequence: u32,
    pub state: EngineState,
    pub devices: Vec<DeviceSnapshot>,
    pub active_device: Option<u32>,
    pub active_profile: Option<String>,
    pub saved_revision: Option<u32>,
    pub applied_revision: Option<u32>,
    pub error: Option<String>,
}
#[derive(Debug, Clone, Serialize, Type, PartialEq)]
#[serde(rename_all = "camelCase")]
pub enum EngineState {
    Stopped,
    Starting,
    Running,
    Stopping,
    Failed,
}
#[derive(Debug, Clone, Serialize, Type)]
#[serde(tag = "type", rename_all = "camelCase")]
pub enum ServiceEvent {
    Snapshot { snapshot: Snapshot },
    Input { event: EngineEvent },
}
#[derive(Deserialize, Type)]
#[serde(tag = "type", rename_all = "camelCase", rename_all_fields = "camelCase")]
pub enum Request {
    Snapshot,
    Start,
    Stop,
    LoadProfile { id: String },
    SaveProfile { id: String, expected_revision: u32, config: Box<Config>, color: Option<GripColor> },
    ActivateProfile { id: String },
    SelectDevice { id: Option<u32> },
    Rumble { id: u32 },
    VirtualAttach { model: String },
    VirtualDetach,
    VirtualButton { button: String, pressed: bool },
    VirtualAxis { axis: String, value: i16 },
    Suspend { token: String },
    Resume { token: String },
}
#[derive(Serialize, Type)]
#[serde(tag = "type", rename_all = "camelCase")]
pub enum Response {
    Snapshot { snapshot: Snapshot },
    Profile { profile: Option<Profile> },
    Saved { profile: Profile, snapshot: Snapshot },
    Ok,
}

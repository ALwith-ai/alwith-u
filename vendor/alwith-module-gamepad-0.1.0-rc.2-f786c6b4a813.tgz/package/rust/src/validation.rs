use crate::action::{Event, Mapping};
use crate::config::Config;

impl Config {
    pub fn validate(&self) -> Result<(), String> {
        if !self.deadzone.is_finite() || !(0.0..1.0).contains(&self.deadzone) {
            return Err("deadzone must be finite and in [0, 1)".into());
        }
        if !(1..=1000).contains(&self.poll_interval_ms) {
            return Err("poll_interval_ms must be in [1, 1000]".into());
        }
        if !self.mouse_move_scale.is_finite() || self.mouse_move_scale <= 0.0 {
            return Err("mouse_move_scale must be finite and positive".into());
        }
        for mapping in self.buttons.values().chain(self.left_stick.values()).chain(self.right_stick.values()) {
            validate_mapping(mapping)?;
        }
        for layer in &self.overrides {
            for mapping in layer.buttons.values().chain(layer.left_stick.values()).chain(layer.right_stick.values()) {
                validate_mapping(mapping)?;
            }
        }
        Ok(())
    }
}

fn validate_mapping(mapping: &Mapping) -> Result<(), String> {
    if mapping.to_layer.as_ref().is_some_and(|name| name.trim().is_empty()) {
        return Err("Layer name must not be empty".into());
    }
    for event in
        mapping.to.iter().chain(&mapping.to_if_alone).chain(&mapping.to_if_held_down).chain(&mapping.to_after_key_up)
    {
        validate_event(event)?;
    }
    Ok(())
}

fn validate_event(event: &Event) -> Result<(), String> {
    let count = [
        event.key_code.is_some(),
        event.consumer_key_code.is_some(),
        event.pointing_button.is_some(),
        event.mouse_key.is_some(),
        event.shell_command.is_some(),
        event.open.is_some(),
    ]
    .into_iter()
    .filter(|present| *present)
    .count();
    if count != 1 {
        return Err("An event must contain exactly one action".into());
    }
    if (event.repeat || !event.modifiers.is_empty()) && event.key_code.is_none() {
        return Err("repeat and modifiers require key_code".into());
    }
    for key in event.key_code.iter().chain(event.consumer_key_code.iter()).chain(event.modifiers.iter()) {
        if !crate::output::is_supported_key(key) {
            return Err(format!("Unsupported key: {key}"));
        }
    }
    if event.pointing_button.as_ref().is_some_and(|key| !matches!(key.as_str(), "button1" | "button2" | "button3")) {
        return Err("Unsupported pointing_button".into());
    }
    if event.open.as_ref().is_some_and(|value| value.trim().is_empty())
        || event.shell_command.as_ref().is_some_and(|value| value.trim().is_empty())
    {
        return Err("Action target must not be empty".into());
    }
    Ok(())
}

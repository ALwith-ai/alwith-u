//! 动作模型 —— 一比一对齐 Karabiner manipulator 的 handler + event 结构(名字照搬,不自造)。
//!
//! 每个手柄控件 = 一个 [`Mapping`],含 4 个 handler(触发时机);每个 handler 是**一串** [`Event`](按序发)。
//! [`Event`] 用「字段存在即该类型」的写法,和 Karabiner 的 `to` JSON 完全一致。
//! 采用的 event 类型(5,原名):`key_code` / `consumer_key_code` / `pointing_button` / `mouse_key` / `shell_command`。
//! 不搬 Karabiner 的内部管线(set_variable / software_function 等)——独立注入器无对应,搬了就是发明。
//! 唯一 Karabiner 之外的扩展是 `open`(打开路径/URL):Karabiner 仅 macOS、启动 app 用 `shell_command: open -a`,
//! 但那是 mac 命令,Windows 无 `sh`/`open`,跨平台启动 app 只能走 `open` crate,见 `Event::open`。

use serde::{Deserialize, Serialize};

fn is_false(b: &bool) -> bool {
    !*b
}
fn is_zero(n: &i32) -> bool {
    *n == 0
}

/// 一个控件的映射:handler 决定何时发。空 handler 省略序列化。
#[derive(Debug, Clone, PartialEq, Default, Serialize, Deserialize, specta::Type)]
pub struct Mapping {
    /// 按下即发(key_code 走「按下→按下、抬起→抬起」的按住语义)。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub to: Vec<Event>,
    /// 单独轻点才发(tap)。需计时判定,见 mapper。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub to_if_alone: Vec<Event>,
    /// 长按超过阈值才发(hold)。需计时判定,见 mapper。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub to_if_held_down: Vec<Event>,
    /// 松开后发(一次性)。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub to_after_key_up: Vec<Event>,
    /// 按住期间激活名为该值的**图层**:此控件成为「层修饰键」,本身不发键;按住时
    /// `when.layer` 含该名的条件覆盖(`config.overrides`)即生效。让手柄按键成倍扩展。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub to_layer: Option<String>,
}

impl Mapping {
    pub fn is_empty(&self) -> bool {
        self.to.is_empty()
            && self.to_if_alone.is_empty()
            && self.to_if_held_down.is_empty()
            && self.to_after_key_up.is_empty()
            && self.to_layer.is_none()
    }
}

/// Karabiner `to` 里的一个 event。字段存在即该类型(和 Karabiner JSON 一致)。
#[derive(Debug, Clone, PartialEq, Default, Serialize, Deserialize, specta::Type)]
pub struct Event {
    /// 键盘键(值用 W3C KeyboardEvent.code,如 `Enter` / `MetaLeft`)。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub key_code: Option<String>,
    /// 与 `key_code` 同按的修饰键(code 名)。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub modifiers: Vec<String>,
    /// 按住期间连发该 key_code。
    #[serde(default, skip_serializing_if = "is_false")]
    pub repeat: bool,
    /// 媒体/消费键(音量、播放…)。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub consumer_key_code: Option<String>,
    /// 鼠标键:`button1`(左)/`button2`(右)/`button3`(中)。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pointing_button: Option<String>,
    /// 鼠标移动/滚轮。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub mouse_key: Option<MouseKey>,
    /// 执行 shell 命令。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub shell_command: Option<String>,
    /// 用系统默认方式打开一个路径 / URL(跨平台启动 app:mac `.app` 路径、Windows exe 路径、URL)。
    /// **Karabiner 之外的扩展**:Karabiner 只在 macOS、启动 app 用 `shell_command: open -a`;
    /// 但 `open -a` 是 mac 命令、Windows 无 `sh` 也无 `open`,跨平台启动只能走 `open` crate
    /// (`open::that`,mac→`open`、Windows→ShellExecute)。命令 tab「按键启动 app」产出这个。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub open: Option<String>,
}

/// Karabiner `mouse_key`:按住期间每 tick 的相对位移 / 滚轮量(字段名照搬 Karabiner)。
#[derive(Debug, Clone, PartialEq, Default, Serialize, Deserialize, specta::Type)]
pub struct MouseKey {
    #[serde(default, skip_serializing_if = "is_zero")]
    pub x: i32,
    #[serde(default, skip_serializing_if = "is_zero")]
    pub y: i32,
    #[serde(default, skip_serializing_if = "is_zero")]
    pub vertical_wheel: i32,
    #[serde(default, skip_serializing_if = "is_zero")]
    pub horizontal_wheel: i32,
}

/// 鼠标键三态。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum MouseBtn {
    Left,
    Middle,
    Right,
}

impl MouseBtn {
    /// Karabiner `pointing_button` 名 → 三态。button1=左 / button2=右 / button3=中。
    pub fn parse(name: &str) -> Option<MouseBtn> {
        match name.trim() {
            "button1" => Some(MouseBtn::Left),
            "button2" => Some(MouseBtn::Right),
            "button3" => Some(MouseBtn::Middle),
            _ => None,
        }
    }
}

/// 映射引擎产出的底层输出意图。由执行层(enigo 键鼠 / shell)真正执行。
/// 把「决策」与「执行」分开,使映射引擎可纯逻辑单测。
#[derive(Debug, Clone, PartialEq)]
pub enum Output {
    /// 键:按住(Press)/ 松开(Release)/ 单击(Tap)。
    Press(String),
    Release(String),
    Tap(String),
    /// 组合键(同时按,内部有稳定修饰键的时序处理)。
    Combo(Vec<String>),
    /// 执行命令(argv;shell 命令走 ["sh","-c", cmd])。
    Exec(Vec<String>),
    /// 用系统默认方式打开路径 / URL(`open::that`,跨平台启动 app)。
    Open(String),
    /// 开始/停止连发某键(间隔毫秒)。
    RepeatStart(String, u64),
    RepeatStop(String),
    // ── 鼠标(pointing_button / mouse_key)──
    /// 鼠标键:按住 / 松开 / 单击。
    MouseDown(MouseBtn),
    MouseUp(MouseBtn),
    MouseClick(MouseBtn),
    /// 相对移动光标 / 滚轮(一次)。mouse_key 按住期间的持续移动由 mapper 每 tick 产出这两个。
    MouseMove {
        x: i32,
        y: i32,
    },
    Scroll {
        x: i32,
        y: i32,
    },
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parse(json: &str) -> Mapping {
        serde_json::from_str(json).unwrap()
    }

    #[test]
    fn parses_to_key_code() {
        let m = parse(r#"{ "to": [{ "key_code": "Enter" }] }"#);
        assert_eq!(m.to, vec![Event { key_code: Some("Enter".into()), ..Default::default() }]);
    }

    #[test]
    fn parses_tap_hold_dual() {
        let m = parse(
            r#"{ "to_if_alone": [{ "key_code": "Escape" }], "to_if_held_down": [{ "key_code": "ControlLeft" }] }"#,
        );
        assert_eq!(m.to_if_alone[0].key_code.as_deref(), Some("Escape"));
        assert_eq!(m.to_if_held_down[0].key_code.as_deref(), Some("ControlLeft"));
        assert!(m.to.is_empty());
    }

    #[test]
    fn parses_key_code_with_modifiers() {
        let m = parse(r#"{ "to": [{ "key_code": "Tab", "modifiers": ["MetaLeft"] }] }"#);
        assert_eq!(m.to[0].modifiers, vec!["MetaLeft".to_string()]);
    }

    #[test]
    fn parses_mouse_and_shell() {
        let m = parse(
            r#"{ "to": [{ "pointing_button": "button1" }, { "mouse_key": { "y": -1536 } }, { "shell_command": "open -a X" }] }"#,
        );
        assert_eq!(m.to[0].pointing_button.as_deref(), Some("button1"));
        assert_eq!(m.to[1].mouse_key, Some(MouseKey { y: -1536, ..Default::default() }));
        assert_eq!(m.to[2].shell_command.as_deref(), Some("open -a X"));
    }

    #[test]
    fn pointing_button_names_map_karabiner() {
        assert_eq!(MouseBtn::parse("button1"), Some(MouseBtn::Left));
        assert_eq!(MouseBtn::parse("button2"), Some(MouseBtn::Right));
        assert_eq!(MouseBtn::parse("button3"), Some(MouseBtn::Middle));
        assert_eq!(MouseBtn::parse("button9"), None);
    }

    #[test]
    fn roundtrip_omits_empty_fields() {
        let m = parse(r#"{ "to": [{ "key_code": "Enter" }] }"#);
        let json = serde_json::to_string(&m).unwrap();
        assert_eq!(json, r#"{"to":[{"key_code":"Enter"}]}"#);
    }
}

//! 手柄事件翻译 —— 把 SDL Gamepad 事件归一成统一 InputEvent。
//!
//! 用真·SDL3(而非 gilrs):SDL 自带 Switch/PS 等手柄的 HIDAPI 驱动,
//! 能正确初始化 Nintendo Switch Pro / Joy-Con 等非标准 HID 设备。
//! 左右摇杆各自 4 方向(带死区),扳机 → L2/R2(带阈值)。纯逻辑,可单测。

use sdl3::gamepad::{Axis, Button as SdlButton};

use crate::event::{Button, Control, Direction, InputEvent, StickSide};

/// 扳机按下判定阈值(SDL 扳机轴范围 0..32767)。
const TRIGGER_THRESHOLD: i16 = 16384;

/// SDL 标准布局按钮 → 我们的标准布局按钮。无对应则忽略。
/// SDL3 用位置语义命名(South/East/West/North),与我们的标准布局一一对应。
fn map_button(b: SdlButton) -> Option<Button> {
    Some(match b {
        SdlButton::South => Button::South,
        SdlButton::East => Button::East,
        SdlButton::West => Button::West,
        SdlButton::North => Button::North,
        SdlButton::LeftShoulder => Button::L1,
        SdlButton::RightShoulder => Button::R1,
        SdlButton::Back => Button::Select,
        SdlButton::Start => Button::Start,
        SdlButton::Guide => Button::Mode,
        SdlButton::Misc1 => Button::Capture, // Switch 截图键
        SdlButton::LeftStick => Button::L3,
        SdlButton::RightStick => Button::R3,
        SdlButton::DPadUp => Button::Up,
        SdlButton::DPadDown => Button::Down,
        SdlButton::DPadLeft => Button::Left,
        SdlButton::DPadRight => Button::Right,
        _ => return None,
    })
}

/// 单只**左** Joy-Con 横持时,SDL 把整块布局都转/挪了。这里给出它的**完整按钮映射**:
/// - 方向箭头 90° 逆时针:↑=West、↓=East、←=South、→=North
/// - 减号 = SDL Start → Select(左侧菜单键)
/// - L = SDL LeftPaddle1 → L1;ZL = SDL LeftPaddle2 → L2(SDL 把它俩当背键)
/// - 其余按钮(SL/SR/截图/摇杆按下等)回退到通用 [`map_button`]。仅对左 Joy-Con 调用。
pub fn joycon_left_button(b: SdlButton) -> Option<Button> {
    Some(match b {
        SdlButton::West => Button::Up,
        SdlButton::East => Button::Down,
        SdlButton::South => Button::Left,
        SdlButton::North => Button::Right,
        SdlButton::Start => Button::Select,
        SdlButton::LeftPaddle1 => Button::L1,
        SdlButton::LeftPaddle2 => Button::L2,
        _ => return map_button(b),
    })
}

/// 单只**左** Joy-Con 横持时,摇杆轴也转了 90°(和按键同一旋转):把 SDL 的 LeftX/LeftY
/// 互换并对 Y→X 取负,使推杆方向与玩家手持方向一致。扳机等其它轴原样透传。仅对左 Joy-Con 调用。
pub fn remap_joycon_left_axis(axis: Axis, value: i16) -> (Axis, i16) {
    match axis {
        Axis::LeftX => (Axis::LeftY, value),
        Axis::LeftY => (Axis::LeftX, value.saturating_neg()),
        other => (other, value),
    }
}

/// 单只**右** Joy-Con:我们用**竖向**合体图,所以把 SDL(对单只右 Joy-Con 已按横持旋转上报)
/// 的面键**反旋转**回竖向本来位置,让物理 A/B/X/Y = 图上 A/B/X/Y(east/south/north/west)。
/// 依据实测:旋转后 SDL 把物理 A 报成 West、B→North、X→South、Y→East(对应方向 下/左/右/上)。
/// - 面键反旋转:West=A→East、North=B→South、South=X→North、East=Y→West
/// - R=RightPaddle1→R1;ZR=RightPaddle2→R2;Plus(Start)→Start、Home(Guide)→Mode 走 map_button
/// - 摇杆轴在 [`remap_joycon_right_axis`] 里反旋转。仅对右 Joy-Con 调用。
pub fn joycon_right_button(b: SdlButton) -> Option<Button> {
    Some(match b {
        // 实测:上一版整体还差 90°(物理 X 显示成 Y),四个输出统一再转一格校正到竖向对位。
        SdlButton::East => Button::North, // 物理 X
        SdlButton::North => Button::West, // 物理 Y
        SdlButton::West => Button::South, // 物理 B
        SdlButton::South => Button::East, // 物理 A
        SdlButton::RightPaddle1 => Button::R1,
        SdlButton::RightPaddle2 => Button::R2,
        SdlButton::LeftStick => Button::R3, // 单杆按下:SDL 当主杆上报,竖向图里是右摇杆 → R3
        _ => return map_button(b),
    })
}

/// 右 Joy-Con 摇杆轴:SDL 把单只右 Joy-Con 的杆当主杆(LeftX/Y)上报,但竖向合体图里它是
/// **右**摇杆 → 输出到 RightX/RightY;并做 90° 反旋转校正到竖向(方向待实测微调正负号)。
pub fn remap_joycon_right_axis(axis: Axis, value: i16) -> (Axis, i16) {
    match axis {
        Axis::LeftX => (Axis::RightY, value.saturating_neg()),
        Axis::LeftY => (Axis::RightX, value),
        other => (other, value),
    }
}

/// 摇杆轴(与具体输入库解耦)。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StickAxis {
    X,
    Y,
}

/// 跟踪一个摇杆的位置,产出方向"进入/离开"变化(带死区)。
/// 约定:y 正方向为上(调用方负责把 SDL 的"下为正"翻转)。
/// 返回 `(方向, 是否按下)`:按下=进入该方向,松开=离开。
///
/// **两轴独立判定**(而非取较大轴的单一方向):X 轴独立产出 Left/Right,Y 轴独立产出 Up/Down。
/// 斜推(x、y 都过死区)时**同时**激活水平 + 垂直两个方向 —— 摇杆映射成方向键即 8 向斜走、
/// 映射成鼠标即斜向移动(配合 `mag()` 的模拟量按分量缩放速度)。
pub struct StickTracker {
    x: f32,
    y: f32,
    deadzone: f32,
    last_h: Option<Direction>, // 水平轴当前方向(Left/Right)
    last_v: Option<Direction>, // 垂直轴当前方向(Up/Down)
}

impl StickTracker {
    pub fn new(deadzone: f32) -> Self {
        StickTracker { x: 0.0, y: 0.0, deadzone, last_h: None, last_v: None }
    }

    fn horizontal(&self) -> Option<Direction> {
        if self.x.abs() < self.deadzone {
            None
        } else if self.x > 0.0 {
            Some(Direction::Right)
        } else {
            Some(Direction::Left)
        }
    }

    fn vertical(&self) -> Option<Direction> {
        if self.y.abs() < self.deadzone {
            None
        } else if self.y > 0.0 {
            Some(Direction::Up)
        } else {
            Some(Direction::Down)
        }
    }

    /// 该方向当前的模拟量幅度(0..1):水平方向取 |x|、垂直方向取 |y|。摇杆映射成鼠标移动时
    /// 按此缩放每 tick 位移(推得越满越快)。
    pub fn mag(&self, dir: Direction) -> f32 {
        match dir {
            Direction::Left | Direction::Right => self.x.abs().min(1.0),
            Direction::Up | Direction::Down => self.y.abs().min(1.0),
        }
    }

    /// 更新一个轴的值,返回该轴的方向变化 `(方向, 是否按下)`。另一轴不受影响(两轴独立)。
    pub fn update(&mut self, axis: StickAxis, value: f32) -> Vec<(Direction, bool)> {
        match axis {
            StickAxis::X => {
                self.x = value;
                let new = self.horizontal();
                Self::transition(&mut self.last_h, new)
            }
            StickAxis::Y => {
                self.y = value;
                let new = self.vertical();
                Self::transition(&mut self.last_v, new)
            }
        }
    }

    /// 单轴的方向迁移:先离开旧方向、再进入新方向。
    fn transition(last: &mut Option<Direction>, new: Option<Direction>) -> Vec<(Direction, bool)> {
        if new == *last {
            return vec![];
        }
        let mut out = vec![];
        if let Some(old) = *last {
            out.push((old, false));
        }
        if let Some(n) = new {
            out.push((n, true));
        }
        *last = new;
        out
    }
}

/// 把 SDL Gamepad 事件翻译成统一输入事件。左右摇杆独立跟踪。
pub struct Translator {
    left: StickTracker,
    right: StickTracker,
    l2_down: bool,
    r2_down: bool,
}

impl Translator {
    pub fn new(deadzone: f32) -> Self {
        Translator {
            left: StickTracker::new(deadzone),
            right: StickTracker::new(deadzone),
            l2_down: false,
            r2_down: false,
        }
    }

    pub fn on_button_down(&self, b: SdlButton) -> Vec<InputEvent> {
        // 校准日志(含手柄名)在 main 的事件循环里打,这里只做翻译。
        map_button(b).map(|x| vec![InputEvent::Pressed(Control::Button(x))]).unwrap_or_default()
    }

    pub fn on_button_up(&self, b: SdlButton) -> Vec<InputEvent> {
        map_button(b).map(|x| vec![InputEvent::Released(Control::Button(x))]).unwrap_or_default()
    }

    pub fn on_axis(&mut self, axis: Axis, value: i16) -> Vec<InputEvent> {
        match axis {
            Axis::LeftX => {
                let changes = self.left.update(StickAxis::X, value as f32 / 32767.0);
                Self::wrap(StickSide::Left, changes)
            }
            // SDL 约定向下为正;翻转使"上"为正,与 StickTracker 约定一致。
            Axis::LeftY => {
                let changes = self.left.update(StickAxis::Y, -(value as f32) / 32767.0);
                Self::wrap(StickSide::Left, changes)
            }
            Axis::RightX => {
                let changes = self.right.update(StickAxis::X, value as f32 / 32767.0);
                Self::wrap(StickSide::Right, changes)
            }
            Axis::RightY => {
                let changes = self.right.update(StickAxis::Y, -(value as f32) / 32767.0);
                Self::wrap(StickSide::Right, changes)
            }
            Axis::TriggerLeft => self.trigger(value, Button::L2, true),
            Axis::TriggerRight => self.trigger(value, Button::R2, false),
        }
    }

    /// 当前两摇杆各方向的模拟量幅度(供 mapper 缩放摇杆→鼠标的移动量)。每次轴变化后由引擎
    /// 读取推给 mapper;非当前激活方向的幅度对 mapper 无用(那些方向没有活动 mouse_key)。
    pub fn stick_mags(&self) -> Vec<(Control, f32)> {
        let mut out = Vec::with_capacity(8);
        for (side, tracker) in [(StickSide::Left, &self.left), (StickSide::Right, &self.right)] {
            for dir in [Direction::Up, Direction::Down, Direction::Left, Direction::Right] {
                out.push((Control::Stick { side, dir }, tracker.mag(dir)));
            }
        }
        out
    }

    /// 把方向变化包装成带摇杆侧别的统一事件。
    fn wrap(side: StickSide, changes: Vec<(Direction, bool)>) -> Vec<InputEvent> {
        changes
            .into_iter()
            .map(|(dir, pressed)| {
                let ctrl = Control::Stick { side, dir };
                if pressed { InputEvent::Pressed(ctrl) } else { InputEvent::Released(ctrl) }
            })
            .collect()
    }

    /// 扳机轴 → L2/R2 的按下/松开边沿(带阈值,避免抖动重复触发)。
    fn trigger(&mut self, value: i16, button: Button, is_left: bool) -> Vec<InputEvent> {
        let down = value > TRIGGER_THRESHOLD;
        let state = if is_left { &mut self.l2_down } else { &mut self.r2_down };
        if down == *state {
            return vec![];
        }
        *state = down;
        let ctrl = Control::Button(button);
        if down { vec![InputEvent::Pressed(ctrl)] } else { vec![InputEvent::Released(ctrl)] }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn below_deadzone_produces_nothing() {
        let mut t = StickTracker::new(0.2);
        assert_eq!(t.update(StickAxis::X, 0.1), vec![]);
    }

    #[test]
    fn push_right_then_center() {
        let mut t = StickTracker::new(0.2);
        assert_eq!(t.update(StickAxis::X, 0.9), vec![(Direction::Right, true)]);
        assert_eq!(t.update(StickAxis::X, 0.0), vec![(Direction::Right, false)]);
    }

    #[test]
    fn switch_direction_emits_release_then_press() {
        let mut t = StickTracker::new(0.2);
        t.update(StickAxis::X, 0.9); // Right
        t.update(StickAxis::X, 0.0); // 离开 Right
        assert_eq!(t.update(StickAxis::Y, 0.9), vec![(Direction::Up, true)]);
    }

    #[test]
    fn diagonal_activates_both_axes() {
        let mut t = StickTracker::new(0.2);
        // 两轴独立:先右推激活 Right,再上推**同时保留** Right 并新增 Up(斜向 = 两方向并存)。
        assert_eq!(t.update(StickAxis::X, 0.5), vec![(Direction::Right, true)]);
        assert_eq!(t.update(StickAxis::Y, 0.9), vec![(Direction::Up, true)]);
    }

    #[test]
    fn mag_reflects_axis_displacement() {
        let mut t = StickTracker::new(0.2);
        t.update(StickAxis::X, 0.6);
        t.update(StickAxis::Y, -0.9);
        assert!((t.mag(Direction::Right) - 0.6).abs() < 1e-6);
        assert!((t.mag(Direction::Down) - 0.9).abs() < 1e-6);
    }

    #[test]
    fn right_stick_wraps_with_right_side() {
        let mut t = Translator::new(0.2);
        // 右摇杆右推 → 右侧的 Right 方向按下。
        assert_eq!(
            t.on_axis(Axis::RightX, 30000),
            vec![InputEvent::Pressed(Control::Stick { side: StickSide::Right, dir: Direction::Right })]
        );
    }

    #[test]
    fn left_and_right_sticks_are_independent() {
        let mut t = Translator::new(0.2);
        let l = t.on_axis(Axis::LeftX, 30000);
        let r = t.on_axis(Axis::RightX, 30000);
        assert_eq!(l, vec![InputEvent::Pressed(Control::Stick { side: StickSide::Left, dir: Direction::Right })]);
        assert_eq!(r, vec![InputEvent::Pressed(Control::Stick { side: StickSide::Right, dir: Direction::Right })]);
    }

    #[test]
    fn trigger_crosses_threshold_once() {
        let mut t = Translator::new(0.2);
        assert_eq!(t.on_axis(Axis::TriggerLeft, 1000), vec![]);
        assert_eq!(t.on_axis(Axis::TriggerLeft, 30000), vec![InputEvent::Pressed(Control::Button(Button::L2))]);
        assert_eq!(t.on_axis(Axis::TriggerLeft, 32000), vec![]);
        assert_eq!(t.on_axis(Axis::TriggerLeft, 0), vec![InputEvent::Released(Control::Button(Button::L2))]);
    }

    #[test]
    fn left_y_is_flipped_sdl_down_positive_maps_to_direction_down() {
        // SDL 约定「向下为正」;Translator 翻转 Y,使正值 → Down、负值 → Up。
        let mut t = Translator::new(0.2);
        assert_eq!(
            t.on_axis(Axis::LeftY, 30000),
            vec![InputEvent::Pressed(Control::Stick { side: StickSide::Left, dir: Direction::Down })]
        );

        let mut t2 = Translator::new(0.2);
        assert_eq!(
            t2.on_axis(Axis::LeftY, -30000),
            vec![InputEvent::Pressed(Control::Stick { side: StickSide::Left, dir: Direction::Up })]
        );
    }

    #[test]
    fn right_y_is_flipped_independently_of_left() {
        // 右摇杆同样翻转,且与左摇杆独立。
        let mut t = Translator::new(0.2);
        assert_eq!(
            t.on_axis(Axis::RightY, 30000),
            vec![InputEvent::Pressed(Control::Stick { side: StickSide::Right, dir: Direction::Down })]
        );
    }

    #[test]
    fn joycon_left_button_full_mapping() {
        // 方向(90° 逆时针)+ 减号/L/ZL。
        assert_eq!(joycon_left_button(SdlButton::West), Some(Button::Up));
        assert_eq!(joycon_left_button(SdlButton::East), Some(Button::Down));
        assert_eq!(joycon_left_button(SdlButton::South), Some(Button::Left));
        assert_eq!(joycon_left_button(SdlButton::North), Some(Button::Right));
        assert_eq!(joycon_left_button(SdlButton::Start), Some(Button::Select)); // 减号
        assert_eq!(joycon_left_button(SdlButton::LeftPaddle1), Some(Button::L1)); // L
        assert_eq!(joycon_left_button(SdlButton::LeftPaddle2), Some(Button::L2)); // ZL
        // 其余回退到通用映射(摇杆按下 → L3)。
        assert_eq!(joycon_left_button(SdlButton::LeftStick), Some(Button::L3));
    }

    #[test]
    fn joycon_right_button_vertical_mapping() {
        // 右 Joy-Con(实测竖向对位):面键再转一格校正 + R/ZR + 单杆 R3。
        assert_eq!(joycon_right_button(SdlButton::East), Some(Button::North)); // 物理 X
        assert_eq!(joycon_right_button(SdlButton::North), Some(Button::West)); // 物理 Y
        assert_eq!(joycon_right_button(SdlButton::West), Some(Button::South)); // 物理 B
        assert_eq!(joycon_right_button(SdlButton::South), Some(Button::East)); // 物理 A
        assert_eq!(joycon_right_button(SdlButton::RightPaddle1), Some(Button::R1)); // R
        assert_eq!(joycon_right_button(SdlButton::RightPaddle2), Some(Button::R2)); // ZR
        assert_eq!(joycon_right_button(SdlButton::LeftStick), Some(Button::R3)); // 单杆按下 → R3
        assert_eq!(joycon_right_button(SdlButton::Guide), Some(Button::Mode)); // Home(回退)
    }

    #[test]
    fn joycon_left_remaps_stick_by_90deg() {
        // 摇杆轴同样转 90°:LeftX↔LeftY 互换 + Y→X 取负(与按键同一旋转)。
        assert_eq!(remap_joycon_left_axis(Axis::LeftX, 30000), (Axis::LeftY, 30000));
        assert_eq!(remap_joycon_left_axis(Axis::LeftY, 30000), (Axis::LeftX, -30000));
        // 扳机等其它轴原样。
        assert_eq!(remap_joycon_left_axis(Axis::TriggerLeft, 12345), (Axis::TriggerLeft, 12345));
    }
}

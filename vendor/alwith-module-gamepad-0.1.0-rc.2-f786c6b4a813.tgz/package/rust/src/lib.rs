//! ALwith gamepad 库——把核心模块公开，供 CLI 与 Tauri GUI 复用。
//!
//! CLI 在主线程跑 `main.rs` 自己的循环;GUI 用 [`engine::Engine`] 在后台线程跑同一套逻辑。

pub mod action;
pub mod config;
pub mod engine;
pub mod event;
pub mod exec;
pub mod gamepad;
pub mod mapper;
pub mod output;

mod validation;

pub mod contract;
pub mod profiles;
pub mod service;

pub mod capture;

#[cfg(feature = "desktop")]
pub mod desktop;

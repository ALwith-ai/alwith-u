//! 统一输入事件 —— 把任意手柄归一成标准布局,上层只认这套名字。

use serde::{Deserialize, Serialize};
use specta::Type;

/// 标准手柄按钮(SDL Gamepad 布局,位置语义)。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Type)]
#[serde(rename_all = "lowercase")]
pub enum Button {
    South, // 底键(Xbox A / Switch B)
    East,  // 右键(Xbox B / Switch A)
    West,  // 左键(Xbox X / Switch Y)
    North, // 上键(Xbox Y / Switch X)
    // 以下对外键名与 SDL3 完全一致;Rust 变体名保留(内部代码不动)。
    #[serde(rename = "leftshoulder")]
    L1, // SDL LeftShoulder(L / LB / L1)
    #[serde(rename = "rightshoulder")]
    R1, // SDL RightShoulder(R / RB / R1)
    #[serde(rename = "triggerleft")]
    L2, // SDL 扳机轴 TriggerLeft 合成(ZL / LT / L2)
    #[serde(rename = "triggerright")]
    R2, // SDL 扳机轴 TriggerRight 合成(ZR / RT / R2)
    #[serde(rename = "back")]
    Select, // SDL Back(View / Share / −)
    Start,
    #[serde(rename = "guide")]
    Mode, // SDL Guide(Xbox / PS / HOME)
    #[serde(rename = "misc1")]
    Capture, // SDL Misc1(Switch/Joy-Con 截图键)
    #[serde(rename = "leftstick")]
    L3, // SDL LeftStick(左摇杆按下)
    #[serde(rename = "rightstick")]
    R3, // SDL RightStick(右摇杆按下)
    #[serde(rename = "dpadup")]
    Up, // SDL DPadUp
    #[serde(rename = "dpaddown")]
    Down,
    #[serde(rename = "dpadleft")]
    Left,
    #[serde(rename = "dpadright")]
    Right,
}

/// 摇杆方向(4 向)。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Type)]
#[serde(rename_all = "lowercase")]
pub enum Direction {
    Up,
    Down,
    Left,
    Right,
}

/// 哪个摇杆。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Type)]
#[serde(rename_all = "lowercase")]
pub enum StickSide {
    Left,
    Right,
}

/// 可映射的控件:按钮,或某个摇杆的某个方向。映射引擎对两者一视同仁。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Type)]
pub enum Control {
    Button(Button),
    Stick { side: StickSide, dir: Direction },
}

/// 归一后的输入事件:按下 / 松开某个控件。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InputEvent {
    Pressed(Control),
    Released(Control),
}

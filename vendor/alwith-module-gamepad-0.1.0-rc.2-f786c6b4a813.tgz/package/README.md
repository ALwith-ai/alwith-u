# Gamepad module

Reusable controller mapping engine and React interface. This is a private release candidate.

Exports: core client, React panel/provider, transport adapter, generated native contract, locales, assets, and a Rust SDK. Import `styles.css` once and explicitly register `gamepadResources` in the host i18n instance. Wrap `GamepadPanel` in `GamepadProvider` with native transport, permissions, capture lifecycle, and error reporting.

Cargo consumers use the installed npm artifact at `node_modules/@alwith/module-gamepad/rust`. No sibling source dependency is required at runtime or build time.

The native service owns profiles, revisions, startup/shutdown, and input injection. Selecting a controller automatically activates its saved profile. All controllers retain the shared mapping policy. System injection ownership is exclusive among hosts that implement the shared lock. An unmodified Desktop does not yet participate in this lock.

Build and tests use Bun and Cargo. Run `bun run build`, `bun run test`, and `cargo test --manifest-path rust/Cargo.toml --lib --tests` from this directory. Native smoke tests marked ignored require explicit execution. Physical device coverage and Windows validation remain required before a stable release. This package has not been published.

## Host integration

```ts
import { createGamepadClient } from "@alwith/module-gamepad"
import { createTauriGamepadTransport } from "@alwith/module-gamepad/tauri"
import { GamepadPanel, GamepadProvider } from "@alwith/module-gamepad/react"
import { gamepadResources } from "@alwith/module-gamepad/locales"
import "@alwith/module-gamepad/styles.css"
```

The root entry has no React, DOM or Tauri imports and does not start native services.
`createTauriGamepadTransport` takes typed invoke/listen functions rather than importing a
specific Tauri major version. A headless consumer can provide `GamepadTransport` directly.
Register the desired entries from `gamepadResources` under the `gamepad` namespace (13 languages).
The panel uses the host's semantic color variables. Portals carry their own style scope.

```toml
[dependencies]
alwith-gamepad = { path = "../node_modules/@alwith/module-gamepad/rust", features = ["desktop"] }
```

Create one `GamepadService` per application, supplying an app-data profile path and the
shared per-user injection-lock path. Forward `ServiceEvent` to authorized windows and
serialize request responses. Use `with_repository` to supply a different native `ProfileStore`.
Profile saves require the expected revision. `savedRevision` and `appliedRevision` are distinct:
persistence while stopped does not imply injection is active. Selecting a device automatically
loads and activates its profile; subsequent edits are saved and applied immediately.
Controllers share that mapping but own separate layer, axis, held-action and repeat states.

The host owns key-capture policy: suspend injection, remove conflicting menus where needed,
retain `CaptureSession`, and restore both on stop, failure, focus loss, window destruction and
application exit. Cancel pending starts on focus loss as well as active sessions. Restrict
capture and service commands to trusted application windows. Native global capture is
implemented for macOS and Windows; other hosts use DOM capture with injection suspended.
AI generation is optional, receives an AbortSignal, and never imports a model provider.
The `./ai` entry provides prompt construction and validated full/incremental JSON parsing.
Provide `applications`, `microphones` and `generateConfig` host capabilities for the complete
interface. The optional Rust `desktop` feature exposes application discovery and microphone
enumeration; catalog subscriptions refresh application icons. Host window teardown must detach
virtual devices and stop owned AI tasks independently of JavaScript cleanup.

The panel retains a 320px device column and fixed-size controller diagram. Use a dedicated
window at least 1250 by 750 pixels. Semantic host colors theme the interface and its portals.

## Validation and release status

macOS arm64 verification includes unit tests, profile persistence/conflict tests, client
subscription races, a React stale-save test, and explicit native virtual-controller tests
with system output disabled. Physical controllers, rumble hardware, permission UI,
global key interception, and Windows execution still require manual validation.
The package remains private and must not be published as a stable release on this evidence.

# Third-party notices

The Rust engine and UI were extracted from the Desktop revision in `provenance.json`. Source distribution permission and the package license must be finalized before publication. This release candidate is private.

Controller artwork: AL2009man/Gamepad-Asset-Pack, MIT. Source: https://github.com/AL2009man/Gamepad-Asset-Pack.

PromptFont: SIL Open Font License 1.1; Reserved Font Name "PromptFont". Source: https://github.com/Shinmera/promptfont.

Native dependencies include SDL3 (zlib) and enigo (MIT). The locked Rust and Bun dependency graphs must be included in the host's complete license audit before distribution.

Phosphor Sparkle icon geometry: MIT. Source: @phosphor-icons/react, https://github.com/phosphor-icons/react.

MIT License

Copyright (c) 2020 Phosphor Icons

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


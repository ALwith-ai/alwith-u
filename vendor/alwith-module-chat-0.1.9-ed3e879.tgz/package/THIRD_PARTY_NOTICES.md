# Third-party notices — @alwith/module-chat

ALwith's proprietary license applies only to its own material. Third-party
material retains its original license and rights; the package license does not
replace or restrict those rights. Preserve applicable notices when redistributing.

## Included/adapted components

- UI primitives (`dist/ui/*`) were brought through ALwith Desktop from shadcn/ui. Upstream: https://github.com/shadcn-ui/ui. MIT notice: `licenses/shadcn-ui-MIT.txt`. ALwith adaptations are not upstream releases.
- Prompt-input family (`dist/composer/prompt-input*`) is conservatively attributed to the Vercel AI Elements lineage pending exact revision verification. Upstream: https://github.com/vercel/ai-elements. Retained copyright: `licenses/ai-elements-notice.txt`; Apache-2.0 terms: `licenses/Apache-2.0.txt`. ALwith modified and split this family for shared context, host callbacks, attachments and Desktop behavior. This attribution does not assert that every file in the family is upstream code.

## External direct dependencies and peers

These are external imports, not bundled dependency implementations in this npm
artifact. Versions below record the local release-preparation inventory; declared
ranges can resolve to different versions. Keep the notices from the versions
actually distributed by your application, including transitive dependencies.

| Package | Inspected version | License | Included license copy |
| --- | --- | --- | --- |
| @agentclientprotocol/sdk | 1.4.0 | Apache-2.0 | `licenses/_agentclientprotocol_sdk-LICENSE` |
| @base-ui/react | 1.8.0 | MIT | `licenses/_base-ui_react-LICENSE` |
| @floating-ui/dom | 1.8.0 | MIT | `licenses/_floating-ui_dom-LICENSE` |
| ansi_up | 6.0.6 | MIT | `licenses/ansi_up-LICENSE` |
| class-variance-authority | 0.7.1 | Apache-2.0 | `licenses/class-variance-authority-LICENSE` |
| cn | 0.3.0 | MIT | `licenses/cn-LICENSE` |
| diff2html | 3.4.56 | MIT | `licenses/diff2html-LICENSE.md` |
| entities | 8.1.0 | BSD-2-Clause | `licenses/entities-LICENSE` |
| highlight.js | 11.12.0 | BSD-3-Clause | `licenses/highlight.js-LICENSE` |
| katex | 0.18.7 | MIT | `licenses/katex-LICENSE` |
| lucide-react | 1.46.0 | ISC | `licenses/lucide-react-LICENSE` |
| marked | 18.0.13 | MIT | `licenses/marked-LICENSE` |
| marked-linkify-it | 4.0.2 | MIT | `licenses/marked-linkify-it-LICENSE` |
| react | 19.3.0 | MIT | `licenses/react-LICENSE` |
| react-dom | 19.3.0 | MIT | `licenses/react-dom-LICENSE` |
| smplr | 1.0.0 | MIT | MIT declared in package.json; full license/copyright notice not found in installed package or upstream repository; release review required |

## Runtime-loaded media

`smplr` navigation audio can load instrument samples from external services. Those
samples are not included in this npm archive. The library license does not license
all sample collections; verify the selected collection and provider terms before
redistributing or caching media.

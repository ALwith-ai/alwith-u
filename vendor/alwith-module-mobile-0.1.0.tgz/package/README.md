# Mobile connection

Shared encrypted mobile bridge for ALwith applications. The host supplies its app identity, configuration directory and Runtime requests. Transport, pairing and routing run in the native mobile library.

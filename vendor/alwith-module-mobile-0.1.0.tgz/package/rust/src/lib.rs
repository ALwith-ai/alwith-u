//! Public mobile ABI client. Encryption and transport remain in the native library.
use alwith_native_client::{EventReader, Handle};
use serde::{Deserialize, Serialize, de::DeserializeOwned};
use serde_json::{Value, json};
use std::path::Path;

#[derive(Clone, Copy, Debug, Serialize, Deserialize, specta::Type)]
#[serde(rename_all = "lowercase")]
pub enum HostApp {
    Desktop,
    U,
}
#[derive(Clone, Serialize, Deserialize, specta::Type)]
#[serde(rename_all = "camelCase")]
pub struct PairingInfo {
    pub device_id: String,
    pub public_key_b64: String,
    pub code: String,
    pub expires_at: i64,
    pub host_app: HostApp,
}
#[derive(Clone, Serialize, Deserialize, specta::Type)]
#[serde(rename_all = "camelCase")]
pub struct BridgeIdentity {
    pub device_id: String,
    pub public_key_b64: String,
}
#[derive(Clone, Serialize, Deserialize, specta::Type)]
#[serde(rename_all = "camelCase")]
pub struct TrustedDevice {
    pub device_id: String,
    pub public_key_b64: String,
    pub name: String,
    #[serde(default)]
    pub model: Option<String>,
    pub paired_at: i64,
    #[serde(default)]
    pub push_handle: Option<String>,
}
#[derive(Clone, Serialize, Deserialize, specta::Type)]
#[serde(rename_all = "camelCase")]
pub struct MobileBridgeStatus {
    pub running: bool,
    pub connected: bool,
    pub relay_connected: bool,
}

#[derive(Deserialize)]
#[serde(tag = "type", rename_all = "camelCase")]
pub enum HostEvent {
    Request {
        #[serde(rename = "requestId")]
        request_id: u64,
        method: String,
        params: Value,
    },
    Event {
        name: String,
        payload: Value,
    },
}
#[derive(Clone)]
pub struct Mobile(Handle);
impl Mobile {
    pub fn new(directory: &Path, host_app: HostApp) -> Result<Self, String> {
        Ok(Self(Handle::open("mobile", json!({"directory":directory,"hostApp":host_app}))?))
    }
    pub fn listen(&self, callback: impl Fn(Result<HostEvent, String>) + Send + 'static) -> Result<EventReader, String> {
        EventReader::start(self.0.clone(), "next", "closeEvents", callback)
    }
    pub fn reply(&self, request_id: u64, result: Result<Value, String>) -> Result<(), String> {
        self.0.call("reply", json!({"requestId":request_id,"result":result}))
    }
    pub fn call<T: DeserializeOwned>(&self, method: &str, params: Value) -> Result<T, String> {
        self.0.call(method, params)
    }
    pub async fn call_async<T: DeserializeOwned + Send + 'static>(
        &self, method: &str, params: Value,
    ) -> Result<T, String> {
        self.0.call_async(method, params).await
    }
    pub fn close(&self) -> Result<(), String> {
        self.0.close()
    }
}

#[cfg(feature = "tauri")]
pub mod host;

pub use alwith_native_client::configure;

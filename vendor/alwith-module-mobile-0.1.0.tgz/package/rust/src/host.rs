//! Tauri integration shared by hosts; Runtime requests remain application supplied.
use super::*;
use std::{
    future::Future,
    pin::Pin,
    sync::{Arc, OnceLock},
};
use tauri::{AppHandle, Emitter, Manager};

type RequestFuture = Pin<Box<dyn Future<Output = Result<Value, String>> + Send>>;
static MOBILE: OnceLock<Mobile> = OnceLock::new();
struct Reader {
    _reader: EventReader,
}
pub fn init(
    app: &AppHandle, host_app: HostApp, request: impl Fn(String, Value) -> RequestFuture + Send + Sync + 'static,
) -> Result<(), String> {
    let mobile = Mobile::new(&app.path().app_config_dir().map_err(|e| e.to_string())?, host_app)?;
    let handler = Arc::new(request);
    let worker = mobile.clone();
    let emitter = app.clone();
    let reader = mobile.listen(move |event| match event {
        Ok(HostEvent::Event { name, payload }) => emitter.emit(&name, payload).expect("emit mobile event"),
        Ok(HostEvent::Request { request_id, method, params }) => {
            let handler = handler.clone();
            let worker = worker.clone();
            tauri::async_runtime::spawn(async move {
                worker.reply(request_id, handler(method, params).await).expect("reply to mobile host request");
            });
        }
        Err(error) => {
            emitter.emit("bridge:error", error).expect("emit mobile failure");
        }
    })?;
    MOBILE.set(mobile).map_err(|_| "Mobile host initialized twice")?;
    app.manage(Reader { _reader: reader });
    Ok(())
}
fn mobile() -> &'static Mobile {
    MOBILE.get().expect("Mobile host initialized during setup")
}
pub async fn shutdown() -> Result<(), String> {
    mobile().call_async("stop", json!({})).await
}
pub fn publish_run_states(sessions_json: String) {
    let sessions: Value = serde_json::from_str(&sessions_json).expect("Runtime states JSON");
    mobile().call::<()>("publishRunStates", json!({"sessions":sessions})).expect("publish mobile run states");
}
pub fn publish_session_lines(agent_id: String, lines_json: String) {
    let lines: Value = serde_json::from_str(&lines_json).expect("Runtime lines JSON");
    mobile()
        .call::<()>("publishSessionLines", json!({"agentId":agent_id,"lines":lines}))
        .expect("publish mobile session lines");
}
#[tauri3_specta::command]
pub async fn mobile_bridge_start(relay_url: String) -> Result<(), String> {
    mobile().call_async("start", json!({"relayUrl":relay_url})).await
}
#[tauri3_specta::command]
pub async fn mobile_bridge_stop() -> Result<(), String> {
    shutdown().await
}
#[tauri3_specta::command]
pub async fn mobile_bridge_status() -> MobileBridgeStatus {
    mobile().call_async("status", json!({})).await.expect("Read mobile bridge status")
}
#[tauri3_specta::command]
pub fn bridge_set_active_session(session_id: Option<String>) {
    mobile().call::<()>("setActiveSession", json!({"sessionId":session_id})).expect("publish active mobile session")
}
#[tauri3_specta::command]
pub async fn bridge_pairing_start() -> Result<PairingInfo, String> {
    mobile().call_async("pairing", json!({})).await
}
#[tauri3_specta::command]
pub async fn bridge_identity() -> Result<BridgeIdentity, String> {
    mobile().call_async("identity", json!({})).await
}
#[tauri3_specta::command]
pub async fn bridge_device_id() -> Result<String, String> {
    Ok(bridge_identity().await?.device_id)
}
#[tauri3_specta::command]
pub async fn bridge_trusted_list() -> Result<Vec<TrustedDevice>, String> {
    mobile().call_async("trusted", json!({})).await
}
#[tauri3_specta::command]
pub async fn bridge_trusted_revoke(device_id: String) -> Result<(), String> {
    mobile().call_async("revoke", json!({"deviceId":device_id})).await
}
#[tauri3_specta::command]
pub async fn bridge_e2e_selftest() -> Result<Vec<String>, String> {
    mobile().call_async("selftest", json!({})).await
}

# @alwith/module-fs

A transport-independent filesystem contract and operation coordinator. The core has no React, DOM or Tauri dependency. Adapters enforce permissions; JavaScript capabilities only describe the UI's available actions.

## Use

```ts
import { createFileSystem } from "@alwith/module-fs"
import { createMemoryAdapter } from "@alwith/module-fs/testing"
const fs = createFileSystem({
  adapter: createMemoryAdapter({ "/project/readme.md": "# Hello" }),
  reportError: error => console.error(error)
})
const stop = fs.subscribe(event => console.log(event))
await fs.writeFile("/project/readme.md", new TextEncoder().encode("# Changed"), { mode: "replace" })
stop()
```

## Contract

- `FsAdapter` implements stat, byte reads/writes, directory listing, mkdir, move, copy and remove. `stat` returns null only for an absent path; all other errors propagate.
- `WriteOptions.mode` distinguishes create-only, replace-existing and upsert. `expectedVersion` rejects stale saves. Adapters must enforce both, not treat them as advisory.
- `createFileSystem` serializes mutations and `transaction` calls in one instance. A transaction receives a non-queuing writer; never call the outer service's mutation methods from inside a transaction or guard.
- `beforeMutation` can cancel move/remove/copy/mkdir. Editor controllers use it to protect unsaved deleted documents. A cancellation rejects with `MutationCancelledError`. A guard may return `{ allow, release }` to hold an operation lease until commit/failure; releases always run and cannot change the disk result.
- `subscribe` reports committed operations. Native/watch observations have a separate `source: "watch"`; they are invalidations, not proof a particular UI operation committed. `reportError` must not throw.
- `watch` is optional. Hosts own and release the returned subscription. No polling or network access is started by importing the package.
- Path helpers understand POSIX, Windows drive and UNC roots. `joinPath` accepts a single filename and rejects traversal. Helpers are lexical; adapters still must enforce canonical/symlink boundaries. Path identity is case-sensitive; native adapters must provide consistent canonical identities.

## Native distribution

`@alwith/module-fs/tauri` accepts `{ root, transport, watch? }`. The host supplies IPC, authorization and watcher transport. It does not import the Tauri JavaScript SDK.

The tarball also contains `rust/`, staged by `build-native.ts` from the single source of truth `crates/fs`. Consume it in a Tauri host:

```toml
alwith-fs = { path = "../node_modules/@alwith/module-fs/rust", default-features = false, features = ["workspace"] }
```

The host authorizes roots, constructs `FileSystem::new`, serializes requests and calls `workspace::execute`. Never construct it from an unverified request root. `workspace::watch` returns a handle owned by the host. The `workspace` feature is optional; existing crate consumers keep their default Specta derives.

The workspace service limits reads/writes to 16 MiB, preserves binary bytes, checks versions, uses same-directory temporary writes, rejects root mutation and mutation of terminal symbolic links, and refuses existing copy/move destinations. A recursive copy is staged before exposing the destination. Saves coordinate requests in the host process; version checks do not provide an OS-wide transaction against arbitrary external writers. Watch errors are reported explicitly.

## Develop

From the repository root: `bun run --cwd packages/fs build` and `bun test packages/fs/src`. `bun pm pack` from this package creates the npm tarball. Build before packing so native staging is current. Publish authorization is separate.

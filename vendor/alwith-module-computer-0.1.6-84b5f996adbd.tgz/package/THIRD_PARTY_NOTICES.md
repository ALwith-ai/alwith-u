# Third-party notices

This integration pins the separately distributed MIT-licensed Cua Driver 0.37.0.
Upstream: https://github.com/trycua/cua/tree/cua-driver-rs-v0.37.0/libs/cua-driver

Applications staging the executable must distribute the included upstream
`licenses/cua-driver-LICENSE.md` and `licenses/cua-driver-THIRD_PARTY_NOTICES.md`.
No Cua Spaces, VM, perception models, Node SDK or Windows UIAccess helper is shipped.

Window previews use XCap 0.9.8 (Apache-2.0), https://github.com/nashaofu/xcap.
Its license is included as `licenses/xcap-LICENSE`. JPEG encoding uses the
MIT-licensed `image` crate; base64 transport uses the MIT-licensed `base64` crate.

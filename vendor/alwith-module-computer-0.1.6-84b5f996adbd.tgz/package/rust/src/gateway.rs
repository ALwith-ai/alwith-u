use crate::{Connection, preview::CursorPosition};
use alwith_native_client::Handle;
use serde::Serialize;
use serde_json::json;
use std::{collections::HashSet, sync::Arc};
#[derive(Clone, Debug, PartialEq, Eq, Serialize, specta::Type, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Target {
    pub pid: u32,
    pub window_id: u32,
}
#[derive(Clone, Debug, Serialize, specta::Type, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Activity {
    pub session_id: String,
    pub phase: String,
    pub queue_position: usize,
    pub owner_session_id: Option<String>,
    pub action: Option<String>,
    pub target: Option<Target>,
    pub revision: u64,
}

pub struct Gateway(Handle);
impl Default for Gateway {
    fn default() -> Self {
        Self(
            Handle::open_with_close("computer", "gateway_close", json!({"kind":"gateway"}))
                .expect("Native computer gateway is required"),
        )
    }
}
impl Gateway {
    pub async fn listen(self: &Arc<Self>) -> Result<(), String> {
        self.0.call_async("gateway_listen", json!({})).await
    }
    pub fn register(&self, driver: Connection) -> Result<(String, String), String> {
        self.0.call("gateway_register", json!({"driver":driver}))
    }
    pub fn bind(&self, token: &str, session: &str) -> Result<(), String> {
        self.0.call("gateway_bind", json!({"token":token,"session":session}))
    }
    pub async fn ensure_ready(&self, session: &str) -> Result<(), String> {
        self.0.call_async("gateway_ensure_ready", json!({"session":session})).await
    }
    pub fn sync_running(&self, running: HashSet<String>) {
        self.0.call::<()>("gateway_sync_running", json!({"running":running})).expect("Native computer sync failed");
    }
    pub fn stop_session(&self, session: &str) {
        self.0.call::<()>("gateway_stop_session", json!({"session":session})).expect("Native computer stop failed");
    }
    pub fn stop_all(&self) {
        self.0.call::<()>("gateway_stop_all", json!({})).expect("Native computer stop failed");
    }
    pub fn diagnostics(&self) -> String {
        self.0.call("gateway_diagnostics", json!({})).expect("Native computer diagnostics failed")
    }
    pub fn faulted(&self) -> bool {
        self.0.call("gateway_faulted", json!({})).expect("Native computer state failed")
    }
    pub fn activity(&self, session: &str) -> Activity {
        self.0.call("gateway_activity", json!({"session":session})).expect("Native computer activity failed")
    }
    pub async fn cursor_position(&self, session: &str) -> Option<CursorPosition> {
        self.0
            .call_async("gateway_cursor_position", json!({"session":session}))
            .await
            .expect("Native computer cursor failed")
    }
    pub async fn focus_preview(&self, session: &str, revision: u64) -> Result<(), String> {
        self.0.call_async("gateway_focus_preview", json!({"session":session,"revision":revision})).await
    }
}

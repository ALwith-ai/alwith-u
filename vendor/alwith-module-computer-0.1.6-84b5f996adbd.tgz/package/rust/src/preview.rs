use crate::gateway::Target;
use alwith_native_client::Library;
use serde_json::json;
#[derive(Clone, Debug, serde::Serialize, specta::Type, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Frame {
    pub image: String,
    pub title: String,
    pub app_name: String,
    pub cursor: Option<CursorPosition>,
}
#[derive(Clone, Debug, serde::Serialize, specta::Type, serde::Deserialize)]
pub struct CursorPosition {
    pub x: f64,
    pub y: f64,
}

pub fn capture(target: &Target, cursor: Option<CursorPosition>) -> Result<Frame, String> {
    Library::module("computer")?.call("computer.preview_capture", json!({"target":target,"cursor":cursor}))
}

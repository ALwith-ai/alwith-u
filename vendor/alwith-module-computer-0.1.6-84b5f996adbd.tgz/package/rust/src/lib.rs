//! Computer-use types and ABI transport.
pub mod gateway;
pub mod permissions;
pub mod preview;
use alwith_native_client::Handle;
use serde::Serialize;
use serde_json::{Value, json};
use std::path::PathBuf;
pub const DRIVER_VERSION: &str = "0.37.0";
#[derive(Debug, Clone, Serialize, specta::Type, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Status {
    pub permissions: permissions::Permissions,
    pub available: bool,
    pub session_id: Option<String>,
    pub ready: bool,
    pub version: String,
    pub phase: String,
    pub last_error: Option<String>,
    pub diagnostics: String,
}
#[derive(Debug, Clone, Serialize, specta::Type, serde::Deserialize)]
pub struct Environment {
    pub name: String,
    pub value: String,
}
#[derive(Debug, Clone, Serialize, specta::Type, serde::Deserialize)]
pub struct Connection {
    pub generation: String,
    pub command: String,
    pub args: Vec<String>,
    pub env: Vec<Environment>,
}

pub struct ComputerHost {
    handle: Handle,
    options: Value,
}
impl ComputerHost {
    pub fn new(binary: PathBuf, bundle_id: String) -> Self {
        let options = json!({"binary":binary,"bundle_id":bundle_id});
        Self { handle: Handle::open("computer", options.clone()).expect("Native computer module is required"), options }
    }
    pub fn with_cursor_theme(mut self, id: String, bytes: Vec<u8>) -> Self {
        self.handle.close().expect("Native computer builder close failed");
        self.options["cursor_theme"] = json!({"id":id,"bytes":bytes});
        self.handle = Handle::open("computer", self.options.clone()).expect("Native computer builder failed");
        self
    }
    pub fn status(&self) -> Result<Status, String> {
        self.handle.call("status", json!({}))
    }
    pub fn connection(&self, session: &str) -> Result<Option<Connection>, String> {
        self.handle.call("connection", json!({"session":session}))
    }
    pub async fn start(&self, session: String) -> Result<Status, String> {
        self.handle.call_async("start", json!({"session":session})).await
    }
    pub async fn stop(&self, session: &str) -> Result<(), String> {
        self.handle.call_async("stop", json!({"session":session})).await
    }
    pub async fn shutdown(&self) -> Result<(), String> {
        self.handle.call_async("shutdown", json!({})).await
    }
    pub async fn stop_current(&self) -> Result<(), String> {
        self.handle.call_async("stop_current", json!({})).await
    }
    pub fn kill_on_exit(&self) {
        self.handle.call::<()>("kill_on_exit", json!({})).expect("Native computer exit failed");
    }
}

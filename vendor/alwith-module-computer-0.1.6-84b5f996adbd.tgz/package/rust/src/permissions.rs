use alwith_native_client::Library;
use serde::Serialize;
use serde_json::json;
#[derive(Debug, Clone, Serialize, specta::Type, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Permissions {
    pub supported: bool,
    pub accessibility: bool,
    pub screen_capture: bool,
}

pub fn status() -> Permissions {
    Library::module("computer")
        .expect("Native computer module is required")
        .call("computer.permissions_status", json!({}))
        .expect("Native permission status failed")
}
pub fn request() -> Permissions {
    Library::module("computer")
        .expect("Native computer module is required")
        .call("computer.permissions_request", json!({}))
        .expect("Native permission request failed")
}

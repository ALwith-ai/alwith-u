# Computer module

Computer access using Cua Driver 0.37.0 (contract 0.8.0). The TypeScript entry
composes MCP descriptors from native authority without storing conversations.
It returns a generation revision so clients can refresh existing threads when
the host's grant changes. New, resumed and forked threads receive the same tools
when the application grant is enabled.

The Rust host owns one embedded Driver child and a private transport. Its logical
lease key is chosen by the consumer: U uses one application lease shared by every
conversation. Individual thread cancellation or window hiding does not revoke
this lease. Disabling computer use stops the child and invalidates every proxy.
Hosts must shut down on application exit and connection loss. Launch directly
from the signed application for macOS permission attribution.

macOS uses a Unix socket and requires Accessibility and Screen Recording.
Windows uses named pipes. Linux is not enabled. Permission covers the local
desktop, not an application allowlist. Elevated Windows apps may require OS
privileges the ordinary driver does not have. No UIAccess helper is installed.

`./artifacts` supplies pinned download URLs or package-relative `bundled` paths,
with SHA-256 digests. Apple Silicon macOS uses the archive in `artifacts/` with
the multi-display cursor patch; other targets use upstream downloads. Resolve
`bundled` paths relative to the `./artifacts` module and verify the archive before
extracting it. Stage the executable, distribute `licenses/`, and sign it with the
application. Patch sources and the rebuild script live in this repository under
`driver-patches/` and are excluded from the npm package. The MCP proxy uses an
explicit embedded endpoint and cannot start a standalone daemon after revocation.

Run `bun run test`, `bun run build`, and `bun run test:rust` in this directory.

The optional Rust `gateway` binds an MCP connection token to the returned session
ID. It serializes tool access with a FIFO lease held until Runtime turn completion.
Cancellation drains an outstanding native action before handoff; transport failure
requires the host to stop the Driver before resetting the gateway. Consumers must
forward Runtime run-state snapshots, including sessions awaiting input.

`proxy/stdio.mjs` runs with Bun and bridges MCP over authenticated loopback TCP.
Stage it as an application resource. `preview::capture` independently captures the
owned window as a bounded JPEG without changing the Driver's grounding cache.
Consumers scope subscriptions to visible windows and discard stale target revisions.
Frames are ephemeral and are not a video recording or conversation storage.

Startup verifies the driver's screenshot and accessibility-tree path against a visible
host window before publishing a connection. Keep a host window open during recovery.
Tool replies have a 150-second deadline (the driver's maximum 120-second tool budget
plus transport headroom); protocol discovery has a 20-second deadline. Notifications
do not extend these deadlines. A timed-out action has an unknown outcome: stop the
Driver before resetting the gateway, reconnect, and observe rather than replaying it.
Driver stderr and content-free tool timing records are kept in bounded in-memory
buffers for the current application session only. Raw stderr may contain driver
error details; it is never automatically persisted or uploaded.

# @alwith/native-computer

Precompiled computer implementation. Install the optional package matching the host target and call `stageNative` from `@alwith/native-computer/stage`.

The package contains no private Rust implementation sources.

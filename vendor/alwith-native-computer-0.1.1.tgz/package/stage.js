import { stageNativeModule } from "@alwith/native-kit/stage"
export function stageNative(target, destination, licenses) {
  return stageNativeModule(import.meta.url, "computer", target, destination, licenses)
}

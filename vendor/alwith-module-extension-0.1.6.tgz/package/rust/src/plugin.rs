//! Optional Tauri boundary. Paths are authorized by native file-picker grants,
//! not by trusting a JavaScript string. Window identity comes from Tauri.
use crate::{Request, Response, Service, ServiceError, error};
use std::{
    path::{Path, PathBuf},
    sync::Mutex,
};
use tauri::{
    Emitter, Manager, Runtime,
    plugin::{Builder, TauriPlugin},
};
struct InstallGrant {
    window: String,
    path: PathBuf,
    source: String,
}
struct ExtensionService {
    navigating: Mutex<std::collections::BTreeMap<String, Vec<String>>>,
    service: Mutex<Result<Service, ServiceError>>,
    grants: Mutex<Vec<InstallGrant>>,
}

impl ExtensionService {
    fn initialize(root: Result<PathBuf, ServiceError>) -> Self {
        Self {
            navigating: Mutex::new(Default::default()),
            service: Mutex::new(root.and_then(Service::open)),
            grants: Mutex::new(Vec::new()),
        }
    }
    fn with_service<T>(
        &self,
        operation: impl FnOnce(&mut Service) -> Result<T, ServiceError>,
    ) -> Result<T, ServiceError> {
        let mut service = self
            .service
            .lock()
            .map_err(|_| error("poisoned", "extension service lock poisoned"))?;
        let service = service.as_mut().map_err(|error| error.clone())?;
        operation(service)
    }
}

/// Call this only after a native host-owned file picker or trusted seed policy
/// selected a directory. A grant authorizes one install/update attempt.
pub fn grant_install<R: Runtime>(
    app: &tauri::AppHandle<R>,
    window: &str,
    path: &Path,
    source: &str,
) -> Result<(), ServiceError> {
    let state = app
        .try_state::<ExtensionService>()
        .ok_or_else(|| error("notInitialized", "extension plugin is not initialized"))?;
    state.with_service(|_| Ok(()))?;
    let path = path.canonicalize()?;
    if !path.is_dir() || source.trim().is_empty() {
        return Err(error(
            "invalidGrant",
            "a directory and source identity are required",
        ));
    }
    state
        .grants
        .lock()
        .map_err(|_| error("poisoned", "install grant lock poisoned"))?
        .push(InstallGrant {
            window: window.into(),
            path,
            source: source.into(),
        });
    Ok(())
}
/// Read a verified package snapshot through the service's native authority.
/// Not exposed as a JavaScript command; host capability policy remains mandatory.
pub fn installed_package<R: Runtime>(
    app: &tauri::AppHandle<R>,
    id: &str,
    source: &str,
) -> Result<(crate::Installation, crate::PackageFiles), ServiceError> {
    let state = app
        .try_state::<ExtensionService>()
        .ok_or_else(|| error("notInitialized", "extension plugin is not initialized"))?;
    state.with_service(|service| service.installed_package(id, source))
}

/// Read lifecycle state without depending on the private on-disk representation.
pub fn snapshot<R: Runtime>(app: &tauri::AppHandle<R>) -> Result<crate::Snapshot, ServiceError> {
    let state = app
        .try_state::<ExtensionService>()
        .ok_or_else(|| error("notInitialized", "extension plugin is not initialized"))?;
    state.with_service(|service| Ok(service.snapshot()))
}

fn consume_grant(
    state: &ExtensionService,
    window: &str,
    request: &Request,
) -> Result<(), ServiceError> {
    let selection = match request {
        Request::InstallLocal { path, source, .. } => Some((path, source)),
        Request::BeginTransition {
            action: crate::TransitionAction::Update,
            path: Some(path),
            source: Some(source),
            ..
        } => Some((path, source)),
        _ => None,
    };
    if let Some((path, source)) = selection {
        let canonical = Path::new(path).canonicalize()?;
        let mut grants = state
            .grants
            .lock()
            .map_err(|_| error("poisoned", "install grant lock poisoned"))?;
        let index = grants
            .iter()
            .position(|g| g.window == window && g.path == canonical && &g.source == source)
            .ok_or_else(|| {
                error(
                    "installNotGranted",
                    "native host must authorize the selected directory first",
                )
            })?;
        grants.remove(index);
    }
    Ok(())
}
#[tauri::command]
fn dispatch<R: Runtime>(
    window: tauri::Window<R>,
    state: tauri::State<'_, ExtensionService>,
    request: Request,
) -> Result<Response, ServiceError> {
    state.with_service(|service| {
        consume_grant(&state, window.label(), &request)?;
        let before = service.snapshot().sequence;
        let response = service.dispatch(window.label(), request)?;
        let snapshot = service.snapshot();
        if snapshot.sequence != before {
            // Emission stays inside the serialization boundary to retain event order.
            window
                .app_handle()
                .emit("extension://changed", &snapshot)
                .map_err(|e| {
                    error(
                        "eventDelivery",
                        format!("state committed; refresh authoritative snapshot: {e}"),
                    )
                })?;
        }
        Ok(response)
    })
}
#[tauri::command]
async fn pick_local<R: Runtime>(window: tauri::Window<R>) -> Result<Option<String>, ServiceError> {
    use tauri_plugin_dialog::DialogExt;
    let app = window.app_handle().clone();
    let label = window.label().to_owned();
    {
        let state = app
            .try_state::<ExtensionService>()
            .ok_or_else(|| error("notInitialized", "extension plugin is not initialized"))?;
        state.with_service(|_| Ok(()))?;
    }
    tauri::async_runtime::spawn_blocking(move || {
        if app.try_state::<tauri_plugin_dialog::Dialog<R>>().is_none() {
            return Err(error(
                "notInitialized",
                "host must register tauri_plugin_dialog::init() before using pick_local",
            ));
        }
        let Some(selected) = app
            .dialog()
            .file()
            .set_title("Select an application extension directory")
            .blocking_pick_folder()
        else {
            return Ok(None);
        };
        let path = selected
            .into_path()
            .map_err(|e| error("invalidPath", e.to_string()))?;
        let path = path.canonicalize()?;
        grant_install(&app, &label, &path, "local")?;
        let value = path
            .to_str()
            .ok_or_else(|| error("invalidPath", "selected path is not UTF-8"))?
            .to_owned();
        Ok(Some(value))
    })
    .await
    .map_err(|e| error("pickerFailed", e.to_string()))?
}
pub fn init<R: Runtime>() -> TauriPlugin<R> {
    init_with_root(None)
}
pub fn init_with_root<R: Runtime>(root: Option<PathBuf>) -> TauriPlugin<R> {
    Builder::new("extension")
        .invoke_handler(tauri::generate_handler![dispatch, pick_local])
        .setup(move |app, _| {
            let root = match root {
                Some(root) => Ok(root),
                None => app
                    .path()
                    .app_local_data_dir()
                    .map(|path| path.join("extensions"))
                    .map_err(|e| error("appDataPath", e.to_string())),
            };
            app.manage(ExtensionService::initialize(root));
            Ok(())
        })
        .register_uri_scheme_protocol("extension", |context, request| {
            let result = (|| -> Result<(Vec<u8>, String), ServiceError> {
                if request.method() != tauri::http::Method::GET {
                    return Err(error("invalidRequest", "only GET resources are supported"));
                }
                let decoded = percent_encoding::percent_decode_str(request.uri().path())
                    .decode_utf8()
                    .map_err(|e| error("invalidPath", e.to_string()))?;
                let (token, path) =
                    decoded
                        .trim_start_matches('/')
                        .split_once('/')
                        .ok_or_else(|| {
                            error("invalidPath", "expected instance token and resource path")
                        })?;
                let app = context.app_handle();
                let webview = app
                    .get_webview_window(context.webview_label())
                    .ok_or_else(|| error("invalidWindow", "webview no longer exists"))?;
                let state = app.try_state::<ExtensionService>().ok_or_else(|| {
                    error("notInitialized", "extension plugin is not initialized")
                })?;
                state.with_service(|service| {
                    service.resource_for_window(webview.label(), token, path)
                })
            })();
            match result {
                Ok((bytes, mime)) => tauri::http::Response::builder()
                    .status(200)
                    .header("Content-Type", mime)
                    .header("Cache-Control", "no-store")
                    .header("Access-Control-Allow-Origin", "*")
                    .header("X-Content-Type-Options", "nosniff")
                    .body(bytes)
                    .expect("fixed resource response is valid"),
                Err(error) => tauri::http::Response::builder()
                    .status(403)
                    .header("Content-Type", "application/json")
                    .body(
                        serde_json::to_vec(&error)
                            .expect("ServiceError contains only JSON strings"),
                    )
                    .expect("fixed error response is valid"),
            }
        })
        .on_page_load(|webview, payload| {
            let app = webview.app_handle();
            if let Some(state) = app.try_state::<ExtensionService>() {
                let result = (|| -> Result<(), ServiceError> {
                    let window = webview.window();
                    let label = window.label();
                    let mut navigating = state
                        .navigating
                        .lock()
                        .map_err(|_| error("poisoned", "navigation lock poisoned"))?;
                    state.with_service(|service| {
                        match payload.event() {
                            tauri::webview::PageLoadEvent::Started => {
                                navigating
                                    .insert(label.into(), service.capture_window_instances(label));
                            }
                            tauri::webview::PageLoadEvent::Finished => {
                                if let Some(tokens) = navigating.remove(label) {
                                    let before = service.snapshot().sequence;
                                    service.complete_window_navigation(label, &tokens)?;
                                    let snapshot = service.snapshot();
                                    if snapshot.sequence != before {
                                        app.emit("extension://changed", &snapshot)
                                            .map_err(|e| error("eventDelivery", e.to_string()))?;
                                    }
                                }
                            }
                        }
                        Ok(())
                    })
                })();
                if let Err(error) = result {
                    eprintln!("extension navigation cleanup failed: {error}");
                }
            }
        })
        .on_event(|app, event| {
            if let tauri::RunEvent::WindowEvent {
                label,
                event: tauri::WindowEvent::Destroyed,
                ..
            } = event
                && let Some(state) = app.try_state::<ExtensionService>()
            {
                let result = (|| -> Result<(), ServiceError> {
                    state
                        .grants
                        .lock()
                        .map_err(|_| error("poisoned", "grant lock poisoned"))?
                        .retain(|g| g.window != *label);
                    state.with_service(|service| {
                        let before = service.snapshot().sequence;
                        service.close_window(label)?;
                        let snapshot = service.snapshot();
                        if before != snapshot.sequence {
                            app.emit("extension://changed", &snapshot)
                                .map_err(|e| error("eventDelivery", e.to_string()))?;
                        }
                        Ok(())
                    })
                })();
                if let Err(error) = result {
                    eprintln!("extension window destruction failed: {error}");
                }
            }
        })
        .build()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn corrupt_storage_initializes_plugin_state_but_commands_keep_the_original_error() {
        let root = tempfile::tempdir().unwrap();
        std::fs::write(root.path().join("state.json"), "broken state").unwrap();
        let original = Service::open(root.path())
            .err()
            .expect("core must still reject corrupt state");
        let state = ExtensionService::initialize(Ok(root.path().to_path_buf()));
        for _ in 0..2 {
            let observed = state
                .with_service(|service| service.dispatch("main", Request::Snapshot))
                .unwrap_err();
            assert_eq!(observed.code, original.code);
            assert_eq!(observed.message, original.message);
        }
        let resource_error = state
            .with_service(|service| service.resource_for_window("main", "missing-token", "main.js"))
            .unwrap_err();
        assert_eq!(resource_error.code, original.code);
        assert_eq!(resource_error.message, original.message);
        assert_eq!(
            std::fs::read_to_string(root.path().join("state.json")).unwrap(),
            "broken state"
        );
    }
    #[test]
    fn app_data_path_failure_is_preserved_for_command_access() {
        let state = ExtensionService::initialize(Err(error(
            "appDataPath",
            "host has no local data directory",
        )));
        let observed = state
            .with_service(|service| service.dispatch("main", Request::Snapshot))
            .unwrap_err();
        assert_eq!(observed.code, "appDataPath");
        assert_eq!(observed.message, "host has no local data directory");
    }
    #[test]
    fn local_install_grants_are_window_source_path_bound_and_single_use() {
        let root = tempfile::tempdir().unwrap();
        let chosen = tempfile::tempdir().unwrap();
        let other = tempfile::tempdir().unwrap();
        let state = ExtensionService {
            navigating: Mutex::new(Default::default()),
            service: Mutex::new(Service::open(root.path())),
            grants: Mutex::new(vec![InstallGrant {
                window: "main".into(),
                path: chosen.path().canonicalize().unwrap(),
                source: "local".into(),
            }]),
        };
        let request = |path: &Path, source: &str| Request::InstallLocal {
            path: path.display().to_string(),
            source: source.into(),
            expected_id: None,
            expected_version: None,
            expected_digest: None,
        };
        assert!(consume_grant(&state, "other", &request(chosen.path(), "local")).is_err());
        assert!(consume_grant(&state, "main", &request(chosen.path(), "market")).is_err());
        assert!(consume_grant(&state, "main", &request(other.path(), "local")).is_err());
        consume_grant(&state, "main", &request(chosen.path(), "local")).unwrap();
        assert!(consume_grant(&state, "main", &request(chosen.path(), "local")).is_err());
    }
}

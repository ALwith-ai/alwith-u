# @alwith/native-mobile

Precompiled mobile implementation. Install the optional package matching the host target and call `stageNative` from `@alwith/native-mobile/stage`.

The package contains no private Rust implementation sources.

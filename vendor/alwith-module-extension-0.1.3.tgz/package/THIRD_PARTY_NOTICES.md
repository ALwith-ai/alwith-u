# Third-party notices

The extension system's own sources are governed by LICENSE. JavaScript dependencies remain separately licensed and are installed through the package manager: semver (ISC), @babel/parser (MIT). React, React DOM (MIT) and @tauri-apps/api and @tauri-apps/plugin-http (Apache-2.0 OR MIT) are optional peer dependencies supplied by the host.

Rust dependencies are resolved from rust/Cargo.toml and rust/Cargo.lock. Their sources and licenses remain in their respective crates; consumers compiling the optional Tauri integration must include applicable notices with their application distribution. The extension system contains no copied Desktop business extension or native service implementation.

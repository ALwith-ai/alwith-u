# @alwith/module-extension

Reusable application extensions for ALwith desktop hosts. This package is separate from Codex plugins and skills. It contains no Desktop or U application imports and does not own agent sessions.

## Delivery

Install the npm package with Bun. The package includes compiled JavaScript, declarations, schemas and the extension system's Rust sources. A host compiles those Rust sources; ordinary extension bundles contain only JavaScript and static assets. See LICENSE for redistribution terms.

```toml
[dependencies]
alwith-extension = { path = "../node_modules/@alwith/module-extension/rust", features = ["tauri"] }
tauri-plugin-dialog = "2"
```

```rust
tauri::Builder::default()
    .plugin(tauri_plugin_dialog::init())
    .plugin(alwith_extension::plugin::init());
```

Grant `extension:default` only to participating windows in Tauri capabilities. Each such window creates one `createTauriExtensionRuntime` from `/tauri`, supplying application capability versions, actual service objects, author module mappings and an evaluator from `/host`. Call `start()` once per WebView; React StrictMode and page navigation are not instance ownership boundaries. Native destruction/navigation observation releases the old document's tokens. Do not release tokens merely because a window is hidden.

Main and settings windows can advertise the same application contributions while mounting different views. `/react` provides `useHostSnapshot` and `ExtensionView`; callers supply a container and error handler. Commands and surfaces are explicit host UI outlets. There are no automatic global listeners or DOM prototype patches. Native capabilities are opt-in; no filesystem capability is registered automatically.

The root SDK and `/host` can be imported without DOM, React, or Tauri. `/testing` supplies in-memory data for independent hosts. `/marketplace` is an optional validated catalogue, not a second installer. `/build` is a Bun author tool. React and Tauri are optional peers; the selected adapter requires the corresponding peer.

## Build an extension

```typescript
import { buildExtension } from "@alwith/module-extension/build"

await buildExtension({ sourceDirectory: "./my-extension", outputDirectory: "./build/my-extension" })
```

The source contains `manifest.json`, `main.tsx` and optional assets. The default export is a `defineExtension(context => ({ onload, onunload }))` factory. Register commands with `context.command` and views with `context.view("settings" | "surfaces" | "statusBar" | "settingsPages", view)`. Start rendering and background work in a view's mount hook. Register cancellation listeners and all cleanup with the provided owner.

The tool produces one CommonJS entry and records actual external imports in the manifest. It rejects unknown/dynamic requires, private host entrypoints, links and output overwrites. Only author SDK, DOM helpers, `mountReact`, shared React and JSX modules belong in the evaluator map. This execution model is for trusted same-context UI code, not a security sandbox.

`examples/portable` exercises commands, settings, a React surface and compare-and-swap data. Its manifest requires extension API `^0.1.0`. `examples/host` is an independent two-window Tauri consumer; it installs the packed tarball and never imports the U or Desktop source trees.

## State and errors

Native storage uses the application's local data directory under `extensions/`; hosts and development identifiers remain isolated. Native state selects an immutable package, installation identity and data generation. The service owns all writes; data writes require the expected revision and live instance token. Conflict, corruption, revoked instance and absent data are distinct results.

Activation awaits asynchronous hooks. Deactivation revokes new calls immediately, then awaits hooks and LIFO resource cleanup. Cleanup errors are aggregated. A hung hook remains hung; no timeout reports a false successful stop. Update, disable and uninstall commit only after every participating window releases its instance. Events carry full sequenced snapshots and a service identity; data changes notify subscribers without reloading code. Call `refresh()` on transport reconnection or window focus.

Use native `plugin:extension|pick_local` to grant a user-selected directory to the calling window, then request `installLocal` or an update transition through the runtime. Package resources use a scoped read-only URI scheme with real URL directories for relative CSS assets; no home-directory asset scope is required.

Uninstall retains installation source and data. Reinstall from a different source is rejected. The current native installer supports local directories; it deliberately rejects data schema changes with `migrationRequired`. ZIP/network installation, explicit data migrations/rollback, data clearing and package garbage collection are not yet implemented. Immutable old content is retained. Do not present this initial package as completion of the architecture document's full stability phase.

## Development and verification

From this directory in alwith-modules:

```sh
bun install
bun run test
bun run typecheck
bunx tsc -p tsconfig.core.json
bun run build
bun pm pack
cargo test --manifest-path rust/Cargo.toml --features tauri
cargo clippy --manifest-path rust/Cargo.toml --all-targets --features tauri -- -D warnings
```

Rust DTOs are the source of `src/tauri/protocol.ts` and schemas. Regenerate using `cargo run --manifest-path rust/Cargo.toml --bin generate-protocol`. Keep generated changes under review with their Rust source. Tests cover delayed activation, cancellation, cleanup failures, real bundled JSX, multiwindow CAS and stop barriers, content validation and storage failure recovery. Target-platform WebView behavior and power-loss behavior still require platform validation before a stable release or replacing Desktop.

## Optional native capabilities

The root SDK exports `httpCapability`, `notificationsCapability`, `externalLinksCapability` and `dialogsCapability`, plus DOM-free contracts. Each capability is version `1.0.0`. Extensions declare the corresponding IDs (`http`, `notifications`, `externalLinks`, `dialogs`) in manifest `capabilities.required` or `capabilities.optional`; declaration alone does not enable a service.

Hosts explicitly register providers from `@alwith/module-extension/tauri/capabilities`:

```typescript
import { httpCapability, dialogsCapability } from "@alwith/module-extension"
import { createTauriHttp, createTauriDialogs } from "@alwith/module-extension/tauri/capabilities"

const capabilities = {
  [httpCapability.id]: createTauriHttp({
    allowUrl: (url, _extensionId) => url.origin === "https://example.com",
    timeoutMs: 30_000,
    maxResponseBytes: 8 * 1024 * 1024
  }),
  [dialogsCapability.id]: createTauriDialogs()
}
// Supply capabilities to createTauriExtensionRuntime's options.
```

HTTP additionally requires the optional `@tauri-apps/plugin-http` JS peer (2.7+) and the host's matching Rust plugin. The HTTP peer loads only when a request is made. Other adapters use the existing Tauri API peer and await native commands directly. The host initializes the selected Rust plugins and configures native ACLs:

| Provider | Rust plugin | Permissions |
| --- | --- | --- |
| `createTauriHttp` | `tauri-plugin-http` | `http:default` with explicit URL allow scopes |
| `createTauriNotifications` | `tauri-plugin-notification` | `notification:default` |
| `createTauriExternalLinks` | `tauri-plugin-opener` | `opener:allow-open-url` with allowed URL scopes, or `opener:default` |
| `createTauriDialogs` | `tauri-plugin-dialog` 2.7+ | `dialog:allow-message` |

The extension package's Rust infrastructure is still shipped in `rust/` and compiled by the host. These adapters reuse host-linked native plugins; business extensions never gain a private Rust build. A non-Tauri host can implement the same contracts through a provider's `create(binding)` callback. Existing `{ version, value }` capability registrations remain supported, but a shared value does not automatically acquire lifecycle guards: use a binding factory for native or stateful services.

Providers are cached per activation, receive the manifest identity and cancellation, and register one completion barrier with the owner. Retained methods reject after revocation, including after reactivation of the same extension. Every pending operation is joined before normal owner cleanup finishes. Rejections remain observable on the original call; disposal does not report the same operation error a second time.

HTTP accepts text request bodies and returns status, final URL, headers and a UTF-8 text body. The default response limit is 8 MiB of bytes, with a 30-second timeout including reading. HTTP errors such as 404 remain responses; transport/ACL/limit errors reject. Automatic redirects are disabled: a 3xx response requires a new explicit request, checked against host policy again. Only HTTP(S) URLs without embedded credentials are accepted; the adapter does not inject host login tokens or expose unsafe TLS/proxy options. To avoid implicit shared authentication, hosts MUST disable the HTTP plugin's `cookies` Cargo feature (including defaults enabled transitively). The plugin ignores JS `credentials` and otherwise shares a cookie jar between the application and every extension. Check the resolved feature graph; a host that needs automatic cookies must supply a separate isolated transport instead. A caller may pass a view's `Cancellation` to end work when the view closes. Instance revocation, caller cancellation and timeout propagate to the plugin's AbortSignal. The upstream HTTP plugin handles native resource cancellation; its JS API does not provide an independently awaited cancellation acknowledgement, so this is not a hard guarantee of native network quiescence.

Notification permission requests are explicit; `send` never opens a permission prompt. Permission values reflect the plugin's report, not independently verified OS authorization: the current desktop backend reports granted without an OS permission query. `send` resolves when the native command accepts the request, not when the OS delivers or displays it. IPC and returned native-command errors propagate, but the upstream desktop backend may discard later OS delivery errors. Notifications prefix their title with the extension name. Link opening accepts only HTTP(S) URLs allowed by host policy and offers no executable or file-path option. Dialogs expose message and confirmation only, using the extension name as the title; they do not grant filesystem access. Native dialogs, already submitted notifications and browser launches cannot be undone by cancellation. Revocation rejects late successful results, and an open dialog keeps cleanup pending until the user closes it.

The evaluator and capability facade are lifecycle/convention boundaries for trusted extensions, not isolation from other JavaScript in the same WebView. Tauri ACLs remain window-scoped. Filesystem access, subprocesses, credentials, application login, Runtime sessions and business-specific native services belong to separately authorized host providers.

For a host that does not need automatic HTTP cookies (including U), preserve the other default transport features explicitly:

```toml
tauri-plugin-http = { version = "2.7", default-features = false, features = ["rustls-tls", "http2", "charset", "system-proxy"] }
```

Verify `cargo tree -e features -i tauri-plugin-http` contains neither `cookies` nor `default`. Cargo features unify across dependencies; setting `default-features = false` in only one dependency declaration is insufficient if another dependency re-enables cookies.


## Host UI outlets (0.1.1)

In addition to commands and surfaces, hosts can advertise these `1.0.0` contributions:

| Contribution | Registration | Host responsibility |
| --- | --- | --- |
| `topBar` | `context.action("topBar", action)` | Render a compact toolbar action |
| `navigation` | `context.action("navigation", action)` | Render a navigation entry |
| `statusBar` | `context.view("statusBar", view)` | Mount a compact persistent widget |
| `settingsPages` | `context.view("settingsPages", view)` | Render a settings column entry and mount its full page when selected |

Actions have `id`, `title`, optional `icon` and `order`, and `target: { type: "command" | "surface", id }`. Both action and target IDs must be local nonempty ASCII IDs containing only letters, digits, `.`, `_`, `-`. The host prefixes both with the extension ID, so an action cannot name another extension's contribution. Register the referenced command or surface as well; registration order is free. Targets may disappear independently, so host UIs must disable or hide actions without a current target. Execute commands through their guarded `run()` function; route surface targets through the host's navigation.

`HostSnapshot.actions` publishes actions only for active instances; stop/failure removes them along with views. Existing consumers of commands/views keep working. Main and settings windows may advertise all supported application contributions but only mount their actual local outlets. Lifecycle compatibility does not imply a view is rendered in every window.

Presentation metadata is optional on views and actions. `order` must be finite (host default 0); icon names are `blocks`, `play`, `panel`, `settings`, `clock`, `chart`, `globe`. `mountReact` preserves both fields. The package owns no application layout or UI toolkit. Dimensions, ordering, scrolling, empty-state behavior and placement remain host decisions. Put timers and subscriptions in mount scope and release them on unmount.

The `top-bar`, `navigation`, `status-bar`, and `settings-page` examples require extension API `^0.1.1`; build them along with the four existing entry examples using `bun run build:entry-examples <new-output-directory>`.


## Bar alignment (0.1.2)

`ContributionPresentation.alignment` accepts `"left" | "center" | "right"` for `topBar` actions and `statusBar` views. `mountReact` forwards it unchanged. Invalid values are rejected on registration. Navigation and settings/page outlets ignore alignment. Existing contributions remain compatible: U defaults omitted top-bar alignment to right and status-bar alignment to left.

U uses three equal-width groups in each bar's available space. Center is relative to that available space (after native controls, sidebar and version-info clearances), independent of side content width. Within each group, `order` is ascending from left to right, ties use the full contribution ID. A crowded group scrolls horizontally without displacing another group. Unoccupied toolbar space stays available for dragging the native window.

Declare extension engine `^0.1.2` when relying on alignment. The updated `top-bar` and `status-bar` examples (extension version 1.0.1) demonstrate all three positions.

## Contribution lifecycle and host helpers (0.1.3)

- `context.supportsContribution(kind)` checks the required/optional version range declared by this extension against the application's contribution support. Undeclared kinds and revoked instances throw. An unsupported optional contribution returns false; registration itself still rejects unsupported kinds. This is application support, not whether the current window has mounted an outlet.
- The disposer returned by `context.view()` synchronously removes that registration and cancels all its mounts. Await it to wait for every mount's asynchronous cleanup. Other views and the extension remain active. A new registration with the same ID has a separate lifetime.
- `/host` exports `resolveActionTarget(snapshot, action)` for ownership-aware command/surface lookup and `sortContributions(items)` for default order/ID sorting without mutating the input. Layout, routing and disabled/hidden presentation remain host responsibilities.
- `mountReact()` catches component rendering failures inside the extension root. `host.mount(id, container, cancellation?, onError?)` reports them as `ViewRenderError` with `extensionId`, `viewId` and `cause`; the instance diagnostic snapshot records the error without stopping unrelated views. `ExtensionView.onError` receives these errors too. The host renders its own local error/retry UI; remounting recreates the root. Errors reported after cancellation are ignored. This does not catch arbitrary asynchronous tasks or event-handler errors; extension code must handle or report those explicitly through the mount context's optional `reportError`.

The top-bar example requires API 0.1.3 and treats `topBar` as optional. Hosts without a top bar can still expose its required surface through their page navigation.

# Application extension native service

This crate ships as source inside `@alwith/module-extension`. Hosts compile it;
ordinary extension bundles contain JavaScript and assets only.

Version 0.1.1 targets Tauri 3 alpha (Tauri 2 hosts must use 0.1.0).
When using `tauri-plugin-dialog` 3.0.0-alpha.1 with Tauri 3.0.0-alpha.3,
the host must supply the dialog `Manager` import fix, as ALwith U does via
its root `[patch.crates-io]`. The package has no dependency on host source paths.

```toml
[dependencies]
alwith-extension = { path = "../node_modules/@alwith/module-extension/rust", features = ["tauri"] }
```

```rust,ignore
// Register dialog before extension; restrict extension:default to participating windows.
.plugin(tauri_plugin_dialog::init())
.plugin(alwith_extension::plugin::init())
```

The default root is `app_local_data_dir()/extensions`. `init_with_root(Some(path))`
allows a host-controlled override. One service owns each canonical root via an OS
file lock. The crate has its own workspace and no sibling source dependencies.

## Failed initialization

An unavailable app-local data path, root lock conflict, or corrupt extension state,
package or data does not abort the host application's Tauri startup. The plugin
keeps that initialization error in managed state. Commands (including the picker)
return its original structured `ServiceError`; private resource responses return
JSON errors, and native navigation/destruction callbacks log unavailable-service
errors. No empty service, alternate data root, or automatic data reset is created.
Repair the underlying issue and restart the application to initialize the service
again. Calling `Service::open` directly still returns the error normally.

## Contract

`Service::dispatch(window, Request)` is synchronous. Serialize access through a
mutex; Tauri does this and supplies its observed window identity. A host must never
accept a caller-provided window identity. `snapshot()` includes serviceId, durable
sequence, selected installations and pending stopping barriers. Generated wire
bindings and schemas come from `protocol.rs`:

```sh
cargo run --bin generate-protocol
cargo test
cargo clippy --all-targets --features tauri -- -D warnings
```

Tauri commands are `plugin:extension|dispatch` and `plugin:extension|pick_local`.
The picker returns a directory or null and authorizes one local-source attempt for
that window. A trusted native host can also call `plugin::grant_install`; never
expose it as an unrestricted JavaScript command. The shared default permission is
`extension:default`. The host must separately allow required core event APIs.

Every durable mutation emits `extension://changed` with a full Snapshot; reading
never emits. Consumers subscribe before requesting their first snapshot and
refresh after gaps, reconnect, or `eventDelivery` errors. Delivery errors mean the
state committed; do not blindly retry a mutation. Releasing an already absent
instance is idempotent (no sequence increment or event); a different window still
cannot release a live instance.

Resource URLs have the form `extension://localhost/<activationToken>/<path>`.
Use Tauri `convertFileSrc` with protocol `extension` for the appropriate platform
URL. The scheme resolves the native requesting WebviewWindow and its lease,
accepts decoded package-relative paths, rejects traversal and links, and serves
MIME types without opening an app-data filesystem scope. CSS relative URLs work
within that same token directory. Embedded multi-webview windows are not supported
by this initial protocol adapter.

`beginTransition` immediately revokes instance calls and blocks registration.
Each window runs its cleanup and then releases its token. `commitTransition` or
`abortTransition` requires every instance to be released. Closing merely hides a
window in some apps, so only native Destroyed events release it. For navigation,
Started captures outgoing tokens and Finished releases only those tokens. A new
page encountering `alreadyRegistered` can retry after the resulting snapshot.

## Manifest compatibility grammar

IDs match `^[a-z0-9][a-z0-9-]{0,63}$`. Wire version ranges use comparator
sets separated by whitespace (AND), with `||` between alternatives (OR).
Caret, tilde, wildcard and exact comparators are supported; Cargo commas,
empty alternatives and raw hyphen ranges are rejected. The package builder
normalizes npm input (including hyphen ranges) using `new semver.Range(range).range
|| "*"` before writing the manifest. Rust validates this wire grammar only;
TypeScript/npm semver remains authoritative for host/capability matching.
`schemas/manifest-compatibility.json` supplies shared cross-language fixtures.

## Persistence and current limits

Packages are canonical SHA-256 revisions over lexically sorted relative paths and
bytes (each UTF-8 path and body prefixed by little-endian u64 length). The digest
pins content; it does not authenticate a publisher. Local directory installs reject
links, special files, invalid manifests, missing entrypoints, mismatched requested
id/version/digest, more than 4096 files, more than 64 MiB, and depth over 64.

Storage layout v2 groups each extension's immutable bundles and mutable configuration:

```text
extensions/
  state.json
  <extensionId>/
    packages/<packageRevision>/  # manifest, code and bundled assets
    data/
      data.json                 # current configuration envelope
      .previous.json            # at most one recovery copy
  .legacy-v1/                   # preserved only when migrating layout v1
  .migration-v2/                # migration staging/recovery
  .staging/                     # package installation staging
```

State selects immutable package content and a configuration revision. `data.json`
stores installationId, generation, schemaVersion, revision and value. Writes validate
lease, generation, schema and expectedRevision inside the same serialization boundary.
The previously selected value is flushed to `.previous.json`, then the new value to
`data.json`, before atomic state replacement selects it. An uncertain write poisons
the service until reopen. Recovery restores the previous value only when state still
selects it and the current file is exactly the next prepared revision; malformed or
mismatched configuration fails explicitly. Normal writes retain at most two config
files, rather than accumulating every historical revision.

Opening layout v1 validates and stages all selected packages and data before switching
state to version 2. The old `packages/`, `data/` and state are preserved under
`.legacy-v1/`; directory promotion resumes after interruption. Installation identities,
sources, disabled states and data revisions are retained, including uninstalled records.
Old binaries reject state version 2. The archive is not an automatic rollback mechanism;
do not replace state alone or delete the archive while migrating. This migration only
covers this package's v1 layout, not ALwith Desktop's original extension system.
On restart, pending transitions revert to the old selection, all leases expire,
and selected package/data corruption is reported. Uninstall retains source,
installation identity and data; another source cannot acquire that identity.

This version intentionally has no ZIP/network installer, schema migrations,
rollback/data restore API, data purge, package garbage collector, signing or
malicious-extension sandbox. Schema-changing updates/reinstalls return
`migrationRequired`. Unselected complete packages and archived v1 data are retained.

Tests cover macOS local-filesystem commits and injected state replacement failure.
Unix directory fsync is performed; power loss and Windows/Linux filesystem behavior
need target-platform testing. The UI/window lifecycle integration still requires
real WebView validation; core tests do not substitute for that.

## Manifest v3 / crate 0.1.0

The package, SDK API and crate share the 0.1.0 development baseline. All current
features are retained; the next patch is 0.1.1. Manifest and protocol versions,
capability/contribution versions and host constraints remain independent.

The only runtime requirements are `dependencies` (exactly the `@alwith/module-extension` SDK range) and optional `hosts` (host ID → version range). `manifestVersion`, `entry`, `hosts`, and `dataSchemaVersion` default to 3, `main.js`, `{}`, and 1. Unknown/old fields and explicit manifest version 2 are rejected. This includes old manifests serialized in a development state file: they are not silently converted or deleted. Layout migration is independent of manifest compatibility. The host performs SDK/host matching; native code validates identities, ranges, package paths and data identity/schema rules.

Optional `locales` maps supported language codes to objects containing `name`,
`description`, or both. Codes match `^[A-Za-z]{2,8}(-[A-Za-z0-9]{1,8})*$` against
the original ASCII spelling; this is not full BCP 47 validation. Language keys
must be unique ignoring ASCII case. Every supplied localized string must be
nonblank using ECMAScript trim rules. Unknown entry fields, explicit nulls, and
non-object entries are rejected. An empty locales map is allowed.

Omitted locales stay omitted; language key casing and string whitespace survive
installation, snapshots, disabled states, and restart. Updating with a manifest
without locales clears previous translations. Top-level metadata is default text;
`%key%` text is literal. JSON resources are ordinary package resources, with no
NLS loading or snapshot cache. The native service never rewrites author files,
and package hashing covers their original bytes.

Optional `icon` accepts an absolute HTTP(S) image URL or one of `lucide:blocks`,
`lucide:play`, `lucide:panel`, `lucide:settings`, `lucide:clock`, `lucide:chart`,
and `lucide:globe`. Lucide names are exact and lowercase; whitespace and unknown
names are rejected. `authorUrl` remains HTTP(S)-only. Network URLs still reject
credentials, surrounding whitespace, control characters, and backslashes.

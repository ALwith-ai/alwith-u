//! Wire types are the source of the JSON schema and TypeScript bindings.
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

fn one() -> u32 {
    1
}
fn manifest_version() -> u32 {
    3
}
fn default_entry() -> String {
    "main.js".into()
}
// Missing metadata stays absent; an explicit null must not deserialize as None.
fn optional_string<'de, D>(deserializer: D) -> Result<Option<String>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    String::deserialize(deserializer).map(Some)
}
fn optional_locales<'de, D>(
    deserializer: D,
) -> Result<Option<BTreeMap<String, ManifestLocale>>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    let values = BTreeMap::<String, serde_json::Value>::deserialize(deserializer)?;
    values
        .into_iter()
        .map(|(language, value)| {
            // Serde structs also accept sequences; locale entries must be JSON objects.
            if !value.is_object() {
                return Err(serde::de::Error::custom("locale entries must be objects"));
            }
            serde_json::from_value(value)
                .map(|locale| (language, locale))
                .map_err(serde::de::Error::custom)
        })
        .collect::<Result<BTreeMap<_, _>, _>>()
        .map(Some)
}
#[derive(Clone, Debug, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ManifestLocale {
    #[serde(
        default,
        deserialize_with = "optional_string",
        skip_serializing_if = "Option::is_none"
    )]
    #[schemars(with = "String")]
    pub name: Option<String>,
    #[serde(
        default,
        deserialize_with = "optional_string",
        skip_serializing_if = "Option::is_none"
    )]
    #[schemars(with = "String")]
    pub description: Option<String>,
}
#[derive(Clone, Debug, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Manifest {
    #[serde(default = "manifest_version")]
    pub manifest_version: u32,
    pub id: String,
    pub name: String,
    pub version: String,
    #[serde(
        default,
        deserialize_with = "optional_string",
        skip_serializing_if = "Option::is_none"
    )]
    #[schemars(with = "String")]
    pub description: Option<String>,
    #[serde(
        default,
        deserialize_with = "optional_string",
        skip_serializing_if = "Option::is_none"
    )]
    #[schemars(with = "String")]
    pub author: Option<String>,
    #[serde(
        default,
        deserialize_with = "optional_string",
        skip_serializing_if = "Option::is_none"
    )]
    #[schemars(with = "String")]
    pub author_url: Option<String>,
    #[serde(
        default,
        deserialize_with = "optional_string",
        skip_serializing_if = "Option::is_none"
    )]
    #[schemars(with = "String")]
    pub icon: Option<String>,
    #[serde(
        default,
        deserialize_with = "optional_locales",
        skip_serializing_if = "Option::is_none"
    )]
    #[schemars(with = "BTreeMap<String, ManifestLocale>")]
    pub locales: Option<BTreeMap<String, ManifestLocale>>,
    #[serde(default = "default_entry")]
    pub entry: String,
    pub dependencies: BTreeMap<String, String>,
    #[serde(default)]
    pub hosts: BTreeMap<String, String>,
    #[serde(default = "one")]
    pub data_schema_version: u32,
}
#[derive(Clone, Debug, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Installation {
    pub id: String,
    pub manifest: Manifest,
    pub source: String,
    pub installation_id: String,
    pub package_revision: String,
    pub data_generation: u32,
    pub enabled: bool,
}
#[derive(Clone, Debug, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ActivationToken {
    pub token: String,
    pub installation_id: String,
    pub package_revision: String,
    pub data_generation: u32,
}
#[derive(Clone, Debug, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct DataSnapshot {
    pub generation: u32,
    pub schema_version: u32,
    pub revision: u32,
    pub value: serde_json::Value,
}
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "camelCase")]
pub enum TransitionAction {
    Disable,
    Update,
    Uninstall,
}
#[derive(Clone, Debug, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PendingTransition {
    pub id: String,
    pub action: TransitionAction,
    pub waiting_instances: u32,
}
#[derive(Clone, Debug, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Snapshot {
    pub service_id: String,
    pub protocol_version: u32,
    pub sequence: u32,
    pub installations: Vec<Installation>,
    pub pending: Vec<PendingTransition>,
}
#[derive(Clone, Debug, Serialize, Deserialize, JsonSchema)]
#[serde(
    tag = "type",
    rename_all = "camelCase",
    rename_all_fields = "camelCase",
    deny_unknown_fields
)]
pub enum Request {
    Snapshot,
    InstallLocal {
        path: String,
        source: String,
        #[serde(rename = "expectedId")]
        expected_id: Option<String>,
        #[serde(rename = "expectedVersion")]
        expected_version: Option<String>,
        #[serde(rename = "expectedDigest")]
        expected_digest: Option<String>,
    },
    Enable {
        id: String,
    },
    BeginTransition {
        id: String,
        action: TransitionAction,
        path: Option<String>,
        source: Option<String>,
        #[serde(rename = "expectedDigest")]
        expected_digest: Option<String>,
    },
    CommitTransition {
        id: String,
    },
    AbortTransition {
        id: String,
    },
    Register {
        id: String,
    },
    Release {
        token: String,
    },
    ReadData {
        token: String,
    },
    WriteData {
        token: String,
        generation: u32,
        #[serde(rename = "expectedRevision")]
        expected_revision: Option<u32>,
        #[serde(rename = "schemaVersion")]
        schema_version: u32,
        value: serde_json::Value,
    },
    ReadResource {
        token: String,
        path: String,
    },
}
#[derive(Clone, Debug, Serialize, Deserialize, JsonSchema)]
#[serde(
    tag = "type",
    rename_all = "camelCase",
    rename_all_fields = "camelCase",
    deny_unknown_fields
)]
pub enum Response {
    Snapshot { snapshot: Snapshot },
    Installation { installation: Box<Installation> },
    Token { activation: ActivationToken },
    Data { data: Option<DataSnapshot> },
    Resource { bytes: Vec<u8>, mime: String },
    Ok,
}
#[derive(Clone, Debug, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ServiceError {
    pub code: String,
    pub message: String,
}
impl std::fmt::Display for ServiceError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}: {}", self.code, self.message)
    }
}
impl std::error::Error for ServiceError {}
impl From<std::io::Error> for ServiceError {
    fn from(error: std::io::Error) -> Self {
        Self {
            code: "io".into(),
            message: error.to_string(),
        }
    }
}
impl From<serde_json::Error> for ServiceError {
    fn from(error: serde_json::Error) -> Self {
        Self {
            code: "invalidJson".into(),
            message: error.to_string(),
        }
    }
}

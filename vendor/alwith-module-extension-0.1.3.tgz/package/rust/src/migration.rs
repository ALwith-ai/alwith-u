//! Stage and validate before changing authority. Layout v1 remains archived, never deleted.
use crate::{
    Service, ServiceError, atomic_json, durable_directories, error, package, storage,
    sync_directory,
};
use serde::{Deserialize, Serialize};
use std::fs;

#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct LegacyMigration {
    packages: bool,
    data: bool,
}
impl Service {
    pub(crate) fn migrate_layout(&mut self) -> Result<(), ServiceError> {
        if self.state.version == 1 {
            // Validate every selected value before any source directory is moved.
            for record in self.state.records.values() {
                if record.installed {
                    let package = package::read(
                        &self
                            .root
                            .join("packages")
                            .join(&record.installation.id)
                            .join(&record.installation.package_revision),
                    )?;
                    if package.digest != record.installation.package_revision
                        || serde_json::to_value(package.manifest)?
                            != serde_json::to_value(&record.installation.manifest)?
                    {
                        return Err(error(
                            "corruptPackage",
                            "selected legacy package verification failed",
                        ));
                    }
                }
                storage::read_legacy(&self.root, record)?;
                if !["packages", "data"].contains(&record.installation.id.as_str())
                    && self.root.join(&record.installation.id).try_exists()?
                {
                    return Err(error(
                        "migrationConflict",
                        "destination extension directory already exists",
                    ));
                }
            }
            let staging = self.root.join(".migration-v2");
            storage::check_directory(&staging)?;
            durable_directories(&staging)?;
            for record in self.state.records.values() {
                durable_directories(&storage::directory(&staging, &record.installation.id)?)?;
                if record.installed {
                    package::prepare(
                        &staging,
                        &self
                            .root
                            .join("packages")
                            .join(&record.installation.id)
                            .join(&record.installation.package_revision),
                        Some(&record.installation.id),
                        Some(&record.installation.manifest.version),
                        Some(&record.installation.package_revision),
                    )?;
                }
                if let Some(data) = storage::read_legacy(&self.root, record)? {
                    storage::seed(&staging, record, data)?;
                }
            }
            let backup = self.root.join(".legacy-v1");
            storage::check_directory(&backup)?;
            durable_directories(&backup)?;
            if backup.join("packages").try_exists()? || backup.join("data").try_exists()? {
                return Err(error(
                    "migrationConflict",
                    "legacy archive already contains a previous layout",
                ));
            }
            atomic_json(&backup.join("state.json"), &self.state)?;
            let mut next = self.state.clone();
            next.version = 2;
            next.migration = Some(LegacyMigration {
                packages: self.root.join("packages").try_exists()?,
                data: self.root.join("data").try_exists()?,
            });
            // Older binaries reject version 2 before any legacy paths are relocated.
            self.commit(next)?;
        }
        if let Some(migration) = self.state.migration.clone() {
            let backup = self.root.join(".legacy-v1");
            let staging = self.root.join(".migration-v2");
            storage::check_directory(&backup)?;
            storage::check_directory(&staging)?;
            for (name, existed) in [("packages", migration.packages), ("data", migration.data)] {
                if existed && !backup.join(name).try_exists()? {
                    storage::check_directory(&self.root.join(name))?;
                    fs::rename(self.root.join(name), backup.join(name))?;
                    sync_directory(&backup)?;
                    sync_directory(&self.root)?;
                }
            }
            for record in self.state.records.values() {
                let id = &record.installation.id;
                let prepared = storage::directory(&staging, id)?;
                let target = storage::directory(&self.root, id)?;
                if prepared.try_exists()? {
                    if target.try_exists()? {
                        return Err(error(
                            "migrationConflict",
                            "destination extension directory already exists",
                        ));
                    }
                    fs::rename(&prepared, &target)?;
                    sync_directory(&staging)?;
                    sync_directory(&self.root)?;
                }
            }
            self.validate_layout()?;
            let mut next = self.state.clone();
            next.migration = None;
            self.commit(next)?;
        }
        Ok(())
    }
    pub(crate) fn validate_layout(&self) -> Result<(), ServiceError> {
        for record in self.state.records.values() {
            let i = &record.installation;
            if record.installed {
                let package = package::read(&storage::package_path(
                    &self.root,
                    &i.id,
                    &i.package_revision,
                )?)?;
                if package.digest != i.package_revision
                    || serde_json::to_value(package.manifest)? != serde_json::to_value(&i.manifest)?
                {
                    return Err(error(
                        "corruptPackage",
                        "selected package verification failed",
                    ));
                }
            }
            storage::recover(&self.root, record)?;
        }
        Ok(())
    }
}

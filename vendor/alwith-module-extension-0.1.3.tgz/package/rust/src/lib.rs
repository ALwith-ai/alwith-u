//! Shared, process-local authority for package selection, activation leases and CAS data.
//! A service owns its root exclusively. Hosts serialize calls through a mutex.
mod migration;
mod package;
#[cfg(feature = "tauri")]
pub mod plugin;
pub mod protocol;
mod storage;
pub use protocol::*;
use serde::{Deserialize, Serialize};
use std::{
    collections::BTreeMap,
    fs::{self, File, OpenOptions},
    io::Write,
    path::{Path, PathBuf},
};

pub(crate) fn error(code: impl Into<String>, message: impl Into<String>) -> ServiceError {
    ServiceError {
        code: code.into(),
        message: message.into(),
    }
}
pub(crate) fn sync_directory(path: &Path) -> Result<(), ServiceError> {
    #[cfg(unix)]
    File::open(path)?.sync_all()?;
    #[cfg(not(unix))]
    let _ = path;
    Ok(())
}
pub(crate) fn durable_directories(path: &Path) -> Result<(), ServiceError> {
    if path.is_dir() {
        return Ok(());
    }
    let parent = path.parent().filter(|p| !p.as_os_str().is_empty());
    if let Some(parent) = parent {
        durable_directories(parent)?;
    }
    match fs::create_dir(path) {
        Ok(()) => {}
        Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists && path.is_dir() => {}
        Err(error) => return Err(error.into()),
    }
    // Flush the directory entry in its parent, not just the new directory itself.
    if let Some(parent) = parent {
        sync_directory(parent)?;
    }
    Ok(())
}
fn atomic_json(path: &Path, value: &impl Serialize) -> Result<(), ServiceError> {
    let parent = path
        .parent()
        .ok_or_else(|| error("invalidPath", "missing parent"))?;
    durable_directories(parent)?;
    let mut temporary = tempfile::NamedTempFile::new_in(parent)?;
    serde_json::to_writer(&mut temporary, value)?;
    temporary.flush()?;
    temporary.as_file().sync_all()?;
    temporary.persist(path).map_err(|e| e.error)?;
    sync_directory(parent)
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Record {
    installation: Installation,
    installed: bool,
    data_revision: Option<u32>,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Transition {
    action: TransitionAction,
    replacement: Option<Installation>,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct State {
    version: u32,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    migration: Option<migration::LegacyMigration>,
    sequence: u32,
    records: BTreeMap<String, Record>,
    pending: BTreeMap<String, Transition>,
}
impl Default for State {
    fn default() -> Self {
        Self {
            version: 2,
            migration: None,
            sequence: 0,
            records: BTreeMap::new(),
            pending: BTreeMap::new(),
        }
    }
}
struct Lease {
    window: String,
    id: String,
    activation: ActivationToken,
    revoked: bool,
}
pub struct Service {
    service_id: String,
    _lock: File,
    root: PathBuf,
    state: State,
    leases: BTreeMap<String, Lease>,
    poisoned: bool,
}
impl Service {
    pub fn open(root: impl AsRef<Path>) -> Result<Self, ServiceError> {
        durable_directories(root.as_ref())?;
        let root = root.as_ref().canonicalize()?;
        let lock = OpenOptions::new()
            .create(true)
            .truncate(false)
            .read(true)
            .write(true)
            .open(root.join(".lock"))?;
        lock.try_lock()
            .map_err(|e| error("rootLocked", e.to_string()))?;
        let state = match fs::read(root.join("state.json")) {
            Ok(bytes) => serde_json::from_slice(&bytes)?,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
                for entry in fs::read_dir(&root)? {
                    let entry = entry?;
                    let name = entry.file_name();
                    // A killed first atomic write may leave a NamedTempFile, but
                    // package/data directories without authority must never reset.
                    let temporary =
                        name.to_string_lossy().starts_with(".tmp") && entry.file_type()?.is_file();
                    if name != ".lock" && !temporary {
                        return Err(error(
                            "corruptState",
                            "authoritative state is missing from an initialized root",
                        ));
                    }
                }
                let initial = State::default();
                atomic_json(&root.join("state.json"), &initial)?;
                initial
            }
            Err(e) => return Err(e.into()),
        };
        let mut service = Self {
            service_id: uuid::Uuid::new_v4().to_string(),
            _lock: lock,
            root,
            state,
            leases: BTreeMap::new(),
            poisoned: false,
        };
        if ![1, 2].contains(&service.state.version) {
            return Err(error("protocolMismatch", "unsupported state version"));
        }
        for (id, record) in &service.state.records {
            let i = &record.installation;
            if id != &i.id
                || !package::valid_id(id)
                || uuid::Uuid::parse_str(&i.installation_id).is_err()
                || i.data_generation == 0
                || i.package_revision.len() != 64
                || !i.package_revision.bytes().all(|v| v.is_ascii_hexdigit())
            {
                return Err(error("corruptState", "invalid installation identity"));
            }
        }
        service.migrate_layout()?;
        service.validate_layout()?;
        // A restarted process has no surviving in-process instances. Uncommitted
        // transitions restore the previous selection without replaying any work.
        if !service.state.pending.is_empty() {
            let mut next = service.state.clone();
            next.pending.clear();
            service.commit(next)?;
        }
        Ok(service)
    }
    fn commit(&mut self, mut next: State) -> Result<(), ServiceError> {
        next.sequence = self
            .state
            .sequence
            .checked_add(1)
            .ok_or_else(|| error("overflow", "sequence exhausted"))?;
        if let Err(e) = atomic_json(&self.root.join("state.json"), &next) {
            self.poisoned = true;
            return Err(e);
        }
        self.state = next;
        Ok(())
    }
    pub fn snapshot(&self) -> Snapshot {
        Snapshot {
            service_id: self.service_id.clone(),
            protocol_version: 1,
            sequence: self.state.sequence,
            installations: self
                .state
                .records
                .values()
                .filter(|r| r.installed)
                .map(|r| r.installation.clone())
                .collect(),
            pending: self
                .state
                .pending
                .iter()
                .map(|(id, t)| PendingTransition {
                    id: id.clone(),
                    action: t.action.clone(),
                    waiting_instances: self.leases.values().filter(|l| &l.id == id).count() as u32,
                })
                .collect(),
        }
    }
    fn record(&self, id: &str) -> Result<&Record, ServiceError> {
        self.state
            .records
            .get(id)
            .filter(|r| r.installed)
            .ok_or_else(|| error("notInstalled", "extension is not installed"))
    }
    fn eligible(&self, window: &str, token: &str) -> Result<&Record, ServiceError> {
        let lease = self
            .leases
            .get(token)
            .filter(|l| l.window == window && !l.revoked)
            .ok_or_else(|| {
                error(
                    "staleToken",
                    "instance is revoked or belongs to another window",
                )
            })?;
        let record = self.record(&lease.id)?;
        if record.installation.installation_id != lease.activation.installation_id
            || record.installation.package_revision != lease.activation.package_revision
            || record.installation.data_generation != lease.activation.data_generation
        {
            return Err(error("staleToken", "installation changed"));
        }
        Ok(record)
    }
    fn read_record_data(&self, record: &Record) -> Result<Option<DataSnapshot>, ServiceError> {
        storage::read(&self.root, record)
    }
    fn unchanged_schema(&self, old: &Record, manifest: &Manifest) -> Result<(), ServiceError> {
        if old.installation.manifest.data_schema_version != manifest.data_schema_version {
            return Err(error(
                "migrationRequired",
                "schema changes require an explicit data migration, unsupported by this service version",
            ));
        }
        Ok(())
    }
    pub fn dispatch(&mut self, window: &str, request: Request) -> Result<Response, ServiceError> {
        if self.poisoned {
            return Err(error(
                "restartRequired",
                "a durable commit failed; reopen service before further operations",
            ));
        }
        if window.is_empty() {
            return Err(error("invalidWindow", "window identity is required"));
        }
        match request {
            Request::Snapshot => Ok(Response::Snapshot {
                snapshot: self.snapshot(),
            }),
            Request::InstallLocal {
                path,
                source,
                expected_id,
                expected_version,
                expected_digest,
            } => {
                if source.trim().is_empty() {
                    return Err(error("invalidSource", "source identity is required"));
                }
                let (manifest, package_revision) = package::prepare(
                    &self.root,
                    Path::new(&path),
                    expected_id.as_deref(),
                    expected_version.as_deref(),
                    expected_digest.as_deref(),
                )?;
                let id = manifest.id.clone();
                let (installation_id, data_generation, data_revision) = if let Some(old) =
                    self.state.records.get(&id)
                {
                    if old.installation.source != source {
                        return Err(error("sourceMismatch", "id belongs to a different source"));
                    }
                    if old.installed {
                        return Err(error("alreadyInstalled", "use an update transition"));
                    }
                    self.unchanged_schema(old, &manifest)?;
                    (
                        old.installation.installation_id.clone(),
                        old.installation.data_generation,
                        old.data_revision,
                    )
                } else {
                    (uuid::Uuid::new_v4().to_string(), 1, None)
                };
                let installation = Installation {
                    id: id.clone(),
                    manifest,
                    source,
                    installation_id,
                    package_revision,
                    data_generation,
                    enabled: false,
                };
                let mut next = self.state.clone();
                next.records.insert(
                    id,
                    Record {
                        installation: installation.clone(),
                        installed: true,
                        data_revision,
                    },
                );
                self.commit(next)?;
                Ok(Response::Installation {
                    installation: Box::new(installation),
                })
            }
            Request::Enable { id } => {
                if self.state.pending.contains_key(&id) {
                    return Err(error("transitionPending", "extension is stopping"));
                }
                self.record(&id)?;
                let mut next = self.state.clone();
                next.records.get_mut(&id).unwrap().installation.enabled = true;
                self.commit(next)?;
                Ok(Response::Installation {
                    installation: Box::new(self.record(&id)?.installation.clone()),
                })
            }
            Request::Register { id } => {
                let record = self.record(&id)?;
                if !record.installation.enabled || self.state.pending.contains_key(&id) {
                    return Err(error("activationBlocked", "extension disabled or stopping"));
                }
                if self
                    .leases
                    .values()
                    .any(|l| l.id == id && l.window == window)
                {
                    return Err(error("alreadyRegistered", "window already has an instance"));
                }
                let activation = ActivationToken {
                    token: uuid::Uuid::new_v4().to_string(),
                    installation_id: record.installation.installation_id.clone(),
                    package_revision: record.installation.package_revision.clone(),
                    data_generation: record.installation.data_generation,
                };
                self.leases.insert(
                    activation.token.clone(),
                    Lease {
                        window: window.into(),
                        id,
                        activation: activation.clone(),
                        revoked: false,
                    },
                );
                Ok(Response::Token { activation })
            }
            Request::Release { token } => {
                if self.leases.get(&token).is_some_and(|l| l.window != window) {
                    return Err(error("staleToken", "instance belongs to another window"));
                }
                if self.leases.remove(&token).is_none() {
                    // Cleanup acknowledgement can be retried after a lost response.
                    return Ok(Response::Ok);
                }
                // Snapshot ordering also covers barriers changed by instance release.
                self.commit(self.state.clone())?;
                Ok(Response::Ok)
            }
            Request::BeginTransition {
                id,
                action,
                path,
                source,
                expected_digest,
            } => {
                if self.state.pending.contains_key(&id) {
                    return Err(error("transitionPending", "extension already stopping"));
                }
                let old = self.record(&id)?.clone();
                let replacement = if action == TransitionAction::Update {
                    if source.as_deref() != Some(old.installation.source.as_str()) {
                        return Err(error(
                            "sourceMismatch",
                            "update source must match installation",
                        ));
                    }
                    let path = path.ok_or_else(|| {
                        error("invalidRequest", "update package path is required")
                    })?;
                    let (manifest, package_revision) = package::prepare(
                        &self.root,
                        Path::new(&path),
                        Some(&id),
                        None,
                        expected_digest.as_deref(),
                    )?;
                    self.unchanged_schema(&old, &manifest)?;
                    Some(Installation {
                        manifest,
                        package_revision,
                        ..old.installation
                    })
                } else {
                    None
                };
                let mut next = self.state.clone();
                next.pending.insert(
                    id.clone(),
                    Transition {
                        action,
                        replacement,
                    },
                );
                self.commit(next)?;
                for lease in self.leases.values_mut().filter(|l| l.id == id) {
                    lease.revoked = true;
                }
                Ok(Response::Snapshot {
                    snapshot: self.snapshot(),
                })
            }
            Request::CommitTransition { id } => {
                let transition = self
                    .state
                    .pending
                    .get(&id)
                    .ok_or_else(|| error("noTransition", "no transition to commit"))?
                    .clone();
                if self.leases.values().any(|l| l.id == id) {
                    return Err(error(
                        "notQuiescent",
                        "instances have not acknowledged cleanup",
                    ));
                }
                let mut next = self.state.clone();
                let record = next
                    .records
                    .get_mut(&id)
                    .ok_or_else(|| error("corruptState", "transition installation missing"))?;
                match transition.action {
                    TransitionAction::Disable => record.installation.enabled = false,
                    TransitionAction::Uninstall => {
                        record.installed = false;
                        record.installation.enabled = false;
                    }
                    TransitionAction::Update => {
                        record.installation = transition
                            .replacement
                            .ok_or_else(|| error("corruptState", "update package missing"))?
                    }
                }
                next.pending.remove(&id);
                self.commit(next)?;
                Ok(Response::Snapshot {
                    snapshot: self.snapshot(),
                })
            }
            Request::AbortTransition { id } => {
                if !self.state.pending.contains_key(&id) {
                    return Err(error("noTransition", "no transition to abort"));
                }
                if self.leases.values().any(|l| l.id == id) {
                    return Err(error(
                        "notQuiescent",
                        "revoked instances must finish cleanup before restarting",
                    ));
                }
                let mut next = self.state.clone();
                next.pending.remove(&id);
                self.commit(next)?;
                Ok(Response::Snapshot {
                    snapshot: self.snapshot(),
                })
            }
            Request::ReadData { token } => {
                let record = self.eligible(window, &token)?;
                Ok(Response::Data {
                    data: self.read_record_data(record)?,
                })
            }
            Request::WriteData {
                token,
                generation,
                expected_revision,
                schema_version,
                value,
            } => {
                let record = self.eligible(window, &token)?.clone();
                if generation != record.installation.data_generation {
                    return Err(error("staleGeneration", "data generation changed"));
                }
                if schema_version != record.installation.manifest.data_schema_version {
                    return Err(error(
                        "schemaMismatch",
                        "schema version differs from manifest",
                    ));
                }
                if expected_revision != record.data_revision {
                    return Err(error("conflict", "data revision changed"));
                }
                // A corrupt selected record must never be mistaken for absent data.
                self.read_record_data(&record)?;
                let revision = record
                    .data_revision
                    .unwrap_or(0)
                    .checked_add(1)
                    .ok_or_else(|| error("overflow", "data revision exhausted"))?;
                let data = DataSnapshot {
                    generation,
                    schema_version,
                    revision,
                    value,
                };
                if let Err(error) = storage::save(&self.root, &record, data.clone()) {
                    self.poisoned = true;
                    return Err(error);
                }
                let mut next = self.state.clone();
                next.records
                    .get_mut(&record.installation.id)
                    .unwrap()
                    .data_revision = Some(revision);
                self.commit(next)?;
                Ok(Response::Data { data: Some(data) })
            }
            Request::ReadResource { token, path } => {
                let record = self.eligible(window, &token)?;
                let (bytes, mime) = package::resource(
                    &self.root,
                    &record.installation.id,
                    &record.installation.package_revision,
                    &path,
                )?;
                Ok(Response::Resource { bytes, mime })
            }
        }
    }
    /// Capture outgoing instances when the native webview starts navigation.
    pub fn capture_window_instances(&self, window: &str) -> Vec<String> {
        self.leases
            .iter()
            .filter(|(_, lease)| lease.window == window)
            .map(|(token, _)| token.clone())
            .collect()
    }
    /// Call only after the native webview reports that its new document loaded.
    /// New registrations created after the capture are intentionally retained.
    pub fn complete_window_navigation(
        &mut self,
        window: &str,
        tokens: &[String],
    ) -> Result<(), ServiceError> {
        let count = self.leases.len();
        self.leases
            .retain(|token, lease| lease.window != window || !tokens.contains(token));
        if count != self.leases.len() {
            self.commit(self.state.clone())?;
        }
        Ok(())
    }
    /// Only the native window-destroyed callback may confirm a lost window stopped.
    pub fn close_window(&mut self, window: &str) -> Result<(), ServiceError> {
        let count = self.leases.len();
        self.leases.retain(|_, lease| lease.window != window);
        if count != self.leases.len() {
            self.commit(self.state.clone())?;
        }
        Ok(())
    }
    /// Used by the private resource protocol after it derives the webview identity.
    pub fn resource_for_window(
        &self,
        window: &str,
        token: &str,
        path: &str,
    ) -> Result<(Vec<u8>, String), ServiceError> {
        if self.poisoned {
            return Err(error("restartRequired", "service must restart"));
        }
        let record = self.eligible(window, token)?;
        package::resource(
            &self.root,
            &record.installation.id,
            &record.installation.package_revision,
            path,
        )
    }
}

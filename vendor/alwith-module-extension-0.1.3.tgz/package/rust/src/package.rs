use crate::{Manifest, ServiceError, error};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    io::{Read, Write},
    path::{Component, Path},
};
type PackageFiles = BTreeMap<String, Vec<u8>>;
pub(crate) struct Package {
    pub manifest: Manifest,
    pub digest: String,
    files: PackageFiles,
}
const MAX_BYTES: u64 = 64 * 1024 * 1024;
const MAX_FILES: usize = 4096;

pub(crate) fn relative(path: &str) -> Result<&Path, ServiceError> {
    if path.is_empty()
        || path.contains(['\\', '\0', '%', ':'])
        || Path::new(path)
            .components()
            .any(|part| !matches!(part, Component::Normal(_)))
    {
        return Err(error("invalidPath", "expected a package-relative path"));
    }
    Ok(Path::new(path))
}
pub(crate) fn valid_id(id: &str) -> bool {
    id.as_bytes()
        .first()
        .is_some_and(|c| c.is_ascii_lowercase() || c.is_ascii_digit())
        && id.len() <= 64
        && id
            .bytes()
            .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == b'-')
}
fn validate_wire_range(range: &str) -> Result<(), ServiceError> {
    // Manifest ranges use npm comparator sets. Cargo comma syntax never crosses
    // the wire; only convert a single AND set for the Rust syntax parser.
    // Matching SDK and host versions remains the TypeScript host's authority.
    if range.contains(',') {
        return Err(error(
            "invalidManifest",
            "range comparators must be separated by whitespace",
        ));
    }
    for alternative in range.split("||") {
        let comparators = alternative.split_whitespace().collect::<Vec<_>>();
        if comparators.is_empty() {
            return Err(error(
                "invalidManifest",
                "range alternatives must not be empty",
            ));
        }
        semver::VersionReq::parse(&comparators.join(", "))
            .map_err(|e| error("invalidManifest", e.to_string()))?;
    }
    Ok(())
}
fn metadata_whitespace(character: char) -> bool {
    // Match ECMAScript trim: include BOM and exclude the Unicode next-line character.
    (character.is_whitespace() && character != '\u{0085}') || character == '\u{feff}'
}
fn valid_language_code(language: &str) -> bool {
    let mut parts = language.split('-');
    parts.next().is_some_and(|part| {
        (2..=8).contains(&part.len()) && part.bytes().all(|byte| byte.is_ascii_alphabetic())
    }) && parts.all(|part| {
        (1..=8).contains(&part.len()) && part.bytes().all(|byte| byte.is_ascii_alphanumeric())
    })
}
fn validate_network_url(value: &str) -> Result<(), ServiceError> {
    let has_http_prefix = value
        .get(..7)
        .is_some_and(|prefix| prefix.eq_ignore_ascii_case("http://"))
        || value
            .get(..8)
            .is_some_and(|prefix| prefix.eq_ignore_ascii_case("https://"));
    if value.trim_matches(metadata_whitespace) != value
        || value
            .chars()
            .any(|character| character.is_control() || character == '\\')
        || !has_http_prefix
    {
        return Err(error(
            "invalidManifest",
            "metadata URL must be an absolute HTTP(S) URL without whitespace, controls or backslashes",
        ));
    }
    let parsed = url::Url::parse(value).map_err(|e| error("invalidManifest", e.to_string()))?;
    if !parsed.has_host() || !parsed.username().is_empty() || parsed.password().is_some() {
        return Err(error(
            "invalidManifest",
            "metadata URL must have a host and no credentials",
        ));
    }
    Ok(())
}
pub(crate) fn validate(manifest: &Manifest) -> Result<(), ServiceError> {
    if manifest.manifest_version != 3
        || !valid_id(&manifest.id)
        || manifest.name.trim_matches(metadata_whitespace).is_empty()
        || manifest.data_schema_version == 0
    {
        return Err(error(
            "invalidManifest",
            "invalid manifest version, id, name or data schema",
        ));
    }
    for value in [
        &manifest.description,
        &manifest.author,
        &manifest.author_url,
        &manifest.icon,
    ]
    .into_iter()
    .flatten()
    {
        if value.trim_matches(metadata_whitespace).is_empty() {
            return Err(error(
                "invalidManifest",
                "metadata strings must not be empty",
            ));
        }
    }
    if let Some(author_url) = &manifest.author_url {
        validate_network_url(author_url)?;
    }
    if let Some(icon) = &manifest.icon {
        if let Some(name) = icon.strip_prefix("lucide:") {
            if !matches!(
                name,
                "blocks" | "play" | "panel" | "settings" | "clock" | "chart" | "globe"
            ) {
                return Err(error(
                    "invalidManifest",
                    "icon must use a supported lowercase lucide name",
                ));
            }
        } else {
            validate_network_url(icon)?;
        }
    }
    if let Some(locales) = &manifest.locales {
        let mut languages = BTreeSet::new();
        for (language, locale) in locales {
            if !valid_language_code(language) || !languages.insert(language.to_ascii_lowercase()) {
                return Err(error(
                    "invalidManifest",
                    "locales must use unique supported language codes (case-insensitive)",
                ));
            }
            if locale.name.is_none() && locale.description.is_none() {
                return Err(error(
                    "invalidManifest",
                    "locale entries must contain a name or description",
                ));
            }
            for value in [&locale.name, &locale.description].into_iter().flatten() {
                if value.trim_matches(metadata_whitespace).is_empty() {
                    return Err(error("invalidManifest", "locale strings must not be empty"));
                }
            }
        }
    }
    relative(&manifest.entry)?;
    semver::Version::parse(&manifest.version)
        .map_err(|e| error("invalidManifest", e.to_string()))?;
    if manifest.dependencies.len() != 1
        || !manifest
            .dependencies
            .contains_key("@alwith/module-extension")
    {
        return Err(error(
            "invalidManifest",
            "dependencies must contain only @alwith/module-extension",
        ));
    }
    if manifest.hosts.keys().any(|id| !valid_id(id)) {
        return Err(error("invalidManifest", "invalid host id"));
    }
    for range in manifest
        .dependencies
        .values()
        .chain(manifest.hosts.values())
    {
        validate_wire_range(range)?;
    }
    Ok(())
}
fn collect(
    root: &Path,
    path: &Path,
    files: &mut BTreeMap<String, Vec<u8>>,
    size: &mut u64,
) -> Result<(), ServiceError> {
    if path
        .strip_prefix(root)
        .map_err(|e| error("invalidPath", e.to_string()))?
        .components()
        .count()
        > 64
    {
        return Err(error(
            "packageTooLarge",
            "package nesting exceeds 64 levels",
        ));
    }
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() {
        return Err(error("invalidPackage", "symbolic links are not supported"));
    }
    if metadata.is_dir() {
        for entry in fs::read_dir(path)? {
            collect(root, &entry?.path(), files, size)?;
        }
    } else if metadata.is_file() {
        let relative_path = path
            .strip_prefix(root)
            .map_err(|e| error("invalidPath", e.to_string()))?
            .to_str()
            .ok_or_else(|| error("invalidPath", "non UTF-8 filename"))?
            .replace(std::path::MAIN_SEPARATOR, "/");
        relative(&relative_path)?;
        if files.len() >= MAX_FILES {
            return Err(error("packageTooLarge", "too many package files"));
        }
        let mut bytes = Vec::new();
        fs::File::open(path)?
            .take(MAX_BYTES + 1)
            .read_to_end(&mut bytes)?;
        *size += bytes.len() as u64;
        if *size > MAX_BYTES {
            return Err(error("packageTooLarge", "package exceeds 64 MiB"));
        }
        files.insert(relative_path, bytes);
    } else {
        return Err(error("invalidPackage", "special files are not supported"));
    }
    Ok(())
}
pub(crate) fn read(root: &Path) -> Result<Package, ServiceError> {
    if !fs::symlink_metadata(root)?.is_dir() {
        return Err(error("invalidPackage", "package must be a directory"));
    }
    let mut files = BTreeMap::new();
    collect(root, root, &mut files, &mut 0)?;
    let manifest: Manifest = serde_json::from_slice(
        files
            .get("manifest.json")
            .ok_or_else(|| error("invalidManifest", "manifest.json is missing"))?,
    )
    .map_err(|cause| error("invalidManifest", format!("manifest.json: {cause}")))?;
    validate(&manifest)?;
    if !files.contains_key(&manifest.entry) {
        return Err(error("invalidManifest", "entry is missing"));
    }
    let mut digest = Sha256::new();
    for (path, bytes) in &files {
        digest.update((path.len() as u64).to_le_bytes());
        digest.update(path.as_bytes());
        digest.update((bytes.len() as u64).to_le_bytes());
        digest.update(bytes);
    }
    Ok(Package {
        manifest,
        digest: format!("{:x}", digest.finalize()),
        files,
    })
}
pub(crate) fn prepare(
    root: &Path,
    source: &Path,
    expected_id: Option<&str>,
    expected_version: Option<&str>,
    expected_digest: Option<&str>,
) -> Result<(Manifest, String), ServiceError> {
    let Package {
        manifest,
        digest,
        files,
    } = read(source)?;
    if expected_id.is_some_and(|v| v != manifest.id)
        || expected_version.is_some_and(|v| v != manifest.version)
        || expected_digest.is_some_and(|v| v != digest)
    {
        return Err(error(
            "packageMismatch",
            "package id, version or digest differs from request",
        ));
    }
    let parent = crate::storage::directory(root, &manifest.id)?.join("packages");
    crate::storage::check_directory(&parent)?;
    crate::durable_directories(&parent)?;
    let destination = parent.join(&digest);
    if destination.exists() {
        let existing = read(&destination)?;
        if existing.digest != digest {
            return Err(error("corruptPackage", "immutable package was modified"));
        }
    } else {
        let staging = root.join(".staging");
        crate::durable_directories(&staging)?;
        let temporary = tempfile::tempdir_in(&staging)?;
        for (path, bytes) in files {
            let target = temporary.path().join(path);
            crate::durable_directories(
                target
                    .parent()
                    .ok_or_else(|| error("invalidPath", "missing parent"))?,
            )?;
            let mut file = fs::File::create(target)?;
            file.write_all(&bytes)?;
            file.sync_all()?;
        }
        sync_tree(temporary.path())?;
        fs::rename(temporary.path(), destination)?;
        crate::sync_directory(&parent)?;
    }
    Ok((manifest, digest))
}
fn sync_tree(path: &Path) -> Result<(), ServiceError> {
    for entry in fs::read_dir(path)? {
        let entry = entry?;
        if entry.file_type()?.is_dir() {
            sync_tree(&entry.path())?;
        }
    }
    crate::sync_directory(path)
}
pub(crate) fn resource(
    root: &Path,
    id: &str,
    revision: &str,
    path: &str,
) -> Result<(Vec<u8>, String), ServiceError> {
    let relative = relative(path)?;
    let package = crate::storage::package_path(root, id, revision)?;
    let mut target = package.clone();
    for part in relative.components() {
        target.push(part);
        if fs::symlink_metadata(&target)?.file_type().is_symlink() {
            return Err(error("invalidPath", "resource contains a symbolic link"));
        }
    }
    if !target.canonicalize()?.starts_with(package.canonicalize()?) {
        return Err(error("invalidPath", "resource escaped package"));
    }
    let bytes = fs::read(&target)?;
    let mime = match target.extension().and_then(|v| v.to_str()).unwrap_or("") {
        "js" | "cjs" | "mjs" => "text/javascript",
        "css" => "text/css",
        "json" => "application/json",
        "html" => "text/html",
        "svg" => "image/svg+xml",
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "gif" => "image/gif",
        "webp" => "image/webp",
        "woff" => "font/woff",
        "woff2" => "font/woff2",
        "ttf" => "font/ttf",
        "txt" => "text/plain",
        _ => "application/octet-stream",
    };
    Ok((bytes, mime.into()))
}

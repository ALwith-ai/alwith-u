//! Layout v2 groups immutable bundles and bounded configuration storage by extension.
use crate::{DataSnapshot, Record, ServiceError, atomic_json, error};
use serde::{Deserialize, Serialize};
use std::{
    fs,
    path::{Path, PathBuf},
};

pub(crate) fn directory(root: &Path, id: &str) -> Result<PathBuf, ServiceError> {
    if !crate::package::valid_id(id) {
        return Err(error("invalidPath", "invalid extension identity"));
    }
    let path = root.join(id);
    check_directory(&path)?;
    Ok(path)
}
pub(crate) fn check_directory(path: &Path) -> Result<(), ServiceError> {
    match fs::symlink_metadata(path) {
        Ok(metadata) if !metadata.is_dir() || metadata.file_type().is_symlink() => {
            Err(error("invalidPath", "expected a real directory"))
        }
        Ok(_) => Ok(()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(e) => Err(e.into()),
    }
}
pub(crate) fn package_path(root: &Path, id: &str, revision: &str) -> Result<PathBuf, ServiceError> {
    let parent = directory(root, id)?.join("packages");
    check_directory(&parent)?;
    Ok(parent.join(revision))
}
fn path(root: &Path, record: &Record, name: &str) -> Result<PathBuf, ServiceError> {
    let parent = directory(root, &record.installation.id)?.join("data");
    check_directory(&parent)?;
    Ok(parent.join(name))
}
#[derive(Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct StoredData {
    installation_id: String,
    #[serde(flatten)]
    snapshot: DataSnapshot,
}
fn document(record: &Record, snapshot: DataSnapshot) -> StoredData {
    StoredData {
        installation_id: record.installation.installation_id.clone(),
        snapshot,
    }
}
fn read_document(path: &Path, record: &Record) -> Result<DataSnapshot, ServiceError> {
    if fs::symlink_metadata(path)?.file_type().is_symlink() {
        return Err(error("invalidPath", "data links are unsupported"));
    }
    let stored: StoredData = serde_json::from_slice(&fs::read(path)?)?;
    if stored.installation_id != record.installation.installation_id {
        return Err(error("corruptData", "data belongs to another installation"));
    }
    validate(&stored.snapshot, record)?;
    Ok(stored.snapshot)
}
pub(crate) fn validate(data: &DataSnapshot, record: &Record) -> Result<(), ServiceError> {
    if data.generation != record.installation.data_generation
        || data.schema_version != record.installation.manifest.data_schema_version
    {
        return Err(error(
            "corruptData",
            "selected data metadata does not match state",
        ));
    }
    Ok(())
}
pub(crate) fn read(root: &Path, record: &Record) -> Result<Option<DataSnapshot>, ServiceError> {
    let Some(revision) = record.data_revision else {
        return Ok(None);
    };
    let data = read_document(&path(root, record, "data.json")?, record)?;
    if data.revision == revision {
        return Ok(Some(data));
    }
    // Only a prepared next revision can be abandoned by an interrupted state commit.
    if revision.checked_add(1) != Some(data.revision) {
        return Err(error("corruptData", "unexpected data revision"));
    }
    let previous = read_document(&path(root, record, ".previous.json")?, record)?;
    if previous.revision != revision {
        return Err(error("corruptData", "recovery data does not match state"));
    }
    Ok(Some(previous))
}
pub(crate) fn save(root: &Path, record: &Record, data: DataSnapshot) -> Result<(), ServiceError> {
    if let Some(previous) = read(root, record)? {
        atomic_json(
            &path(root, record, ".previous.json")?,
            &document(record, previous),
        )?;
    }
    seed(root, record, data)
}
pub(crate) fn seed(root: &Path, record: &Record, data: DataSnapshot) -> Result<(), ServiceError> {
    atomic_json(&path(root, record, "data.json")?, &document(record, data))
}
pub(crate) fn recover(root: &Path, record: &Record) -> Result<(), ServiceError> {
    if let Some(selected) = read(root, record)? {
        let current = read_document(&path(root, record, "data.json")?, record)?;
        if current.revision != selected.revision {
            seed(root, record, selected)?;
        }
    }
    Ok(())
}
pub(crate) fn read_legacy(
    root: &Path,
    record: &Record,
) -> Result<Option<DataSnapshot>, ServiceError> {
    let Some(revision) = record.data_revision else {
        return Ok(None);
    };
    let path = root
        .join("data")
        .join(&record.installation.installation_id)
        .join(record.installation.data_generation.to_string())
        .join(format!("{revision}.json"));
    let data: DataSnapshot = serde_json::from_slice(&fs::read(path)?)?;
    validate(&data, record)?;
    if data.revision != revision {
        return Err(error("corruptData", "legacy revision does not match state"));
    }
    Ok(Some(data))
}

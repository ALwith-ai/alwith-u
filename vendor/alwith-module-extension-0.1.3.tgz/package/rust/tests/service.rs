use alwith_extension::Service;
#[test]
fn opens_empty_root_and_rejects_second_owner() {
    let root = tempfile::tempdir().unwrap();
    let service = Service::open(root.path()).expect("empty service root opens");
    assert!(
        Service::open(root.path()).is_err(),
        "one process owner per root"
    );
    drop(service);
    assert!(
        Service::open(root.path()).is_ok(),
        "lock releases with service"
    );
}

use alwith_extension::{
    ActivationToken, Installation, Request, Response, Snapshot, TransitionAction,
};
use serde_json::json;
use std::fs;
fn package(version: &str) -> tempfile::TempDir {
    let dir = tempfile::tempdir().unwrap();
    fs::write(dir.path().join("manifest.json"), serde_json::to_vec(&json!({"id":"weather","name":"Weather","version":version,"dependencies":{"@alwith/module-extension":"^0.1.0"}})).unwrap()).unwrap();
    fs::write(
        dir.path().join("main.js"),
        format!("exports.version = '{version}';"),
    )
    .unwrap();
    dir
}
fn install(service: &mut Service, dir: &tempfile::TempDir, source: &str) -> Installation {
    let response = service
        .dispatch(
            "main",
            Request::InstallLocal {
                path: dir.path().display().to_string(),
                source: source.into(),
                expected_id: None,
                expected_version: None,
                expected_digest: None,
            },
        )
        .unwrap();
    let Response::Installation { installation } = response else {
        panic!("wrong response")
    };
    *installation
}
fn snapshot(service: &mut Service) -> Snapshot {
    let Response::Snapshot { snapshot } = service.dispatch("main", Request::Snapshot).unwrap()
    else {
        panic!("wrong response")
    };
    snapshot
}
fn register(service: &mut Service, window: &str) -> ActivationToken {
    let Response::Token { activation } = service
        .dispatch(
            window,
            Request::Register {
                id: "weather".into(),
            },
        )
        .unwrap()
    else {
        panic!("wrong response")
    };
    activation
}
fn begin(service: &mut Service, action: TransitionAction, path: Option<String>) {
    service
        .dispatch(
            "main",
            Request::BeginTransition {
                id: "weather".into(),
                action,
                path,
                source: Some("local".into()),
                expected_digest: None,
            },
        )
        .unwrap();
}
fn write(
    service: &mut Service,
    window: &str,
    token: &ActivationToken,
    expected: Option<u32>,
) -> Result<Response, alwith_extension::ServiceError> {
    service.dispatch(
        window,
        Request::WriteData {
            token: token.token.clone(),
            generation: token.data_generation,
            expected_revision: expected,
            schema_version: 1,
            value: json!({"city":"Taipei"}),
        },
    )
}
#[test]
fn install_persists_fixed_content_and_cas_data() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    assert!(!installed.enabled);
    assert!(
        service
            .dispatch(
                "main",
                Request::Register {
                    id: "weather".into()
                }
            )
            .is_err()
    );
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    assert!(matches!(
        service
            .dispatch(
                "main",
                Request::ReadData {
                    token: token.token.clone()
                }
            )
            .unwrap(),
        Response::Data { data: None }
    ));
    assert!(
        write(&mut service, "other", &token, None).is_err(),
        "window spoofing rejected"
    );
    let Response::Data { data: Some(data) } = write(&mut service, "main", &token, None).unwrap()
    else {
        panic!("missing data")
    };
    assert_eq!(data.revision, 1);
    assert_eq!(
        write(&mut service, "main", &token, None).unwrap_err().code,
        "conflict"
    );
    fs::write(pkg.path().join("main.js"), "changed source").unwrap();
    let Response::Resource { bytes, .. } = service
        .dispatch(
            "main",
            Request::ReadResource {
                token: token.token.clone(),
                path: "main.js".into(),
            },
        )
        .unwrap()
    else {
        panic!("missing resource")
    };
    assert_eq!(
        String::from_utf8(bytes).unwrap(),
        "exports.version = '1.0.0';"
    );
    let sequence = snapshot(&mut service).sequence;
    drop(service);
    let mut restored = Service::open(root.path()).unwrap();
    assert!(
        restored
            .dispatch("main", Request::ReadData { token: token.token })
            .is_err()
    );
    let next = register(&mut restored, "main");
    let Response::Data { data: Some(data) } = restored
        .dispatch("main", Request::ReadData { token: next.token })
        .unwrap()
    else {
        panic!("missing recovered data")
    };
    assert_eq!(data.value, json!({"city":"Taipei"}));
    assert!(snapshot(&mut restored).sequence >= sequence);
}
#[test]
fn update_waits_for_both_windows_and_revokes_old_tokens() {
    let root = tempfile::tempdir().unwrap();
    let v1 = package("1.0.0");
    let v2 = package("2.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let old = install(&mut service, &v1, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let a = register(&mut service, "main");
    let b = register(&mut service, "settings");
    begin(
        &mut service,
        TransitionAction::Update,
        Some(v2.path().display().to_string()),
    );
    assert_eq!(snapshot(&mut service).pending[0].waiting_instances, 2);
    assert!(write(&mut service, "main", &a, None).is_err());
    assert!(
        service
            .dispatch(
                "new",
                Request::Register {
                    id: "weather".into()
                }
            )
            .is_err()
    );
    assert!(
        service
            .dispatch(
                "main",
                Request::CommitTransition {
                    id: "weather".into()
                }
            )
            .is_err()
    );
    service
        .dispatch("main", Request::Release { token: a.token })
        .unwrap();
    assert!(
        service
            .dispatch(
                "main",
                Request::CommitTransition {
                    id: "weather".into()
                }
            )
            .is_err()
    );
    service.close_window("settings").unwrap();
    service
        .dispatch(
            "main",
            Request::CommitTransition {
                id: "weather".into(),
            },
        )
        .unwrap();
    let next = &snapshot(&mut service).installations[0];
    assert_eq!(next.manifest.version, "2.0.0");
    assert_eq!(next.installation_id, old.installation_id);
    assert!(next.enabled);
    assert!(write(&mut service, "settings", &b, None).is_err());
}
#[test]
fn uninstall_retains_identity_and_data_and_rejects_other_source() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    write(&mut service, "main", &token, None).unwrap();
    begin(&mut service, TransitionAction::Uninstall, None);
    service
        .dispatch("main", Request::Release { token: token.token })
        .unwrap();
    service
        .dispatch(
            "main",
            Request::CommitTransition {
                id: "weather".into(),
            },
        )
        .unwrap();
    assert!(snapshot(&mut service).installations.is_empty());
    assert!(
        service
            .dispatch(
                "main",
                Request::InstallLocal {
                    path: pkg.path().display().to_string(),
                    source: "registry".into(),
                    expected_id: None,
                    expected_version: None,
                    expected_digest: None
                }
            )
            .is_err()
    );
    let next = install(&mut service, &pkg, "local");
    assert_eq!(next.installation_id, installed.installation_id);
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    assert!(matches!(
        service
            .dispatch("main", Request::ReadData { token: token.token })
            .unwrap(),
        Response::Data { data: Some(_) }
    ));
}
#[test]
fn recovery_before_commit_keeps_old_selection() {
    let root = tempfile::tempdir().unwrap();
    let v1 = package("1.0.0");
    let v2 = package("2.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &v1, "local");
    begin(
        &mut service,
        TransitionAction::Update,
        Some(v2.path().display().to_string()),
    );
    drop(service);
    let mut service = Service::open(root.path()).unwrap();
    let state = snapshot(&mut service);
    assert_eq!(state.installations[0].manifest.version, "1.0.0");
    assert!(state.pending.is_empty());
}
#[test]
fn rejects_corrupt_state_and_selected_package() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    drop(service);
    fs::write(
        root.path()
            .join("weather/packages")
            .join(installed.package_revision)
            .join("main.js"),
        "corruption",
    )
    .unwrap();
    assert!(Service::open(root.path()).is_err());
    fs::write(root.path().join("state.json"), "not json").unwrap();
    assert!(Service::open(root.path()).is_err());
}
#[test]
fn rejects_package_symlinks_and_resource_escape() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    for path in [
        "../state.json",
        "/etc/passwd",
        "a/../../state.json",
        "a\\..\\state.json",
        "%2e%2e/state.json",
    ] {
        assert!(
            service
                .dispatch(
                    "main",
                    Request::ReadResource {
                        token: token.token.clone(),
                        path: path.into()
                    }
                )
                .is_err(),
            "{path}"
        );
    }
    #[cfg(unix)]
    {
        std::os::unix::fs::symlink("/etc/passwd", pkg.path().join("secret")).unwrap();
        assert!(
            service
                .dispatch(
                    "main",
                    Request::InstallLocal {
                        path: pkg.path().display().to_string(),
                        source: "local".into(),
                        expected_id: None,
                        expected_version: None,
                        expected_digest: None
                    }
                )
                .is_err()
        );
    }
}

#[test]
fn navigation_completion_releases_only_captured_instances() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let old = register(&mut service, "main");
    let captured = service.capture_window_instances("main");
    service
        .dispatch("main", Request::Release { token: old.token })
        .unwrap();
    let new = register(&mut service, "main");
    service
        .complete_window_navigation("main", &captured)
        .unwrap();
    assert!(write(&mut service, "main", &new, None).is_ok());
    let captured = service.capture_window_instances("main");
    service
        .complete_window_navigation("main", &captured)
        .unwrap();
    assert!(write(&mut service, "main", &new, Some(1)).is_err());
}

#[test]
fn validates_request_identity_digest_schema_and_missing_entry() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    for (id, version, digest) in [
        (Some("other"), None, None),
        (None, Some("2.0.0"), None),
        (None, None, Some("bad")),
    ] {
        let err = service
            .dispatch(
                "main",
                Request::InstallLocal {
                    path: pkg.path().display().to_string(),
                    source: "local".into(),
                    expected_id: id.map(str::to_owned),
                    expected_version: version.map(str::to_owned),
                    expected_digest: digest.map(str::to_owned),
                },
            )
            .unwrap_err();
        assert_eq!(err.code, "packageMismatch");
    }
    assert!(snapshot(&mut service).installations.is_empty());
    install(&mut service, &pkg, "local");
    let newer = package("2.0.0");
    let path = newer.path().join("manifest.json");
    let mut manifest: serde_json::Value =
        serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
    manifest["dataSchemaVersion"] = json!(2);
    fs::write(&path, serde_json::to_vec(&manifest).unwrap()).unwrap();
    let err = service
        .dispatch(
            "main",
            Request::BeginTransition {
                id: "weather".into(),
                action: TransitionAction::Update,
                path: Some(newer.path().display().to_string()),
                source: Some("local".into()),
                expected_digest: None,
            },
        )
        .unwrap_err();
    assert_eq!(err.code, "migrationRequired");
    assert!(snapshot(&mut service).pending.is_empty());
}
#[test]
fn data_corruption_is_error_not_first_run() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    write(&mut service, "main", &token, None).unwrap();
    fs::write(
        root.path().join(&installed.id).join("data/data.json"),
        "broken",
    )
    .unwrap();
    assert!(
        service
            .dispatch(
                "main",
                Request::ReadData {
                    token: token.token.clone()
                }
            )
            .is_err()
    );
    assert!(write(&mut service, "main", &token, Some(1)).is_err());
    drop(service);
    assert!(Service::open(root.path()).is_err());
}
#[test]
fn failed_state_commit_never_selects_prepared_data() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    write(&mut service, "main", &token, None).unwrap();
    // Force atomic state replacement to fail after the new data file is durable.
    fs::rename(
        root.path().join("state.json"),
        root.path().join("saved-state.json"),
    )
    .unwrap();
    fs::create_dir(root.path().join("state.json")).unwrap();
    assert!(write(&mut service, "main", &token, Some(1)).is_err());
    assert_eq!(
        service
            .dispatch("main", Request::Snapshot)
            .unwrap_err()
            .code,
        "restartRequired"
    );
    drop(service);
    fs::rename(
        root.path().join("state.json"),
        root.path().join("blocked-state"),
    )
    .unwrap();
    fs::rename(
        root.path().join("saved-state.json"),
        root.path().join("state.json"),
    )
    .unwrap();
    let mut service = Service::open(root.path()).unwrap();
    let token = register(&mut service, "main");
    let Response::Data { data: Some(data) } = service
        .dispatch("main", Request::ReadData { token: token.token })
        .unwrap()
    else {
        panic!("expected old data")
    };
    assert_eq!(data.revision, 1);
}

#[test]
fn rejects_excessively_nested_packages_before_recursive_stack_growth() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut nested = pkg.path().to_path_buf();
    for _ in 0..70 {
        nested = nested.join("d");
        fs::create_dir(&nested).unwrap();
    }
    let mut service = Service::open(root.path()).unwrap();
    let result = service.dispatch(
        "main",
        Request::InstallLocal {
            path: pkg.path().display().to_string(),
            source: "local".into(),
            expected_id: None,
            expected_version: None,
            expected_digest: None,
        },
    );
    assert_eq!(result.unwrap_err().code, "packageTooLarge");
}
#[test]
fn two_windows_competing_cas_only_one_commits() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let a = register(&mut service, "main");
    let b = register(&mut service, "settings");
    let service = std::sync::Arc::new(std::sync::Mutex::new(service));
    let start = std::sync::Arc::new(std::sync::Barrier::new(2));
    let tasks = [("main", a), ("settings", b)]
        .into_iter()
        .map(|(window, token)| {
            let service = service.clone();
            let start = start.clone();
            std::thread::spawn(move || {
                start.wait();
                write(&mut service.lock().unwrap(), window, &token, None)
            })
        })
        .collect::<Vec<_>>();
    let outcomes = tasks
        .into_iter()
        .map(|t| t.join().unwrap())
        .collect::<Vec<_>>();
    assert_eq!(outcomes.iter().filter(|r| r.is_ok()).count(), 1);
    assert_eq!(
        outcomes
            .iter()
            .filter_map(|r| r.as_ref().err())
            .next()
            .unwrap()
            .code,
        "conflict"
    );
}

#[test]
fn missing_authoritative_state_after_initialization_is_not_an_empty_installation() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    drop(service);
    fs::rename(
        root.path().join("state.json"),
        root.path().join("lost-state.json"),
    )
    .unwrap();
    assert!(
        Service::open(root.path()).is_err(),
        "missing authority must not silently reset source ownership or data identity"
    );
}

#[test]
fn release_can_retry_after_lost_response_but_cannot_release_another_window() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    let request = Request::Release {
        token: token.token.clone(),
    };
    assert_eq!(
        service
            .dispatch("settings", request.clone())
            .unwrap_err()
            .code,
        "staleToken"
    );
    assert!(
        write(&mut service, "main", &token, None).is_ok(),
        "foreign release must preserve the live lease"
    );
    service.dispatch("main", request.clone()).unwrap();
    let after = snapshot(&mut service).sequence;
    assert!(matches!(
        service.dispatch("main", request).unwrap(),
        Response::Ok
    ));
    assert_eq!(
        snapshot(&mut service).sequence,
        after,
        "retry must not mutate durable state or rebroadcast"
    );
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct ManifestCompatibility {
    valid_ids: Vec<String>,
    invalid_ids: Vec<String>,
    valid_ranges: Vec<String>,
    invalid_ranges: Vec<String>,
}
#[test]
fn manifest_installer_matches_shared_id_and_wire_range_fixtures() {
    let fixture: ManifestCompatibility =
        serde_json::from_str(include_str!("../../schemas/manifest-compatibility.json")).unwrap();
    let check = |id: &str, range: &str, valid: bool| {
        let root = tempfile::tempdir().unwrap();
        let pkg = package("1.0.0");
        let path = pkg.path().join("manifest.json");
        fs::write(path,serde_json::to_vec(&json!({"id":id,"name":"Fixture","version":"1.0.0","dependencies":{"@alwith/module-extension":range},"hosts":{"alwith-u":range,"alwith-desktop":range}})).unwrap()).unwrap();
        let mut service = Service::open(root.path()).unwrap();
        let result = service.dispatch(
            "main",
            Request::InstallLocal {
                path: pkg.path().display().to_string(),
                source: "local".into(),
                expected_id: None,
                expected_version: None,
                expected_digest: None,
            },
        );
        assert_eq!(
            result.is_ok(),
            valid,
            "id={id:?}, range={range:?}: {result:?}"
        );
    };
    for id in fixture.valid_ids {
        check(&id, "^0.1.0", true);
    }
    for id in fixture.invalid_ids {
        check(&id, "^0.1.0", false);
    }
    for range in fixture.valid_ranges {
        check("weather", &range, true);
    }
    for range in fixture.invalid_ranges {
        check("weather", &range, false);
    }
}

#[test]
fn grouped_layout_keeps_one_current_config_and_a_bounded_recovery_copy() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    assert!(
        root.path()
            .join("weather/packages")
            .join(&installed.package_revision)
            .join("main.js")
            .is_file()
    );
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    for n in 0..20 {
        write(
            &mut service,
            "main",
            &token,
            if n == 0 { None } else { Some(n) },
        )
        .unwrap();
    }
    let path = root.path().join("weather/data/data.json");
    let value: serde_json::Value = serde_json::from_slice(&fs::read(path).unwrap()).unwrap();
    assert_eq!(value["revision"], 20);
    assert_eq!(value["installationId"], installed.installation_id);
    assert_eq!(
        fs::read_dir(root.path().join("weather/data"))
            .unwrap()
            .count(),
        2
    );
    assert!(!root.path().join("data").exists());
    assert!(!root.path().join("packages").exists());
    assert!(
        service
            .resource_for_window("main", &token.token, "../../data/data.json")
            .is_err()
    );
    drop(service);
    assert!(Service::open(root.path()).is_ok());
}

fn legacy_fixture(id: &str) -> (tempfile::TempDir, Installation) {
    let probe = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let manifest_path = pkg.path().join("manifest.json");
    let mut manifest: serde_json::Value =
        serde_json::from_slice(&fs::read(&manifest_path).unwrap()).unwrap();
    manifest["id"] = json!(id);
    fs::write(&manifest_path, serde_json::to_vec(&manifest).unwrap()).unwrap();
    let mut service = Service::open(probe.path()).unwrap();
    let installation = install(&mut service, &pkg, "local");
    let root = tempfile::tempdir().unwrap();
    let dest = root
        .path()
        .join("packages")
        .join(id)
        .join(&installation.package_revision);
    fs::create_dir_all(&dest).unwrap();
    for file in ["manifest.json", "main.js"] {
        fs::copy(pkg.path().join(file), dest.join(file)).unwrap();
    }
    let data = root
        .path()
        .join("data")
        .join(&installation.installation_id)
        .join("1");
    fs::create_dir_all(&data).unwrap();
    fs::write(
        data.join("3.json"),
        serde_json::to_vec(
            &json!({"generation":1,"schemaVersion":1,"revision":3,"value":{"saved":true}}),
        )
        .unwrap(),
    )
    .unwrap();
    fs::write(root.path().join("state.json"), serde_json::to_vec(&json!({"version":1,"sequence":17,"records":{id:{"installation":installation,"installed":true,"data_revision":3}},"pending":{}})).unwrap()).unwrap();
    (root, installation)
}

#[test]
fn legacy_layout_migrates_identity_config_and_disabled_state_without_losing_backup() {
    let (root, installed) = legacy_fixture("weather");
    let mut service = Service::open(root.path()).unwrap();
    let item = &service.snapshot().installations[0];
    assert_eq!(item.installation_id, installed.installation_id);
    assert!(!item.enabled);
    assert!(
        root.path()
            .join("weather/packages")
            .join(&installed.package_revision)
            .is_dir()
    );
    assert!(root.path().join(".legacy-v1/state.json").is_file());
    assert!(
        root.path()
            .join(".legacy-v1/data")
            .join(&installed.installation_id)
            .join("1/3.json")
            .is_file()
    );
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    let Response::Data { data: Some(data) } = service
        .dispatch(
            "main",
            Request::ReadData {
                token: token.token.clone(),
            },
        )
        .unwrap()
    else {
        panic!("expected saved data")
    };
    assert_eq!(data.value, json!({"saved":true}));
    assert_eq!(data.revision, 3);
    write(&mut service, "main", &token, Some(3)).unwrap();
    drop(service);
    let mut service = Service::open(root.path()).unwrap();
    let token = register(&mut service, "main");
    let Response::Data { data: Some(data) } = service
        .dispatch("main", Request::ReadData { token: token.token })
        .unwrap()
    else {
        panic!("expected saved data")
    };
    assert_eq!(data.revision, 4, "reopening must not restore archived data");
}

#[test]
fn migration_handles_extension_ids_that_match_legacy_directory_names() {
    for id in ["packages", "data"] {
        let (root, installed) = legacy_fixture(id);
        let service = Service::open(root.path()).unwrap();
        assert_eq!(service.snapshot().installations[0].id, id);
        assert!(
            root.path()
                .join(id)
                .join("packages")
                .join(&installed.package_revision)
                .join("main.js")
                .is_file()
        );
        assert!(root.path().join(id).join("data/data.json").is_file());
        drop(service);
        assert!(Service::open(root.path()).is_ok());
    }
}

#[test]
fn invalid_legacy_data_does_not_switch_layout_or_move_source() {
    let (root, installed) = legacy_fixture("weather");
    fs::write(
        root.path()
            .join("data")
            .join(installed.installation_id)
            .join("1/3.json"),
        b"broken",
    )
    .unwrap();
    assert!(Service::open(root.path()).is_err());
    let state: serde_json::Value =
        serde_json::from_slice(&fs::read(root.path().join("state.json")).unwrap()).unwrap();
    assert_eq!(state["version"], 1);
    assert!(root.path().join("packages/weather").is_dir());
    assert!(!root.path().join(".legacy-v1").exists());
}

#[test]
fn migration_resumes_after_each_directory_promotion_boundary() {
    for phase in 0..4 {
        let (root, installed) = legacy_fixture("weather");
        drop(Service::open(root.path()).unwrap());
        // Reconstruct durable crash boundaries of the migration, without mocking filesystem writes.
        if phase < 3 {
            fs::rename(
                root.path().join("weather"),
                root.path().join(".migration-v2/weather"),
            )
            .unwrap();
        }
        if phase < 2 {
            fs::rename(
                root.path().join(".legacy-v1/data"),
                root.path().join("data"),
            )
            .unwrap();
        }
        if phase == 0 {
            fs::rename(
                root.path().join(".legacy-v1/packages"),
                root.path().join("packages"),
            )
            .unwrap();
        }
        let path = root.path().join("state.json");
        let mut state: serde_json::Value =
            serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
        state["migration"] = json!({"packages":true,"data":true});
        fs::write(&path, serde_json::to_vec(&state).unwrap()).unwrap();
        let mut service = Service::open(root.path()).unwrap();
        assert_eq!(
            service.snapshot().installations[0].installation_id,
            installed.installation_id
        );
        service
            .dispatch(
                "main",
                Request::Enable {
                    id: "weather".into(),
                },
            )
            .unwrap();
        let token = register(&mut service, "main");
        let Response::Data { data: Some(data) } = service
            .dispatch("main", Request::ReadData { token: token.token })
            .unwrap()
        else {
            panic!("configuration must survive")
        };
        assert_eq!(data.value, json!({"saved":true}));
        let state: serde_json::Value = serde_json::from_slice(&fs::read(path).unwrap()).unwrap();
        assert!(state.get("migration").is_none());
    }
}

#[test]
fn grouped_config_cannot_be_inherited_from_a_different_installation() {
    let (root, _) = legacy_fixture("weather");
    drop(Service::open(root.path()).unwrap());
    let path = root.path().join("weather/data/data.json");
    let mut data: serde_json::Value = serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
    data["installationId"] = json!(uuid::Uuid::new_v4().to_string());
    fs::write(path, serde_json::to_vec(&data).unwrap()).unwrap();
    assert!(Service::open(root.path()).is_err());
}

#[test]
fn first_write_state_commit_failure_stays_absent_and_can_retry_after_reopen() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    fs::rename(
        root.path().join("state.json"),
        root.path().join("saved-state.json"),
    )
    .unwrap();
    fs::create_dir(root.path().join("state.json")).unwrap();
    assert!(write(&mut service, "main", &token, None).is_err());
    drop(service);
    fs::rename(
        root.path().join("state.json"),
        root.path().join("blocked-state"),
    )
    .unwrap();
    fs::rename(
        root.path().join("saved-state.json"),
        root.path().join("state.json"),
    )
    .unwrap();
    let mut service = Service::open(root.path()).unwrap();
    let token = register(&mut service, "main");
    assert!(matches!(
        service
            .dispatch(
                "main",
                Request::ReadData {
                    token: token.token.clone()
                }
            )
            .unwrap(),
        Response::Data { data: None }
    ));
    write(&mut service, "main", &token, None).unwrap();
    let Response::Data { data: Some(data) } = service
        .dispatch("main", Request::ReadData { token: token.token })
        .unwrap()
    else {
        panic!("expected config")
    };
    assert_eq!(data.revision, 1);
}

#[test]
fn interrupted_initial_state_write_can_retry() {
    let root = tempfile::tempdir().unwrap();
    let temporary = tempfile::NamedTempFile::new_in(root.path()).unwrap();
    let (_file, _path) = temporary.keep().unwrap();
    assert!(Service::open(root.path()).is_ok());
}

#[test]
fn prepared_data_recovers_exact_value_and_rejects_invalid_backup() {
    for invalid in [false, true] {
        let (root, _) = legacy_fixture("weather");
        drop(Service::open(root.path()).unwrap());
        let current = root.path().join("weather/data/data.json");
        let previous = root.path().join("weather/data/.previous.json");
        fs::copy(&current, &previous).unwrap();
        let mut prepared: serde_json::Value =
            serde_json::from_slice(&fs::read(&current).unwrap()).unwrap();
        prepared["revision"] = json!(4);
        prepared["value"] = json!({"uncommitted":true});
        fs::write(&current, serde_json::to_vec(&prepared).unwrap()).unwrap();
        if invalid {
            fs::write(previous, b"malformed backup").unwrap();
            assert!(Service::open(root.path()).is_err());
            continue;
        }
        let mut service = Service::open(root.path()).unwrap();
        service
            .dispatch(
                "main",
                Request::Enable {
                    id: "weather".into(),
                },
            )
            .unwrap();
        let token = register(&mut service, "main");
        let Response::Data { data: Some(data) } = service
            .dispatch(
                "main",
                Request::ReadData {
                    token: token.token.clone(),
                },
            )
            .unwrap()
        else {
            panic!("expected selected data")
        };
        assert_eq!(data.revision, 3);
        assert_eq!(data.value, json!({"saved":true}));
        let Response::Data {
            data: Some(updated),
        } = service
            .dispatch(
                "main",
                Request::WriteData {
                    token: token.token,
                    expected_revision: Some(3),
                    value: json!({"retried":true}),
                    generation: 1,
                    schema_version: 1,
                },
            )
            .unwrap()
        else {
            panic!("expected updated data")
        };
        assert_eq!(updated.revision, 4);
        assert_eq!(updated.value, json!({"retried":true}));
        drop(service);
        let stored: serde_json::Value =
            serde_json::from_slice(&fs::read(&current).unwrap()).unwrap();
        assert_eq!(stored["value"], json!({"retried":true}));
        assert!(Service::open(root.path()).is_ok());
    }
}

#[test]
fn simplified_manifest_defaults_and_installs() {
    let package = tempfile::tempdir().unwrap();
    std::fs::write(
        package.path().join("manifest.json"),
        serde_json::json!({
            "id":"modern", "name":"Modern", "version":"1.0.0",
            "dependencies":{"@alwith/module-extension":"^0.1.0"}, "hosts":{"alwith-u":">=0.1.1"}
        })
        .to_string(),
    )
    .unwrap();
    std::fs::write(
        package.path().join("main.js"),
        "module.exports = () => ({})",
    )
    .unwrap();
    let root = tempfile::tempdir().unwrap();
    let mut service = alwith_extension::Service::open(root.path()).unwrap();
    let request = serde_json::from_value(
        serde_json::json!({"type":"installLocal", "path":package.path(), "source":"local"}),
    )
    .unwrap();
    service.dispatch("main", request).unwrap();
    let snapshot = service.snapshot();
    let manifest = &snapshot.installations[0].manifest;
    assert_eq!(manifest.manifest_version, 3);
    assert_eq!(manifest.entry, "main.js");
    assert_eq!(manifest.data_schema_version, 1);
}

#[test]
fn manifest_rejects_legacy_fields_and_invalid_dependencies_or_hosts() {
    let cases = [
        ("v2", json!({"manifestVersion":2}), "invalidManifest"),
        (
            "future version",
            json!({"manifestVersion":4}),
            "invalidManifest",
        ),
        (
            "engines",
            json!({"engines":{"extension":"^1.0.3"}}),
            "invalidManifest",
        ),
        (
            "capabilities",
            json!({"capabilities":{}}),
            "invalidManifest",
        ),
        (
            "contributions",
            json!({"contributions":{}}),
            "invalidManifest",
        ),
        ("externals", json!({"externals":[]}), "invalidManifest"),
        (
            "empty dependencies",
            json!({"dependencies":{}}),
            "invalidManifest",
        ),
        (
            "unknown dependency",
            json!({"dependencies":{"@alwith/module-extension":"^0.1.0","react":"^19"}}),
            "invalidManifest",
        ),
        (
            "dependency range",
            json!({"dependencies":{"@alwith/module-extension":"broken"}}),
            "invalidManifest",
        ),
        (
            "empty host",
            json!({"hosts":{"":"^1.0.3"}}),
            "invalidManifest",
        ),
        (
            "invalid host",
            json!({"hosts":{"../host":"^1.0.3"}}),
            "invalidManifest",
        ),
        (
            "host range",
            json!({"hosts":{"alwith-u":"broken"}}),
            "invalidManifest",
        ),
        (
            "zero data schema",
            json!({"dataSchemaVersion":0}),
            "invalidManifest",
        ),
    ];
    for (label, patch, expected_code) in cases {
        let root = tempfile::tempdir().unwrap();
        let pkg = package("1.0.0");
        let path = pkg.path().join("manifest.json");
        let mut manifest: serde_json::Value =
            serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
        manifest
            .as_object_mut()
            .unwrap()
            .extend(patch.as_object().unwrap().clone());
        fs::write(path, serde_json::to_vec(&manifest).unwrap()).unwrap();
        let mut service = Service::open(root.path()).unwrap();
        let result = service.dispatch(
            "main",
            Request::InstallLocal {
                path: pkg.path().display().to_string(),
                source: "local".into(),
                expected_id: None,
                expected_version: None,
                expected_digest: None,
            },
        );
        assert_eq!(result.unwrap_err().code, expected_code, "{label}");
        assert!(service.snapshot().installations.is_empty(), "{label}");
    }
    let value = json!({"id":"weather","name":"Weather","version":"1.0.0"});
    let error = serde_json::from_value::<alwith_extension::Manifest>(value).unwrap_err();
    assert!(error.to_string().contains("missing field `dependencies`"));
}

#[test]
fn manifest_normalizes_defaults_and_accepts_explicit_package_entry() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let path = pkg.path().join("manifest.json");
    let mut manifest: serde_json::Value =
        serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
    manifest["manifestVersion"] = json!(3);
    manifest["entry"] = json!("dist/extension.js");
    fs::create_dir(pkg.path().join("dist")).unwrap();
    fs::write(pkg.path().join("dist/extension.js"), "module.exports = {};").unwrap();
    fs::write(path, serde_json::to_vec(&manifest).unwrap()).unwrap();
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    assert_eq!(installed.manifest.entry, "dist/extension.js");
    assert!(installed.manifest.hosts.is_empty());
    let serialized = serde_json::to_value(&installed.manifest).unwrap();
    assert_eq!(serialized["manifestVersion"], 3);
    assert_eq!(serialized["dataSchemaVersion"], 1);
    assert_eq!(serialized["hosts"], json!({}));
    drop(service);
    let reopened = Service::open(root.path()).unwrap();
    assert_eq!(
        reopened.snapshot().installations[0].manifest.entry,
        "dist/extension.js"
    );
}

#[test]
fn manifest_metadata_survives_install_snapshot_and_reopen() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let path = pkg.path().join("manifest.json");
    let mut manifest: serde_json::Value =
        serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
    let metadata = json!({
        "description":" Shows the weather ", "author":" Weather team ",
        "authorUrl":"HTTPS://example.com/about?team=weather#people",
        "icon":"http://[::1]:8080/icon.png"
    });
    manifest
        .as_object_mut()
        .unwrap()
        .extend(metadata.as_object().unwrap().clone());
    fs::write(path, serde_json::to_vec(&manifest).unwrap()).unwrap();
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    let installed_value = serde_json::to_value(&installed.manifest).unwrap();
    for (key, expected) in metadata.as_object().unwrap() {
        assert_eq!(&installed_value[key], expected, "installed {key}");
        assert_eq!(
            &serde_json::to_value(service.snapshot().installations[0].manifest.clone()).unwrap()
                [key],
            expected,
            "snapshot {key}"
        );
    }
    drop(service);
    let reopened = Service::open(root.path()).unwrap();
    let persisted = serde_json::to_value(&reopened.snapshot().installations[0].manifest).unwrap();
    for (key, expected) in metadata.as_object().unwrap() {
        assert_eq!(&persisted[key], expected, "persisted {key}");
    }
}

#[test]
fn manifest_metadata_rejects_invalid_values_and_network_urls() {
    let mut cases = Vec::new();
    for key in ["description", "author", "authorUrl", "icon"] {
        for value in [json!(null), json!(42), json!(false), json!([]), json!({})] {
            cases.push((key, value, "invalidManifest"));
        }
        for value in ["", " \t\n", "\u{feff}"] {
            cases.push((key, json!(value), "invalidManifest"));
        }
    }
    for key in ["authorUrl", "icon"] {
        for url in [
            "images/icon.png",
            "//example.com/icon.png",
            "file:///icon.png",
            "data:image/png;base64,eA==",
            "javascript:alert(1)",
            "https:example.com",
            "http://",
            "https://[broken",
            "https://example.com:99999/icon.png",
            "https://user@example.com",
            "https://user:password@example.com",
            "https://:password@example.com",
            " https://example.com",
            "https://example.com ",
            "https://example.com\nicon.png",
            "https://example.com/\u{007f}",
            "https://example.com/\u{0085}",
            "https://example.com/\u{feff}",
            "https://example.com\\icon.png",
        ] {
            cases.push((key, json!(url), "invalidManifest"));
        }
    }
    for (key, value, expected_code) in cases {
        let root = tempfile::tempdir().unwrap();
        let pkg = package("1.0.0");
        let path = pkg.path().join("manifest.json");
        let mut manifest: serde_json::Value =
            serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
        manifest[key] = value.clone();
        fs::write(path, serde_json::to_vec(&manifest).unwrap()).unwrap();
        let mut service = Service::open(root.path()).unwrap();
        let result = service.dispatch(
            "main",
            Request::InstallLocal {
                path: pkg.path().display().to_string(),
                source: "local".into(),
                expected_id: None,
                expected_version: None,
                expected_digest: None,
            },
        );
        assert_eq!(result.unwrap_err().code, expected_code, "{key}={value}");
        assert!(service.snapshot().installations.is_empty());
    }
}

#[test]
fn manifest_without_metadata_omits_optional_fields_on_serialization() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    let value = serde_json::to_value(&installed.manifest).unwrap();
    for key in ["description", "author", "authorUrl", "icon"] {
        assert!(value.get(key).is_none(), "{key} must be omitted");
    }
}

fn set_metadata(pkg: &tempfile::TempDir, fields: serde_json::Value) {
    let path = pkg.path().join("manifest.json");
    let mut manifest: serde_json::Value =
        serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
    manifest
        .as_object_mut()
        .unwrap()
        .extend(fields.as_object().unwrap().clone());
    fs::write(path, serde_json::to_vec(&manifest).unwrap()).unwrap();
}
fn commit_transition(service: &mut Service) {
    service
        .dispatch(
            "main",
            Request::CommitTransition {
                id: "weather".into(),
            },
        )
        .unwrap();
}
#[test]
fn manifest_rejects_author_supplied_nls_field() {
    for value in [json!({}), json!(null), json!([])] {
        let root = tempfile::tempdir().unwrap();
        let pkg = package("1.0.0");
        set_metadata(&pkg, json!({"nls": value}));
        let mut service = Service::open(root.path()).unwrap();
        let error = service
            .dispatch(
                "main",
                Request::InstallLocal {
                    path: pkg.path().display().to_string(),
                    source: "local".into(),
                    expected_id: None,
                    expected_version: None,
                    expected_digest: None,
                },
            )
            .unwrap_err();
        assert_eq!(error.code, "invalidManifest");
        assert!(service.snapshot().installations.is_empty());
    }
}

#[test]
fn manifest_locales_survive_install_snapshot_and_reopen_without_normalization() {
    for locales in [
        json!({}),
        json!({
            "EN-us": {"name": " Weather ", "description": " Forecast "},
            "zh-Hant-TW": {"name": "天氣"},
            "es-419": {"description": "Pronóstico"},
            "abcdefgh-12345678-A": {"name": "\u{0085}"}
        }),
    ] {
        let root = tempfile::tempdir().unwrap();
        let pkg = package("1.0.0");
        let path = pkg.path().join("manifest.json");
        let mut manifest: serde_json::Value =
            serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
        manifest["locales"] = locales.clone();
        fs::write(path, serde_json::to_vec(&manifest).unwrap()).unwrap();
        let mut service = Service::open(root.path()).unwrap();
        let installed = install(&mut service, &pkg, "local");
        assert_eq!(
            serde_json::to_value(installed.manifest).unwrap()["locales"],
            locales
        );
        assert_eq!(
            serde_json::to_value(snapshot(&mut service)).unwrap()["installations"][0]["manifest"]["locales"],
            locales
        );
        drop(service);
        let mut reopened = Service::open(root.path()).unwrap();
        assert_eq!(
            serde_json::to_value(snapshot(&mut reopened)).unwrap()["installations"][0]["manifest"]
                ["locales"],
            locales
        );
    }
}

#[test]
fn manifest_locales_reject_invalid_shapes_values_and_language_codes() {
    let mut cases = vec![
        (json!(null), "invalidManifest"),
        (json!([]), "invalidManifest"),
        (json!("en"), "invalidManifest"),
        (json!(42), "invalidManifest"),
        (json!(false), "invalidManifest"),
        (json!({"en":null}), "invalidManifest"),
        (json!({"en":[]}), "invalidManifest"),
        (json!({"en":"Weather"}), "invalidManifest"),
        (json!({"en":{"author":"Team"}}), "invalidManifest"),
        (
            json!({"en":{"name":"Weather","icon":"https://example.com/icon.png"}}),
            "invalidManifest",
        ),
        (json!({"en":{}}), "invalidManifest"),
        (
            json!({"en":{"name":"Weather"},"EN":{"name":"Other"}}),
            "invalidManifest",
        ),
        (
            json!({"en-US":{"name":"Weather"},"EN-us":{"description":"Other"}}),
            "invalidManifest",
        ),
    ];
    for field in ["name", "description"] {
        for value in [json!(null), json!(false), json!(42), json!([]), json!({})] {
            cases.push((json!({"en":{field:value}}), "invalidManifest"));
        }
        for value in ["", " \t\r\n", "\u{feff}"] {
            cases.push((json!({"en":{field:value}}), "invalidManifest"));
        }
    }
    cases.push((
        json!({"en":{"name":"Weather","description":" "}}),
        "invalidManifest",
    ));
    for language in [
        "",
        "e",
        "abcdefghi",
        "1a",
        "en_US",
        " en",
        "en ",
        "éé",
        "Kn",
        "en-K",
        "en-",
        "en--US",
        "en-abcdefghi",
        "en-u_",
        "en-中文",
    ] {
        cases.push((json!({language:{"name":"Weather"}}), "invalidManifest"));
    }
    for (locales, expected_code) in cases {
        let root = tempfile::tempdir().unwrap();
        let pkg = package("1.0.0");
        let path = pkg.path().join("manifest.json");
        let mut manifest: serde_json::Value =
            serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
        manifest["locales"] = locales.clone();
        fs::write(path, serde_json::to_vec(&manifest).unwrap()).unwrap();
        let mut service = Service::open(root.path()).unwrap();
        let result = service.dispatch(
            "main",
            Request::InstallLocal {
                path: pkg.path().display().to_string(),
                source: "local".into(),
                expected_id: None,
                expected_version: None,
                expected_digest: None,
            },
        );
        assert_eq!(result.unwrap_err().code, expected_code, "locales={locales}");
        assert!(service.snapshot().installations.is_empty());
    }
}

#[test]
fn manifest_without_locales_remains_readable_and_omits_locales() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    assert!(
        serde_json::to_value(installed.manifest)
            .unwrap()
            .get("locales")
            .is_none()
    );
    drop(service);
    let reopened = Service::open(root.path()).unwrap();
    assert!(
        serde_json::to_value(&reopened.snapshot().installations[0].manifest)
            .unwrap()
            .get("locales")
            .is_none()
    );
}

fn locales_fixture(version: &str) -> tempfile::TempDir {
    let pkg = package(version);
    set_metadata(
        &pkg,
        json!({"description":"Forecast", "locales":{"ZH-Hant":{"name":"天氣"}, "en":{"description":"Weather forecast"}}}),
    );
    pkg
}
#[test]
fn manifest_locales_survive_disable_and_reopen() {
    let root = tempfile::tempdir().unwrap();
    let pkg = locales_fixture("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    assert_eq!(installed.manifest.name, "Weather");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let activation = register(&mut service, "main");
    begin(&mut service, TransitionAction::Disable, None);
    service
        .dispatch(
            "main",
            Request::Release {
                token: activation.token,
            },
        )
        .unwrap();
    commit_transition(&mut service);
    drop(service);
    let reopened = Service::open(root.path()).unwrap();
    let snapshot = &reopened.snapshot().installations[0];
    assert!(!snapshot.enabled);
    assert_eq!(snapshot.installation_id, installed.installation_id);
    assert_eq!(
        serde_json::to_value(&snapshot.manifest).unwrap()["locales"],
        json!({"ZH-Hant":{"name":"天氣"}, "en":{"description":"Weather forecast"}})
    );
}
#[test]
fn manifest_locales_update_replaces_and_plain_update_clears_locales() {
    let root = tempfile::tempdir().unwrap();
    let pkg = locales_fixture("1.0.0");
    let updated = locales_fixture("1.1.0");
    set_metadata(&updated, json!({"locales":{"zh":{"name":"新的天氣"}}}));
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    begin(
        &mut service,
        TransitionAction::Update,
        Some(updated.path().display().to_string()),
    );
    assert_eq!(
        serde_json::to_value(&service.snapshot().installations[0].manifest).unwrap()["locales"]["ZH-Hant"]
            ["name"],
        "天氣"
    );
    commit_transition(&mut service);
    assert_eq!(
        serde_json::to_value(&service.snapshot().installations[0].manifest).unwrap()["locales"],
        json!({"zh":{"name":"新的天氣"}})
    );
    let plain = package("1.2.0");
    begin(
        &mut service,
        TransitionAction::Update,
        Some(plain.path().display().to_string()),
    );
    commit_transition(&mut service);
    assert!(
        serde_json::to_value(&service.snapshot().installations[0].manifest)
            .unwrap()
            .get("locales")
            .is_none()
    );
    drop(service);
    let reopened = Service::open(root.path()).unwrap();
    assert!(
        serde_json::to_value(&reopened.snapshot().installations[0].manifest)
            .unwrap()
            .get("locales")
            .is_none()
    );
}
#[test]
fn manifest_locales_original_bytes_change_digest_without_rewriting_manifest() {
    let root = tempfile::tempdir().unwrap();
    let pkg = locales_fixture("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let initial = install(&mut service, &pkg, "local");
    let path = pkg.path().join("manifest.json");
    let mut bytes = fs::read(&path).unwrap();
    bytes.push(b'\n');
    fs::write(path, &bytes).unwrap();
    begin(
        &mut service,
        TransitionAction::Update,
        Some(pkg.path().display().to_string()),
    );
    commit_transition(&mut service);
    let updated = &service.snapshot().installations[0];
    assert_ne!(initial.package_revision, updated.package_revision);
    let stored = root
        .path()
        .join("weather/packages")
        .join(&updated.package_revision);
    assert_eq!(fs::read(stored.join("manifest.json")).unwrap(), bytes);
}
#[test]
fn plain_metadata_preserves_percent_text_and_json_resources_without_translation() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    set_metadata(
        &pkg,
        json!({"name":"%name%", "description":"100% ready %description%"}),
    );
    // These names are ordinary resources. No default translation is required.
    fs::write(
        pkg.path().join("manifest.nls.EN.json"),
        "not translation JSON",
    )
    .unwrap();
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    assert_eq!(installed.manifest.name, "%name%");
    assert_eq!(
        installed.manifest.description.as_deref(),
        Some("100% ready %description%")
    );
    assert!(
        serde_json::to_value(&installed)
            .unwrap()
            .get("nls")
            .is_none()
    );
    drop(service);
    let reopened = Service::open(root.path()).unwrap();
    assert_eq!(reopened.snapshot().installations[0].manifest.name, "%name%");
}

#[test]
fn manifest_lucide_icons_survive_install_snapshot_disable_and_reopen() {
    for icon in [
        "lucide:blocks",
        "lucide:play",
        "lucide:panel",
        "lucide:settings",
        "lucide:clock",
        "lucide:chart",
        "lucide:globe",
    ] {
        let root = tempfile::tempdir().unwrap();
        let pkg = package("1.0.0");
        set_metadata(
            &pkg,
            json!({"icon": icon, "authorUrl": "https://example.com/author"}),
        );
        let mut service = Service::open(root.path()).unwrap();
        let installed = install(&mut service, &pkg, "local");
        assert_eq!(installed.manifest.icon.as_deref(), Some(icon));
        assert_eq!(
            service.snapshot().installations[0].manifest.icon.as_deref(),
            Some(icon)
        );
        service
            .dispatch(
                "main",
                Request::Enable {
                    id: "weather".into(),
                },
            )
            .unwrap();
        let activation = register(&mut service, "main");
        begin(&mut service, TransitionAction::Disable, None);
        service
            .dispatch(
                "main",
                Request::Release {
                    token: activation.token,
                },
            )
            .unwrap();
        commit_transition(&mut service);
        drop(service);
        let reopened = Service::open(root.path()).unwrap();
        let snapshot = &reopened.snapshot().installations[0];
        assert!(!snapshot.enabled);
        assert_eq!(snapshot.manifest.icon.as_deref(), Some(icon));
        assert_eq!(
            snapshot.manifest.author_url.as_deref(),
            Some("https://example.com/author")
        );
    }
}

#[test]
fn manifest_lucide_icons_reject_unknown_names_and_never_apply_to_author_urls() {
    let mut cases = Vec::new();
    for icon in [
        "lucide:",
        "lucide:unknown",
        "lucide:Clock",
        "LUCIDE:clock",
        "Lucide:clock",
        " lucide:clock",
        "lucide:clock ",
        "lucide:clock\n",
        "lucide:clock\u{feff}",
        "lucide: clock",
        "lucide://clock",
        "lucide:clock/path",
        "lucide:clock?size=20",
        "lucide:clock#icon",
        "clock",
    ] {
        cases.push(("icon", icon));
    }
    for icon in [
        "lucide:blocks",
        "lucide:play",
        "lucide:panel",
        "lucide:settings",
        "lucide:clock",
        "lucide:chart",
        "lucide:globe",
    ] {
        cases.push(("authorUrl", icon));
    }
    for (field, value) in cases {
        let root = tempfile::tempdir().unwrap();
        let pkg = package("1.0.0");
        set_metadata(&pkg, json!({field: value}));
        let mut service = Service::open(root.path()).unwrap();
        let error = service
            .dispatch(
                "main",
                Request::InstallLocal {
                    path: pkg.path().display().to_string(),
                    source: "local".into(),
                    expected_id: None,
                    expected_version: None,
                    expected_digest: None,
                },
            )
            .unwrap_err();
        assert_eq!(error.code, "invalidManifest", "{field}={value:?}");
        assert!(service.snapshot().installations.is_empty());
    }
}

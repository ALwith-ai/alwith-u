use alwith_extension::Service;
#[test]
fn opens_empty_root_and_rejects_second_owner() {
    let root = tempfile::tempdir().unwrap();
    let service = Service::open(root.path()).expect("empty service root opens");
    assert!(
        Service::open(root.path()).is_err(),
        "one process owner per root"
    );
    drop(service);
    assert!(
        Service::open(root.path()).is_ok(),
        "lock releases with service"
    );
}

use alwith_extension::{
    ActivationToken, Installation, Request, Response, Snapshot, TransitionAction,
};
use serde_json::json;
use std::fs;
fn package(version: &str) -> tempfile::TempDir {
    let dir = tempfile::tempdir().unwrap();
    fs::write(dir.path().join("manifest.json"), serde_json::to_vec(&json!({"manifestVersion":2,"id":"weather","name":"Weather","version":version,"entry":"main.js","engines":{"extension":"^0.1.0"}})).unwrap()).unwrap();
    fs::write(
        dir.path().join("main.js"),
        format!("exports.version = '{version}';"),
    )
    .unwrap();
    dir
}
fn install(service: &mut Service, dir: &tempfile::TempDir, source: &str) -> Installation {
    let response = service
        .dispatch(
            "main",
            Request::InstallLocal {
                path: dir.path().display().to_string(),
                source: source.into(),
                expected_id: None,
                expected_version: None,
                expected_digest: None,
            },
        )
        .unwrap();
    let Response::Installation { installation } = response else {
        panic!("wrong response")
    };
    *installation
}
fn snapshot(service: &mut Service) -> Snapshot {
    let Response::Snapshot { snapshot } = service.dispatch("main", Request::Snapshot).unwrap()
    else {
        panic!("wrong response")
    };
    snapshot
}
fn register(service: &mut Service, window: &str) -> ActivationToken {
    let Response::Token { activation } = service
        .dispatch(
            window,
            Request::Register {
                id: "weather".into(),
            },
        )
        .unwrap()
    else {
        panic!("wrong response")
    };
    activation
}
fn begin(service: &mut Service, action: TransitionAction, path: Option<String>) {
    service
        .dispatch(
            "main",
            Request::BeginTransition {
                id: "weather".into(),
                action,
                path,
                source: Some("local".into()),
                expected_digest: None,
            },
        )
        .unwrap();
}
fn write(
    service: &mut Service,
    window: &str,
    token: &ActivationToken,
    expected: Option<u32>,
) -> Result<Response, alwith_extension::ServiceError> {
    service.dispatch(
        window,
        Request::WriteData {
            token: token.token.clone(),
            generation: token.data_generation,
            expected_revision: expected,
            schema_version: 1,
            value: json!({"city":"Taipei"}),
        },
    )
}
#[test]
fn install_persists_fixed_content_and_cas_data() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    assert!(!installed.enabled);
    assert!(
        service
            .dispatch(
                "main",
                Request::Register {
                    id: "weather".into()
                }
            )
            .is_err()
    );
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    assert!(matches!(
        service
            .dispatch(
                "main",
                Request::ReadData {
                    token: token.token.clone()
                }
            )
            .unwrap(),
        Response::Data { data: None }
    ));
    assert!(
        write(&mut service, "other", &token, None).is_err(),
        "window spoofing rejected"
    );
    let Response::Data { data: Some(data) } = write(&mut service, "main", &token, None).unwrap()
    else {
        panic!("missing data")
    };
    assert_eq!(data.revision, 1);
    assert_eq!(
        write(&mut service, "main", &token, None).unwrap_err().code,
        "conflict"
    );
    fs::write(pkg.path().join("main.js"), "changed source").unwrap();
    let Response::Resource { bytes, .. } = service
        .dispatch(
            "main",
            Request::ReadResource {
                token: token.token.clone(),
                path: "main.js".into(),
            },
        )
        .unwrap()
    else {
        panic!("missing resource")
    };
    assert_eq!(
        String::from_utf8(bytes).unwrap(),
        "exports.version = '1.0.0';"
    );
    let sequence = snapshot(&mut service).sequence;
    drop(service);
    let mut restored = Service::open(root.path()).unwrap();
    assert!(
        restored
            .dispatch("main", Request::ReadData { token: token.token })
            .is_err()
    );
    let next = register(&mut restored, "main");
    let Response::Data { data: Some(data) } = restored
        .dispatch("main", Request::ReadData { token: next.token })
        .unwrap()
    else {
        panic!("missing recovered data")
    };
    assert_eq!(data.value, json!({"city":"Taipei"}));
    assert!(snapshot(&mut restored).sequence >= sequence);
}
#[test]
fn update_waits_for_both_windows_and_revokes_old_tokens() {
    let root = tempfile::tempdir().unwrap();
    let v1 = package("1.0.0");
    let v2 = package("2.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let old = install(&mut service, &v1, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let a = register(&mut service, "main");
    let b = register(&mut service, "settings");
    begin(
        &mut service,
        TransitionAction::Update,
        Some(v2.path().display().to_string()),
    );
    assert_eq!(snapshot(&mut service).pending[0].waiting_instances, 2);
    assert!(write(&mut service, "main", &a, None).is_err());
    assert!(
        service
            .dispatch(
                "new",
                Request::Register {
                    id: "weather".into()
                }
            )
            .is_err()
    );
    assert!(
        service
            .dispatch(
                "main",
                Request::CommitTransition {
                    id: "weather".into()
                }
            )
            .is_err()
    );
    service
        .dispatch("main", Request::Release { token: a.token })
        .unwrap();
    assert!(
        service
            .dispatch(
                "main",
                Request::CommitTransition {
                    id: "weather".into()
                }
            )
            .is_err()
    );
    service.close_window("settings").unwrap();
    service
        .dispatch(
            "main",
            Request::CommitTransition {
                id: "weather".into(),
            },
        )
        .unwrap();
    let next = &snapshot(&mut service).installations[0];
    assert_eq!(next.manifest.version, "2.0.0");
    assert_eq!(next.installation_id, old.installation_id);
    assert!(next.enabled);
    assert!(write(&mut service, "settings", &b, None).is_err());
}
#[test]
fn uninstall_retains_identity_and_data_and_rejects_other_source() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    write(&mut service, "main", &token, None).unwrap();
    begin(&mut service, TransitionAction::Uninstall, None);
    service
        .dispatch("main", Request::Release { token: token.token })
        .unwrap();
    service
        .dispatch(
            "main",
            Request::CommitTransition {
                id: "weather".into(),
            },
        )
        .unwrap();
    assert!(snapshot(&mut service).installations.is_empty());
    assert!(
        service
            .dispatch(
                "main",
                Request::InstallLocal {
                    path: pkg.path().display().to_string(),
                    source: "registry".into(),
                    expected_id: None,
                    expected_version: None,
                    expected_digest: None
                }
            )
            .is_err()
    );
    let next = install(&mut service, &pkg, "local");
    assert_eq!(next.installation_id, installed.installation_id);
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    assert!(matches!(
        service
            .dispatch("main", Request::ReadData { token: token.token })
            .unwrap(),
        Response::Data { data: Some(_) }
    ));
}
#[test]
fn recovery_before_commit_keeps_old_selection() {
    let root = tempfile::tempdir().unwrap();
    let v1 = package("1.0.0");
    let v2 = package("2.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &v1, "local");
    begin(
        &mut service,
        TransitionAction::Update,
        Some(v2.path().display().to_string()),
    );
    drop(service);
    let mut service = Service::open(root.path()).unwrap();
    let state = snapshot(&mut service);
    assert_eq!(state.installations[0].manifest.version, "1.0.0");
    assert!(state.pending.is_empty());
}
#[test]
fn rejects_corrupt_state_and_selected_package() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    drop(service);
    fs::write(
        root.path()
            .join("packages/weather")
            .join(installed.package_revision)
            .join("main.js"),
        "corruption",
    )
    .unwrap();
    assert!(Service::open(root.path()).is_err());
    fs::write(root.path().join("state.json"), "not json").unwrap();
    assert!(Service::open(root.path()).is_err());
}
#[test]
fn rejects_package_symlinks_and_resource_escape() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    for path in [
        "../state.json",
        "/etc/passwd",
        "a/../../state.json",
        "a\\..\\state.json",
        "%2e%2e/state.json",
    ] {
        assert!(
            service
                .dispatch(
                    "main",
                    Request::ReadResource {
                        token: token.token.clone(),
                        path: path.into()
                    }
                )
                .is_err(),
            "{path}"
        );
    }
    #[cfg(unix)]
    {
        std::os::unix::fs::symlink("/etc/passwd", pkg.path().join("secret")).unwrap();
        assert!(
            service
                .dispatch(
                    "main",
                    Request::InstallLocal {
                        path: pkg.path().display().to_string(),
                        source: "local".into(),
                        expected_id: None,
                        expected_version: None,
                        expected_digest: None
                    }
                )
                .is_err()
        );
    }
}

#[test]
fn navigation_completion_releases_only_captured_instances() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let old = register(&mut service, "main");
    let captured = service.capture_window_instances("main");
    service
        .dispatch("main", Request::Release { token: old.token })
        .unwrap();
    let new = register(&mut service, "main");
    service
        .complete_window_navigation("main", &captured)
        .unwrap();
    assert!(write(&mut service, "main", &new, None).is_ok());
    let captured = service.capture_window_instances("main");
    service
        .complete_window_navigation("main", &captured)
        .unwrap();
    assert!(write(&mut service, "main", &new, Some(1)).is_err());
}

#[test]
fn validates_request_identity_digest_schema_and_missing_entry() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    for (id, version, digest) in [
        (Some("other"), None, None),
        (None, Some("2.0.0"), None),
        (None, None, Some("bad")),
    ] {
        let err = service
            .dispatch(
                "main",
                Request::InstallLocal {
                    path: pkg.path().display().to_string(),
                    source: "local".into(),
                    expected_id: id.map(str::to_owned),
                    expected_version: version.map(str::to_owned),
                    expected_digest: digest.map(str::to_owned),
                },
            )
            .unwrap_err();
        assert_eq!(err.code, "packageMismatch");
    }
    assert!(snapshot(&mut service).installations.is_empty());
    install(&mut service, &pkg, "local");
    let newer = package("2.0.0");
    let path = newer.path().join("manifest.json");
    let mut manifest: serde_json::Value =
        serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
    manifest["dataSchemaVersion"] = json!(2);
    fs::write(&path, serde_json::to_vec(&manifest).unwrap()).unwrap();
    let err = service
        .dispatch(
            "main",
            Request::BeginTransition {
                id: "weather".into(),
                action: TransitionAction::Update,
                path: Some(newer.path().display().to_string()),
                source: Some("local".into()),
                expected_digest: None,
            },
        )
        .unwrap_err();
    assert_eq!(err.code, "migrationRequired");
    assert!(snapshot(&mut service).pending.is_empty());
}
#[test]
fn data_corruption_is_error_not_first_run() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    let installed = install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    write(&mut service, "main", &token, None).unwrap();
    fs::write(
        root.path()
            .join("data")
            .join(installed.installation_id)
            .join("1/1.json"),
        "broken",
    )
    .unwrap();
    assert!(
        service
            .dispatch(
                "main",
                Request::ReadData {
                    token: token.token.clone()
                }
            )
            .is_err()
    );
    assert!(write(&mut service, "main", &token, Some(1)).is_err());
    drop(service);
    assert!(Service::open(root.path()).is_err());
}
#[test]
fn failed_state_commit_never_selects_prepared_data() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    write(&mut service, "main", &token, None).unwrap();
    // Force atomic state replacement to fail after the new data file is durable.
    fs::rename(
        root.path().join("state.json"),
        root.path().join("saved-state.json"),
    )
    .unwrap();
    fs::create_dir(root.path().join("state.json")).unwrap();
    assert!(write(&mut service, "main", &token, Some(1)).is_err());
    assert_eq!(
        service
            .dispatch("main", Request::Snapshot)
            .unwrap_err()
            .code,
        "restartRequired"
    );
    drop(service);
    fs::rename(
        root.path().join("state.json"),
        root.path().join("blocked-state"),
    )
    .unwrap();
    fs::rename(
        root.path().join("saved-state.json"),
        root.path().join("state.json"),
    )
    .unwrap();
    let mut service = Service::open(root.path()).unwrap();
    let token = register(&mut service, "main");
    let Response::Data { data: Some(data) } = service
        .dispatch("main", Request::ReadData { token: token.token })
        .unwrap()
    else {
        panic!("expected old data")
    };
    assert_eq!(data.revision, 1);
}

#[test]
fn rejects_excessively_nested_packages_before_recursive_stack_growth() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut nested = pkg.path().to_path_buf();
    for _ in 0..70 {
        nested = nested.join("d");
        fs::create_dir(&nested).unwrap();
    }
    let mut service = Service::open(root.path()).unwrap();
    let result = service.dispatch(
        "main",
        Request::InstallLocal {
            path: pkg.path().display().to_string(),
            source: "local".into(),
            expected_id: None,
            expected_version: None,
            expected_digest: None,
        },
    );
    assert_eq!(result.unwrap_err().code, "packageTooLarge");
}
#[test]
fn two_windows_competing_cas_only_one_commits() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let a = register(&mut service, "main");
    let b = register(&mut service, "settings");
    let service = std::sync::Arc::new(std::sync::Mutex::new(service));
    let start = std::sync::Arc::new(std::sync::Barrier::new(2));
    let tasks = [("main", a), ("settings", b)]
        .into_iter()
        .map(|(window, token)| {
            let service = service.clone();
            let start = start.clone();
            std::thread::spawn(move || {
                start.wait();
                write(&mut service.lock().unwrap(), window, &token, None)
            })
        })
        .collect::<Vec<_>>();
    let outcomes = tasks
        .into_iter()
        .map(|t| t.join().unwrap())
        .collect::<Vec<_>>();
    assert_eq!(outcomes.iter().filter(|r| r.is_ok()).count(), 1);
    assert_eq!(
        outcomes
            .iter()
            .filter_map(|r| r.as_ref().err())
            .next()
            .unwrap()
            .code,
        "conflict"
    );
}

#[test]
fn missing_authoritative_state_after_initialization_is_not_an_empty_installation() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    drop(service);
    fs::rename(
        root.path().join("state.json"),
        root.path().join("lost-state.json"),
    )
    .unwrap();
    assert!(
        Service::open(root.path()).is_err(),
        "missing authority must not silently reset source ownership or data identity"
    );
}

#[test]
fn release_can_retry_after_lost_response_but_cannot_release_another_window() {
    let root = tempfile::tempdir().unwrap();
    let pkg = package("1.0.0");
    let mut service = Service::open(root.path()).unwrap();
    install(&mut service, &pkg, "local");
    service
        .dispatch(
            "main",
            Request::Enable {
                id: "weather".into(),
            },
        )
        .unwrap();
    let token = register(&mut service, "main");
    let request = Request::Release {
        token: token.token.clone(),
    };
    assert_eq!(
        service
            .dispatch("settings", request.clone())
            .unwrap_err()
            .code,
        "staleToken"
    );
    assert!(
        write(&mut service, "main", &token, None).is_ok(),
        "foreign release must preserve the live lease"
    );
    service.dispatch("main", request.clone()).unwrap();
    let after = snapshot(&mut service).sequence;
    assert!(matches!(
        service.dispatch("main", request).unwrap(),
        Response::Ok
    ));
    assert_eq!(
        snapshot(&mut service).sequence,
        after,
        "retry must not mutate durable state or rebroadcast"
    );
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct ManifestCompatibility {
    valid_ids: Vec<String>,
    invalid_ids: Vec<String>,
    valid_ranges: Vec<String>,
    invalid_ranges: Vec<String>,
}
#[test]
fn manifest_installer_matches_shared_id_and_wire_range_fixtures() {
    let fixture: ManifestCompatibility =
        serde_json::from_str(include_str!("../../schemas/manifest-compatibility.json")).unwrap();
    let check = |id: &str, range: &str, valid: bool| {
        let root = tempfile::tempdir().unwrap();
        let pkg = package("1.0.0");
        let path = pkg.path().join("manifest.json");
        fs::write(path,serde_json::to_vec(&json!({"manifestVersion":2,"id":id,"name":"Fixture","version":"1.0.0","entry":"main.js","engines":{"extension":range},"capabilities":{"required":{"http":range},"optional":{"theme":range}},"contributions":{"required":{"commands":range},"optional":{"settings":range}}})).unwrap()).unwrap();
        let mut service = Service::open(root.path()).unwrap();
        let result = service.dispatch(
            "main",
            Request::InstallLocal {
                path: pkg.path().display().to_string(),
                source: "local".into(),
                expected_id: None,
                expected_version: None,
                expected_digest: None,
            },
        );
        assert_eq!(
            result.is_ok(),
            valid,
            "id={id:?}, range={range:?}: {result:?}"
        );
    };
    for id in fixture.valid_ids {
        check(&id, "^0.1.0", true);
    }
    for id in fixture.invalid_ids {
        check(&id, "^0.1.0", false);
    }
    for range in fixture.valid_ranges {
        check("weather", &range, true);
    }
    for range in fixture.invalid_ranges {
        check("weather", &range, false);
    }
}

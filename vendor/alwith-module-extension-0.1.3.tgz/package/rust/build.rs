fn main() {
    #[cfg(feature = "tauri")]
    tauri_plugin::Builder::new(&["dispatch", "pick_local"]).build();
}

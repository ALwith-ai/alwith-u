## Default Permission

Application extension infrastructure; local installation additionally requires a native selection grant.

#### This default permission set includes the following:

- `allow-dispatch`
- `allow-pick-local`

## Permission Table

<table>
<tr>
<th>Identifier</th>
<th>Description</th>
</tr>


<tr>
<td>

`alwith-extension:allow-dispatch`

</td>
<td>

Enables the dispatch command without any pre-configured scope.

</td>
</tr>

<tr>
<td>

`alwith-extension:deny-dispatch`

</td>
<td>

Denies the dispatch command without any pre-configured scope.

</td>
</tr>

<tr>
<td>

`alwith-extension:allow-pick-local`

</td>
<td>

Enables the pick_local command without any pre-configured scope.

</td>
</tr>

<tr>
<td>

`alwith-extension:deny-pick-local`

</td>
<td>

Denies the pick_local command without any pre-configured scope.

</td>
</tr>
</table>

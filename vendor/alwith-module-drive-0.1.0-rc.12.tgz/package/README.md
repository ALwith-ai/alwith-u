# @alwith/module-drive

Pre-release shared Drive module. JavaScript and Rust ship in the same versioned artifact. The native engine is extracted from ALwith Desktop; `desktop-provenance.json` records the source revision and original file hashes. Desktop migration is deferred.

## Entry points

- `@alwith/module-drive`: generated protocol types, transport interface and controller.
- `@alwith/module-drive/react`: controller subscriptions, launcher/settings/status panels, permissions, badges, mass-delete confirmation, localization and pinned-entry helpers. Inject host shadcn controls and navigation.
- `@alwith/module-drive/content`: comments, Markdown/HTML integration, collaboration, frontmatter, versions, knowledge jobs, chat suggestions, cross-project move and file-link helpers.
- `@alwith/module-drive/tauri`: transport constructor; no dependency on a particular Tauri version.
- `@alwith/module-drive/styles.css`: scoped semantic-token styles.
- `rust/`: `alwith-drive` service and `drive-sync` engine. Cargo consumers use the installed package path, not a sibling application checkout.

## Host contract

Create one native `DriveService` for the application. Inject application data, a shared ownership registry, default local directory, reserved legacy application directories, device identity and a system browser opener. Forward `execute` and `subscribe` only to authorized application windows. Forward a fresh snapshot on broadcast lag. Keep credentials out of snapshots, logs and persisted frontend state. Restrict the explicit MCP/collaboration credential responses to the primary trusted window.

Subscribe before fetching the initial snapshot. `createDriveController` buffers this interval and reconciles generation/sequence gaps. A window's disposal stops its listener, not the application service. Call and await native `shutdown` before terminating the process. Keep the service alive until shutdown completes.

All native filesystem mutations that can intersect the Drive root must run through `with_filesystem` after host path authorization. Pass exact write destinations and removed source paths. It serializes native changes with complete sync rounds, checks indexed read-only/collaboration state, and records successful removal intent. This coarse coordinator can delay operations during a transfer. It is not an OS sandbox: external editors and agents use ordinary filesystem permissions.

Use independent application roots. New roots must be empty. Ownership is persisted by canonical root, account/server and host data directory; overlapping roots and reuse by another profile are rejected. Old Desktop does not participate in this registry: hosts must reserve its configured root and prohibit sharing it. There is no automatic credential or index migration.

Credentials are stored in a native atomic profile file (owner-only permissions on Unix); protect the containing app data directory on the host OS. Logout preserves local files. Revocation retains the extracted engine's cleanup/residual behavior. Use dedicated accounts and temporary directories when testing revocation.

## Current boundaries

This remains an integration candidate pending real service and multi-client acceptance. The panel provides separate `launcher`, `settings` and `status` modes; the host supplies native directory selection, navigation, settings routing and external opening. It uses the existing workspace rather than rendering a second tree. Download preference changes reload the engine while preserving pause state.

Opt into content integration by mounting `DriveContentProvider`, wrapping managed documents in `CommentSurface`, and merging `drivePreviewIntegrations` into the shared editor host. Supply `saveDocument` and track collaboration ownership. Route authorized collaborative atomic writes through `with_collaborative_filesystem`; ordinary writes remain subject to `with_filesystem`. Lock source editing separately from collaborative preview permissions. The content entry requires its documented optional Milkdown, Yjs and editor peer dependencies.

Mount `DriveMassDeleteDialog` in the primary window independently of panel visibility. `ChatCondenseEntry` takes host preference storage for its 30-day snooze; pass approved jobs to `DriveCondense.initialJob`. Keep dialog ownership outside transient context menus. Hosts choose their OS link scheme; avoid claiming another application's registered protocol.

Archive is disabled by default. Hosts obtain explicit consent, export dialogue through their existing conversation owner, and provide `expectedGeneration` with each upload. Native code rechecks consent, private-session exclusion, workspace markers and generation before filtering and uploading. Archive metadata contains hashes and status, not a second conversation store. Knowledge and MCP configuration are resolved for each explicit session workspace. Configure a skills directory before starting the native engine.

Removal intent is inherited in-memory engine state; crash-safe delete/move recovery is not provided. The shared service adds no database schema migration. The editor host must preserve dirty buffers and check expected file versions. Native workspace size limits still apply after downloads. Cloud-only files cannot be edited locally; collaborative files require the explicit owner adapter rather than ordinary source writes.

Generated JSON numeric fields use JavaScript numbers, matching the existing transport. Values outside JavaScript's safe integer range are not supported; remote identifiers preserve string variants.

## Development

```sh
bun install
bun run bindings
bun test src
cargo test --manifest-path rust/Cargo.toml --workspace
bun run build
bun pm pack
```

Use the repository's `scripts/build-npm.ts` builder. Publish only after an explicit release decision and real native, multi-process and supported-platform validation.

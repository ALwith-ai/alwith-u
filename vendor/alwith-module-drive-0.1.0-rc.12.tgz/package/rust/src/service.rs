mod move_target;

use crate::contract::Snapshot;
use crate::contract::*;
use crate::ownership::{RootLease, canonical_target};
use crate::profile::{self, Profile};
use drive_sync::push::{PushConfig, PushEvent, run_push};
use drive_sync::types::*;
use drive_sync::watcher::{DEFAULT_DEBOUNCE, Watcher};
use drive_sync::{DriveClient, Engine, EngineConfig, EngineEvent};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::{HashMap, HashSet};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tokio::sync::{broadcast, mpsc, watch};

// Cancellation only drops work at an await boundary. Engine disk/index writes are
// synchronous, and host mutations are awaited separately after authorization.
async fn interruptible<T, R>(
    signal: &mut watch::Receiver<T>, operation: impl std::future::Future<Output = R>,
) -> Result<R, String> {
    if signal.has_changed().map_err(|error| error.to_string())? {
        return Err("Drive operation interrupted by shutdown".into());
    }
    tokio::select! {
        biased;
        _ = signal.changed() => Err("Drive operation interrupted by shutdown".into()),
        result = operation => Ok(result),
    }
}

pub type UrlOpener = Arc<dyn Fn(&str) -> Result<(), String> + Send + Sync>;

pub struct ServiceOptions {
    pub data_directory: PathBuf,
    pub ownership_directory: PathBuf,
    pub default_root: PathBuf,
    /// Existing applications that do not yet participate in root ownership.
    pub reserved_roots: Vec<PathBuf>,
    pub device_name: String,
    pub client_version: String,
    pub open_url: UrlOpener,
}

struct Running {
    engine: Arc<Engine>,
    wake: mpsc::UnboundedSender<()>,
    stop: watch::Sender<bool>,
    tasks: Vec<tokio::task::JoinHandle<()>>,
    gate: Arc<tokio::sync::Mutex<()>>,
    _lease: Arc<RootLease>,
}

impl Drop for Running {
    fn drop(&mut self) {
        self.stop.send_replace(true);
    }
}

struct Inner {
    profile: Option<Profile>,
    running: Option<Running>,
    generation: u32,
    collab_owners: HashMap<String, (RemoteId, String, HashSet<String>)>,
    comment_owners: HashMap<String, Vec<RemoteId>>,
}

struct Projection {
    snapshot: Snapshot,
    events: broadcast::Sender<DriveEvent>,
}

impl Projection {
    fn emit(&mut self, payload: Payload) {
        self.snapshot.sequence = self.snapshot.sequence.checked_add(1).expect("Drive event sequence exhausted");
        match &payload {
            Payload::Status(status) => {
                self.snapshot.status = Some(status.clone());
                if matches!(status.state, EngineState::Idle) {
                    self.snapshot.error = None;
                }
            }
            Payload::File(file) => {
                self.snapshot.files.retain(|entry| entry.local_path != file.local_path);
                self.snapshot.files.push(file.clone());
            }
            Payload::Project(project) => {
                self.snapshot.projects.retain(|entry| entry.project_id != project.project_id);
                self.snapshot.projects.push(project.clone());
            }
            Payload::Error(error) => self.snapshot.error = Some(error.clone()),
            _ => {}
        }
        let _ = self.events.send(DriveEvent {
            version: CONTRACT_VERSION,
            generation: self.snapshot.generation,
            sequence: self.snapshot.sequence,
            payload,
        });
    }
}

pub struct DriveService {
    options: ServiceOptions,
    inner: tokio::sync::Mutex<Inner>,
    operations: tokio::sync::Mutex<()>,
    shutdown_signal: watch::Sender<()>,
    projection: Arc<Mutex<Projection>>,
    comment_files: watch::Sender<Vec<RemoteId>>,
    skills_directory: Mutex<Option<PathBuf>>,
}

impl DriveService {
    pub fn new(options: ServiceOptions) -> Result<Self, String> {
        let profile = profile::load(&options.data_directory.join("profile.json"))?;
        let (events, _) = broadcast::channel(1024);
        let snapshot = Snapshot {
            version: CONTRACT_VERSION,
            generation: 1,
            sequence: 0,
            configured: profile.is_some(),
            running: false,
            base_url: profile.as_ref().map(|value| value.base_url.clone()).unwrap_or_default(),
            local_root: profile
                .as_ref()
                .map(|value| value.local_root.clone())
                .unwrap_or_else(|| options.default_root.clone())
                .to_string_lossy()
                .into_owned(),
            web_base_url: profile.as_ref().and_then(|value| value.web_base_url.clone()),
            status: None,
            roots: vec![],
            pending_deletes: vec![],
            files: vec![],
            projects: vec![],
            error: None,
        };
        Ok(Self {
            options,
            skills_directory: Mutex::new(None),
            comment_files: watch::channel(Vec::new()).0,
            inner: tokio::sync::Mutex::new(Inner {
                profile,
                running: None,
                generation: 1,
                collab_owners: HashMap::new(),
                comment_owners: HashMap::new(),
            }),
            operations: tokio::sync::Mutex::new(()),
            shutdown_signal: watch::channel(()).0,
            projection: Arc::new(Mutex::new(Projection { snapshot, events })),
        })
    }

    /// Set the host-owned skill mirror destination before starting Drive.
    pub async fn set_skills_directory(&self, directory: PathBuf) -> Result<(), String> {
        let _operation = self.operations.lock().await;
        if self.inner.lock().await.running.is_some() {
            return Err("Set skill directory before starting Drive".into());
        }
        *self.skills_directory.lock().expect("Drive skills directory poisoned") = Some(canonical_target(&directory)?);
        Ok(())
    }

    pub fn snapshot(&self) -> Snapshot {
        self.projection.lock().expect("Drive projection poisoned").snapshot.clone()
    }
    pub fn subscribe(&self) -> broadcast::Receiver<DriveEvent> {
        self.projection.lock().expect("Drive projection poisoned").events.subscribe()
    }

    fn owner(&self, profile: &Profile) -> Result<String, String> {
        Ok(format!("{}:{}", profile.identity(), canonical_target(&self.options.data_directory)?.display()))
    }

    fn publish_profile(&self, inner: &Inner) {
        let mut projection = self.projection.lock().expect("Drive projection poisoned");
        projection.snapshot.generation = inner.generation;
        projection.snapshot.configured = inner.profile.is_some();
        projection.snapshot.running = inner.running.is_some();
        projection.snapshot.base_url = inner.profile.as_ref().map(|value| value.base_url.clone()).unwrap_or_default();
        projection.snapshot.local_root = inner
            .profile
            .as_ref()
            .map(|value| value.local_root.clone())
            .unwrap_or_else(|| self.options.default_root.clone())
            .to_string_lossy()
            .into_owned();
        projection.snapshot.web_base_url = inner.profile.as_ref().and_then(|value| value.web_base_url.clone());
        projection.snapshot.status = inner.running.as_ref().map(|value| value.engine.status());
        projection.snapshot.files.clear();
        projection.snapshot.projects.clear();
        projection.snapshot.roots.clear();
        projection.snapshot.pending_deletes.clear();
        projection.snapshot.error = None;
        let snapshot = projection.snapshot.clone();
        projection.emit(Payload::Snapshot(snapshot));
    }

    fn validate_root(&self, raw: &str) -> Result<PathBuf, String> {
        let root = canonical_target(Path::new(raw))?;
        for reserved in &self.options.reserved_roots {
            let reserved = canonical_target(reserved)?;
            if root.starts_with(&reserved) || reserved.starts_with(&root) {
                return Err(
                    "This directory is reserved by another application; choose a separate Drive directory".into()
                );
            }
        }
        let data = canonical_target(&self.options.data_directory)?;
        let registry = canonical_target(&self.options.ownership_directory)?;
        if data.starts_with(&root)
            || root.starts_with(&data)
            || registry.starts_with(&root)
            || root.starts_with(&registry)
        {
            return Err("Drive files must be outside application data".into());
        }
        Ok(root)
    }

    async fn login(
        &self, base_url: String, local_root: String, token: Option<String>,
    ) -> Result<DriveResponse, String> {
        let base_url = profile::validate_url(&base_url)?;
        let root = self.validate_root(&local_root)?;
        let generation = {
            let mut inner = self.inner.lock().await;
            if inner.profile.is_some() {
                return Err("Log out before changing the Drive profile".into());
            }
            inner.generation += 1;
            inner.generation
        };
        let device = drive_sync::sso::DeviceDescriptor {
            device_name: self.options.device_name.clone(),
            platform: std::env::consts::OS.into(),
            client_version: self.options.client_version.clone(),
        };
        let (device_id, token, user_name, user_id) = match token {
            Some(token) => {
                if token.trim().is_empty() {
                    return Err("A personal access token is required".into());
                }
                let client = DriveClient::new(&base_url, token.trim());
                let registration = client
                    .register_device(&RegisterDeviceRequest {
                        device_name: device.device_name,
                        platform: device.platform,
                        client_version: device.client_version,
                    })
                    .await
                    .map_err(|error| error.to_string().replace(token.trim(), "[redacted]"))?;
                let user = DriveClient::new(&base_url, &registration.token)
                    .me()
                    .await
                    .map_err(|error| error.to_string().replace(&registration.token, "[redacted]"))?;
                let user_id = user.id.ok_or("Drive server did not identify the account")?.as_key();
                (registration.device_id, registration.token, user.name.unwrap_or_else(|| user_id.clone()), user_id)
            }
            None => {
                let open = self.options.open_url.clone();
                let response = drive_sync::sso::login(
                    &DriveClient::new(&base_url, ""),
                    device,
                    move |url| open(url),
                    drive_sync::sso::LOGIN_TIMEOUT,
                )
                .await
                .map_err(|error| error.to_string())?;
                (
                    response.device_id.ok_or("SSO did not register a device")?,
                    response.token,
                    response.user.display_name,
                    response.user.user_id.as_key(),
                )
            }
        };
        let client_config = match DriveClient::new(&base_url, &token).client_config().await {
            Ok(config) => config,
            // Legacy servers have no configuration endpoint; transport/auth failures are not absence.
            Err(drive_sync::ClientError::Http { status: 404, .. }) => ClientConfig::default(),
            Err(error) => return Err(error.to_string().replace(&token, "[redacted]")),
        };
        let web_base_url = client_config.web_base_url.as_deref().map(profile::validate_url).transpose()?;
        let profile = Profile {
            base_url,
            token,
            device_id,
            user_name,
            user_id,
            local_root: root,
            web_base_url,
            max_auto_download_mb: None,
            client_config,
            preferences: Preferences::default(),
        };
        let _operation = self.operations.lock().await;
        let mut inner = self.inner.lock().await;
        if inner.generation != generation {
            return Err("Drive login was superseded".into());
        }
        // Ownership is checked before persisting credentials or starting any writer.
        let _lease =
            RootLease::acquire(&self.options.ownership_directory, &profile.local_root, &self.owner(&profile)?)?;
        profile::save(&self.options.data_directory.join("profile.json"), &Some(profile.clone()))?;
        inner.profile = Some(profile);
        self.publish_profile(&inner);
        Ok(DriveResponse::Snapshot(self.snapshot()))
    }

    async fn start(&self, inner: &mut Inner, paused: bool) -> Result<(), String> {
        self.start_with_lease(inner, paused, None).await
    }

    async fn start_with_lease(
        &self, inner: &mut Inner, paused: bool, lease: Option<Arc<RootLease>>,
    ) -> Result<(), String> {
        if let Some(running) = &inner.running {
            if running.engine.is_revoked() {
                return Err("Drive device revoked; sign out and register again".into());
            }
            if self.snapshot().running {
                return Ok(());
            }
            self.stop(inner).await?;
        }
        inner.generation += 1;
        let profile = inner.profile.as_ref().ok_or("Drive is not configured")?;
        if self.validate_root(&profile.local_root.to_string_lossy())? != profile.local_root {
            return Err("Drive directory identity changed; restore its original location before starting".into());
        }
        let lease = match lease {
            Some(lease) => lease,
            None => Arc::new(RootLease::acquire(
                &self.options.ownership_directory,
                &profile.local_root,
                &self.owner(profile)?,
            )?),
        };
        let directory = self.options.data_directory.join("profiles").join(profile.identity());
        let engine = Arc::new(
            Engine::new(
                DriveClient::new(&profile.base_url, &profile.token),
                EngineConfig {
                    local_root: profile.local_root.clone(),
                    index_path: Some(directory.join("index.sqlite3")),
                    device_id: profile.device_id.clone(),
                    user_name: profile.user_name.clone(),
                    skills_dir: self.skills_directory.lock().expect("Drive skills directory poisoned").clone(),
                    windows_names: cfg!(windows),
                    residual_root: directory.join("residual"),
                    transfer_concurrency: drive_sync::DEFAULT_TRANSFER_CONCURRENCY,
                    web_base_url: profile.web_base_url.clone(),
                    max_auto_download_bytes: drive_sync::engine::resolve_max_auto_download_bytes(
                        profile.max_auto_download_mb,
                        profile.client_config.large_file_threshold_bytes,
                    ),
                    max_upload_bytes: profile
                        .client_config
                        .max_upload_bytes
                        .unwrap_or(drive_sync::ignore::DEFAULT_MAX_FILE_SIZE),
                },
            )
            .map_err(|error| error.to_string())?,
        );
        if paused {
            engine.pause();
        }
        let (watcher, mut batches) = Watcher::start(std::slice::from_ref(&profile.local_root), DEFAULT_DEBOUNCE)
            .map_err(|error| error.to_string())?;
        let (stop, mut shutdown) = watch::channel(false);
        let (wake, mut wake_receiver) = mpsc::unbounded_channel();
        let (subscriptions, subscription_receiver) = watch::channel(Vec::<RemoteId>::new());
        let comments_receiver = self.comment_files.subscribe();
        let (push_sender, mut push_receiver) = mpsc::unbounded_channel();
        let push_config = PushConfig::standard(engine.client().push_url());
        let mut push_shutdown = stop.subscribe();
        let push = tokio::spawn(async move {
            tokio::select! { _ = push_shutdown.changed() => {}, _ = run_push(push_config, subscription_receiver, comments_receiver, push_sender) => {} }
        });
        let mut events = engine.subscribe();
        let projection = self.projection.clone();
        let event_engine = engine.clone();
        let mut event_shutdown = stop.subscribe();
        let forward = tokio::spawn(async move {
            loop {
                tokio::select! {
                    _ = event_shutdown.changed() => break,
                    event = events.recv() => {
                        let payload = match event {
                            Ok(EngineEvent::Status(value)) => Payload::Status(value),
                            Ok(EngineEvent::FileState(value)) => Payload::File(value),
                            Ok(EngineEvent::Project(value)) => Payload::Project(value),
                            Ok(EngineEvent::Conflict(value)) => Payload::Conflict(value),
                            Ok(EngineEvent::ReadOnly(value)) => Payload::ReadOnly(value),
                            Ok(EngineEvent::Revoked) => Payload::Error("Drive device revoked".into()),
                            Ok(EngineEvent::CloudOnly(_) | EngineEvent::PendingDeletes(_)) => Payload::Reconcile,
                            Err(broadcast::error::RecvError::Lagged(_)) => Payload::Reconcile,
                            Err(broadcast::error::RecvError::Closed) => break,
                        };
                        let mut state = projection.lock().expect("Drive projection poisoned");
                        state.snapshot.pending_deletes = event_engine.pending_deletes();
                        state.emit(payload);
                    }
                }
            }
        });
        let gate = Arc::new(tokio::sync::Mutex::new(()));
        let worker_gate = gate.clone();
        let run_engine = engine.clone();
        let projection = self.projection.clone();
        let worker_lease = lease.clone();
        let mut host_shutdown = self.shutdown_signal.subscribe();
        let worker = tokio::spawn(async move {
            let _lease = worker_lease;
            let _watcher = watcher;
            loop {
                if *shutdown.borrow() {
                    break;
                }
                let interval = if run_engine.is_push_connected() { 600 } else { 60 };
                tokio::select! {
                    _ = shutdown.changed() => break,
                    signal = wake_receiver.recv() => if signal.is_none() { break; },
                    batch = batches.recv() => match batch {
                        Some(paths) => projection.lock().expect("Drive projection poisoned").emit(Payload::Changed(paths.iter().map(|path| path.to_string_lossy().into_owned()).collect())),
                        None => break,
                    },
                    event = push_receiver.recv() => match event {
                        Some(PushEvent::Connected) => run_engine.set_push_connected(true),
                        Some(PushEvent::Disconnected { .. }) => { run_engine.set_push_connected(false); continue; },
                        Some(PushEvent::FileEvents { .. }) => {},
                        Some(PushEvent::Comment { file_id, comment_id, action, actor_id, at }) => {
                            projection.lock().expect("Drive projection poisoned").emit(Payload::Comment(CommentEvent { file_id, comment_id, action, actor_id, at }));
                            continue;
                        },
                        Some(_) => continue,
                        None => { projection.lock().expect("Drive projection poisoned").emit(Payload::Error("Drive push task stopped".into())); break; },
                    },
                    _ = tokio::time::sleep(Duration::from_secs(interval)) => {},
                }
                let _gate = tokio::select! {
                    biased;
                    _ = shutdown.changed() => break,
                    gate = interruptible(&mut host_shutdown, worker_gate.lock()) => match gate {
                        Ok(gate) => gate,
                        Err(_) => break,
                    },
                };
                if *shutdown.borrow() {
                    break;
                }
                // Cancel network waits without interrupting synchronous disk/index writes.
                // Downloads are owned by this future; the blocking scanner only reads files.
                let result = tokio::select! {
                    biased;
                    _ = shutdown.changed() => break,
                    result = interruptible(&mut host_shutdown, run_engine.sync_once()) => match result {
                        Ok(result) => result,
                        Err(_) => break,
                    },
                };
                if let Err(error) = result {
                    projection
                        .lock()
                        .expect("Drive projection poisoned")
                        .emit(Payload::Error(error.to_string().replace(run_engine.client().token(), "[redacted]")));
                }
                match run_engine.roots() {
                    Ok(roots) => {
                        subscriptions.send_replace(
                            roots.iter().filter(|root| root.selected).map(|root| root.project_id.clone()).collect(),
                        );
                        let mut state = projection.lock().expect("Drive projection poisoned");
                        state.snapshot.roots = roots;
                        state.snapshot.pending_deletes = run_engine.pending_deletes();
                        state.emit(Payload::Reconcile);
                    }
                    Err(error) => {
                        projection.lock().expect("Drive projection poisoned").emit(Payload::Error(error.to_string()))
                    }
                }
                if run_engine.is_revoked() {
                    break;
                }
            }
            {
                let mut state = projection.lock().expect("Drive projection poisoned");
                state.snapshot.running = false;
                state.emit(Payload::Reconcile);
            }
        });
        inner.running = Some(Running { engine, wake, stop, tasks: vec![worker, push, forward], gate, _lease: lease });
        self.publish_profile(inner);
        inner.running.as_ref().expect("started").wake.send(()).map_err(|_| "Drive worker stopped")?;
        Ok(())
    }

    async fn stop(&self, inner: &mut Inner) -> Result<(), String> {
        inner.collab_owners.clear();
        inner.generation += 1;
        if let Some(mut running) = inner.running.take() {
            running.stop.send_replace(true);
            let mut errors = vec![];
            for task in running.tasks.drain(..) {
                if let Err(error) = task.await {
                    errors.push(error.to_string());
                }
            }
            drop(running);
            if !errors.is_empty() {
                self.publish_profile(inner);
                return Err(errors.join("; "));
            }
        }
        self.publish_profile(inner);
        Ok(())
    }

    /// Preserve remote identity when a host moves between two managed projects.
    /// Returns false when ordinary local filesystem semantics apply.
    pub async fn move_between_projects(&self, source: &Path, destination: &Path) -> Result<bool, String> {
        let mut shutdown = self.shutdown_signal.subscribe();
        let _operation = interruptible(&mut shutdown, self.operations.lock()).await?;
        let inner = self.inner.lock().await;
        let Some(running) = &inner.running else {
            return Ok(false);
        };
        let _gate = interruptible(&mut shutdown, running.gate.lock()).await?;
        let source = canonical_target(source)?;
        let destination = canonical_target(destination)?;
        let engine = &running.engine;
        let Some(from) = engine.project_of(&source).map_err(|error| error.to_string())? else {
            return Ok(false);
        };
        let Some(to) = engine.project_of(&destination).map_err(|error| error.to_string())? else {
            return Ok(false);
        };
        if from == to {
            return Ok(false);
        }
        if source.file_name() != destination.file_name() {
            return Err("Move between projects first, then rename the file".into());
        }
        if destination.try_exists().map_err(|error| error.to_string())? {
            return Err("Move destination already exists".into());
        }
        interruptible(&mut shutdown, engine.sync_once()).await?.map_err(|error| error.to_string())?;
        if engine.unsynced_summary(&from, None).map_err(|error| error.to_string())?.pending != 0 {
            return Err("Finish syncing the source project before moving it".into());
        }
        let roots = engine.roots().map_err(|error| error.to_string())?;
        for id in [&from, &to] {
            let root = roots.iter().find(|root| &root.project_id == id).ok_or("Project disappeared during move")?;
            if !root.can_write || !root.sync_enabled || root.cloud_only || root.kind == ProjectKind::Skill {
                return Err("Move requires writable projects".into());
            }
            if source == Path::new(&root.local_path) {
                return Err("Cannot move a project root".into());
            }
        }
        check_writable(engine, &source)?;
        let parent = destination.parent().ok_or("Move destination has no parent")?;
        if !parent.is_dir() {
            return Err("Move destination directory must already exist".into());
        }
        let target =
            interruptible(&mut shutdown, engine.grant_target(parent)).await?.map_err(|error| error.to_string())?;
        if target.is_none() && !roots.iter().any(|root| root.project_id == to && Path::new(&root.local_path) == parent)
        {
            return Err("Cannot resolve the cloud destination folder".into());
        }
        let folder = target.as_ref().map(|target| &target.id);
        let moved = interruptible(&mut shutdown, async {
            if source.is_dir() {
                engine.move_folder_to_project(&source, &to, folder).await
            } else {
                engine.move_file_to_project(&source, &to, folder).await
            }
        })
        .await?
        .map_err(|error| error.to_string())?;
        if moved.is_none() {
            return Err("Upload the source before moving it between projects".into());
        }
        // Never locally delete the source of a committed server move.
        interruptible(&mut shutdown, engine.sync_once())
            .await?
            .map_err(|error| format!("Cloud move committed; local synchronization failed: {error}"))?;
        let mut state = self.projection.lock().expect("Drive projection poisoned");
        state.snapshot.roots = engine.roots().map_err(|error| error.to_string())?;
        state.emit(Payload::Reconcile);
        Ok(true)
    }

    /// Hosts must authorize paths themselves before entering this coordinator.
    /// Lock order: host operations -> lifecycle operations -> inner -> sync gate.
    /// This first release serializes whole sync rounds; it favors correctness over latency.
    pub async fn with_filesystem<T, F>(
        &self, writes: &[PathBuf], removed: &[PathBuf], operation: F,
    ) -> Result<T, String>
    where
        F: std::future::Future<Output = Result<T, String>>,
    {
        let _operation = self.operations.lock().await;
        let inner = self.inner.lock().await;
        let Some(profile) = &inner.profile else {
            return operation.await;
        };
        let targets = writes.iter().map(|path| canonical_target(path)).collect::<Result<Vec<_>, _>>()?;
        let managed =
            targets.iter().any(|path| path.starts_with(&profile.local_root) || profile.local_root.starts_with(path));
        let Some(running) = &inner.running else {
            if managed {
                return Err("Start Drive before changing its files".into());
            }
            return operation.await;
        };
        let _gate = running.gate.lock().await;
        if managed {
            if running.engine.is_revoked() {
                return Err("Drive device revoked".into());
            }
            let roots = running.engine.roots().map_err(|error| error.to_string())?;
            if !removed.is_empty() {
                let ids: std::collections::HashSet<_> = targets
                    .iter()
                    .filter_map(|path| {
                        roots
                            .iter()
                            .find(|root| path.starts_with(Path::new(&root.local_path)))
                            .map(|root| root.project_id.as_key())
                    })
                    .collect();
                if ids.len() > 1 {
                    return Err("Cross-project moves require the Drive move coordinator".into());
                }
            }
            for path in &targets {
                if !path.starts_with(&profile.local_root) && !profile.local_root.starts_with(path) {
                    continue;
                }
                let root = roots
                    .iter()
                    .find(|root| path.starts_with(Path::new(&root.local_path)))
                    .ok_or("Cannot mutate the Drive container")?;
                if path == Path::new(&root.local_path)
                    || !root.can_write
                    || !root.sync_enabled
                    || root.cloud_only
                    || root.kind == ProjectKind::Skill
                {
                    return Err("This Drive location is read-only".into());
                }
                check_writable(&running.engine, path)?;
            }
        }
        let result = operation.await?;
        if managed {
            running.engine.mark_user_removed(removed);
            running.wake.send(()).map_err(|_| "Drive worker stopped after the filesystem operation completed")?;
        }
        Ok(result)
    }

    /// Materialize the current editor's collaboration buffer through the host's atomic CAS write.
    /// The host may use this only for a single writeFile, never moves, deletes or directory creation.
    pub async fn with_collaborative_filesystem<T, F>(
        &self, path: &Path, owner_id: &str, operation: F,
    ) -> Result<T, String>
    where
        F: std::future::Future<Output = Result<T, String>>,
    {
        let mut shutdown = self.shutdown_signal.subscribe();
        let _operation = interruptible(&mut shutdown, self.operations.lock()).await?;
        let inner = self.inner.lock().await;
        let path = canonical_target(path)?;
        let key = path.to_string_lossy();
        let (project, cloud_path, _) = inner
            .collab_owners
            .get(key.as_ref())
            .filter(|(_, _, owners)| owners.contains(owner_id))
            .ok_or("This editor does not own the collaboration session")?;
        let running = inner.running.as_ref().ok_or("Drive is not running")?;
        if !self.snapshot().running || running.engine.is_revoked() {
            return Err("Drive collaboration is unavailable".into());
        }
        let _gate = interruptible(&mut shutdown, running.gate.lock()).await?;
        let engine = &running.engine;
        let (root, row) = engine
            .file_row(&path)
            .map_err(|e| e.to_string())?
            .ok_or("Collaborative file is no longer managed by Drive")?;
        if &root.project_id != project
            || &row.path != cloud_path
            || !path.is_file()
            || !root.can_write
            || !root.sync_enabled
            || root.cloud_only
            || root.kind == ProjectKind::Skill
            || row.read_only
            || path.extension().is_some_and(|extension| extension == "yupcloud")
        {
            return Err("This collaborative file is read-only or changed identity".into());
        }
        let file_id = row.remote_file_id.ok_or("Collaborative file has no remote identity")?;
        let access = interruptible(&mut shutdown, engine.client().file_access(&file_id))
            .await?
            .map_err(|error| error.to_string().replace(engine.client().token(), "[redacted]"))?;
        if access.can_write == Some(false) {
            return Err("This collaborative file is read-only".into());
        }
        // Refresh the upload exclusion before materializing disk content under the same sync gate.
        engine.begin_local_collab(project, cloud_path);
        let result = operation.await?;
        running.wake.send(()).map_err(|_| "Drive worker stopped after the filesystem operation completed")?;
        Ok(result)
    }

    pub async fn shutdown(&self) -> Result<(), String> {
        // Signal before taking lifecycle locks: a foreground request may hold them
        // while waiting for the worker's sync gate or a stalled network response.
        self.shutdown_signal.send_replace(());
        let _operation = self.operations.lock().await;
        let mut inner = self.inner.lock().await;
        inner.generation += 1;
        self.stop(&mut inner).await
    }

    pub async fn execute(&self, mut request: DriveRequest) -> Result<DriveResponse, String> {
        let mut shutdown = self.shutdown_signal.subscribe();
        // Different editor paths to the same file must share one collaboration lease.
        if let DriveRequest::CollabSession { path, .. } | DriveRequest::CollabEnd { path, .. } = &mut request {
            *path = canonical_target(Path::new(path))?.to_string_lossy().into_owned();
        }
        match request {
            DriveRequest::MoveBetweenProjects { source, destination } => {
                if !self.move_between_projects(Path::new(&source), Path::new(&destination)).await? {
                    return Err("Move requires two distinct managed Drive projects".into());
                }
                return Ok(DriveResponse::Done);
            }
            DriveRequest::Snapshot => return Ok(DriveResponse::Snapshot(self.snapshot())),
            DriveRequest::Login { base_url, token, local_root } => {
                return self.login(base_url, local_root, Some(token)).await;
            }
            DriveRequest::SsoLogin { base_url, local_root } => return self.login(base_url, local_root, None).await,
            DriveRequest::SsoConfig { base_url } => {
                return Ok(DriveResponse::SsoConfig(
                    DriveClient::new(&profile::validate_url(&base_url)?, "")
                        .sso_config()
                        .await
                        .map_err(|error| error.to_string())?,
                ));
            }
            _ => {}
        }
        let _operation = interruptible(&mut shutdown, self.operations.lock()).await?;
        let mut inner = self.inner.lock().await;
        match &request {
            DriveRequest::ArchivePrivateSessions => {
                let privacy = ArchivePrivacy::load(&self.options.data_directory.join("archive-private.json"))?;
                let mut ids: Vec<_> = privacy.session_ids.into_iter().collect();
                ids.sort();
                return Ok(DriveResponse::ArchivePrivateSessions(ids));
            }
            DriveRequest::SetArchivePrivate { session_id, private } => {
                validate_archive_session_id(session_id)?;
                let path = self.options.data_directory.join("archive-private.json");
                let mut privacy = ArchivePrivacy::load(&path)?;
                if *private {
                    privacy.session_ids.insert(session_id.clone());
                } else {
                    privacy.session_ids.remove(session_id);
                }
                privacy.save(&path)?;
                return Ok(DriveResponse::Done);
            }
            DriveRequest::ArchiveStatus => {
                let profile = inner.profile.as_ref().ok_or("Drive is not configured")?;
                let manifest = ArchiveManifest::load(
                    &self.options.data_directory.join("profiles").join(profile.identity()).join("archive.json"),
                )?;
                return Ok(DriveResponse::ArchiveStatus(ArchiveStatus {
                    enabled: profile.preferences.session_archive,
                    syncing: false,
                    last_run_at: manifest.last_run_at,
                    last_upload_at: manifest.last_upload_at,
                    synced: manifest.hashes.len().try_into().map_err(|_| "Archive count overflow")?,
                    last_uploaded: manifest.last_uploaded,
                    last_error: manifest.last_error,
                    mode: Some("sessions".into()),
                }));
            }
            DriveRequest::ArchiveSession { expected_generation, session_id, cwd, title, content, .. } => {
                if *expected_generation != inner.generation {
                    return Err("Drive profile changed during session export".into());
                }
                let profile = inner.profile.as_ref().ok_or("Drive is not configured")?;
                if !profile.preferences.session_archive {
                    return Err("Session archive is disabled".into());
                }
                validate_archive_session_id(session_id)?;
                if ArchivePrivacy::load(&self.options.data_directory.join("archive-private.json"))?
                    .session_ids
                    .contains(session_id)
                {
                    return Ok(DriveResponse::Count(0));
                }
                if content.len() > 25 * 1024 * 1024 {
                    return Err("Session exceeds archive size limit".into());
                }
                let cwd = canonical_target(Path::new(cwd))?;
                if cwd.ancestors().any(|path| path.join(".private").exists()) {
                    return Ok(DriveResponse::Count(0));
                }
                let filtered = drive_sync::archive::filter_jsonl_for_archive(content);
                if filtered.kept == 0 {
                    return Ok(DriveResponse::Count(0));
                }
                let hash = hex::encode(Sha256::digest(filtered.jsonl.as_bytes()));
                let manifest_path =
                    self.options.data_directory.join("profiles").join(profile.identity()).join("archive.json");
                let mut manifest = ArchiveManifest::load(&manifest_path)?;
                if manifest.hashes.get(session_id) == Some(&hash) {
                    return Ok(DriveResponse::Count(0));
                }
                let running = inner.running.as_ref().ok_or("Drive is not running")?;
                let _gate = interruptible(&mut shutdown, running.gate.lock()).await?;
                let roots = interruptible(&mut shutdown, running.engine.refresh_roots())
                    .await?
                    .map_err(|e| e.to_string().replace(&profile.token, "[redacted]"))?;
                let root = roots
                    .iter()
                    .filter(|r| {
                        cwd.starts_with(&r.local_path) && r.can_write && r.sync_enabled && r.kind != ProjectKind::Skill
                    })
                    .max_by_key(|r| r.local_path.len());
                let folder = root
                    .and_then(|r| cwd.strip_prefix(&r.local_path).ok())
                    .filter(|p| !p.as_os_str().is_empty())
                    .map(|p| p.to_string_lossy().replace('\\', "/"));
                let safe_title: String = title
                    .chars()
                    .map(|c| if c.is_alphanumeric() || c == '-' || c == '_' { c } else { '_' })
                    .take(80)
                    .collect();
                let id_hash = hex::encode(Sha256::digest(session_id.as_bytes()));
                let name = format!("{}-{}.jsonl", safe_title, &id_hash[..16]);
                manifest.last_run_at = Some(chrono::Utc::now().to_rfc3339());
                manifest.last_uploaded = 0;
                match interruptible(
                    &mut shutdown,
                    running.engine.client().archive_session(
                        session_id,
                        &hash,
                        root.map(|r| &r.project_id),
                        folder.as_deref(),
                        &name,
                        filtered.jsonl.into_bytes(),
                    ),
                )
                .await?
                {
                    Ok(_) => {
                        manifest.hashes.insert(session_id.clone(), hash);
                        manifest.last_upload_at = Some(chrono::Utc::now().to_rfc3339());
                        manifest.last_error = None;
                        manifest.last_uploaded = 1;
                    }
                    Err(error) => {
                        let error = error.to_string().replace(&profile.token, "[redacted]");
                        manifest.last_error = Some(error.clone());
                        manifest.save(&manifest_path)?;
                        return Err(error);
                    }
                }
                manifest.save(&manifest_path)?;
                return Ok(DriveResponse::Count(1));
            }
            DriveRequest::Preferences => {
                return Ok(DriveResponse::Preferences(
                    inner.profile.as_ref().map(|p| p.preferences.clone()).unwrap_or_default(),
                ));
            }
            DriveRequest::SetPreferences { session_archive, knowledge_inject } => {
                let mut profile = inner.profile.clone().ok_or("Drive is not configured")?;
                profile.preferences =
                    Preferences { session_archive: *session_archive, knowledge_inject: *knowledge_inject };
                profile::save(&self.options.data_directory.join("profile.json"), &Some(profile.clone()))?;
                let preferences = profile.preferences.clone();
                inner.profile = Some(profile);
                return Ok(DriveResponse::Preferences(preferences));
            }
            DriveRequest::KnowledgeContext { .. }
                if !inner.profile.as_ref().is_some_and(|p| p.preferences.knowledge_inject) =>
            {
                return Ok(DriveResponse::Text(None));
            }
            DriveRequest::Configuration => {
                return Ok(DriveResponse::Configuration(Configuration {
                    device_id: inner.profile.as_ref().map(|p| p.device_id.clone()),
                    user_name: inner.profile.as_ref().map(|p| p.user_name.clone()),
                    user_id: inner.profile.as_ref().map(|p| p.user_id.clone()),
                    client_config: inner.profile.as_ref().map(|p| p.client_config.clone()),
                }));
            }
            DriveRequest::McpSessionConfig => {
                return Ok(DriveResponse::McpSessionConfig(inner.profile.as_ref().map(|p| McpSessionConfig {
                    url: format!("{}/mcp/drive", p.base_url.trim_end_matches('/')),
                    headers: vec![McpHeader { name: "Authorization".into(), value: format!("Bearer {}", p.token) }],
                })));
            }
            DriveRequest::CommentWatch { owner_id, file_ids } => {
                if owner_id.is_empty() {
                    return Err("Comment owner is required".into());
                }
                if file_ids.is_empty() {
                    inner.comment_owners.remove(owner_id);
                } else {
                    inner.comment_owners.insert(owner_id.clone(), file_ids.clone());
                }
                let mut files = Vec::new();
                for id in inner.comment_owners.values().flatten() {
                    if !files.contains(id) {
                        files.push(id.clone());
                    }
                }
                self.comment_files.send_replace(files);
                return Ok(DriveResponse::Done);
            }
            DriveRequest::Reconfigure { local_root, user_name } => {
                let mut profile = inner.profile.clone().ok_or("Drive is not configured")?;
                let root = self.validate_root(local_root)?;
                let changed_root = root != profile.local_root;
                profile.local_root = root;
                profile.user_name = user_name.clone();
                // Register the candidate identity and hold its lock through engine startup.
                let lease = if changed_root {
                    Some(Arc::new(RootLease::acquire(
                        &self.options.ownership_directory,
                        &profile.local_root,
                        &self.owner(&profile)?,
                    )?))
                } else {
                    None
                };
                let was_running = inner.running.is_some();
                let paused =
                    inner.running.as_ref().is_some_and(|r| matches!(r.engine.status().state, EngineState::Paused));
                self.stop(&mut inner).await?;
                profile::save(&self.options.data_directory.join("profile.json"), &Some(profile.clone()))?;
                inner.profile = Some(profile);
                if was_running {
                    self.start_with_lease(&mut inner, paused, lease).await?;
                }
                self.publish_profile(&inner);
                return Ok(DriveResponse::Snapshot(self.snapshot()));
            }
            DriveRequest::RefreshClientConfig => {
                let mut profile = inner.profile.clone().ok_or("Drive is not configured")?;
                let client = DriveClient::new(&profile.base_url, &profile.token);
                let config = interruptible(&mut shutdown, client.client_config())
                    .await?
                    .map_err(|e| e.to_string().replace(&profile.token, "[redacted]"))?;
                profile.web_base_url = config.web_base_url.as_deref().map(profile::validate_url).transpose()?;
                profile.client_config = config.clone();
                profile::save(&self.options.data_directory.join("profile.json"), &Some(profile.clone()))?;
                inner.profile = Some(profile);
                self.projection.lock().expect("Drive projection poisoned").snapshot.web_base_url =
                    config.web_base_url.clone();
                return Ok(DriveResponse::ClientConfig(config));
            }
            DriveRequest::CollabEnd { path, owner_id } => {
                if let Some((project, cloud_path, owners)) = inner.collab_owners.get_mut(path) {
                    owners.remove(owner_id);
                    if owners.is_empty() {
                        let project = project.clone();
                        let cloud_path = cloud_path.clone();
                        if let Some(running) = &inner.running {
                            running.engine.end_local_collab(&project, &cloud_path);
                        }
                        inner.collab_owners.remove(path);
                    }
                }
                return Ok(DriveResponse::Done);
            }
            DriveRequest::CollabSession { path, owner_id } => {
                if owner_id.is_empty() {
                    return Err("Collaboration owner is required".into());
                }
                let Some(profile) = &inner.profile else {
                    return Ok(DriveResponse::CollabSession(None));
                };
                let Some(server_url) = profile.client_config.collab_relay_url.as_deref().and_then(collab_server_url)
                else {
                    return Ok(DriveResponse::CollabSession(None));
                };
                let token = profile.token.clone();
                let running = inner.running.as_ref().ok_or("Drive is not running")?;
                let gate = running.gate.clone();
                let _gate = interruptible(&mut shutdown, gate.lock()).await?;
                let engine = running.engine.clone();
                let Some((root, row)) = engine.file_row(Path::new(path)).map_err(|e| e.to_string())? else {
                    return Ok(DriveResponse::CollabSession(None));
                };
                let Some(file_id) = row.remote_file_id else {
                    return Ok(DriveResponse::CollabSession(None));
                };
                let root_can_write = root.can_write && root.sync_enabled && !root.cloud_only;
                let access = interruptible(&mut shutdown, engine.client().file_access(&file_id))
                    .await?
                    .map_err(|e| e.to_string().replace(&token, "[redacted]"))?;
                engine.begin_local_collab(&root.project_id, &row.path);
                inner
                    .collab_owners
                    .entry(path.clone())
                    .or_insert_with(|| (root.project_id, row.path, HashSet::new()))
                    .2
                    .insert(owner_id.clone());
                return Ok(DriveResponse::CollabSession(Some(CollabSession {
                    room: file_id.as_key(),
                    file_id,
                    server_url,
                    token,
                    can_write: access.can_write.unwrap_or(root_can_write) && root_can_write,
                })));
            }
            _ => {}
        }
        match request {
            DriveRequest::MaxAutoDownloadMb => {
                let profile = inner.profile.as_ref().ok_or("Drive is not configured")?;
                let bytes = drive_sync::engine::resolve_max_auto_download_bytes(
                    profile.max_auto_download_mb,
                    profile.client_config.large_file_threshold_bytes,
                );
                return Ok(DriveResponse::MaxAutoDownloadMb(bytes / (1024 * 1024)));
            }
            DriveRequest::SetMaxAutoDownloadMb { megabytes } => {
                if megabytes > 1_048_576 {
                    return Err("Download threshold must be between 0 and 1048576 MB".into());
                }
                let mut profile = inner.profile.clone().ok_or("Drive is not configured")?;
                profile.max_auto_download_mb = Some(megabytes);
                let running = inner.running.is_some();
                let paused = inner
                    .running
                    .as_ref()
                    .is_some_and(|running| matches!(running.engine.status().state, EngineState::Paused));
                self.stop(&mut inner).await?;
                profile::save(&self.options.data_directory.join("profile.json"), &Some(profile.clone()))?;
                inner.profile = Some(profile);
                if running {
                    self.start(&mut inner, paused).await?;
                }
                self.publish_profile(&inner);
                return Ok(DriveResponse::MaxAutoDownloadMb(megabytes));
            }
            DriveRequest::Start => {
                self.start(&mut inner, false).await?;
                return Ok(DriveResponse::Snapshot(self.snapshot()));
            }
            DriveRequest::Stop => {
                self.stop(&mut inner).await?;
                return Ok(DriveResponse::Snapshot(self.snapshot()));
            }
            DriveRequest::Logout => {
                inner.generation += 1;
                self.stop(&mut inner).await?;
                profile::save(&self.options.data_directory.join("profile.json"), &None)?;
                inner.profile = None;
                inner.comment_owners.clear();
                self.comment_files.send_replace(Vec::new());
                self.publish_profile(&inner);
                return Ok(DriveResponse::Snapshot(self.snapshot()));
            }
            _ => {}
        }
        let running = inner.running.as_ref().ok_or("Drive is not running")?;
        if !self.snapshot().running {
            return Err("Drive worker stopped; restart Drive or sign out after revocation".into());
        }
        let _gate = interruptible(&mut shutdown, running.gate.lock()).await?;
        let wake = matches!(
            &request,
            DriveRequest::Pin { .. }
                | DriveRequest::ConfirmDeletes { .. }
                | DriveRequest::RetryUploads
                | DriveRequest::RetryUpload { .. }
                | DriveRequest::SyncProject { .. }
                | DriveRequest::Reconcile { .. }
                | DriveRequest::SyncAllPersonal { .. }
                | DriveRequest::Pause { paused: false }
        );
        let engine = &running.engine;
        let response = interruptible(&mut shutdown, execute_engine(engine, request)).await?;
        if let Err(error) = &response {
            let message = error.replace(engine.client().token(), "[redacted]");
            self.projection.lock().expect("Drive projection poisoned").emit(Payload::Error(message.clone()));
            return Err(message);
        }
        if wake {
            running.wake.send(()).map_err(|_| "Drive worker stopped")?;
        }
        let mut state = self.projection.lock().expect("Drive projection poisoned");
        if let Ok(DriveResponse::File(Some(file))) = &response {
            state.emit(Payload::File(file.clone()));
        }
        state.snapshot.roots = engine.roots().map_err(|error| error.to_string())?;
        state.snapshot.pending_deletes = engine.pending_deletes();
        state.emit(Payload::Reconcile);
        response
    }
}

async fn execute_engine(engine: &Engine, request: DriveRequest) -> Result<DriveResponse, String> {
    macro_rules! run {
        ($expression:expr) => {
            $expression.map_err(|error| error.to_string())?
        };
    }
    Ok(match request {
        DriveRequest::FileRemoteId { path } => DriveResponse::Id(run!(engine.remote_file_id(Path::new(&path)))),
        DriveRequest::CloudFolders { project_id } => {
            DriveResponse::CloudFolders(run!(engine.cloud_folders(&project_id).await))
        }
        DriveRequest::RetryUpload { project_id, path } => {
            DriveResponse::Count(run!(engine.retry_failed_upload(&project_id, &path)))
        }
        DriveRequest::CommentContext { path } => {
            let context = if let Some(file_id) = run!(engine.remote_file_id(Path::new(&path))) {
                let current_user_id =
                    run!(engine.client().me().await).id.ok_or("Drive server did not identify the account")?;
                let is_owner =
                    run!(engine.client().file_access(&file_id).await).owner_id.as_ref() == Some(&current_user_id);
                Some(CommentContext { file_id, current_user_id, is_owner })
            } else {
                None
            };
            DriveResponse::CommentContext(context)
        }
        DriveRequest::Comments { file_id } => DriveResponse::Comments(run!(engine.client().comments(&file_id).await)),
        DriveRequest::CommentCreate { file_id, request } => {
            DriveResponse::Comment(run!(engine.client().create_comment(&file_id, &request).await))
        }
        DriveRequest::CommentUpdate { comment_id, body } => {
            run!(engine.client().update_comment(&comment_id, &body).await);
            DriveResponse::Done
        }
        DriveRequest::CommentDelete { comment_id } => {
            run!(engine.client().delete_comment(&comment_id).await);
            DriveResponse::Done
        }
        DriveRequest::CommentApply { comment_id } => {
            DriveResponse::Comment(run!(engine.client().apply_comment(&comment_id).await))
        }
        DriveRequest::CondensePreflight { project_id, scope_path } => {
            DriveResponse::Unsynced(run!(engine.settle_before_condense(&project_id, scope_path.as_deref()).await))
        }
        DriveRequest::CondenseStart { project_id, scope_path } => {
            DriveResponse::Job(run!(engine.start_condense(&project_id, scope_path.as_deref()).await))
        }
        DriveRequest::Job { job_id } => DriveResponse::Job(run!(engine.job(&job_id).await)),
        DriveRequest::ProposedCondense { project_id } => {
            DriveResponse::Jobs(run!(engine.proposed_condense(&project_id).await))
        }
        DriveRequest::ApproveJob { job_id } => {
            run!(engine.approve_job(&job_id).await);
            DriveResponse::Done
        }
        DriveRequest::CancelJob { job_id } => {
            run!(engine.cancel_job(&job_id).await);
            DriveResponse::Done
        }
        DriveRequest::SkillMirrors => DriveResponse::SkillMirrors(run!(engine.skill_mirrors())),
        DriveRequest::ArchiveStatus => DriveResponse::ArchiveStatus(engine.archive_status()),
        DriveRequest::SyncProject { project_id } => {
            engine.prioritize(&project_id);
            DriveResponse::Done
        }
        DriveRequest::KnowledgeContext { cwd } => {
            let cwd = canonical_target(Path::new(&cwd))?;
            let project = run!(engine.roots())
                .into_iter()
                .filter(|r| cwd.starts_with(&r.local_path))
                .max_by_key(|r| r.local_path.len());
            let text = if let Some(project) = project {
                let project_dir = Path::new(&project.local_path);
                let readme = [project_dir.join("README.md"), cwd.join("README.md")]
                    .into_iter()
                    .find(|p| p.is_file())
                    .map(std::fs::read_to_string)
                    .transpose()
                    .map_err(|e| e.to_string())?;
                let fallback = project_dir.file_name().unwrap_or_default().to_string_lossy();
                let keywords = drive_sync::knowledge::extract_keywords(readme.as_deref(), &fallback);
                if keywords.is_empty() {
                    None
                } else {
                    let hits = run!(engine.client().ai_search(&keywords.join(" "), Some("KNOWLEDGE"), 5).await);
                    drive_sync::knowledge::build_prompt(&keywords, &hits, engine.client().base_url())
                }
            } else {
                None
            };
            DriveResponse::Text(text)
        }
        DriveRequest::Pause { paused } => {
            if paused {
                engine.pause();
            } else {
                engine.resume();
            }
            DriveResponse::Done
        }
        DriveRequest::Sync => {
            run!(engine.sync_once().await);
            DriveResponse::Done
        }
        DriveRequest::Roots => DriveResponse::Roots(run!(engine.refresh_roots().await)),
        DriveRequest::Pin { project_id, pinned } => {
            run!(engine.pin_root(&project_id, pinned));
            DriveResponse::Done
        }
        DriveRequest::Land { project_id } => {
            run!(engine.pin_root(&project_id, true));
            engine.prioritize(&project_id);
            run!(engine.sync_once().await);
            let root = run!(engine.roots())
                .into_iter()
                .find(|root| root.project_id == project_id)
                .ok_or("Project is not available")?;
            if !Path::new(&root.local_path).is_dir() {
                return Err("Project has not landed; inspect synchronization errors".into());
            }
            DriveResponse::Root(root)
        }
        DriveRequest::File { path } => DriveResponse::File(run!(engine.file_state(Path::new(&path)))),
        DriveRequest::Download { project_id, path } => {
            run!(engine.download_on_demand(&project_id, &path).await);
            DriveResponse::Done
        }
        DriveRequest::ConfirmDeletes { project_id } => {
            engine.confirm_deletes(&project_id);
            DriveResponse::Done
        }
        DriveRequest::CancelDeletes { project_id } => {
            run!(engine.cancel_deletes(&project_id).await);
            DriveResponse::Done
        }
        DriveRequest::Templates => DriveResponse::Templates(run!(engine.client().project_templates().await)),
        DriveRequest::Departments => DriveResponse::Departments(run!(engine.client().departments(true).await)),
        DriveRequest::CreateProject { request } => {
            let created = run!(engine.client().create_project_from_template(&request).await);
            run!(engine.refresh_roots().await);
            run!(engine.pin_root(&created.id, true));
            engine.prioritize(&created.id);
            run!(engine.sync_once().await);
            DriveResponse::Root(
                run!(engine.roots())
                    .into_iter()
                    .find(|root| root.project_id == created.id)
                    .ok_or("Created project missing from Drive roots")?,
            )
        }
        DriveRequest::Shared => DriveResponse::Shared(run!(engine.shared_with_me().await)),
        DriveRequest::FailedUploads => DriveResponse::FailedUploads(run!(engine.failed_uploads())),
        DriveRequest::RetryUploads => {
            run!(engine.retry_failed_uploads());
            DriveResponse::Done
        }
        DriveRequest::Reconcile { project_id } => {
            run!(engine.reconcile(project_id.as_ref()));
            DriveResponse::Done
        }
        DriveRequest::RecheckCloudOnly => {
            run!(engine.recheck_cloud_only().await);
            DriveResponse::Done
        }
        DriveRequest::DiskUsage { limit } => DriveResponse::DiskUsage(run!(engine.disk_usage(limit))),
        DriveRequest::CleanupScan => DriveResponse::Cleanup(run!(engine.cleanup_scan())),
        DriveRequest::Cleanup { mut paths } => {
            let mut current: Vec<String> =
                run!(engine.cleanup_scan()).candidates.into_iter().map(|entry| entry.local_path).collect();
            paths.sort();
            current.sort();
            if paths != current {
                return Err("Cleanup candidates changed; review the new list before continuing".into());
            }
            DriveResponse::Cleanup(run!(engine.cleanup_unselected()))
        }
        DriveRequest::OwnershipGuard => DriveResponse::OwnershipGuard(run!(engine.ownership_guard())),
        DriveRequest::SyncAllPersonal { enabled } => {
            run!(engine.set_sync_all_personal(enabled));
            DriveResponse::Done
        }
        DriveRequest::GrantTarget { path } => {
            DriveResponse::GrantTarget(run!(engine.grant_target(Path::new(&path)).await))
        }
        DriveRequest::Grants { target } => DriveResponse::Grants(run!(engine.client().grants(&target).await)),
        DriveRequest::SetGrant { target, request } => {
            DriveResponse::GrantWrite(run!(engine.client().set_grant(&target, &request).await))
        }
        DriveRequest::RemoveGrant { target, subject_type, subject_id } => {
            DriveResponse::GrantWrite(run!(engine.client().remove_grant(&target, &subject_type, &subject_id).await))
        }
        DriveRequest::SearchUsers { query } => {
            DriveResponse::Users(run!(engine.client().search_users(&query, 20).await))
        }
        DriveRequest::SearchDepartments { query } => {
            DriveResponse::Departments(run!(engine.client().search_departments(&query).await))
        }
        DriveRequest::RequestAccess { request_type, target_id, message } => {
            let kind = match request_type {
                AccessRequestType::FileAccess => "FILE_ACCESS",
                AccessRequestType::ProjectJoin => "PROJECT_JOIN",
            };
            let mut query = vec![("type", kind.to_owned()), ("targetId", target_id.as_key())];
            if let Some(message) = message.filter(|value| !value.trim().is_empty()) {
                query.push(("message", message));
            }
            let response = reqwest::Client::new()
                .post(format!("{}/api/v1/access-requests", engine.client().base_url()))
                .timeout(Duration::from_secs(30))
                .bearer_auth(engine.client().token())
                .query(&query)
                .send()
                .await
                .map_err(|error| error.to_string())?;
            let status = response.status();
            let body: serde_json::Value =
                response.json().await.map_err(|error| format!("Invalid access request response: {error}"))?;
            if status.as_u16() == 400
                && body.get("code").and_then(|value| value.as_str()) == Some("REQUEST_ALREADY_PENDING")
            {
                DriveResponse::AccessRequest(AccessRequestOutcome::AlreadyPending)
            } else if status.is_success() && body.get("success").and_then(|value| value.as_bool()) == Some(true) {
                DriveResponse::AccessRequest(AccessRequestOutcome::Submitted)
            } else {
                return Err(body
                    .get("message")
                    .and_then(|value| value.as_str())
                    .map(str::to_owned)
                    .unwrap_or_else(|| format!("Access request failed: HTTP {status}")));
            }
        }
        DriveRequest::SaveVersion { path } => DriveResponse::Id(run!(engine.save_content(Path::new(&path)).await)),
        DriveRequest::LocalPath { file_id } => DriveResponse::Path(run!(engine.local_path_of_remote_file(&file_id))),
        _ => return Err("Request must be handled by the Drive lifecycle service".into()),
    })
}

fn check_writable(engine: &Engine, path: &Path) -> Result<(), String> {
    if path.extension().is_some_and(|extension| extension == "yupcloud") {
        return Err("Download the cloud placeholder before modifying it".into());
    }
    if let Some((_, file)) = engine.file_row(path).map_err(|error| error.to_string())?
        && (file.read_only || file.collab_active)
    {
        return Err("This file is read-only or being collaboratively edited".into());
    }
    if path.is_dir() {
        for entry in std::fs::read_dir(path).map_err(|error| error.to_string())? {
            let entry = entry.map_err(|error| error.to_string())?;
            if entry.file_type().map_err(|error| error.to_string())?.is_symlink() {
                return Err("Symbolic links are not supported in Drive mutations".into());
            }
            check_writable(engine, &entry.path())?;
        }
    }
    Ok(())
}

fn collab_server_url(raw: &str) -> Option<String> {
    let raw = raw.trim().trim_end_matches('/');
    let (scheme, rest) = match raw.split_once("://") {
        Some(("http" | "ws", rest)) => ("ws", rest),
        Some(("https" | "wss", rest)) => ("wss", rest),
        Some(_) => return None,
        None => ("wss", raw),
    };
    let base = rest.strip_suffix("/collab").unwrap_or(rest).trim_end_matches('/');
    if base.is_empty() {
        return None;
    }
    let parsed = url::Url::parse(&format!("{scheme}://{base}/collab")).ok()?;
    if parsed.host_str().is_none()
        || !parsed.username().is_empty()
        || parsed.password().is_some()
        || parsed.query().is_some()
        || parsed.fragment().is_some()
    {
        return None;
    }
    Some(parsed.to_string())
}

fn validate_archive_session_id(session_id: &str) -> Result<(), String> {
    if session_id.is_empty() || session_id.len() > 512 || session_id.chars().any(char::is_control) {
        return Err("Invalid session id".into());
    }
    Ok(())
}

/// Privacy follows the Codex session across account and root changes. No conversation is stored.
#[derive(Default, Serialize, Deserialize)]
struct ArchivePrivacy {
    session_ids: HashSet<String>,
}

impl ArchivePrivacy {
    fn load(path: &Path) -> Result<Self, String> {
        match std::fs::read(path) {
            Ok(bytes) => serde_json::from_slice(&bytes).map_err(|e| e.to_string()),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(Self::default()),
            Err(error) => Err(error.to_string()),
        }
    }
    fn save(&self, path: &Path) -> Result<(), String> {
        let parent = path.parent().ok_or("Archive privacy metadata has no parent")?;
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        let mut file = tempfile::NamedTempFile::new_in(parent).map_err(|e| e.to_string())?;
        file.write_all(&serde_json::to_vec(self).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
        file.as_file().sync_all().map_err(|e| e.to_string())?;
        file.persist(path).map_err(|e| e.to_string())?;
        Ok(())
    }
}

#[derive(Default, Serialize, Deserialize)]
struct ArchiveManifest {
    hashes: HashMap<String, String>,
    last_run_at: Option<String>,
    last_upload_at: Option<String>,
    last_error: Option<String>,
    last_uploaded: u32,
}

impl ArchiveManifest {
    fn load(path: &Path) -> Result<Self, String> {
        match std::fs::read(path) {
            Ok(bytes) => serde_json::from_slice(&bytes).map_err(|e| e.to_string()),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(Self::default()),
            Err(error) => Err(error.to_string()),
        }
    }
    fn save(&self, path: &Path) -> Result<(), String> {
        let parent = path.parent().ok_or("Archive manifest has no parent")?;
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        let mut file = tempfile::NamedTempFile::new_in(parent).map_err(|e| e.to_string())?;
        file.write_all(&serde_json::to_vec(self).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
        file.as_file().sync_all().map_err(|e| e.to_string())?;
        file.persist(path).map_err(|e| e.to_string())?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn relay_urls_normalize_once_and_reject_credentials() {
        assert_eq!(collab_server_url("https://example.com/collab/"), Some("wss://example.com/collab".into()));
        assert_eq!(collab_server_url("ws://localhost:1234"), Some("ws://localhost:1234/collab".into()));
        assert_eq!(collab_server_url("ftp://example.com"), None);
        assert_eq!(collab_server_url("wss://secret@example.com"), None);
        assert_eq!(collab_server_url(""), None);
    }

    #[tokio::test]
    async fn comment_subscriptions_are_owned_independently() {
        let directory = tempfile::tempdir().unwrap();
        let service = DriveService::new(ServiceOptions {
            data_directory: directory.path().join("data"),
            ownership_directory: directory.path().join("owners"),
            default_root: directory.path().join("files"),
            reserved_roots: vec![],
            device_name: "test".into(),
            client_version: "test".into(),
            open_url: Arc::new(|_| Err("No browser in tests".into())),
        })
        .unwrap();
        for owner in ["first", "second"] {
            service
                .execute(DriveRequest::CommentWatch { owner_id: owner.into(), file_ids: vec![RemoteId::Number(1)] })
                .await
                .unwrap();
        }
        assert_eq!(service.comment_files.borrow().len(), 1);
        service.execute(DriveRequest::CommentWatch { owner_id: "first".into(), file_ids: vec![] }).await.unwrap();
        assert_eq!(*service.comment_files.borrow(), vec![RemoteId::Number(1)]);
        service.execute(DriveRequest::CommentWatch { owner_id: "second".into(), file_ids: vec![] }).await.unwrap();
        assert!(service.comment_files.borrow().is_empty());
    }
}

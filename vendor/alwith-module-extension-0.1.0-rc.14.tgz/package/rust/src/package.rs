use crate::{Manifest, ServiceError, call};
use std::path::Path;
pub(crate) struct Package {
    pub manifest: Manifest,
}
pub(crate) fn read(root: &Path) -> Result<Package, ServiceError> {
    Ok(Package { manifest: call("extension.package_manifest", serde_json::json!({"root":root}))? })
}

use alwith_native_client::Handle;
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::path::{Path, PathBuf};
pub const MAX_BYTES: usize = 64 * 1024 * 1024;

#[derive(Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum FileOperation {
    Read,
    Write,
    Mkdir,
    Remove,
    List,
    Stat,
}

#[derive(Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct FileRequest {
    pub operation: FileOperation,
    pub scope: Option<String>,
    pub path: String,
    pub body: Option<Vec<u8>>,
    #[serde(default)]
    pub recursive: bool,
}

#[derive(Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FileEntry {
    pub name: String,
    pub is_file: bool,
    pub is_directory: bool,
}

#[derive(Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "camelCase", rename_all_fields = "camelCase")]
pub enum FileResponse {
    Read { body: Vec<u8> },
    List { entries: Vec<FileEntry> },
    Stat { exists: bool, size: u64, mtime: Option<u64>, is_file: bool, is_directory: bool },
    Ok,
}

pub struct Directory(Handle);
#[derive(Debug, Deserialize)]
pub struct Metadata {
    is_dir: bool,
    is_file: bool,
    len: u64,
}
impl Metadata {
    pub fn is_dir(&self) -> bool {
        self.is_dir
    }
    pub fn is_file(&self) -> bool {
        self.is_file
    }
    pub fn len(&self) -> u64 {
        self.len
    }
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }
}
impl Directory {
    fn call<T: serde::de::DeserializeOwned>(&self, method: &str, path: &Path) -> std::io::Result<T> {
        // Native paths must return to the portable relative-path wire format on Windows.
        let path = wire_path(path)?;
        let value = self.0.call_value(method, json!({"path":path})).map_err(|error| {
            let kind = match error["code"].as_str() {
                Some("NotFound") => std::io::ErrorKind::NotFound,
                Some("AlreadyExists") => std::io::ErrorKind::AlreadyExists,
                Some("PermissionDenied") => std::io::ErrorKind::PermissionDenied,
                _ => std::io::ErrorKind::Other,
            };
            std::io::Error::new(kind, error.to_string())
        })?;
        serde_json::from_value(value).map_err(std::io::Error::other)
    }
    pub fn metadata(&self, path: impl AsRef<Path>) -> std::io::Result<Metadata> {
        self.call("scope_metadata", path.as_ref())
    }
    pub fn create_dir_all(&self, path: impl AsRef<Path>) -> std::io::Result<()> {
        self.call("scope_create_dir_all", path.as_ref())
    }
    pub fn try_exists(&self, path: impl AsRef<Path>) -> std::io::Result<bool> {
        self.call("scope_try_exists", path.as_ref())
    }
}
fn wire_path(path: &Path) -> std::io::Result<String> {
    let value = path
        .to_str()
        .ok_or_else(|| std::io::Error::new(std::io::ErrorKind::InvalidInput, "Extension paths must be UTF-8"))?;
    #[cfg(windows)]
    let value = value.replace('\\', "/");
    Ok(value.to_owned())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn native_relative_paths_use_portable_separators() {
        let path = Path::new("legacy-extension-files").join("yup-kb");
        assert_eq!(wire_path(&path).unwrap(), "legacy-extension-files/yup-kb");
        assert_eq!(wire_path(Path::new("../outside")).unwrap(), "../outside");
    }

    #[test]
    #[ignore = "requires ALWITH_NATIVE_DIRECTORY with the packaged extension library"]
    fn scoped_path_round_trips_through_native_library() {
        let root = tempfile::tempdir().unwrap();
        let root = root.path().canonicalize().unwrap();
        let directory = open_scope(&root).unwrap();
        let path = scoped_path(&directory, "legacy-extension-files/yup-kb").unwrap();
        assert!(!directory.try_exists(&path).unwrap());
        directory.create_dir_all(&path).unwrap();
        assert!(directory.metadata(&path).unwrap().is_dir());
        assert!(directory.try_exists(&path).unwrap());
        assert!(scoped_path(&directory, "../outside").is_err());
        assert!(scoped_path(&directory, "C:/outside").is_err());
    }
}
pub fn open_scope(root: &Path) -> Result<Directory, String> {
    Ok(Directory(Handle::open_with_close("extension", "scope_close", json!({"kind":"scope","root":root}))?))
}
pub fn scoped_path(directory: &Directory, value: &str) -> Result<PathBuf, String> {
    directory.0.call("scope_path", json!({"path":value}))
}
pub fn read_scoped(root: &Path, path: &str) -> Result<Vec<u8>, String> {
    crate::call("extension.read_scoped", json!({"root":root,"path":path})).map_err(|e| e.to_string())
}
pub fn perform_file(root: &Path, request: FileRequest) -> Result<FileResponse, String> {
    crate::call("extension.file", json!({"root":root,"request":request})).map_err(|e| e.to_string())
}

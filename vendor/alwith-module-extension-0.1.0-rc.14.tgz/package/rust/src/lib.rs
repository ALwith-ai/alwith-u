//! Public extension contracts, native transport and host authorization integration.
pub mod protocol;
pub use protocol::*;
pub mod filesystem;
#[cfg(feature = "native-http")]
pub mod http;
#[cfg(feature = "tauri")]
mod package;
#[cfg(feature = "tauri")]
pub mod plugin;
pub type PackageFiles = std::collections::BTreeMap<String, Vec<u8>>;
use alwith_native_client::{Handle, Library};
use serde::{Serialize, de::DeserializeOwned};
use serde_json::{Value, json};
use std::path::Path;
pub(crate) fn error(code: impl Into<String>, message: impl Into<String>) -> ServiceError {
    ServiceError { code: code.into(), message: message.into() }
}
fn decode<T: DeserializeOwned>(result: Result<Value, Value>) -> Result<T, ServiceError> {
    let value = result.map_err(|value| match serde_json::from_value::<ServiceError>(value.clone()) {
        Ok(error) => error,
        Err(_) => error("native", value.to_string()),
    })?;
    serde_json::from_value(value).map_err(Into::into)
}
pub(crate) fn call<T: DeserializeOwned>(method: &str, params: impl Serialize) -> Result<T, ServiceError> {
    let library = Library::module("extension").map_err(|e| error("native", e))?;
    decode(library.call_value(method, serde_json::to_value(params)?))
}
pub fn validate_manifest(manifest: &Manifest) -> Result<(), ServiceError> {
    call("extension.validate_manifest", json!({"manifest":manifest}))
}
pub struct Service(Handle);
impl Service {
    pub fn open(root: impl AsRef<Path>) -> Result<Self, ServiceError> {
        Ok(Self(Handle::open("extension", json!({"root":root.as_ref()})).map_err(|e| error("native", e))?))
    }
    fn call<T: DeserializeOwned>(&self, method: &str, params: Value) -> Result<T, ServiceError> {
        decode(self.0.call_value(method, params))
    }
    pub fn snapshot(&self) -> Snapshot {
        self.call("snapshot", json!({})).expect("Native extension snapshot failed")
    }
    pub fn require_uninstalled(&self, id: &str) -> Result<(), ServiceError> {
        self.call("require_uninstalled", json!({"extension_id":id}))
    }
    pub fn purge(&mut self, id: &str) -> Result<(), ServiceError> {
        self.call("purge", json!({"extension_id":id}))
    }
    pub fn dispatch(&mut self, window: &str, request: Request) -> Result<Response, ServiceError> {
        self.call("dispatch", json!({"window":window,"request":request}))
    }
    pub fn installed_package(&self, id: &str, source: &str) -> Result<(Installation, PackageFiles), ServiceError> {
        self.call("installed_package", json!({"extension_id":id,"source":source}))
    }
    pub fn capture_window_instances(&self, window: &str) -> Vec<String> {
        self.call("capture_window_instances", json!({"window":window})).expect("Native extension instances failed")
    }
    pub fn complete_window_navigation(&mut self, window: &str, tokens: &[String]) -> Result<(), ServiceError> {
        self.call("complete_window_navigation", json!({"window":window,"tokens":tokens}))
    }
    pub fn close_window(&mut self, window: &str) -> Result<(), ServiceError> {
        self.call("close_window", json!({"window":window}))
    }
    pub fn resource_for_window(
        &self, window: &str, token: &str, path: &str,
    ) -> Result<(Vec<u8>, String), ServiceError> {
        self.call("resource_for_window", json!({"window":window,"token":token,"path":path}))
    }
}

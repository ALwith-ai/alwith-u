use serde::{Deserialize, Serialize};
use serde_json::json;
use std::collections::BTreeMap;
use url::Url;
pub const MAX_HTTP_BYTES: usize = 64 * 1024 * 1024;

#[derive(Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct HttpRequest {
    pub url: String,
    pub method: Option<String>,
    #[serde(default)]
    pub headers: BTreeMap<String, String>,
    pub body: Option<Vec<u8>>,
}

#[derive(Serialize, Deserialize)]
pub struct HttpResponse {
    pub status: u16,
    pub url: String,
    pub headers: BTreeMap<String, String>,
    pub body: Vec<u8>,
}

pub async fn execute(
    mut request: HttpRequest, validate_url: impl FnOnce(&str) -> Result<Url, String>,
) -> Result<HttpResponse, String> {
    request.url = validate_url(&request.url)?.into();
    tokio::task::spawn_blocking(move || {
        crate::call("extension.http", json!({"request":request})).map_err(|e| e.to_string())
    })
    .await
    .map_err(|e| e.to_string())?
}

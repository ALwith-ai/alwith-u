# @alwith/module-auth

TypeScript side of the alwith-auth capability, colocated with its separately licensed Rust crate.

Owns the existing Desktop auth types, password rule, OAuth PKCE/in-flight verifier,
error-key mapping, request contracts, state lifecycle and token-storage operations. The host supplies its existing
store; authStoreName preserves the auth.<API host> namespace. Tokens remain in
the same store with the same keys. Logout preserves device_id.

This does not move credentials to Rust, replace HTTP, render a login page,
or implement cross-device account synchronization. The framework-neutral state
factory keeps Desktop's existing restoration, login, logout and window-event
semantics; the host supplies storage, HTTP, event transport and product effects.
Desktop still owns native OAuth callbacks, windows, provider loading and analytics.
U consumes the shared package; OAuth callbacks remain host-specific.

## License and redistribution

See [LICENSE](LICENSE) and [third-party notices](THIRD_PARTY_NOTICES.md).
ALwith-owned code is proprietary, not open source. You may build, customize, host,
charge for and distribute your own applications under the included
license, without per-application registration. This does not grant hosted-service
access or rights to separately distributed Rust libraries or Runtime binaries.
The npm artifact includes compiled/minified JS, declarations and necessary assets,
not the private TS/TSX implementation or source maps. Minification is not encryption.

## Pet assets

`@alwith/module-auth/pets` is a framework-independent account asset service. Inject authenticated requests, account identity and revision, storage, binary resource IO, and cancellable downloads. It exposes the existing catalog, album, draw, first-visit, points, selection and cache contracts. Selection is local and ownership is verified against the service. Resource caches preserve the existing catalog and legacy account directories, `config.json`, sheet names, and resource versions. Persisted album snapshots only support offline presentation; they do not authorize new draws or change server ownership.

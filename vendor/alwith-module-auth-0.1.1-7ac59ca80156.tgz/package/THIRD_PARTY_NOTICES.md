# Third-party notices — @alwith/module-auth

ALwith's proprietary license applies only to its own material. Third-party
material retains its original license and rights; the package license does not
replace or restrict those rights. Preserve applicable notices when redistributing.

## External direct dependencies and peers

These are external imports, not bundled dependency implementations in this npm
artifact. Versions below record the local release-preparation inventory; declared
ranges can resolve to different versions. Keep the notices from the versions
actually distributed by your application, including transitive dependencies.

| Package | Inspected version | License | Included license copy |
| --- | --- | --- | --- |

No external direct runtime dependencies or peers are declared in this package.

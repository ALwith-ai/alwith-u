# Vibemon

Private, shared pet capability for desktop hosts. The JavaScript package contains the existing asset UI, sprite renderer, animation engine, bubble state, and presentation handshake. Hosts inject account assets, storage, session observations, and window actions through `VibemonHost`.

`@alwith/module-auth/pets` owns the account API contract, catalog, album, draws, selection, and compatible local resource cache. A pet selection is local to an application and account; the API remains the authority for ownership. Draw requests are never retried after an uncertain response.

The Rust crate supplies native overlay policy through C ABI v1 in `@alwith/native`: macOS panel conversion, Space/wake repair, IME candidate ownership, Windows inactive positioning and dragging, and request deduplication. It has no Runtime, ACP, Tauri, or conversation-store dependency.

A host must execute chat actions in its existing session owner. Replies carry the complete binding, original permission token, and a unique request id. Runtime snapshots establish a baseline; only live transitions trigger completion animation. A prompt response acknowledges acceptance; Runtime state supplies completion.

The asset window is persistent and hides on close. The pet overlay is presented only after positioning and a decoded canvas frame. A warm presentation requires a new frame before acknowledging the handoff. Closing a pet plays the existing burst sequence before the host persists the disabled state and destroys its overlays.

Resource synchronization runs in the main host. Auxiliary asset windows delegate it, and receive its status. Successful pack replacements reload an open pet; an enabled missing overlay is restored after synchronization when its conversation surface is hidden. Reload generations reject frames from the previous resource.

## Distribution

Build the auth package before this package. `bun run build` emits minified modules and declarations without implementation source or source maps. `bun pm pack` carries the visual assets and existing distribution notices. Components reference images and videos through package-relative URL imports; CSS uses relative font and sprite URLs. A host's Vite build resolves these assets into its output, including hashed filenames and its configured base path. Import `@alwith/module-vibemon/styles.css` once in the host's stylesheet. No public-directory copy or staging command is required. Videos remain separate files.

Build `@alwith/native` with `bun scripts/build-native.ts <target>` in the modules repository. Each target artifact must be packaged with the exact wrapper version and a verified checksum. Do not substitute a previous binary: C ABI v1 is stable, but the pet methods require the new capability. Windows artifacts must be built on a Windows release runner before a Windows application can be packaged.

## Validation

`bun test crates/auth/guest-js/src/pets crates/vibemon/guest-js/src/lib` uses simulated services and consumes no real draws or points. Native tests operate on request claims and invalid requests; real window, multi-monitor, Space, wake, and IME behavior also require host application testing.

### Host window icons

`configureVibemon` accepts optional `sessionIcons: { main: string, chat: string }`
containing trusted SVG markup. Quick reply uses these icons for the session
selector and open-window action. Pass the same mapping to
`sessionIconSvg(windowLabel, sessionIcons)` when constructing a native menu.
Omitting the mapping preserves the package's default icons.
